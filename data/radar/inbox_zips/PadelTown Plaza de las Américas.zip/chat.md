# Exportación de chat de WhatsApp: PadelTown Plaza de las Américas 🎾
Fecha de exportación: 9 de septiembre de 2026 a las 16:19

---

## 16 de julio de 2026

[17:03] __@StivenAJDesign creó el grupo__

---

## 2 de septiembre de 2026

[13:43] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[13:43] __[Notificación del sistema]__

[14:21] __+57 314 3934968 se unieron mediante el enlace de invitación__

[15:36] __@DanielaAbby16 se unieron mediante el enlace de invitación__

[18:28] __+57 310 2847472 añadió a +57 301 4090550__

[19:25] **@_Capi_00:** 🌟 AMERICANO  FEMENINO C PAREJAS FIJAS (6ta) 🌟
 

📅 Jueves 3 de septiembre
⏰ 7:30 a 9:30 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $120.000  por pareja 
🟠 Miembros Orange: $96.000 x pareja
⚫ Miembros Black: $84.000 x pareja

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 2 Kits padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 2 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Daniela V / Katalina N
🎾 
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[22:18] __@EfraJunior se unieron mediante el enlace de invitación__

---

## 3 de septiembre de 2026

[7:21] __+57 320 9994854 se unieron mediante el enlace de invitación__

[8:01] **+57 310 2847472:** 🌟 AMERICANO  FEMENINO C PAREJAS FIJAS (6ta) 🌟
 

📅 Jueves 3 de septiembre
⏰ 7:30 a 9:30 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $120.000  por pareja 
🟠 Miembros Orange: $96.000 x pareja
⚫ Miembros Black: $84.000 x pareja

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 2 Kits padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 2 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Daniela V / Katalina N
🎾 Lina/ Mariana 
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[8:31] **+57 315 4783744:** 🌟 AMERICANO  FEMENINO C PAREJAS FIJAS (6ta) 🌟
 

📅 Jueves 3 de septiembre
⏰ 7:30 a 9:30 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $120.000  por pareja 
🟠 Miembros Orange: $96.000 x pareja
⚫ Miembros Black: $84.000 x pareja

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 2 Kits padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 2 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Daniela V / Katalina N
🎾 Lina/ Mariana 
🎾Stefanie / Vanessa 
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[10:25] **@_Capi_00:** 🌟 AMERICANO  FEMENINO C PAREJAS FIJAS (6ta) 🌟
 

📅 Jueves 3 de septiembre
⏰ 7:30 a 9:30 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $120.000  por pareja 
🟠 Miembros Orange: $96.000 x pareja
⚫ Miembros Black: $84.000 x pareja

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 2 Kits padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 2 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Daniela V / Katalina N
🎾 Lina/ Mariana 
🎾Stefanie / Vanessa 
🎾Camila S / Paula R
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[11:18] **+57 310 2847472:** 🌟 AMERICANO  FEMENINO C PAREJAS FIJAS (6ta) 🌟
 

📅 Jueves 3 de septiembre
⏰ 7:30 a 9:30 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $120.000  por pareja 
🟠 Miembros Orange: $96.000 x pareja
⚫ Miembros Black: $84.000 x pareja

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 2 Kits padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 2 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Daniela V / Katalina N
🎾 Lina/ Mariana 
🎾Stefanie / Vanessa 
🎾Camila S / Paula R
🎾Mónica B/ Sara Sofia R
🎾

¡Nos vemos en la cancha! 🙌🏻

[17:24] **@_Capi_00:** Buenas tardes,
Queda cancelado el torneo de hoy, las esperamos en una proxima ocasión.

[21:33] **@_Capi_00:** 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾
🎾
🎾



NOS VEMOS EN LA CANCHA 💪🏼🎾

---

## 4 de septiembre de 2026

[7:56] **+57 300 7914052:**
> _@_Capi_00: 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾
🎾
🎾



NOS VEMOS EN LA CANCHA 💪🏼🎾_
David M y Oscar C

[8:04] **+57 316 0529219:**
> _+57 300 7914052: David M y Oscar C_
[Sticker]

[8:22] **@_Capi_00:** 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾 David M / Oscar C 
🎾
🎾



NOS VEMOS EN LA CANCHA 💪🏼🎾

[10:14] __+57 313 8789934 se unieron mediante el enlace de invitación__

[12:13] **+57 301 3148922:** 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾 David M / Oscar C 
🎾 Juan Pablo/reservado
🎾



NOS VEMOS EN LA CANCHA 💪🏼🎾

[14:05] __+57 311 2842505 se unieron mediante el enlace de invitación__

[14:58] **@_Capi_00:** 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾 David M / Oscar C 
🎾 Juan Pablo/reservado
🎾Juan O / Edwin M 



NOS VEMOS EN LA CANCHA 💪🏼🎾

[16:29] __+57 301 2241206 se unieron mediante el enlace de invitación__

[17:40] **+57 301 3148922:** 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾 David M / Oscar C 
🎾Juan O / Edwin M 



NOS VEMOS EN LA CANCHA 💪🏼🎾

[17:41] **+57 301 3148922:** Lo siento me toca bajarme no tengo partner para jugar gracias.

[17:42] **+57 312 3617282:** 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾 David M / Oscar C 
🎾Juan O / Edwin M 
🎾


NOS VEMOS EN LA CANCHA 💪🏼🎾

[17:54] __+57 301 3778864 se unieron mediante el enlace de invitación__

[18:23] **+57 301 8098458:** 🔥🏆  
AMERICANO PAREJA FIJA 5TA CATEGORÍA🏆🔥
🍕🍕
🗓️  VIERNES 4 de septiembre de 7:30 a 9:30 pm
📍 Padeltown américas

💰 Inscripción: $120 mil x  pareja 
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

Incluye: pelotas, organización y 1 pizza por pareja! 💪🎾🍕

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown   para la pareja
🥈 SUBCAMPEON 2 h de cancha GRATIS  para la pareja
🥉 TERCER PUESTO 2 bebidas bien frías  🍻
                                          

INSCRÍBETE YA 🥳🏃‍♂️

🎾 Cristian O / Felipe DC
🎾Daniel P/ Juan David 
🎾Daniel R / Jimmy 
🎾 Pablo / Santiago 
🎾 Cristian L / Marlon L
🎾 Simon / William
🎾 Diego R / Sebastian 
🎾 David M / Oscar C 
🎾Juan O / Edwin M 
🎾Juan C / Juan M 


NOS VEMOS EN LA CANCHA 💪🏼🎾

---

## 5 de septiembre de 2026

[7:48] **@_Capi_00:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  
🎾  
🎾  
🎾  

NOS VEMOS EN LA CANCHA 🎾💪🏻

[8:13] **+57 310 2847472:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  
🎾  

NOS VEMOS EN LA CANCHA 🎾💪🏻

[8:44] **+57 310 2847472:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  Javier / Busca Partner
🎾  

NOS VEMOS EN LA CANCHA 🎾💪🏻

[9:17] **@johanbohorque:**
> _+57 310 2847472: 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  Javier / Busca Partner
🎾  

NOS VEMOS EN LA CANCHA 🎾💪🏻_
Sebastián y Heiri buenos días

[9:18] **+57 310 2847472:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  Sebastián / Heiri
🎾  Javier / Busca Partner
🎾
🎾
🎾

NOS VEMOS EN LA CANCHA 🎾💪🏻

[9:42] **+57 324 6541941:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  Sebastián / Heiri
🎾  Javier / Busca Partner
🎾Karol Marín / Andrés Perdomo 
🎾
🎾

NOS VEMOS EN LA CANCHA 🎾💪🏻

[9:44] **+57 301 6402834:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  Sebastián / Heiri
🎾  Javier / Busca Partner
🎾Karol Marín / Andrés Perdomo 
🎾 José/Jessica
🎾

NOS VEMOS EN LA CANCHA 🎾💪🏻

[9:46] **+57 311 5319393:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  Sebastián / Heiri
🎾  Javier / Busca Partner
🎾Karol Marín / Andrés Perdomo 
🎾 José/Jessica
🎾 Esteban V / Alexandra 

NOS VEMOS EN LA CANCHA 🎾💪🏻

[9:58] **+57 310 2847472:** 🔥🏆  
 AMERICANO PAREJAS FIJAS mixto 6ta 🏆🔥

🗓️  SABADO 5 de septiembre de 6 a 8 pm  
📍 Padeltown plaza américas

💰 Inscripción: $120 mil x  pareja
🟠 MIEMBROS ORANGE: 96 mil x pareja - 20% OFF  
⚫ MIEMBROS BLACK: 84 mil x pareja - 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN $200.000 en Gift Card Padeltown  + 2 gatorlite
🥈 SUBCAMPEON 2h de cancha GRATIS  
🥉 TERCER PUESTO 2 bebidas bien frías🍻
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juanita / David Q 
🎾  Vanessa / Diego 
🎾  Camila s / Cristian L 
🎾  Maria Camila / Alfonso
🎾  Alex /Katherine
🎾  Brayan / Laura
🎾  Sebastián / Heiri
🎾  Javier / Busca Partner
🎾Karol Marín / Andrés Perdomo 
🎾 José/Jessica
🎾 Esteban V / Alexandra 

Torneo Cerrado
NOS VEMOS EN LA CANCHA 🎾💪🏻

[13:08] __@cristian_lopezr añadió a +57 313 8963256__

[22:02] **+57 301 6402834:** Pueden enviar porfs el enlace del tornero de hoy, gracias

[22:02] **+57 310 2847472:** Parejas Fijas Mixto: https://americanopadel.app/t/zvR0Z/

---

## 7 de septiembre de 2026

[10:50] __[Notificación del sistema]__

[14:55] __+57 310 2847472 añadió a +57 315 8562305__

[17:00] __+57 305 4229120 se unieron mediante el enlace de invitación__

[23:57] __+57 310 5899189 añadió a +57 301 5968337__

---

## 8 de septiembre de 2026

[12:12] __[Notificación del sistema]__

[12:13] **+57 318 4642929:** Hola grupo 
Alguno esta interesado en comprar una pala marca siux ?

[12:13] **+57 318 4642929:** [Imagen]

[12:13] **+57 318 4642929:** Por si le interesa 
Inbox

[12:13] **+57 318 4642929:** Buen precio

[16:04] __+57 311 4406851 se unieron mediante el enlace de invitación__

[16:18] __Andres Rodriguez Padel se unieron mediante el enlace de invitación__

[16:30] __[Notificación del sistema]__

[18:39] __@juanamado08 se unieron mediante el enlace de invitación__

[22:26] __@sandraraba08 se unieron mediante el enlace de invitación__

---

## 9 de septiembre de 2026

[9:03] **@_Capi_00:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾
🎾 
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[9:04] **+57 315 4783744:** Vanessa

[9:05] **@_Capi_00:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[9:14] **@Charlie0213:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[9:17] **@_Capi_00:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾Camila S
🎾Ana Saza 
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[9:20] **+57 313 4579150:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾Camila S
🎾Ana Saza 
🎾Lisa
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[9:29] **@paulariaba:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil para la pareja

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾Camila S
🎾Ana Saza 
🎾Lisa
🎾Paula Riaño
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[9:29] **@betico204:** Buenos días

[9:29] **@betico204:** Como hago para apartar una cancha ??

[9:29] **@_Capi_00:** Hola Alberto, buen día

[9:30] **@_Capi_00:** Ya te contactamos por interno! 🙌🏻

[9:30] **@betico204:** Hola profe como va

[9:30] **+57 310 2847472:**
> _@betico204: Como hago para apartar una cancha ??_
Buenos dias,
Ya te contactamos

[9:30] **@betico204:** [Sticker]

[9:31] **@_Capi_00:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil 

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾Camila S
🎾Ana Saza 
🎾Lisa
🎾Paula R 
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻

[12:32] **@_Capi_00:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil 

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾Camila S
🎾Ana Saza 
🎾Lisa
🎾Paula R 
🎾Monica Botello
🎾

¡Nos vemos en la cancha! 🙌🏻

[13:36] **@TatianaMH08:** Tatiana 🙋🏽‍♀️

[13:43] **+57 310 2847472:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil 

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾Camila S
🎾Ana Saza 
🎾Lisa
🎾Paula R 
🎾Monica Botello
🎾Tatiana
🎾
🎾
🎾
🎾 

¡Nos vemos en la cancha! 🙌🏻

[13:48] **+57 310 2847472:** 🌟 AMERICANO SENCILLO FEMENINO C  (6ta) 🌟
 

📅 Jueves 10 de septiembre
⏰ 7:30 a 10 p.m.
🎾 Sede plaza de las Américas

💸 Inscripción: $60.000 x persona
🟠 Miembros Orange: $48.000 x persona
⚫ Miembros Black: $42.000 x persona

🏆 Categoría: Femenino C

🎾 Incluye: botella de agua, pala, pelotas y toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: bono padeltown 200 mil 

🥈 2do lugar: 1 Kit padeltown (Camiseta padeltown + grip + 3 sobres Aqualiv) 

🥉 3er lugar: 1 Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾Vanessa R 
🎾 Charlie
🎾Camila S
🎾Ana Saza 
🎾Lisa
🎾Paula R 
🎾Monica Botello
🎾Tatiana
🎾Juanita Quiroga 
🎾
🎾
🎾 

¡Nos vemos en la cancha! 🙌🏻

[15:30] __[Notificación del sistema]__
