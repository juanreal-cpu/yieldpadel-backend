# Exportación de chat de WhatsApp: PadelTown Plaza Claro 🎾
Fecha de exportación: 9 de septiembre de 2026 a las 16:14

---

## 16 de julio de 2026

[18:06] __@StivenAJDesign creó el grupo__

---

## 2 de septiembre de 2026

[13:43] __[Notificación del sistema]__

[13:43] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[13:57] **+57 310 5691636:** PadelTown Plaza claro 🔥
🏆 AMERICANO PAREJAS FIJAS, 6TA CATEGORÍA🏆🔥

🗓️  _Miercoles 2 de Sept de 7 a 10 pm

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas en cancha, hora valle
🥈 SUBCAMPEON 1/2 hora, en hora valle
🥉 Tercer Lugar 2 Gatorades 
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Andres - Alicia
🎾  Andrea G - Laura B
🎾  Kevin R - Alejandro 
🎾 Emelyn - Esteban G
🎾 Oscar - David
🎾 Gustavo Danderino- busca partner
🎾 


NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[14:05] __+57 304 2446318 se unieron mediante el enlace de invitación__

[14:05] __+57 317 6478585 se unieron mediante el enlace de invitación__

[14:07] **+57 310 5691636:** PadelTown Plaza claro 🔥
🏆 AMERICANO PAREJAS FIJAS, 6TA CATEGORÍA🏆🔥

🗓️  _Miercoles 2 de Sept de 7 a 10 pm

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas en cancha, hora valle
🥈 SUBCAMPEON 1/2 hora, en hora valle
🥉 Tercer Lugar 2 Gatorades 
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Andres - Alicia
🎾  Andrea G - Laura B
🎾  Kevin R - Alejandro 
🎾 Emelyn - Esteban G
🎾 Oscar - David
🎾 Gustavo Danderino- busca partner
🎾 


NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[15:31] **+57 319 6418041:** Yo voy de parner de Gustavo

[15:37] __[Notificación del sistema]__

[16:30] **+57 311 5302421:**
> _+57 310 5691636: PadelTown Plaza claro 🔥
🏆 AMERICANO PAREJAS FIJAS, 6TA CATEGORÍA🏆🔥

🗓️  _Miercoles 2 de Sept de 7 a 10 pm

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas en cancha, hora valle
🥈 SUBCAMPEON 1/2 hora, en hora valle
🥉 Tercer Lugar 2 Gatorades 
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Andres - Alicia
🎾  Andrea G - Laura B
🎾  Kevin R - Alejandro 
🎾 Emelyn - Esteban G
🎾 Oscar - David
🎾 Gustavo Danderino- busca partner
🎾 


NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻_
Puedo ir, pero no tengo Partner!!!

[16:31] **+57 310 5691636:** PadelTown Plaza claro 🔥
🏆 AMERICANO PAREJAS FIJAS, 6TA CATEGORÍA🏆🔥

🗓️  _Miercoles 2 de Sept de 7 a 10 pm

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas en cancha, hora valle
🥈 SUBCAMPEON 1/2 hora, en hora valle
🥉 Tercer Lugar 2 Gatorades 
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Andres - Alicia
🎾  Andrea G - Laura B
🎾  Kevin R - Alejandro 
🎾 Emelyn - Esteban G
🎾 Oscar - David
🎾 Gustavo Danderino- James Rojas 
🎾 Javier -  Busca partner 


NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[17:27] __+57 300 4473801 se unieron mediante el enlace de invitación__

[21:38] **@ManuelOlivoR:** [Imagen] Podio

[21:39] **@ManuelOlivoR:** [Imagen] 🎾🔥

[21:40] **@ManuelOlivoR:** [Imagen] Los Ganadores del torneo de 6ta, parejas fijas

[21:41] **@ManuelOlivoR:** [Imagen] Campeones! 🏆🏆

---

## 3 de septiembre de 2026

[7:12] __+507 6402-8892 se unieron mediante el enlace de invitación__

[7:34] **+57 310 5691636:** 🎾 ¡Buenos días  PadelTown Plaza Claro! 🎾
Gracias a todos los que anoche dejaron su energía en la cancha, compitieron con actitud y siguieron elevando su nivel
Cada partido suma, cada punto enseña y cada día jugado cuenta en el proceso
🚀 El progreso no se detiene… solo se construye día a día

📲 Felicidades a los campeones y a todos los participantes🎾🔥

[7:35] **+57 310 5691636:** [Imagen]

[7:36] **+57 310 5691636:** si es tuyo, puedes pasar a la plaza claro pádel Town y reclamar tu objeto olvidado

[8:04] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    03/09/2026
🕘 10:00 AM - 11:00 AM
📌 Cancha #1 
**🏷️ Categoría: *6ta *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾  
🎾 
¡ANIMATE ! 🔥

[10:07] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan 
🎾  Laura
🎾  
🎾  
🎾 
🎾 
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[10:35] **+57 310 5691636:** _Se eliminó este mensaje_

[10:41] **+57 310 5691636:**
> _+57 310 5691636: 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan 
🎾  Laura
🎾  
🎾  
🎾 
🎾 
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻_
🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan 
🎾  Laura
🎾  Juan Fierro
🎾  
🎾 
🎾 
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[11:08] __@davidlopez.20 se unieron mediante el enlace de invitación__

[12:07] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    03/09/2026
🕘 06:00 PM - 07:00 pM
📌 Cancha #1 
*🏷️ Categoría: *6ta -5ta
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Fredy Rojas
🎾  Jorge Espinosa
🎾  Jaime
🎾 
¡ANIMATE ! 🔥

[16:12] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    03/09/2026
🕘 06:00 PM - 07:00 pM
📌 Cancha #1 
*🏷️ Categoría: *6ta -5ta
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Fredy Rojas
🎾  Jorge Espinosa
🎾  Jaime
🎾 
¡ANIMATE ! 🔥

[19:41] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan 
🎾  Laura
🎾  Juan Fierro
🎾  
🎾 
🎾 
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

---

## 4 de septiembre de 2026

[7:32] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  Juan Fierro
🎾  
🎾 
🎾 
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[8:15] **+57 318 7686502:** Me inscribo a ver si se llena 😬

[8:16] **+57 310 5691636:** Claro que si Juan, siempre bienvenido 🧡

[8:16] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  Juan Fierro
🎾  Juan E de la calle
🎾 
🎾 
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[8:40] __+57 304 6527747 se unieron mediante el enlace de invitación__

[8:49] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  Juan Fierro
🎾  Juan E de la calle
🎾 Guillermo
🎾 
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[8:51] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  Juan Fierro
🎾  Juan E de la calle
🎾 Guillermo
🎾 Dayanna
🎾 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[10:10] __+57 310 2499336 se unieron mediante el enlace de invitación__

[14:18] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  Juan Fierro
🎾  Juan E de la calle
🎾 Guillermo
🎾 Dayanna
🎾 Javier 
🎾
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[16:12] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  Juan Fierro
🎾  Juan E de la calle
🎾 Guillermo
🎾 Dayanna
🎾 Javier 
🎾 Alejandra Murcia 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[16:29] __[Notificación del sistema]__

[16:30] **+57 301 2241206:** Quien se anima a jugar hoy ?

[16:30] **+57 300 4473801:** Que ctga?

[16:31] **@josh1011:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    29/08/2026
🕘 8:30PM - 9:30 PM
**🏷️ Categoría: *4ta *
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾 
¡Quien se anima! 🔥

[16:31] **+57 301 2241206:**
> _+57 300 4473801: Que ctga?_
5ta

[16:33] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    04/09/2026
🕘 8:30PM - 9:30 PM
**🏷️ Categoría: *4ta - 5ta *
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾 
¡Quien se anima! 🔥

[16:35] **+57 300 4473801:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    04/09/2026
🕘 8:30PM - 9:30 PM
**🏷️ Categoría: *4ta - 5ta *
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  Rafael Valverde 
🎾 Juan morales 
¡Quien se anima! 🔥

[18:11] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    04/09/2026
🕘 9:00PM - 10:00 PM
**🏷️ Categoría: *4ta - 5ta *
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾 Juan morales 
¡Quien se anima! 🔥

[18:17] **+57 301 3148922:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    04/09/2026
🕘 9:00PM - 10:00 PM
**🏷️ Categoría: *4ta - 5ta *
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  Juan Rodríguez 
🎾 Juan morales 
¡Quien se anima! 🔥
Cerrado

[18:27] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    04/09/2026
🕘 9:00PM - 10:00 PM
**🏷️ Categoría: *4ta - 5ta *
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  Juan Rodríguez 
🎾 
¡Quien se anima! 🔥
Falta una pala anímense !!!

[18:34] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  
🎾  Juan E de la calle
🎾 Guillermo
🎾 Dayanna
🎾 Javier 
🎾 Alejandra Murcia 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[18:45] **+57 301 3148922:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    04/09/2026
🕘 9:00PM - 10:00 PM
**🏷️ Categoría: *4ta - 5ta *
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  Juan Rodríguez 
🎾 Jan
¡Quien se anima! 🔥
Falta una pala anímense !!!
Partido cerrado

[21:40] **+57 310 5691636:** 🔥🏆  
 AMERICANO individual, 5ta CATEGORÍA🏆🔥

🗓️  _Sabado  5 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $80 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                         

INSCRÍBETE YA 🥳🏃‍♂️

🎾  Juan R.
🎾  Laura
🎾  
🎾  Juan E de la calle
🎾 Guillermo
🎾 Dayanna
🎾 Javier 
🎾 Alejandra Murcia 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[22:00] **@ManuelOlivoR:** Buenas noches

[22:01] **@ManuelOlivoR:** Torneo cancelado para el día Domingo

[22:10] **+57 310 5691636:** Por favor confirmar quien puede seguir en el torneo para el día domingo!

---

## 5 de septiembre de 2026

[7:25] **+57 310 5691636:** 🔥PARTIDO ABIERTO🔥
📍 PadelTown Plaza Claro. 
05/09/2026 08:30-10:00 AM
Categoría: 5ta
Cancha:  1
Valor: 20.000

🎾  Alejandra
🎾   
🎾   
🎾  

Partido o miedo?!!!🔥🔥🎾

[7:44] **+57 310 5691636:** 🔥PARTIDO ABIERTO🔥
📍 PadelTown Plaza Claro. 
05/09/2026 09:00-10:00 AM
Categoría: 5ta
Cancha:  1
Valor: 205000

🎾  Alejandra
🎾   Javier
🎾   
🎾  

Partido o miedo?!!!🔥🔥🎾

[8:33] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  
🎾  
🎾 
🎾 
🎾  
🎾 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[8:41] **+57 310 5691636:** [Imagen]

[8:42] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  
🎾 
🎾 
🎾  
🎾 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[8:47] **@josh1011:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/ 09/2026
🕘 11:am - 12:00
**🏷️ Categoría: *4ta *
💰Premio Ganador: 150,000
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾 
¡Quien se anima! 🔥

[8:48] **+57 317 4014488:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavides 
🎾 
🎾 
🎾  
🎾 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[9:26] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 
🎾  
🎾 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[9:38] **@josh1011:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/ 09/2026
🕘 4:00 pm - 5:00pm
**🏷️ Categoría: *4ta *
💰Premio Ganador: 150,000
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾 
¡Quien se anima! 🔥

[9:44] **+57 324 6541941:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾  
🎾 
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[9:47] **+57 301 7868260:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[9:48] **@gdanderino:**
> _+57 301 7868260: 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻_
Voy

[9:48] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾Gustavo 
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[9:52] **+57 313 3916762:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/ 09/2026
🕘 4:00 pm - 5:00pm
**🏷️ Categoría: *4ta *
💰Premio Ganador: 150,000
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾 
¡Quien se anima! 🔥

[14:40] **@josh1011:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/ 09/2026
🕘 4:00 pm - 5:00pm
**🏷️ Categoría: *4ta *
💰Premio Ganador: 150,000
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾 Juan Galvis 
🎾 Nicolás Sierra
¡Quien se anima! 🔥

[14:44] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾Gustavo 
🎾 Alejandro Benavides
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[17:37] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾Gustavo 
🎾 Alejandro Benavides
🎾 Sebastian Rios
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[17:57] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/09/2026
🕘 08:00 PM-09:00 PM
📌 Cancha #1
**🏷️ Categoría: *3ra *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Josh
🎾  Madero
🎾  
🎾 
¡Quien se anima! 🔥

[18:12] **@PadelTownSantafe:** 🌟 _AMERICANO - 6TA / 5TA🌟
 
📅  Domingo 06 de septiembre
⏰ 9 a.m. a 11 a.m.
🎾 Sede📍PadelTown SantaFé.

💸 Inscripción: $60.000 por jugador
🟠 Miembros Orange: 20% de dcto
⚫ Miembros Black: 30% de dcto

🏆 Categoría: 6ta / 5ta (Americano clasico)

🎾 Incluye: Pala, pelotas, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:

🥇 1er lugar: 200.000 consumibles en el club

🥈 2do lugar: 1 hora de cancha libre 

🥉 3er lugar: 50% de cancha libre.

💥Súbanle nivel al juego y vivan un día  lleno de competencia, risas y buena energía🔥🎾

Inscribete aqui!

🎾 Victor
🎾 Edwin
🎾 Andres
🎾 julian gordillo 
🎾 Ana Maria 
🎾 David Mora
🎾
🎾
🎾
🎾
🎾


¿Quién se anima Familia?🏓🔥

[18:27] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾Gustavo 
🎾 Alejandro Benavides
🎾 Sebastian Rios
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[18:27] **+57 310 5691636:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/09/2026
🕘 08:00 PM-09:00 PM
📌 Cancha #1
**🏷️ Categoría: *3ra *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Josh
🎾  Madero
🎾  
🎾 
¡Quien se anima! 🔥

[18:31] **+57 310 5691636:** _Se eliminó este mensaje_

[18:40] **+57 310 5691636:** _Se eliminó este mensaje_

[18:47] **+57 310 5691636:** _Se eliminó este mensaje_

[18:50] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾Gustavo 
🎾 Alejandro Benavides
🎾 Sebastian Rios
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[19:38] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾Gustavo 
🎾 Alejandro Benavides
🎾 Sebastian Rios
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[20:06] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 6 de Sept de 9:00 am - 12pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000+ gaseosa
🥈 SUBCAMPEON Una gorra y toalla + gaseosa
🥉 Tercer Lugar 2 gaseosas
                                        
🎾  Juan E de la calle
🎾  Heidy chacon
🎾  Cristian Gomez
🎾  Juan Benavidez
🎾 Dayanna
🎾 Andrés Perdomo 
🎾 Jhonatan n
🎾 Leidy D
🎾Gustavo 
🎾 Alejandro Benavides
🎾 Sebastian Rios
🎾  Sergio 

TORNEO CERRADO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[20:07] **+57 310 5691636:** Se recomienda llegar con anticipación a todos ya que lo ideal es iniciar el torneo a las 9 am, la programación de los partidos empezara rapidamente, gracias 🔥🎾

---

## 6 de septiembre de 2026

[7:40] **+57 310 5691636:** 🌞🎾 ¡MUY BUENOS DÍAS, PADELEROS! 🎾🔥
¡Feliz domingo! 🧡 Hoy es día de disfrutar, competir y dejarlo todo en la cancha. 💪🎾
🏆 Los esperamos hoy en nuestro torneo a partir de las 9:00 AM.
⏰ Les recomendamos llegar con puntualidad para poder iniciar a tiempo y disfrutar de toda la jornada.
🔥 Vengan con toda la garra, actitud y ganas de darlo todo en la cancha.
¡Que gane el mejor y que se disfrute cada punto! 🔥

[12:36] **+57 313 3916762:** [Mensaje de album]

[12:36] **+57 313 3916762:** [Imagen]

[12:36] **+57 313 3916762:** [Imagen]

[12:36] **+57 313 3916762:** [Imagen]

[12:40] **+57 310 5691636:** gracias a todos nuestros participantes por siempre mostrar la garra dentro y fuera de la cancha, nos encanta verlos crecer,sumar experiencias  y lo más importante tener nuevas amistades  🥎🔥🫂

[14:04] __+52 1 55 5153 8780 se unieron mediante el enlace de invitación__

[16:02] **@josh1011:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/ 09/2026
🕘6/:00 pm - 7:00pm
**🏷️ Categoría: *z 3ta 4ta *
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾
¡Quien se anima! 🔥

[16:03] **+57 310 5691636:**
> _@josh1011: 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    05/ 09/2026
🕘6/:00 pm - 7:00pm
**🏷️ Categoría: *z 3ta 4ta *
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾  
🎾
¡Quien se anima! 🔥_
20000 por jugador

---

## 7 de septiembre de 2026

[14:16] **+57 310 5691636:** [Reenviado] 🔥🏆  AMERICANO tipo Round Robin Parejas fijas, 5ta CATEGORÍA🏆🔥
Mínimo 5 partidos confirmados a 1 short set durante la fase de grupos

🗓️  Viernes 11 de septiembre
⌚ Hora7:30 PM - 11:00 PM
📍 Padeltown Plaza Claro

💰 Inscripción: $100.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 500.000 en efectivo
🥈 SUBCAMPEON Inscripción gratuita del siguiente torneo
🥉 Tercer Lugar 2 gorras + 2 toallas+ 2 gaseosas
                                        
🎾  
🎾  
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾  

TORNEO ABIERTO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[14:52] __[Notificación del sistema]__

[15:01] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Miercoles 09 de Sept de 07:00 pm- 10:00 pm
📍 Padeltown Plaza Claro

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas valle
🥈 SUBCAMPEON Un Termo
🥉 Tercer Lugar 1 gatorade
                                          
🎾  
🎾  
🎾  
🎾 
🎾  
🎾
🎾 
🎾 
 
NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[15:02] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Domingo 13 de Sept de 11:00 am - 2:00 pm
📍 Padeltown Plaza Claro

💰 Inscripción: $65 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Una toalla + gatorade
🥉 Tercer Lugar 1 gatorade
                                          
🎾  
🎾  
🎾  
🎾 
🎾  
🎾
🎾 
🎾 
🎾 
🎾 
🎾 
🎾

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[15:08] **@josh1011:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    07/ 09/2026
🕘 6:00 pm - 7:00pm
**🏷️ Categoría: *4ta *
💰Premio Ganador: 150,000
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾 
🎾
¡Quien se anima! 🔥

[16:38] **@barrosduv:** _Se eliminó este mensaje_

[16:39] **@barrosduv:** _Se eliminó este mensaje_

[16:40] **@barrosduv:** _Se eliminó este mensaje_

[17:45] **@josh1011:** 🌟🎾 PARTIDO DE PÁDEL 🎾🌟
📍 Pádel Town Plaza Claro  
📅    07/ 09/2026
🕘7:00 pm - 8:00pm
**🏷️ Categoría: *4ta-5ta *
💰Precio por jugador: 20.000
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 josh Carrillo 
🎾 Matías Madero 
🎾 
🎾
¡Quien se anima! 🔥

[18:31] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Miercoles 09 de Sept de 07:00 pm- 10:00 pm
📍 Padeltown Plaza Claro

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas valle
🥈 SUBCAMPEON Un Termo
🥉 Tercer Lugar 1 gatorade
                                          
🎾  
🎾  
🎾  
🎾 
🎾  
🎾
🎾 
🎾 
 
NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

---

## 8 de septiembre de 2026

[8:36] **+57 310 5691636:** 🔥🏆  AMERICANO tipo Round Robin Parejas fijas, 5ta CATEGORÍA🏆🔥
Mínimo 5 partidos confirmados a 1 short set durante la fase de grupos

🗓️  Viernes 11 de septiembre
⌚ Hora7:30 PM - 11:00 PM
📍 Padeltown Plaza Claro

💰 Inscripción: $100.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 500.000 en efectivo
🥈 SUBCAMPEON Inscripción gratuita del siguiente torneo
🥉 Tercer Lugar 2 gorras + 2 toallas+ 2 gaseosas
                                        
🎾  Joseph Avendaño - Matias Madero
🎾  
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾  

TORNEO ABIERTO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[9:39] __+57 311 5145335 se unieron mediante el enlace de invitación__

[9:39] __+57 321 2519484 se unieron mediante el enlace de invitación__

[10:05] **+57 311 5145335:** Por favor fotos del torneo de esta mañana

[10:18] **+57 313 3916762:** [Imagen] Torneo americano 6ta 🏆

[10:18] **+57 313 3916762:** [Imagen] Tercer puesto ✨

[10:19] **+57 313 3916762:** [Imagen] Segundo puesto: súper empate 🔥🤭

[10:19] **+57 313 3916762:** [Imagen] Campeón torneo americano cat. 6ta

[10:21] **+57 310 5691636:** [Sticker]

[12:08] **+57 310 5691636:** gracias por acompañarnos en este gran torneo, felicidades campeones, lo dejaron todo en la cancha, los esperamos pronto

[15:25] **+57 310 5691636:** 🔥🏆  AMERICANO tipo Round Robin Parejas fijas, 5ta CATEGORÍA🏆🔥
Mínimo 5 partidos confirmados a 1 short set durante la fase de grupos

🗓️  Viernes 11 de septiembre
⌚ Hora7:30 PM - 11:00 PM
📍 Padeltown Plaza Claro

💰 Inscripción: $100.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 500.000 en efectivo
🥈 SUBCAMPEON Inscripción gratuita del siguiente torneo
🥉 Tercer Lugar 2 gorras + 2 toallas+ 2 gaseosas
                                        
🎾  Joseph Avendaño - Matias Madero
🎾  
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾  

TORNEO ABIERTO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[16:17] __Andres Rodriguez Padel se unieron mediante el enlace de invitación__

[18:18] __[Notificación del sistema]__

[18:18] **+57 318 4642929:** Hola grupo como van 
Estoy vendiendo una pala siux por si les interesa 
Buen precio

[18:18] **+57 318 4642929:** [Imagen]

[20:11] **+57 310 5691636:** [Imagen] Pregunta por el torneo de tu interes, listos para el reto!!!! 🎾🔥

[20:13] **+57 310 5691636:** Programate para nuestros torneos !!!!

[20:18] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Miercoles 09 de Sept de 07:00 pm- 10:00 pm
📍 Padeltown Plaza Claro

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas valle
🥈 SUBCAMPEON Un Termo
🥉 Tercer Lugar 1 gatorade
                                          
🎾  Lina
🎾 Andres  
🎾  
🎾 
🎾  
🎾
🎾 
🎾 
 
NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[20:19] **+57 310 5691636:** Quien para el torneo de mañana!!!

[21:46] **+57 310 5691636:** [Imagen] 🌙 Buenas noches, comunidad PadelTown. Que tengan un merecido descanso y una noche llena de tranquilidad. 🧡

---

## 9 de septiembre de 2026

[9:53] **+57 310 5691636:** 🔥🏆  AMERICANO tipo Round Robin Parejas fijas, 5ta CATEGORÍA🏆🔥
Mínimo 5 partidos confirmados a 1 short set durante la fase de grupos

🗓️  Viernes 11 de septiembre
⌚ Hora7:30 PM - 11:00 PM
📍 Padeltown Plaza Claro

💰 Inscripción: $100.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 500.000 en efectivo
🥈 SUBCAMPEON Inscripción gratuita del siguiente torneo
🥉 Tercer Lugar 2 gorras + 2 toallas+ 2 gaseosas
                                        
🎾  Joseph Avendaño - Matias Madero
🎾  
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾  

TORNEO ABIERTO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[9:53] **+57 310 5691636:** 🔥🏆  AMERICANO individual, 6ta CATEGORÍA🏆🔥

🗓️  Miercoles 09 de Sept de 07:00 pm- 10:00 pm
📍 Padeltown Plaza Claro

💰 Inscripción: $60 mil x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 2 horas valle
🥈 SUBCAMPEON Un Termo
🥉 Tercer Lugar 1 gatorade
                                          
🎾  Lina
🎾 Andres  
🎾  
🎾 
🎾  
🎾
🎾 
🎾 
 
NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[10:16] __+57 310 2500185 se unieron mediante el enlace de invitación__

[11:15] **+57 310 5691636:** 🔥🏆  AMERICANO tipo Round Robin Parejas fijas, 5ta CATEGORÍA🏆🔥
Mínimo 5 partidos confirmados a 1 short set durante la fase de grupos

🗓️  Viernes 11 de septiembre
⌚ Hora7:30 PM - 11:00 PM
📍 Padeltown Plaza Claro

💰 Inscripción: $100.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 500.000 en efectivo
🥈 SUBCAMPEON Inscripción gratuita del siguiente torneo
🥉 Tercer Lugar 2 gorras + 2 toallas+ 2 gaseosas
                                        
🎾  Joseph Avendaño - Matias Madero
🎾  Javier Rodriguez - Diego Aragon
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾  

TORNEO ABIERTO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[14:50] __@josh1011 añadió a +57 314 3029805__

[14:52] **@josh1011:** 🔥🏆  AMERICANO tipo Round Robin Parejas fijas, 5ta CATEGORÍA🏆🔥
Mínimo 5 partidos confirmados a 1 short set durante la fase de grupos

🗓️  Viernes 11 de septiembre
⌚ Hora7:30 PM - 11:00 PM
📍 Padeltown Plaza Claro

💰 Inscripción: $100.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 500.000 en efectivo
🥈 SUBCAMPEON Inscripción gratuita del siguiente torneo
🥉 Tercer Lugar 2 gorras + 2 toallas+ 2 gaseosas
                                        
🎾  Joseph Avendaño - Matias Madero
🎾  Javier Rodriguez - Diego Aragon
🎾 Matias Galindo- Julián Giraldo
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾  

TORNEO ABIERTO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻

[15:01] __+57 315 2374106 se unieron mediante el enlace de invitación__

[15:30] __[Notificación del sistema]__

[16:09] **+57 310 5691636:** 🔥🏆  AMERICANO tipo Round Robin Parejas fijas, 5ta CATEGORÍA🏆🔥
Mínimo 5 partidos confirmados a 1 short set durante la fase de grupos

🗓️  Viernes 11 de septiembre
⌚ Hora7:30 PM - 11:00 PM
📍 Padeltown Plaza Claro

💰 Inscripción: $100.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF

🏆💸 PREMIOS 💸🏆  
🥇 CAMPEÓN 500.000 en efectivo
🥈 SUBCAMPEON Inscripción gratuita del siguiente torneo
🥉 Tercer Lugar 2 gorras + 2 toallas+ 2 gaseosas
                                        
🎾  Joseph Avendaño - Matias Madero
🎾  Javier Rodriguez - Diego Aragon
🎾 Matias Galindo- Julián Giraldo
🎾 Jesus Gonzalez- Jaime L
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾  

TORNEO ABIERTO🔥

NOS VEMOS EN LA CANCHA 🎾⚡️💪🏻
