# Exportación de chat de WhatsApp: 4ta categoría
Fecha de exportación: 9 de septiembre de 2026 a las 16:19

---

## 25 de abril de 2025

[13:12] __+57 302 3414909 creó el grupo__

---

## 7 de septiembre de 2026

[13:01] __[Notificación del sistema]__

[13:36] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[13:39] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 4ta
🕣 3:00pm - 4:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel
🎾 Diego
🎾 Javier
🎾 

Partido Abierto 🔓

[13:39] **@camilo.gm5:** Lunes 7 de septiembre 
 Categoría: 4ta
🕣 3:00pm - 4:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel
🎾 Diego
🎾 Javier
🎾 Camilo 

Partido Abierto 🔓

[13:47] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 4ta
🕣 3:00pm - 4:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel
🎾 Diego
🎾 Camilo 
🎾 

Partido ABIERTO 🔓

[15:19] **+57 301 6450021:** _Se eliminó este mensaje_

[21:03] __[Notificación del sistema]__

[21:12] __[Notificación del sistema]__

[21:15] __[Notificación del sistema]__

---

## 8 de septiembre de 2026

[8:25] **+31 6 84873308:** _Se eliminó este mensaje_

[10:37] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Santiago
🎾 
🎾 
🎾 

Partido ABIERTO 🔓

[11:06] **+31 6 84873308:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Santiago
🎾 Cliff
🎾 
🎾 

Partido ABIERTO 🔓

[15:15] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 6:00pm - 8:30pm
📍 Spin Pádel 
💸 55.000 c/u
🏟️ Cancha estadio

🎾 Nicolás G
🎾 Pablo C
🎾 
🎾 

Partido ABIERTO 🔓

[15:15] **@camilo.gm5:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 6:00pm - 8:30pm
📍 Spin Pádel 
💸 55.000 c/u
🏟️ Cancha estadio

🎾 Nicolás G
🎾 Pablo C
🎾 Camilo G
🎾 

Partido ABIERTO 🔓

[15:19] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 6:00pm - 8:30pm
📍 Spin Pádel 
💸 55.000 c/u
🏟️ Cancha estadio

🎾 Nicolás G
🎾 Pablo C
🎾 Camilo G
🎾 Cliff

Partido CERRADO 🔒

[22:20] **+57 301 1388105:** Miercoles 9 de septiembre 
 Categoría: 4ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro M
🎾 Alan
🎾 
🎾 

Partido ABIERTO 🔓

[22:20] **@santi.catam:** Miercoles 9 de septiembre 
 Categoría: 4ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro M
🎾 Alan
🎾 santiago
🎾 

Partido ABIERTO 🔓

[22:20] **+57 321 3697094:** Miercoles 9 de septiembre 
 Categoría: 4ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro M
🎾 Alan
🎾 santiago
🎾 Felipe r

Partido ABIERTO 🔓

[22:21] **+57 301 1388105:** Miercoles 9 de septiembre 
 Categoría: 4ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro M
🎾 Alan
🎾 santiago
🎾 Felipe r

Partido Cerrado 🔒

---

## 9 de septiembre de 2026

[8:21] **+57 301 1388105:** _Se eliminó este mensaje_

[9:26] **+57 301 1388105:** Miercoles 9 de septiembre   
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro S
🎾 Nicolas M 
🎾 
🎾  

Partido Abierto 🔓

[12:06] **+57 301 1388105:** Miércoles 9 de septiembre   
 Categoría: 4ta / Mixtos B
🕣 4:30pm - 6:00pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Monti
🎾 Julieth 
🎾 
🎾  

Partido Abierto 🔓

[12:44] **+57 301 1388105:** Miercoles 9 de septiembre 
 Categoría: 4ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro M
🎾 Santiago
🎾 Felipe R
🎾

Partido Abierto 🔓

[12:47] **+31 6 84873308:** Miercoles 9 de septiembre 
 Categoría: 4ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro M
🎾 Santiago
🎾 Felipe R
🎾 Cliff

Partido Abierto 🔓

[12:48] **+57 301 1388105:** Miercoles 9 de septiembre 
 Categoría: 4ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro M
🎾 Santiago
🎾 Felipe R
🎾 Cliff

Partido Cerrado 🔒

[13:34] **+57 301 1388105:** Miercoles 9 de septiembre   
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro S
🎾 Nicolas M 
🎾 
🎾  

Partido Abierto 🔓
