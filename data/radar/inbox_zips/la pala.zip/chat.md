# Exportación de chat de WhatsApp: Bogotá General LA PALA🎾🔥
Fecha de exportación: 9 de septiembre de 2026 a las 16:17

---

## 11 de mayo de 2026

[16:42] **@lapalaclubdepadel:** 11 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50K
🎾  
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[16:45] **@lapalaclubdepadel:** 11 DE MAYO
CATEGORIA: MASCULINO 5ta/6TA
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50K
🎾  
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[16:52] **@alejandromusical:** _Se eliminó este mensaje_

---

## 12 de mayo de 2026

[6:56] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  13 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Edymar
🎾 Jesus
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (14) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ec6f5575-a4b8-4b04-ad52-5c57a56ececc?utm_source=manager

[10:38] **@lapalaclubdepadel:** [Imagen]

[12:37] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  13 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Edymar
🎾 Jesus
🎾 Juliana Quinteros
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (14) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ec6f5575-a4b8-4b04-ad52-5c57a56ececc?utm_source=manager

[12:38] **@lapalaclubdepadel:** 12 DE MAYO
CATEGORIA: MASCULINO 5ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰62.5K
🎾  Santiago Bolaños
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[14:04] **@lapalaclubdepadel:** 12 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50K
🎾  
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[15:58] **@juan.younes:**
> _@lapalaclubdepadel: 12 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50K
🎾  
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!_
Hola. Jose y Juan

[16:03] **@juan.younes:** 12 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50K
🎾  Jose
🎾 Juan
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[16:22] **@lapalaclubdepadel:** 12 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50K
🎾  Jose
🎾 Juan
🎾
🎾 
*PARTIDO CANCELADO *
SIN DISPONIBILIDAD DE CANCHA

[17:41] **@lapalaclubdepadel:** MAÑANA 13 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰62.5K
🎾  
🎾 
🎾
🎾 
*PARTIDO ABIERTO *
ANIMO, PROGRAMECEN CON TIEMPO!

[18:12] **+57 316 6264600:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  13 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Edymar
🎾 Jesus
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (14) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ec6f5575-a4b8-4b04-ad52-5c57a56ececc?utm_source=manager

[18:12] **+57 316 6264600:** Vamos comunidad anímense, los esperamos mañana 💪🎾

[18:13] **+57 316 6264600:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  13 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Edymar
🎾 Jesus
🎾 Juliana Quinteros
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (14) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ec6f5575-a4b8-4b04-ad52-5c57a56ececc?utm_source=manager

[19:45] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  13 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Edymar
🎾 Jesus
🎾 Juliana Quinteros
🎾 Andres Hernandez
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ec6f5575-a4b8-4b04-ad52-5c57a56ececc?utm_source=manager

[20:48] __[Notificación del sistema]__

[21:07] **+57 316 6264600:** [Mensaje de album]

[21:07] **+57 316 6264600:** [Imagen]

[21:07] **+57 316 6264600:** Torneo Padel and Wine Martes 💪🍷🎾🍷

[21:07] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

---

## 13 de mayo de 2026

[7:10] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/7223730e-34dc-4f5e-969b-1356d4e79961?utm_source=manager

[11:39] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/7223730e-34dc-4f5e-969b-1356d4e79961?utm_source=manager

[14:15] **+57 310 6898400:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/7223730e-34dc-4f5e-969b-1356d4e79961?utm_source=manager

[15:32] **@lapalaclubdepadel:** MAÑANA 14 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰62.5K
🎾  
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[17:14] **@lapalaclubdepadel:** MAÑANA 14 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 05:00 pm a 06:00 pm
📍La pala 
💰32K
🎾 Ana Velasquez
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[17:28] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾 Yamil
🎾Ivan Camilo Guzman

🎾 Camilo Acevedo
🎾 Irene Hernandez
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/7223730e-34dc-4f5e-969b-1356d4e79961?utm_source=manager

[21:04] **+57 316 6264600:** [Mensaje de album]

[21:04] **+57 316 6264600:** [Imagen]

[21:04] **+57 316 6264600:** [Imagen]

[21:04] **+57 316 6264600:** [Imagen]

[21:04] **+57 316 6264600:** [Imagen]

[21:04] **+57 316 6264600:** [Mensaje de unknown]

[21:04] **+57 316 6264600:** [Mensaje de unknown]

[21:04] **+57 316 6264600:** [Mensaje de unknown]

[21:04] **+57 316 6264600:** Torneo Padel and Beer , Miércoles por la noche 🍻💪🍻🎾

[21:11] __@lapalaclubdepadel añadió a +57 314 7713476__

---

## 14 de mayo de 2026

[8:27] **@lapalaclubdepadel:** 14 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 05:00 pm a 06:00 pm
📍La pala 
💰32K
🎾 Ana Velasquez
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[9:19] **@lapalaclubdepadel:** 15 DE MAYO
CATEGORIA: FEMENINO C/D
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰62.5K
� Daniela Hoyos
🎾 
🎾
🎾 
*PARTIDO ABIERTO
QUIEN SE ANIMA!!

[9:28] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾 Yamil
🎾Ivan Camilo Guzman

🎾 Camilo Acevedo
🎾 Irene Hernandez
️
🎾 Fadil
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA 1 PALA)
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/7223730e-34dc-4f5e-969b-1356d4e79961?utm_source=manager

[12:18] **@lapalaclubdepadel:** 14 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 07:30 pm a 09:00 pm
📍La pala 
💰62.5K
🎾 
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!

[13:22] **+57 312 5456433:** 14 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 05:00 pm a 06:00 pm
📍La pala 
💰32K
🎾 Ana Velasquez
🎾 Roberto C
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!!

[15:08] **+57 310 2967285:** _Se eliminó este mensaje_

[17:20] **@liniscarrillo:** [Imagen] 🚨 ¡Buenas noticias! 🚨

Ampliamos la fecha de inscripción para la CNF 💥🏓

Todavía están a tiempo de armar su equipo, organizar a sus amigas y ser parte de este torneo que está hecho para competir, disfrutar y crear comunidad dentro y fuera de la cancha 💜
No se queden por fuera 👀

¡Las esperamos para vivir una experiencia increíble de pádel! 🎾✨

---

## 15 de mayo de 2026

[11:14] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾 Yamil
🎾Ivan Camilo Guzman

🎾 Camilo Acevedo
🎾 Irene Hernandez
️
🎾 Fadil
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA 1 PALA )
NO TE QUEDES POR FUERA

[11:23] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  15  de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[12:05] **@lapalaclubdepadel:** 15 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 04:00 pm a 06:00 pm
📍La pala 
💰64K
🎾 
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!

[12:06] **+57 320 2043207:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾 Yamil
🎾Ivan Camilo Guzman

🎾 Camilo Acevedo
🎾 Irene Hernandez
️
🎾 Fadil
🎾

🎾 Alex Sierra
🎾 Pedro Alarcón 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA 1 PALA )
NO TE QUEDES POR FUERA

[12:09] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾 Yamil
🎾Ivan Camilo Guzman

🎾 Camilo Acevedo
🎾 Irene Hernandez
️
🎾Alex Sierra 
🎾Pedro Alarcon

🎾 Fadil
🎾  

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PALA )
NO TE QUEDES POR FUERA

[13:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾 Yamil
🎾Ivan Camilo Guzman

🎾 Camilo Acevedo
🎾 Irene Hernandez
️
🎾Alex Sierra 
🎾Pedro Alarcon

🎾 Ignacio Carrasquero
🎾 Roberto Yepes 

 
*TORNEO CERRADO *
LOS ESPERAMOS!

[14:51] __@lapalaclubdepadel añadió a @JuanVila09__

[17:13] **@lapalaclubdepadel:** Torneo* PÁDEL AND BEER masculino viernes 15 de mayo 7.30pm - 9.30 pm. Pareja fija 
📍La Pala
🍻suma beer points 

🎾Néstor G/ luis B
🎾Juan A/Juan Baquero
🎾Dave / Camilo ₿itcoin
🎾 Andres Arcila / Santiago Pinto
🎾 
🎾 Jonny C/Javier F
🎾 Ricardo p/ Leandro 
🎾 Paolo/ Diego O
🎾 Nicolás / Santiago
🎾Nicolás G / Juan S

TORNEO ABIERTO
FALTA UNA PAREJA QUIEN SE ANIMA?

[17:14] **+57 312 7976300:**
> _@lapalaclubdepadel: Torneo* PÁDEL AND BEER masculino viernes 15 de mayo 7.30pm - 9.30 pm. Pareja fija 
📍La Pala
🍻suma beer points 

🎾Néstor G/ luis B
🎾Juan A/Juan Baquero
🎾Dave / Camilo ₿itcoin
🎾 Andres Arcila / Santiago Pinto
🎾 
🎾 Jonny C/Javier F
🎾 Ricardo p/ Leandro 
🎾 Paolo/ Diego O
🎾 Nicolás / Santiago
🎾Nicolás G / Juan S

*TORNEO ABIERTO*FALTA UNA PAREJA QUIEN SE ANIMA?_
Que valor tiene y que categoría ?

[17:15] **@lapalaclubdepadel:**
> _+57 312 7976300: Que valor tiene y que categoría ?_
64K

[17:15] **@lapalaclubdepadel:** CATEGORIA 5TA/6TA

[17:53] **@lapalaclubdepadel:** Torneo* PÁDEL AND BEER masculino viernes 15 de mayo 7.30pm - 9.30 pm. Pareja fija 
📍La Pala
🍻suma beer points 

🎾Néstor G/ luis B
🎾Juan A/Juan Baquero
🎾Dave / Camilo ₿itcoin
🎾 Andres Arcila / Santiago Pinto
🎾 Jonny C/Javier F
🎾 Ricardo p/ Leandro 
🎾 Paolo/ Diego O
🎾 Nicolás / Santiago
🎾Nicolás G / Juan S
🎾Sebastian Diaz /

TORNEO ABIERTO
FALTA UNA PALA  QUIEN SE ANIMA?

[18:03] **+57 310 2924270:** Hola estamos buscando una pala para un partido ahora a las 6 pm … alguien se anima ?

[18:41] **@juanselopez5_:**
> _@lapalaclubdepadel: Torneo* PÁDEL AND BEER masculino viernes 15 de mayo 7.30pm - 9.30 pm. Pareja fija 
📍La Pala
🍻suma beer points 

🎾Néstor G/ luis B
🎾Juan A/Juan Baquero
🎾Dave / Camilo ₿itcoin
🎾 Andres Arcila / Santiago Pinto
🎾 Jonny C/Javier F
🎾 Ricardo p/ Leandro 
🎾 Paolo/ Diego O
🎾 Nicolás / Santiago
🎾Nicolás G / Juan S
🎾Sebastian Diaz /

TORNEO ABIERTO
FALTA UNA PALA  QUIEN SE ANIMA?_
yo voy

[18:42] **@lapalaclubdepadel:**
> _@juanselopez5_: yo voy_
ya lo apunto para cerrar el torneo

[18:42] **@lapalaclubdepadel:** Torneo* PÁDEL AND BEER masculino viernes 15 de mayo 7.30pm - 9.30 pm. Pareja fija 
📍La Pala
🍻suma beer points 

🎾Néstor G/ luis B
🎾Juan A/Juan Baquero
🎾Dave / Camilo ₿itcoin
🎾 Andres Arcila / Santiago Pinto
🎾 Jonny C/Javier F
🎾 Ricardo p/ Leandro 
🎾 Paolo/ Diego O
🎾 Nicolás / Santiago
🎾Nicolás G / Juan S
🎾Sebastian Diaz / Juan S Lopez

TORNEO CERRADO
LOS ESPERAMOS

[20:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 16 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾Carlos Quintana
🎾 Andres Barros
 
🎾 william
🎾 juan david

🎾 Yamil ✅
🎾Ivan Camilo Guzman

🎾 Camilo Acevedo
🎾 Irene Hernandez
️
🎾Alex Sierra 
🎾Pedro Alarcon

🎾 Ignacio Carrasquero✅
🎾 Roberto Yepes ✅

 
*TORNEO CERRADO *
LOS ESPERAMOS!

[21:36] **+57 316 6264600:** [Mensaje de album]

[21:36] **+57 316 6264600:** [Imagen]

[21:36] **+57 316 6264600:** [Imagen]

[21:36] **+57 316 6264600:** [Imagen]

[21:36] **+57 316 6264600:** [Imagen]

[21:36] **+57 316 6264600:** [Mensaje de unknown]

[21:36] **+57 316 6264600:** [Mensaje de unknown]

[21:36] **+57 316 6264600:** [Mensaje de unknown]

[21:36] **+57 316 6264600:** Torneo Padel and Beer , viernes por la noche 🍻💪🎾🍻

[21:53] __@lapalaclubdepadel añadió a +57 317 1170598__

---

## 16 de mayo de 2026

[8:02] **+1 (437) 242-7288:** Hola, estoy en el nivel 5ta/6ta buscando una organización de juegos que se pueda mezclar. Gracias

[8:09] **@lapalaclubdepadel:** 16 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 5ta/6TA
⌚ 02:00 pm a 04:00 pm
📍La pala 
💰64K
🎾 Fadil Ahmad
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!

[9:46] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  15  de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:54] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  15  de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[16:09] **+57 316 6264600:** [Mensaje de album]

[16:09] **+57 316 6264600:** [Imagen]

[16:09] **+57 316 6264600:** [Imagen]

[16:09] **+57 316 6264600:** [Imagen]

[16:09] **+57 316 6264600:** [Imagen]

[16:09] **+57 316 6264600:** [Mensaje de unknown]

[16:09] **+57 316 6264600:** [Mensaje de unknown]

[16:09] **+57 316 6264600:** [Mensaje de unknown]

[16:09] **+57 316 6264600:** Torneo Americano de los Sábados 💪🎾

[19:01] **@lapalaclubdepadel:** 17 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 3ta/4ta
⌚ 11:00 am a 12:30 m
📍La pala 
💰48K
🎾 Pedro F
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!

---

## 17 de mayo de 2026

[9:03] **+57 301 6573017:**
> _@lapalaclubdepadel: 17 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 3ta/4ta
⌚ 11:00 am a 12:30 m
📍La pala 
💰48K
🎾 Pedro F
🎾 
🎾
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!_
17 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 3ta/4ta
⌚ 11:00 am a 12:30 m
📍La pala 
💰48K
🎾 Pedro F
🎾 Daniel
🎾 Eduardo
🎾 
PARTIDO ABIERTO
QUIEN SE ANIMA!

[9:39] **@lapalaclubdepadel:** 17 DE MAYO
CATEGORIA: MIXTO Damas C/D
MASCULINO 3ta/4ta
⌚ 11:00 am a 12:30 m
📍La pala 
💰48K
🎾 Pedro F
🎾 Daniel
🎾 Eduardo
🎾 Camilo Gutierrez
PARTIDO CERRADO

[10:05] **+57 316 6264600:** [Mensaje de album]

[10:05] **+57 316 6264600:** [Imagen]

[10:05] **+57 316 6264600:** [Imagen]

[10:05] **+57 316 6264600:** [Imagen]

[10:05] **+57 316 6264600:** [Imagen]

[10:05] **+57 316 6264600:** [Mensaje de unknown]

[10:05] **+57 316 6264600:** [Imagen]

[10:05] **+57 316 6264600:** [Mensaje de unknown]

[10:05] **+57 316 6264600:** [Mensaje de unknown]

[10:05] **+57 316 6264600:** [Mensaje de unknown]

[10:05] **+57 316 6264600:** Torneo Padelennials Domingo por la Mañana 💪🎾

[10:39] **+57 350 7959826:** Buen día ! Mañana tienen partido ?

[11:41] **@lapalaclubdepadel:** 17 DE MAYO
CATEGORIA:Damas C/D
⌚ 01:00 Pm a 02:00 Pm
📍La pala 
💰30K

🎾 C Paola
🎾 
🎾 
🎾 

PARTIDO ABIERTO

[16:11] __[Notificación del sistema]__

[20:07] **+57 316 6264600:** [Mensaje de album]

[20:07] **+57 316 6264600:** [Imagen]

[20:07] **+57 316 6264600:** [Imagen]

[20:07] **+57 316 6264600:** [Imagen]

[20:07] **+57 316 6264600:** [Imagen]

[20:07] **+57 316 6264600:** [Mensaje de unknown]

[20:07] **+57 316 6264600:** [Mensaje de unknown]

[20:07] **+57 316 6264600:** [Mensaje de unknown]

[20:07] **+57 316 6264600:** Torneo TGIP Domingo por la Tarde 💪🎾

---

## 18 de mayo de 2026

[9:00] __@lapalaclubdepadel añadió a +57 319 4966427__

[9:10] **@lapalaclubdepadel:** 18 DE MAYO
CATEGORIA:5TA/6TA
⌚ 02:00 pm a 04:00 pm
📍La pala 
💰60K

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
(4) PALAS

[9:10] **@lapalaclubdepadel:** 18 DE MAYO
CATEGORIA:4TA
⌚ 02:00 pm a 04:00 pm
📍La pala 
💰60K

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
(4) PALAS

[9:14] **@lapalaclubdepadel:** 8 DE MAYO
CATEGORIA: C/C+ | 5TA/6TA
⌚ 11:00 am a 12:30 m
📍La pala 
💰45K

🎾 C Paola
🎾 
🎾 
🎾 

PARTIDO ABIERTO
(3) PALAS

[9:31] **+507 6419-4314:** 8 DE MAYO
CATEGORIA: C/C+ | 5TA/6TA
⌚ 11:00 am a 12:30 m
📍La pala 
💰45K

🎾 C Paola
🎾 Mariam
🎾 
🎾 

PARTIDO ABIERTO
(3) PALAS

[9:35] **@lapalaclubdepadel:** 8 DE MAYO
CATEGORIA: C/C+ | 5TA/6TA
⌚ 11:00 am a 12:30 m
📍La pala 
💰45K

🎾 C Paola
🎾 Mariam
🎾 
🎾 

PARTIDO ABIERTO
(2) PALAS

[10:03] **@lapalaclubdepadel:** 8 DE MAYO
CATEGORIA: C/C+ | 5TA/6TA
⌚ 11:00 am a 12:30 m
📍La pala 
💰45K

🎾 C Paola
🎾 Mariam
🎾 Juan Crillo
🎾 

PARTIDO ABIERTO
(1) PALAS

[10:19] **+507 6419-4314:** 8 DE MAYO
CATEGORIA: C/C+ | 5TA/6TA
⌚ 11:00 am a 12:30 m
📍La pala 
💰45K

🎾 C Paola
🎾
🎾 Juan Crillo
🎾 

PARTIDO ABIERTO
(1) PALAS

[10:19] **@lapalaclubdepadel:** 8 DE MAYO
CATEGORIA: C/C+ | 5TA/6TA
⌚ 11:00 am a 12:30 m
📍La pala 
💰45K

🎾 C Paola
🎾 Juan Crillo
🎾 
🎾 

PARTIDO ABIERTO
(2) PALAS

[12:57] **@lapalaclubdepadel:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 Juan S López 
🎾 Juan P Rodríguez
🎾 
🎾 

PARTIDO ABIERTO
(2) PALAS

[12:58] **@roduke:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 Juan S López 
🎾 Juan P Rodríguez
🎾 Rodrigo D.
🎾 

PARTIDO ABIERTO
(1) PALAS

[13:47] **@nfmedinalalinde:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 Juan S López 
🎾 Juan P Rodríguez
🎾 Rodrigo D.
🎾 Felipe M

PARTIDO ABIERTO
(1) PALAS

[13:49] **@lapalaclubdepadel:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 Juan S López 
🎾 Juan P Rodríguez
🎾 Rodrigo D.
🎾 Felipe M

PARTIDO CERRADO!!
CANCHA #2

[14:00] **@lapalaclubdepadel:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 Rodrigo D.
🎾 Felipe M
🎾
🎾

PARTIDO ABIERTO!!
(2) PALAS

[14:05] **@roduke:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 
🎾 Felipe M
🎾
🎾

PARTIDO ABIERTO!!
(3) PALAS

[14:37] **+57 310 8698854:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 
🎾 Felipe M
🎾 Daniel G
🎾

PARTIDO ABIERTO!!
(3) PALAS

[14:37] **@lapalaclubdepadel:** 18 DE MAYO
CATEGORIA: 4TA
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰45K

🎾 Daniel G
🎾 
🎾 
🎾

PARTIDO ABIERTO!!
(3) PALAS

[15:28] **@nfmedinalalinde:** _Se eliminó este mensaje_

---

## 19 de mayo de 2026

[7:59] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  20 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (16) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/33c4100f-81ad-41d4-9fcb-130359e7842b?utm_source=manager

[12:16] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[12:51] **@lapalaclubdepadel:** 19 DE MAYO
CATEGORIA: 5ta alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5K

🎾 Santiago
🎾 Giovani Gonzalez
🎾 Juan Garcia
🎾

PARTIDO ABIERTO!!
(1) PALA

[13:12] **@lapalaclubdepadel:** 19 DE MAYO
CATEGORIA: MIXTOS C
⌚ 9:00 pm a 10:30 pm
📍La pala 
💰50K

🎾  Fabián Suárez 
🎾 Tatiana Tamayo
🎾 
🎾 

PARTIDO ABIERTO!!
(2 PALAS)

[14:15] **+57 350 7959826:** 19 DE MAYO
CATEGORIA: MIXTOS C
⌚ 9:00 pm a 10:30 pm
📍La pala 
💰50K

🎾  Fabián Suárez 
🎾 Tatiana Tamayo
🎾 Paola Arroyo FEM C
🎾 

PARTIDO ABIERTO!!
(2 PALAS)

[14:35] **+57 318 6474471:** _Se eliminó este mensaje_

[14:38] **@lapalaclubdepadel:** UNA PALA MAS?

[15:37] **@lapalaclubdepadel:** 19 DE MAYO
CATEGORIA: 5ta alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5K

🎾 Santiago
🎾 Giovani Gonzalez
🎾 Juan Garcia
🎾

PARTIDO ABIERTO!!
falta 1 pala ANIMO!

[15:48] **+57 300 3065645:** 19 DE MAYO
CATEGORIA: 5ta alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5K

🎾 Santiago
🎾 Giovani Gonzalez
🎾 
🎾

PARTIDO ABIERTO!!
falta 1 pala ANIMO!

[15:51] **+57 310 2123180:** 19 DE MAYO
CATEGORIA: MIXTOS C
⌚ 9:00 pm a 10:30 pm
📍La pala 
💰50K

🎾  Fabián Suárez 
🎾 Tatiana Tamayo
🎾 Paola Arroyo FEM C
🎾 Carlos R

PARTIDO ABIERTO!!
(2 PALAS)

[16:04] **@lapalaclubdepadel:** 19 DE MAYO
CATEGORIA: MIXTOS C
⌚ 9:00 pm a 10:30 pm
📍La pala 
💰50K

🎾  Fabián Suárez 
🎾 Tatiana Tamayo
🎾 Paola Arroyo FEM C
🎾 Carlos R

PARTIDO CERRADO
CANCHA 3

[16:58] **@lapalaclubdepadel:** 19 DE MAYO
CATEGORIA: 5ta alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5K

🎾 Santiago
🎾 Giovani Gonzalez
🎾 Juan Garcia
🎾

PARTIDO ABIERTO!!
falta 1 pala ANIMO!

[17:41] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: 19 DE MAYO
CATEGORIA: 5ta alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5K

🎾 Santiago
🎾 Giovani Gonzalez
🎾 Juan Garcia
🎾

PARTIDO ABIERTO!!
falta 1 pala ANIMO!_
19 DE MAYO
CATEGORIA: 5ta alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5K

🎾 Santiago
🎾 Giovani Gonzalez
🎾 Juan Garcia
🎾

PARTIDO CANCELADO!!

[17:42] **@lapalaclubdepadel:** 19 DE MAYO
CATEGORIA: 5ta alta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50K

🎾 Santiago
🎾 
🎾 
🎾

PARTIDO ABIERTO!!

[21:05] **+57 316 6264600:** [Mensaje de album]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:06] **+57 316 6264600:** Torneo Padel and Wine Martes 🍷💪🍷🎾

[21:16] **+57 310 2123180:**
> _@lapalaclubdepadel: 19 DE MAYO
CATEGORIA: MIXTOS C
⌚ 9:00 pm a 10:30 pm
📍La pala 
💰50K

🎾  Fabián Suárez 
🎾 Tatiana Tamayo
🎾 Paola Arroyo FEM C
🎾 Carlos R

PARTIDO CERRADO
CANCHA 3_
Llegan????

[21:33] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: 19 DE MAYO
CATEGORIA: MIXTOS C
⌚ 9:00 pm a 10:30 pm
📍La pala 
💰50K

🎾  Fabián Suárez 
🎾 Tatiana Tamayo
🎾 Paola Arroyo FEM C
🎾 Carlos R

PARTIDO CERRADO
CANCHA 3_
por favor tener en cuenta e informar si se bajan de algun partido programado, asi nos da tiempo de poder buscar otro jugador
y las personas inscritas no pierdan el tiempo al venir.

---

## 20 de mayo de 2026

[6:17] __@lapalaclubdepadel añadió a +52 1 55 4924 0426__

[8:39] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f66c53cb-5a35-47a9-8292-1ba206de14c0?utm_source=manager

[11:22] **+33 7 49 35 27 93:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :00 AM A 1:00PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f66c53cb-5a35-47a9-8292-1ba206de14c0?utm_source=manager_
Me gustaría jugar pero no tengo pareja, soy 5ta, alguien necesita compañero?

[11:26] **@lapalaclubdepadel:** Hola como estas? puedes inscribirte y te buscamos una pareja!

[11:28] **@lapalaclubdepadel:** [Reenviado] [Video]

[13:32] **@lapalaclubdepadel:** Buenas tardes comunidad! el dia 28, 29 y 30 de mayo se llevara a cabo nuestro torneo femenino CNF, es un torneo por equipo y hay uno de ellos que les falta 1 jugadora interesados comunicarse por privado

[13:35] __@lapalaclubdepadel añadió a +57 314 4469624__

[14:59] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[15:03] **+33 7 49 35 27 93:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[17:28] **@lapalaclubdepadel:** MAÑANA 21 DE MAYO
CATEGORIA: 4ta Baja - 5ta alta
⌚ 06:00 am a 07:30 am
📍La pala 
💰48K

🎾 Santiago
🎾 David
🎾 
🎾

PARTIDO ABIERTO!!

[21:03] **+57 316 6264600:** [Mensaje de album]

[21:03] **+57 316 6264600:** [Imagen]

[21:03] **+57 316 6264600:** [Imagen]

[21:03] **+57 316 6264600:** [Imagen]

[21:03] **+57 316 6264600:** [Imagen]

[21:03] **+57 316 6264600:** [Mensaje de unknown]

[21:03] **+57 316 6264600:** [Mensaje de unknown]

[21:03] **+57 316 6264600:** [Mensaje de unknown]

[21:03] **+57 316 6264600:** Pádel and Beer de los Miércoles 🍻💪🍻🎾🍻

[21:26] **@lapalaclubdepadel:** MAÑANA 21 DE MAYO
CATEGORIA: 4ta 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K

🎾 Giovani
🎾 Juan G
🎾 
🎾

PARTIDO ABIERTO!

---

## 21 de mayo de 2026

[2:23] **+57 313 3343399:** _Se eliminó este mensaje_

[6:23] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[9:03] **+57 300 3065645:** HOY 21 DE MAYO
CATEGORIA: 4ta 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K

🎾 Giovani
🎾 Juan G
🎾 
🎾

PARTIDO ABIERTO!

[9:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[10:36] **@gio0924:** HOY 21 DE MAYO
CATEGORIA: 4ta 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K

🎾 
🎾 
🎾 
🎾

PARTIDO ABIERTO!

[10:51] **+57 316 6264600:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾José Miguel Mejía 
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[10:54] **@lapalaclubdepadel:** 21 DE MAYO
CATEGORIA: Principiante/intermedio
⌚ 05:00 Pm a 06:00 Pm
📍La pala 
💰32K

🎾 Adriana
🎾 Angie
🎾 
🎾

PARTIDO ABIERTO!

[11:14] **@lapalaclubdepadel:** 21 DE MAYO
CATEGORIA: Principiante/intermedio
⌚ 05:00 Pm a 06:00 Pm
📍La pala 
💰32K

🎾 Adriana
🎾 Angie
🎾 Irene C
🎾

PARTIDO ABIERTO!

[11:34] **@lapalaclubdepadel:** 21 DE MAYO
CATEGORIA: DAMAS C/D
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰62.5K

🎾 Mariam
🎾 Lorena
🎾 Daniela
🎾

PARTIDO ABIERTO!
UNA PALA

[12:00] **@lapalaclubdepadel:** 21 DE MAYO
CATEGORIA: DAMAS C/D
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰62.5K

🎾 Mariam
🎾 Lorena
🎾 Daniela
🎾 Xiomara

PARTIDO CERRADO LAS ESPERAMOS!

[12:27] **@lapalaclubdepadel:** 21 DE MAYO
CATEGORIA: DAMAS C/D
⌚ 05:00 Pm a 06:00 Pm
📍La pala 
💰32K

🎾 Adriana
🎾 Angie
🎾 Irene C
🎾

PARTIDO ABIERTO!

[13:58] **@lapalaclubdepadel:** 21 DE MAYO
CATEGORIA: DAMAS C/D
⌚ 05:00 Pm a 06:00 Pm
📍La pala 
💰32K

🎾 Adriana
🎾 Angie
🎾 Irene C
🎾Andrea

PARTIDO CERRADO! CANCHA #2

[14:23] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  24  de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[14:40] **@lapalaclubdepadel:** HOY 21 DE MAYO
CATEGORIA: 5ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 
🎾 
🎾 
🎾

PARTIDO ABIERTO!

[14:40] **@julipri02:** HOY 21 DE MAYO
CATEGORIA: 5ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 Julián P
🎾 
🎾 
🎾

PARTIDO ABIERTO!

[19:18] **+57 315 9279497:** HOY 21 DE MAYO
CATEGORIA: 5ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 Julián P
🎾 Jose B 
🎾 
🎾

PARTIDO ABIERTO!

[20:28] **@camilo.gm5:** HOY 21 DE MAYO
CATEGORIA: 5ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 Julián P
🎾 Jose B 
🎾 Camilo 
🎾 Juliana M

PARTIDO ABIERTO!

[20:29] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[20:40] **@lapalaclubdepadel:** HOY 21 DE MAYO
CATEGORIA: 5ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 
🎾 Jose B 
🎾 Camilo 
🎾 Juliana M

PARTIDO ABIERTO!
falta 1 pala, quien se anima

[21:01] **+57 316 6264600:** [Mensaje de album]

[21:01] **+57 316 6264600:** [Imagen]

[21:01] **+57 316 6264600:** [Imagen]

[21:01] **+57 316 6264600:** [Mensaje de unknown]

[21:02] **+57 316 6264600:** Torneo Mixto Jueves por la Noche 💪🎾

[21:20] **@juliquinteroM:** Que cracks !

---

## 22 de mayo de 2026

[6:04] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾José Miguel Mejía 
🎾

🎾 Gabriela Sierra
🎾 Esteban Duarte
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[11:28] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  24  de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[12:33] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[15:05] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾José Miguel Mejía 
🎾

🎾 Gabriela Sierra
🎾 Esteban Duarte
️
🎾 Valeria✅
🎾Federico✅

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[16:12] **@gsierra0214:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾José Miguel Mejía 
🎾

🎾 
🎾 
️
🎾 Valeria✅
🎾Federico✅

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[17:28] **@lapalaclubdepadel:** [Imagen] 🎾📲 Organizar tus partidos ahora es mucho más fácil en La Pala.

Desde la app de Playtomic puedes gestionar tus horarios, encontrar partidos y acceder a beneficios exclusivos pensados para nuestra comunidad. 🔥

Juega cuando quieras, arma tu parche y vive la experiencia La Pala de una forma más rápida y cómoda.

¡Nos vemos en cancha! 💚

[19:07] __@lapalaclubdepadel añadió a @andres.guataqui__

[20:58] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[20:59] **+57 300 8062274:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 Daniel v 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[21:28] **@iaquintero:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 Daniel v 
🎾 Iván Alonso 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

---

## 23 de mayo de 2026

[8:06] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 Daniel v 
🎾 Iván Alonso ✅
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[8:22] **@lapalaclubdepadel:** Buenos dias comunidad! el dia de hoy tenemos nuestro torneo social! faltan dos parejas LOS ESPERAMOS!

[9:23] **@luis_arangohe:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 Daniel v 
🎾 Iván Alonso ✅
️
🎾 LuisFer 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[9:37] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 Daniel v 
🎾 Iván Alonso ✅
️
🎾 LuisFer 
🎾

🎾Luis Uscategui
🎾Felipe Rodriguez

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 JUGADOR )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[10:09] **@luis_arangohe:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 Daniel v 
🎾 Iván Alonso ✅
️
🎾 LuisFer 
🎾 Nico

🎾Luis Uscategui
🎾Felipe Rodriguez

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 JUGADOR )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[11:24] **+57 300 8062274:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 23 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Jacinto ✅
🎾 José Miguel Mejía
 
🎾 Ivan Guzman
🎾 Yamil Lesmes✅

🎾Valeria✅
🎾Federico✅

🎾 
🎾 Iván Alonso ✅
️
🎾 LuisFer 
🎾 Nico

🎾Luis Uscategui
🎾Felipe Rodriguez

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 JUGADOR )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/85bb741b-3822-4bec-8e9b-fb24ceea468f?utm_source=manager

[13:23] **+57 316 6264600:** [Mensaje de album]

[13:23] **+57 316 6264600:** [Imagen]

[13:23] **+57 316 6264600:** [Imagen]

[13:23] **+57 316 6264600:** [Imagen]

[13:23] **+57 316 6264600:** [Imagen]

[13:23] **+57 316 6264600:** [Mensaje de unknown]

[13:23] **+57 316 6264600:** [Mensaje de unknown]

[13:23] **+57 316 6264600:** [Mensaje de unknown]

[13:24] **+57 316 6264600:** Torneo Americano Sábado 💪🎾

[13:25] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO SOCIAL DOMINGO  24  de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Sebastian F y Juanes Z

[13:49] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  24  de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastian F
🟢 Juanes Z
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[13:52] **@lapalaclubdepadel:** Hola! nos queda disponible un cupo en escuela de adultos, nivel inicial! comunicarse por privado

[15:09] __[Notificación del sistema]__

[15:10] **@lapalaclubdepadel:** HOY 23 DE MAYO
CATEGORIA: 5ta/ 6ta 
⌚ 05:00 Pm a 7:00 Pm
📍La pala 
💰64K

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[15:10] **@lapalaclubdepadel:** HOY 23 DE MAYO
CATEGORIA: 5ta/ 6ta 
⌚ 06:00 Pm a 8:00 Pm
📍La pala 
💰64K

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[22:00] __[Notificación del sistema]__

---

## 24 de mayo de 2026

[10:40] **+57 316 6264600:** [Mensaje de album]

[10:40] **+57 316 6264600:** [Imagen]

[10:40] **+57 316 6264600:** [Imagen]

[10:40] **+57 316 6264600:** [Imagen]

[10:40] **+57 316 6264600:** [Imagen]

[10:40] **+57 316 6264600:** [Mensaje de unknown]

[10:40] **+57 316 6264600:** [Mensaje de unknown]

[10:40] **+57 316 6264600:** [Mensaje de unknown]

[10:40] **+57 316 6264600:** Torneo Padelennials Domingo por la mañana 💪🎾

[13:52] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Domingo Mayo 24!! 
📈 *Categoría: Cada vez mejores
⌚6:00 PM A 8:00PM
📍 La Pala
💰53K 


🎾 Adriana 
🎾 Estefania R
🎾 Diana G
🎾 Yamil

🎾 Ivan G
🎾 Oscar
🎾 Patty
🎾


Nos falta una pala… quien se anima :) !!!!

[14:58] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Domingo Mayo 24!! 
📈 *Categoría: Cada vez mejores
⌚6:00 PM A 8:00PM
📍 La Pala
💰53K 


🎾 Adriana 
🎾 Estefania R
🎾 Diana G
🎾 Yamil

🎾 Ivan G
🎾 Oscar
🎾 Patty
🎾Olinda
 
TORNEO CERRADO

[14:59] **+57 316 6264600:** Listo ✅

[15:05] **+57 316 6264600:** TORNEO Thanks God its Padel
Domingo Mayo 24!! 
📈 *Categoría: Cada vez mejores
⌚6:00 PM A 8:00PM
📍 La Pala
💰53K 


🎾 Adriana 
🎾 Estefania R
🎾 Diana G
🎾 Yamil

🎾 Ivan G
🎾 Patty
🎾Olinda
🎾 

Nos falta una Pala , quien se anima .

[20:04] **+57 316 6264600:** [Mensaje de album]

[20:04] **+57 316 6264600:** [Imagen]

[20:04] **+57 316 6264600:** [Imagen]

[20:05] **+57 316 6264600:** [Imagen]

[20:05] **+57 316 6264600:** [Imagen]

[20:05] **+57 316 6264600:** [Mensaje de unknown]

[20:05] **+57 316 6264600:** [Mensaje de unknown]

[20:05] **+57 316 6264600:** [Mensaje de unknown]

[20:05] **+57 316 6264600:** Torneo TGIP Domingo 💪🎾

---

## 25 de mayo de 2026

[7:29] __@lapalaclubdepadel añadió a @oscardavidb___

[7:44] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  27 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾

 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/a3f8bee3-0f04-4066-ac55-f65de0e7e1af?utm_source=manager

[8:12] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[8:13] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  27 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Juliana Quinteros
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾

 
TORNEO ABIERTO (11) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/a3f8bee3-0f04-4066-ac55-f65de0e7e1af?utm_source=manager

[9:00] **@lapalaclubdepadel:** HOY 25 DE MAYO
CATEGORIA: 5ta alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[10:49] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[18:16] **+57 315 3086074:** HOY 25 DE MAYO
CATEGORIA: 5ta alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 Juan Camilo S
🎾 Gerardo 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

---

## 26 de mayo de 2026

[8:50] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  27 de MAYO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Juliana Quinteros
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾

 
TORNEO ABIERTO (11) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/a3f8bee3-0f04-4066-ac55-f65de0e7e1af?utm_source=manager

[12:20] **@juliquinteroM:** [Sticker]

[12:20] **@juliquinteroM:** Hay quorum ??? Anímense. Este horario es chévere. Ja jaja ja

[13:07] **@lapalaclubdepadel:** HOY 26 DE MAYO
CATEGORIA: 5ta alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[14:09] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager

[15:44] **@lapalaclubdepadel:** [Imagen]

[21:20] **+57 316 6264600:** [Mensaje de album]

[21:20] **+57 316 6264600:** [Imagen]

[21:20] **+57 316 6264600:** [Imagen]

[21:20] **+57 316 6264600:** [Imagen]

[21:20] **+57 316 6264600:** [Imagen]

[21:20] **+57 316 6264600:** [Imagen]

[21:20] **+57 316 6264600:** [Mensaje de unknown]

[21:20] **+57 316 6264600:** [Mensaje de unknown]

[21:20] **+57 316 6264600:** [Mensaje de unknown]

[21:20] **+57 316 6264600:** Pádel and Wine , Martes por la noche 🍷💪🍷🎾🍷

[21:20] **+57 316 6264600:** [Mensaje de unknown]

---

## 27 de mayo de 2026

[0:12] **+57 350 7959826:** _Se eliminó este mensaje_

[8:27] **@lapalaclubdepadel:** 27 DE MAYO🤗

📈 CATEGORIA: MIXTO 5ta /C
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[10:51] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager

[11:11] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager

[11:57] **@lapalaclubdepadel:** [Reenviado] [Video] ⚡HOY CLASE 6:15PM 🚴‍♀️💥

[13:45] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager

[14:26] **+57 310 6843763:**
> _@lapalaclubdepadel: ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager_
sebastian F y Juanes Z

[14:51] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager

[15:06] **@nfmedinalalinde:** Buenas tardes algo de 3ra para las 7:30 pm?

[15:07] **@lapalaclubdepadel:**
> _@nfmedinalalinde: Buenas tardes algo de 3ra para las 7:30 pm?_
hola buenas tardes, en esa franja no tenemos disponibilidad, pero si desea armamos uno para las 09:00pm

[16:47] __@lapalaclubdepadel añadió a +57 312 3608993__

[17:17] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager

[17:23] **@jonnycoronel66:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/f167917d-7fbf-4ae9-b9bf-a14225a28273?utm_source=manager

[17:25] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

 
TORNEO CERRADO
LOS ESPERAMOS!!!

[21:44] **+57 316 6264600:** [Mensaje de album]

[21:44] **+57 316 6264600:** [Imagen]

[21:44] **+57 316 6264600:** [Imagen]

[21:44] **+57 316 6264600:** [Imagen]

[21:44] **+57 316 6264600:** [Imagen]

[21:44] **+57 316 6264600:** [Mensaje de unknown]

[21:44] **+57 316 6264600:** [Mensaje de unknown]

[21:44] **+57 316 6264600:** [Mensaje de unknown]

[21:44] **+57 316 6264600:** Torneo Padel and Beer , Miércoles por la noche 🍻💪🍻🎾🍻

---

## 28 de mayo de 2026

[6:36] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO (2 PAREJAS)
LOS ESPERAMOS!!!

[7:45] **+57 312 4036433:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes
🎾

🎾
🎾
 
TORNEO ABIERTO (2 PAREJAS)
LOS ESPERAMOS!!!

[11:53] **Nicolas Cuarta:** 28 DE MAYO🤗

📈 CATEGORIA: 4ta Alta
⌚ 07:30 Pm a 9:00 Pm
📍La pala 

🎾 Nicolas A
🎾 David F
🎾 
🎾 

PARTIDO ABIERTO!!!
(2) PALAS

[12:23] **+57 300 3065645:** 28 DE MAYO🤗

📈 CATEGORIA: 4ta Alta
⌚ 07:30 Pm a 9:00 Pm
📍La pala 

🎾 Nicolas A
🎾 David F
🎾 Juan
🎾 Gio

PARTIDO ABIERTO!!!
(2) PALAS

[12:24] **@lapalaclubdepadel:**
> _+57 300 3065645: 28 DE MAYO🤗

📈 CATEGORIA: 4ta Alta
⌚ 07:30 Pm a 9:00 Pm
📍La pala 

🎾 Nicolas A
🎾 David F
🎾 Juan
🎾 Gio

PARTIDO ABIERTO!!!
(2) PALAS_
Señores que pena con uds, el dia de hoy tenemos un torneo por equipo de mujeres, y no tenemos disponibilidad de canchas a partir de las 6pm

[13:55] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾

🎾
🎾
 
TORNEO ABIERTO (1 PAREJAS)
LOS ESPERAMOS!!!

[19:55] **+57 312 4036433:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾
🎾
 
TORNEO ABIERTO (1 PAREJAS)
LOS ESPERAMOS!!!

---

## 29 de mayo de 2026

[10:25] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  31 de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[11:20] **@iaquintero:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾 Ivan Alonso 
🎾
 
TORNEO ABIERTO (1 PAREJAS)
LOS ESPERAMOS!!!

[13:50] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾 Ivan Alonso 
🎾

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO (2 PAREJAS,  1 PARTNER)
LOS ESPERAMOS!!!

[13:53] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  31 de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Jesus Franco
🟢 Edymar Cabello
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:01] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾 Ivan Alonso 
🎾

🎾Jesus 
🎾Edymar

🎾
🎾
 
TORNEO ABIERTO (1 PAREJAS,  1 PARTNER)
LOS ESPERAMOS!!!

[15:01] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  31 de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[19:33] **+57 301 7112674:** [Imagen] Wilson Bela V3(7 partidos7
800k negociables

[19:34] **+57 301 7112674:** [Imagen]

[19:34] **+57 301 7112674:** [Imagen]

[19:34] **+57 301 7112674:** [Imagen]

[19:34] **+57 301 7112674:** [Imagen]

[19:47] **@lapalaclubdepadel:** Les recordamos a todos que este grupo es exclusivo para compartir torneos.

[21:42] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  31 de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢Esteban D
🟢 Catalina A
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

---

## 30 de mayo de 2026

[7:09] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾 Ivan Alonso 
🎾

🎾Jesus 
🎾Edymar

🎾
🎾
 
TORNEO ABIERTO (1 PAREJAS,  1 PARTNER)
LOS ESPERAMOS!!!

[12:29] __@lapalaclubdepadel añadió a +57 311 5011236__

[12:33] __Alguien añadió a +57 311 5011236__

[12:38] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾 Ivan Alonso 
🎾


 
TORNEO ABIERTO ( 1 PARTNER)
LOS ESPERAMOS!!!

[14:46] **@lapalaclubdepadel:** Hola, buenas tardes!!!
Seguimos en la búsqueda de un participante para nuestro torneo de la tarde - noche. Quién se anima??!!! 🎾✅💪

[15:16] **+57 313 6519397:** Hola, yo podría

[15:20] **+56 9 8218 1963:**
> _+57 313 6519397: Hola, yo podría_
Listo Lida , te esperamos

[15:20] **@lapalaclubdepadel:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾 Ivan Alonso 
🎾 Lida


 
TORNEO CERRADO
LOS ESPERAMOS!!!

[15:20] **+56 9 8218 1963:** ATENCION‼️‼️

TORNEO PADEL SOCIAL PAREJA FIJA POR LA TARDE
 SABADO 30 DE MAYO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚05:00 PM A 07:00 PM
📍 La Pala
💰55k por persona incluye Organización, Bolas  y Rifas 

🎾 Juan D
🎾Daniela P 
 
🎾 Yamil Lesmes✅
🎾 Ivan Guzman

🎾Luis Zerpa
🎾Marco Camacho

🎾 Sebastian F
🎾 Juanes Z
️
🎾 Alejandra Terraza
🎾Sebastian Cortez

🎾Jonny Coronel
🎾Diego Coronel

🎾Milton Puentes✅
🎾Paola Najar

🎾 Ivan Alonso 
🎾Lida Sánchez 


 
TORNEO CERRADO
LOS ESPERAMOS!!!

[15:39] __@lapalaclubdepadel añadió a @ManuelOlivoR__

[19:09] **+57 316 6264600:** [Mensaje de album]

[19:09] **+57 316 6264600:** [Imagen]

[19:09] **+57 316 6264600:** [Imagen]

[19:09] **+57 316 6264600:** [Imagen]

[19:09] **+57 316 6264600:** [Imagen]

[19:09] **+57 316 6264600:** [Mensaje de unknown]

[19:09] **+57 316 6264600:** [Mensaje de unknown]

[19:09] **+57 316 6264600:** [Mensaje de unknown]

[19:10] **+57 316 6264600:** Torneo Américano Sábado por la tarde 💪🎾

[19:38] __@lapalaclubdepadel añadió a +57 322 4098894__

[19:39] __Alguien añadió a +57 322 4098894__

[23:34] **+57 314 3911639:**
> _@lapalaclubdepadel: TORNEO SOCIAL DOMINGO  31 de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢Esteban D
🟢 Catalina A
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Esto sigue?

---

## 31 de mayo de 2026

[7:11] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  31 de MAYO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢
🟢
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[8:19] __[Notificación del sistema]__

[10:13] **+57 316 6264600:** [Mensaje de album]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Mensaje de unknown]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Mensaje de unknown]

[10:13] **+57 316 6264600:** [Mensaje de unknown]

[10:13] **+57 316 6264600:** [Mensaje de unknown]

[10:14] **+57 316 6264600:** Padelennials Domingo por la Mañana 💪🎾🙌

[14:48] **@lapalaclubdepadel:** MAÑANA 01 JUNIO
📈 CATEGORIA: 5ta
⌚ 08:00 Am a 10:30 Am
📍La pala 
💰48K

🎾 Juanda
🎾 Pinto
🎾 Tomas
🎾 

PARTIDO ABIERTO!!!
(1) PALA

[16:22] **@lapalaclubdepadel:** MAÑANA 01 JUNIO
📈 CATEGORIA: 5ta
⌚ 08:00 Am a 09:30 Am
📍La pala 
💰48K

🎾 Juanda
🎾 Pinto
🎾 Tomas
🎾 Felipe

PARTIDO CERRADO!!!
CANCHA 2

[16:46] **@lapalaclubdepadel:** MAÑANA 01 JUNIO
📈 CATEGORIA: 5ta
⌚ 08:00 Am a 10:00 Am
📍La pala 
💰64K

🎾 Juanda
🎾 Pinto
🎾 Tomas
🎾 Felipe

PARTIDO CERRADO!!!
CANCHA 2

---

## 1 de junio de 2026

[6:29] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES 3 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (16) CUPOS LIMITADOS

[9:52] **@lapalaclubdepadel:** 01 DE  JUNIO 🤗

📈 CATEGORIA:FEMENINO C /D 
⌚ 05:00 Pm a 06:00 Pm
📍La pala 

🎾 Angie
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(3) PALAS

[11:49] **@lapalaclubdepadel:** [Imagen]

[11:50] **@lapalaclubdepadel:** El dia de hoy tenemos nuestro torneo interclub P4, comunicarse por privado!

[13:40] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES 3 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Juliana Quintero
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (15) CUPOS LIMITADOS

[13:58] **@alejacastrotorres:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES 3 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Juliana Quintero
🎾 Alejandra Castro 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (15) CUPOS LIMITADOS

[14:20] __@lapalaclubdepadel añadió a +57 300 7662444__

[15:16] **+57 316 6264600:** [Imagen]

[15:17] **+57 316 6264600:** Vamos comunidad anímense falta solo dos jugadores !! Los esperamos 💪

[15:20] __@lapalaclubdepadel añadió a +57 301 4282766__

[15:31] **@lapalaclubdepadel:** 01 DE  JUNIO 
📈 CATEGORIA:MIXTO  C /D  - 5TA / 6TA

⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K
🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[15:51] __@lapalaclubdepadel añadió a @RodrigoDLHB__

[17:45] **@lapalaclubdepadel:** 01 DE  JUNIO 
📈 CATEGORIA:MIXTO  C /D  - 5TA / 6TA

⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K
🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

---

## 2 de junio de 2026

[7:15] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES 3 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Juliana Quintero
🎾 Alejandra Castro 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (14) CUPOS LIMITADOS

[14:34] **@lapalaclubdepadel:** 02 DE  JUNIO 
📈 CATEGORIA:MIXTO  

⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K
🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[14:35] **@lapalaclubdepadel:** 02 DE  JUNIO 
📈 CATEGORIA: 5TA ALTA  

⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K
🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[14:58] **@juancsuarezr:** 02 DE  JUNIO 
📈 CATEGORIA: 5TA ALTA  

⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K
🎾 Gerardo
🎾 Juan Camilo 
🎾 
🎾 

PARTIDO ABIERTO!!!
(4) PALAS

[17:10] **@lapalaclubdepadel:** PARTIDO ABIERTO!!!
(4) PALAS
02 DE JUNIO 
📈 CATEGORIA: 5TA ALTA  

⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K
🎾 Gerardo
🎾 Juan Camilo 
🎾 Daniel
🎾 

PARTIDO ABIERTO!!!
(1) PALA
QUIEN SE ANIMA!

[21:06] **+57 316 6264600:** [Mensaje de album]

[21:06] **+57 316 6264600:** [Imagen]

[21:06] **+57 316 6264600:** [Imagen]

[21:06] **+57 316 6264600:** [Imagen]

[21:06] **+57 316 6264600:** [Imagen]

[21:06] **+57 316 6264600:** [Imagen]

[21:06] **+57 316 6264600:** [Mensaje de unknown]

[21:06] **+57 316 6264600:** [Mensaje de unknown]

[21:06] **+57 316 6264600:** [Mensaje de unknown]

[21:06] **+57 316 6264600:** [Mensaje de unknown]

[21:06] **+57 316 6264600:** Pádel And Wine Martes 🍷💪🍷🎾🍷

[21:11] __@lapalaclubdepadel añadió a @isabellaplazas__

---

## 3 de junio de 2026

[6:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[8:01] **+57 315 3535944:** _Se eliminó este mensaje_

[8:03] **+57 315 3535944:** Buenos días 
 No sé dónde comunicarme . Primero para una clase con Juan José el viernes. Lo segundo es si tienes vigente el horario de 4,30 a 6 de quinta alta ??? Excusa la molestia 
 Y

[8:09] **@lapalaclubdepadel:** Buenos dias! ya nos comunicamos por privado!

[8:09] **+57 315 3535944:** Mil gracias

[12:16] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[15:06] **@lapalaclubdepadel:** ATENCION DAMAS D ‼️‼️‼️
TORNEO AMERICANO🎾

 🗓️ JUEVES 4 DE JUNIO

📈  *Categoría: DAMAS D

⌚ 06:00PM - 7:30PM
📍 La Pala
💰55k por persona 

🎾 Diva
🎾 Olinda
🎾 
🎾 
🎾
🎾 
🎾 
🎾


 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 JUGADORAS )

LAS ESPERAMOS

[15:20] **@lapalaclubdepadel:** ATENCION DAMAS D ‼️‼️‼️
TORNEO AMERICANO🎾

 🗓️ JUEVES 4 DE JUNIO

📈  *Categoría: DAMAS D

⌚ 06:00PM - 7:30PM
📍 La Pala
💰55k por persona 

🎾 Diva
🎾 Olinda
🎾Caro C 
🎾 
🎾
🎾 
🎾 
🎾


 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 JUGADORAS )

LAS ESPERAMOS

[15:56] **@lapalaclubdepadel:** MIERCOLES 03 DE JUNIO 
📈 CATEGORIA: 5TA   
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[15:57] **@lapalaclubdepadel:** MIERCOLES 03 DE JUNIO 
📈 CATEGORIA: 6TA   
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[19:12] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[20:06] **@liniscarrillo:** [Video] 🌎🏆 El Mundial Padelero ya está tomando forma y solo falta una cosa: ¡tu equipo! Reúne a tus jugadores, escoge tu país y prepárate para competir.

⏳ Inscripciones abiertas hasta el 9 de junio.

📲 ¡Inscríbete ahora y asegura tu lugar!

[20:06] **@liniscarrillo:** [Mensaje de unknown]

[21:06] __@lapalaclubdepadel añadió a +57 319 5405771__

[21:35] **+57 316 6264600:** [Mensaje de album]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Mensaje de unknown]

[21:35] **+57 316 6264600:** [Mensaje de unknown]

[21:35] **+57 316 6264600:** [Mensaje de unknown]

[21:35] **+57 316 6264600:** Torneo Padel and Beer Miércoles 🍻💪🍻🎾🍻

[21:37] **+57 318 5373772:** Saludos... Felicitaciones a todos

[21:37] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Paula Nieto
🎾 Nataly Posada

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

---

## 4 de junio de 2026

[6:44] **@lapalaclubdepadel:** JUEVES 04 DE JUNIO 
📈 CATEGORIA: 5TA  ALTA
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[9:22] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  7 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:44] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Paula Nieto
🎾 Nataly Posada

🎾 Gabriel Gutierrez
🎾 Santiago Losada
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[11:27] **@lapalaclubdepadel:** JUEVES 04 DE JUNIO 
📈 CATEGORIA: 5TA  ALTA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[12:06] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[12:09] **@lapalaclubdepadel:** TORNEO AMERICANO DAMAS D
 JUEVES 4 DE JUNIO

📈 *Categoría: DAMAS D

⌚06:00PM - 7:30PM
📍 La Pala
💰55k por persona 

🎾 Diva
🎾 Caro C
🎾Nataly Posada
🎾 Paula Nieto
🎾
🎾 
🎾 
🎾


 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 JUGADORAS )

[12:09] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager_
Sebastian F y Daniel H

[12:10] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[12:38] **@lapalaclubdepadel:** TORNEO AMERICANO DAMAS D
 JUEVES 4 DE JUNIO

📈 *Categoría: DAMAS D

⌚06:00PM - 7:30PM
📍 La Pala
💰55k por persona 

🎾 Diva
🎾 Caro C
🎾Nataly Posada
🎾 Paula Nieto
🎾Laura Lizarazo
🎾 
🎾 
🎾


 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 JUGADORAS )

ANIMENSEE!!

[13:04] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[14:49] **@TomasVilladaBarrios:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾 Juan David
🎾 Tomás 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[14:52] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾 Juan David
🎾 Tomás 

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[15:53] **@lapalaclubdepadel:** [Imagen]

[19:18] __@lapalaclubdepadel añadió a +1 (631) 948-6582__

---

## 5 de junio de 2026

[8:26] **@juansbertran:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[9:23] **+57 313 6519397:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[9:23] **@lapalaclubdepadel:** ATENCION MUJERES‼️‼️‼️

TORNEO AMERICANO DAMAS C

 VIERNES 5 DE JUNIO

📈 *Categoría: DAMAS C

⌚06:00PM - 7:30PM
📍 La Pala
💰55k por persona 

🎾
🎾 
🎾
🎾 
🎾
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾


 
*TORNEO ABIERTO CUPOS LIMITADOS ( 12 JUGADORAS )

ANIMENSEE!!

[10:37] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

🎾Alejandra Terraza
🎾Sebastian Cortez

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[11:37] __@lapalaclubdepadel añadió a +57 304 2631794__

[16:43] **@lapalaclubdepadel:** JUEVES 04 DE JUNIO 
📈 CATEGORIA: 5TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K
🎾 Jose P
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[17:12] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman
 
🎾 Edymar C
🎾 Jesus F

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[17:16] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[17:28] **+57 310 2229667:**
> _@lapalaclubdepadel: Imagen_
Este valor es por una hora, hora y media o dos horas ??

[17:54] **@lapalaclubdepadel:**
> _+57 310 2229667: Este valor es por una hora, hora y media o dos horas ??_
es el valor de la cancha (franja de 1 hora)

[17:57] **@lapalaclubdepadel:** Torneo* PÁDEL AND BEER masculino viernes 5 de junio 7.30pm - 9.30pm. Pareja fija 64K
📍La Pala
🍻suma beer points 
💰64k

🎾Dave / Luis Méndez 
🎾Luis B / Nestor G
🎾 Juan A/Juan Baquero
🎾 Rafael P / Guido M
🎾 Mario Peralta / Mauricio M
🎾 Diego Peña / Ivan A
🎾 Rodrigo D / Camilo E.
🎾 Nicolas P/ Santiago P
🎾 
🎾

faltan 2 parejas
QUIEN SE ANIMA!!!

[21:31] **+57 316 6264600:** [Mensaje de album]

[21:31] **+57 316 6264600:** [Imagen]

[21:31] **+57 316 6264600:** [Imagen]

[21:31] **+57 316 6264600:** [Imagen]

[21:31] **+57 316 6264600:** [Imagen]

[21:31] **+57 316 6264600:** [Mensaje de unknown]

[21:31] **+57 316 6264600:** [Mensaje de unknown]

[21:31] **+57 316 6264600:** [Mensaje de unknown]

[21:32] **+57 316 6264600:** Pádel and Beer , Viernes 🍻💪🎾🍻

---

## 6 de junio de 2026

[7:18] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman 

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H
️
🎾 Luis Zerpa
🎾Marco Camacho

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

🎾
🎾

🎾
🎾
 
🎾 
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[8:31] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman 

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

🎾Luis Zerpa
🎾


*TORNEO ABIERTO CUPOS LIMITADOS (  1 JUGADOR )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/9ff1cbf0-474c-44bf-9902-47b01b0fd7b9?utm_source=manager

[8:54] **@lapalaclubdepadel:** SABADO 6 DE JUNIO 
📈 CATEGORIA: 5TA
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[9:31] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman 

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

🎾Luis Zerpa
🎾Jhonatan Niño


*TORNEO CERRADO LOS ESPERAMOS!

[10:28] **@lapalaclubdepadel:** [Reenviado] [Video]

[10:28] **@lapalaclubdepadel:** [Reenviado] 🎾🔥 ¡Llegó la Liga La Pala! 🔥🎾

Tres meses de competencia, emoción, nuevos retos y mucho pádel te esperan en una experiencia diseñada para que pongas a prueba tu nivel y disfrutes al máximo dentro de la cancha. 💪🏽🏆

Por solo $30.000 por persona podrás ser parte de esta gran liga y vivir cada partido con la pasión que nos caracteriza.

📲 Revisa toda la información en el video e inscríbete antes de que se agoten los cupos.

[10:30] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman 

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

🎾Luis Zerpa
🎾Jhonatan Niño

🎾
🎾

TORNEO ABIERTO

[10:35] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[11:16] **+507 6419-4314:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 6 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Yamil Lesmes✅
🎾 Ivan Guzman 

🎾 Gabriel Gutierrez
🎾 Santiago Losada

🎾 Sebastian F
🎾 Daniel H

🎾 Juan David
🎾 Tomás 

🎾Juan S Bertran 
🎾Juan F Pedraza 

🎾Lida
🎾Carlos 

🎾Luis Zerpa
🎾Jhonatan Niño

🎾mariam 
🎾

TORNEO ABIERTO

[13:37] **+57 316 6264600:** [Mensaje de album]

[13:37] **+57 316 6264600:** [Imagen]

[13:37] **+57 316 6264600:** [Imagen]

[13:37] **+57 316 6264600:** [Imagen]

[13:37] **+57 316 6264600:** [Imagen]

[13:37] **+57 316 6264600:** [Mensaje de unknown]

[13:37] **+57 316 6264600:** [Mensaje de unknown]

[13:37] **+57 316 6264600:** [Mensaje de unknown]

[13:38] **+57 316 6264600:** Americano de los Sábados 💪🎾

[13:46] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[14:01] **@lapalaclubdepadel:** SABADO 6 DE JUNIO 
📈 CATEGORIA: 5TA
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰60K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[14:32] **+57 310 6843763:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Sebastian F y Daniel H

[14:34] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[16:28] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

---

## 7 de junio de 2026

[9:39] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Camilo A
🟢Laura A

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:06] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Camilo A
🟢Laura A

🟢Mauricio Moreno
🟢Juliana Q

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:13] **+57 316 6264600:** [Mensaje de album]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Imagen]

[10:13] **+57 316 6264600:** [Mensaje de unknown]

[10:13] **+57 316 6264600:** [Mensaje de unknown]

[10:13] **+57 316 6264600:** [Mensaje de unknown]

[10:13] **+57 316 6264600:** Torneo Padelennials Domingo por la Mañana 💪🎾💪

[10:22] **+507 6419-4314:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Camilo A
🟢Laura A

🟢Mauricio Moreno
🟢Juliana Q

🟢mariam 
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:25] **+57 320 4233809:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Camilo A
🟢Laura A

🟢Mauricio Moreno
🟢Juliana Q

🟢mariam 
🟢

Lista espera 
Lina Ávila / Mario Peralta 

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:26] **+57 310 6843763:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Camilo A
🟢Laura A

🟢Mauricio Moreno
🟢Juliana Q

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Juanes Z y Alejandro H

[11:55] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Mario P
🟢Lina A

🟢Mauricio Moreno
🟢Juliana Q

🟢mariam 
🟢

Lista espera 
Alejandro H / Juanes Z

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[14:51] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Mario P
🟢Lina A

🟢Mauricio Moreno
🟢Juliana Q

🟢mariam 
🟢Andres Guataqui

Lista espera 
Alejandro H / Juanes Z

*TORNEO CERRADO *
LOS ESPERAMOS!

[18:57] **@lapalaclubdepadel:** lunes 08 DE JUNIO 
📈 CATEGORIA: 5TA
⌚ 09:00 am a 10:00 am
📍La pala 
💰30K
🎾 Arturo
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[19:01] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Mario P
🟢Lina A

🟢Mauricio Moreno
🟢Juliana Q

🟢mariam 
🟢Andres Guataqui

Lista espera 
Alejandro H / Juanes Z
Catalina / Esteban D

*TORNEO CERRADO *
LOS ESPERAMOS!

[19:52] **+57 320 4233809:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢
🟢

🟢Mauricio Moreno
🟢Juliana Q

🟢mariam 
🟢Andres Guataqui

Lista espera 
Alejandro H / Juanes Z
Catalina / Esteban D

*TORNEO CERRADO *
LOS ESPERAMOS!

[19:53] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 8 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Sebastián F
🟢 Daniel H 
 
🟢 Sebastián Cortes
🟢Alejandra Terraza

🟢Juan D
🟢Daniela P

🟢Alejandro H
🟢Juanes Z

🟢Mauricio Moreno
🟢Juliana Q

🟢mariam 
🟢Andres Guataqui

Lista espera 
Catalina / Esteban D

*TORNEO CERRADO *
LOS ESPERAMOS!

---

## 8 de junio de 2026

[9:28] **@lapalaclubdepadel:** lunes 08 DE JUNIO 
📈 CATEGORIA: 5TA/ MIXTO
⌚ 06:00 pm a 8:00 pm
📍La pala 
💰60K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[10:57] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[10:57] **@lapalaclubdepadel:** Buenos dias comunidad!! recuerden nuestra promo!! LOS ESPERAMOS!!

[11:31] **@lapalaclubdepadel:** LUNES FESTIVO! 08 DE JUNIO 
📈 CATEGORIA: 5TA ALTA/4TA
⌚ 01:00 pm a 3:00 pm
📍La pala 
💰60K
🎾 Freddy
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(3) PALAS
QUIEN SE ANIMA

[13:03] **+57 316 6264600:** [Mensaje de album]

[13:03] **+57 316 6264600:** [Imagen]

[13:03] **+57 316 6264600:** [Imagen]

[13:03] **+57 316 6264600:** [Imagen]

[13:03] **+57 316 6264600:** [Imagen]

[13:03] **+57 316 6264600:** [Mensaje de unknown]

[13:03] **+57 316 6264600:** [Mensaje de unknown]

[13:03] **+57 316 6264600:** [Mensaje de unknown]

[13:03] **+57 316 6264600:** Americano Lunes Festivo 💪🎾

[15:47] **@lapalaclubdepadel:** MARTES 9 DE JUNIO 
📈 CATEGORIA: 5TA ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala 
💰62.5K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

---

## 9 de junio de 2026

[6:10] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES 3 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS

[9:20] **@lapalaclubdepadel:** [Imagen]

[9:34] **@lapalaclubdepadel:** MARTES 9 DE JUNIO 
📈 CATEGORIA: 5TA ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala 
💰62.5K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[10:11] __@lapalaclubdepadel añadió a @hernan.higuera1__

[10:54] **+57 301 6599427:**
> _@lapalaclubdepadel: MARTES 9 DE JUNIO 
📈 CATEGORIA: 5TA ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala 
💰62.5K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA_
Freddy Claro

[10:57] **@lapalaclubdepadel:** MARTES 9 DE JUNIO 
📈 CATEGORIA: 5TA ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala 
💰62.5K
🎾 Freddy Claro
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(3) PALAS
QUIEN SE ANIMA

[16:00] **+57 301 6599427:**
> _@lapalaclubdepadel: MARTES 9 DE JUNIO 
📈 CATEGORIA: 5TA ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala 
💰62.5K
🎾 Freddy Claro
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(3) PALAS
QUIEN SE ANIMA_
[Sticker]

[18:12] **+57 316 4728428:** Miércoles 10 de junio  
📈 CATEGORIA: 5TA 
⌚ 06:00 pm a 7:30 pm
📍La pala 
🎾 Douglas
🎾 John Lara
🎾 Juan Guillermo
🎾 
PARTIDO ABIERTO!!! falta 1!

[19:10] **+57 316 4728428:** Miércoles 10 de junio  
📈 CATEGORIA: 5TA 
⌚ 06:00 pm a 7:30 pm
📍La pala 
🎾 Douglas
🎾 John Lara
🎾 Juan Guillermo
🎾 Noe 
PARTIDO CERRADO!!!

[19:11] **@lapalaclubdepadel:**
> _+57 316 4728428: Miércoles 10 de junio  
📈 CATEGORIA: 5TA 
⌚ 06:00 pm a 7:30 pm
📍La pala 
🎾 Douglas
🎾 John Lara
🎾 Juan Guillermo
🎾 Noe 
PARTIDO CERRADO!!!_
CANCHA 3

[20:30] **@carlos.cruz.530111:** [Imagen]

[21:05] **+57 316 6264600:** [Mensaje de album]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:05] **+57 316 6264600:** [Imagen]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:05] **+57 316 6264600:** [Mensaje de unknown]

[21:06] **+57 316 6264600:** Pádel and Wine Martes 🍷💪🍷🎾🍷

[21:40] **+57 315 5758858:** _Se eliminó este mensaje_

---

## 10 de junio de 2026

[7:35] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[8:12] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[10:57] **@lapalaclubdepadel:** MIERCOLES 10 DE JUNIO 
📈 CATEGORIA: 5TA ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰62.5K
🎾 
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(4) PALAS
QUIEN SE ANIMA

[11:11] **+57 315 3599879:** _Se eliminó este mensaje_

[11:14] **@lapalaclubdepadel:** JUEVES 11 DE JUNIO 
📈 CATEGORIA: DAMAS D/6TA
⌚ 05:00 pm a 6:00 pm
📍La pala 
💰32K
🎾 Angelica Herrera
🎾  
🎾
🎾 

PARTIDO ABIERTO!!!
(3) PALAS
QUIEN SE ANIMA

[12:04] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[12:07] **+57 315 5758858:** _Se eliminó este mensaje_

[13:20] **@lapalaclubdepadel:** Miércoles 10 de junio  
📈 CATEGORIA: 5TA 
⌚ 06:00 pm a 7:30 pm
📍La pala 
🎾 Douglas
🎾 Noelia
🎾 Juan Guillermo
🎾 
PARTIDO ABIERTO!!!

[13:27] __@lapalaclubdepadel añadió a +57 320 4116010__

[13:28] __@lapalaclubdepadel añadió a +57 321 5065081__

[15:42] **@lapalaclubdepadel:** Miércoles 10 de junio  
📈 CATEGORIA: 6TA 
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO!!!

[15:52] **@lapalaclubdepadel:** [Reenviado] [Video]

[15:52] **@lapalaclubdepadel:** [Reenviado] 🎾✨ En la Liga La Pala no solo compites y disfrutas del pádel... también puedes vivir experiencias increíbles.

Esta vez, queremos que conozcas cómo es vivir una experiencia VIP en el Movistar Arena para disfrutar de un concierto🎶

¿Quieres ser el próximo ganador? Inscríbete, juega, suma puntos y prepárate para todas las sorpresas que tenemos para ti.

[17:15] **+57 310 8708091:** HOY miércoles 10 de Junio

📈 CATEGORIA: 4ta Alta
⌚ 9:00 Pm a 10:30 Pm
📍La pala 

🎾 Diego V
🎾 Partner 
🎾 Jorge 
🎾 

PARTIDO ABIERTO!!!
Cancha reservada

[20:25] **@lapalaclubdepadel:** MAÑANA JUEVES  11 de Junio
📈 CATEGORIA: DAMAS C
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50
🎾 Miriam 
🎾 Patricia 
🎾  
🎾 

PARTIDO ABIERTO!!!

[21:47] **+57 316 6264600:** [Mensaje de album]

[21:47] **+57 316 6264600:** [Imagen]

[21:47] **+57 316 6264600:** [Imagen]

[21:47] **+57 316 6264600:** [Imagen]

[21:47] **+57 316 6264600:** [Imagen]

[21:47] **+57 316 6264600:** [Mensaje de unknown]

[21:47] **+57 316 6264600:** [Mensaje de unknown]

[21:47] **+57 316 6264600:** [Mensaje de unknown]

[21:47] **+57 316 6264600:** Torneo Padel And Beer , Miércoles por la Noche 🍻💪🍻🎾🍻

---

## 11 de junio de 2026

[10:04] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[10:18] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 
 
🎾 Andres Barros
🎾 Carlos Quintana

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[10:53] **@lapalaclubdepadel:** MAÑANA JUEVES  11 de Junio
📈 CATEGORIA: DAMAS C
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50
🎾 Miriam 
🎾 Patricia 
🎾  
🎾 

PARTIDO ABIERTO!!!

[14:17] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[14:34] **@lapalaclubdepadel:** JUEVES  11 de JUNIO
📈 CATEGORIA: 5ta Alta
⌚ 7:30 Pm a 9:00 Pm
📍La pala 
💰62.5k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[14:34] **+57 301 6599427:**
> _@lapalaclubdepadel: JUEVES  11 de JUNIO
📈 CATEGORIA: 5ta Alta
⌚ 7:30 Pm a 9:00 Pm
📍La pala 
💰62.5k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!_
Freddy Claro

[14:35] **@lapalaclubdepadel:** JUEVES  11 de JUNIO
📈 CATEGORIA: 5ta Alta
⌚ 7:30 Pm a 9:00 Pm
📍La pala 
💰62.5k
🎾Freddy Claro
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[14:42] **@lapalaclubdepadel:** JUEVES  11 de JUNIO
📈 CATEGORIA: 5ta Alta
⌚ 7:30 Pm a 9:00 Pm
📍La pala 
💰62.5k
🎾Freddy Claro
🎾 Oscar Morales
🎾  
🎾 

PARTIDO ABIERTO!!!

[15:48] **@lapalaclubdepadel:** JUEVES  11 de Junio
📈 CATEGORIA: DAMAS C
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50
🎾 Miriam 
🎾 Patricia 
🎾  cristian 
🎾 pedro 

PARTIDO CERRADO!!!
CANCHA 2

[15:54] **@lapalaclubdepadel:** JUEVES  11 de JUNIO
📈 CATEGORIA: 6TA 
⌚ 09:30 Pm a 10:30 Pm
📍La pala 
💰50k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[15:54] **@lapalaclubdepadel:** JUEVES  11 de JUNIO
📈 CATEGORIA: 5TA 
⌚ 09:30 Pm a 10:30 Pm
📍La pala 
💰50k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[16:00] **@ccmo_1030:** JUEVES  11 de JUNIO
📈 CATEGORIA: 5ta Alta
⌚ 7:30 Pm a 9:00 Pm
📍La pala 
💰62.5k
🎾Freddy Claro
🎾 Oscar Morales
🎾  Cristian 
🎾  Pedro 

PARTIDO ABIERTO!!!

[16:02] **@lapalaclubdepadel:**
> _@ccmo_1030: JUEVES  11 de JUNIO
📈 CATEGORIA: 5ta Alta
⌚ 7:30 Pm a 9:00 Pm
📍La pala 
💰62.5k
🎾Freddy Claro
🎾 Oscar Morales
🎾  Cristian 
🎾  Pedro 

PARTIDO ABIERTO!!!_
cancha 1
los esperamos!

[19:15] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren
 
🎾 Andres Barros
🎾 Carlos Quintana

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[20:24] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren
 
🎾 Andres Barros
🎾 Carlos Quintana

🎾Henrry C ✅
🎾Valeria J

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

---

## 12 de junio de 2026

[7:19] **@lapalaclubdepadel:** VIERNES 12 de JUNIO
📈 CATEGORIA: 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[7:37] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  14 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:19] **@lapalaclubdepadel:** VIERNES 12 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[10:21] **@lapalaclubdepadel:** [Imagen]

[11:08] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[12:55] **@lapalaclubdepadel:** Buenas tardes comunidad el dia de hoy se liberaron canchas y disponibles 7:30pm hasta las 9:00pm 50k por persona

[13:01] **@lapalaclubdepadel:** VIERNES 12 de JUNIO
📈 CATEGORIA: 4ta 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k
🎾Juan S Lopez
🎾 Julian Prieto
🎾  
🎾 

PARTIDO ABIERTO!!!

[13:04] **@lapalaclubdepadel:** VIERNES 12 de JUNIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k
🎾
🎾
🎾  
🎾 

PARTIDO ABIERTO!!!

[14:05] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[14:05] **@lapalaclubdepadel:** [Imagen]

[14:21] **@lapalaclubdepadel:** [Imagen]

[15:49] **@maozar777:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Mauricio S
🎾 Pedro A 
️
🎾 
🎾

🎾
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[17:02] **+57 317 5110861:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Mauricio S
🎾 Pedro A 
️
🎾 Ale 
🎾 JuanCa

🎾
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[17:33] **+57 310 6843763:**
> _+57 317 5110861: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Mauricio S
🎾 Pedro A 
️
🎾 Ale 
🎾 JuanCa

🎾
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager_
Sebastian F

[17:34] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Mauricio S
🎾 Pedro A 
️
🎾 Ale 
🎾 JuanCa

🎾 Sebastian F
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[17:37] **+57 310 8800142:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Mauricio S
🎾 Pedro A 
️
🎾 Ale 
🎾 JuanCa

🎾 Sebastian F
🎾 William Rodríguez 

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[17:38] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Mauricio S
🎾 Pedro A 
️
🎾 Ale 
🎾 JuanCa

🎾 Sebastian F
🎾 William Rodríguez 

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/1678b44f-b1f4-48af-8c26-52f242e3cb59?utm_source=manager

[19:48] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Mauricio S
🎾 Pedro A 
️
🎾 Ale 
🎾 JuanCa

🎾 Sebastian F
🎾 William Rodríguez 

🎾Esteban D
🎾Catalina A
 
TORNEO CERRADO
LOS ESPERAMOS!

---

## 13 de junio de 2026

[8:19] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:11] **+65 9138 2902:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:16] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:24] **@lapalaclubdepadel:** SABADO 13 de JUNIO
📈 CATEGORIA: 5ta
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾
🎾
🎾  
🎾 

PARTIDO ABIERTO!!!

[9:29] **@lapalaclubdepadel:** SABADO 13 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾
🎾
🎾  
🎾 

PARTIDO ABIERTO!!!

[9:33] **+52 1 55 4924 0426:** SABADO 13 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾 karla F 
🎾
🎾  
🎾 

PARTIDO ABIERTO!!!

[9:45] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Freddy
🎾 
️
🎾 Ale 
🎾 JuanCa

🎾 Sebastian F
🎾 William Rodríguez 

🎾Esteban D
🎾Catalina A
 
TORNEO ABIERTO 1 CUPO
LOS ESPERAMOS!

[9:49] **@maozar777:** Pedro y Mauricio podemos jugar hay campo ?

[10:11] **@lapalaclubdepadel:** tenemos un cupo disponible

[10:20] **@iaquintero:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Freddy
🎾 Ivan A

🎾 Ale 
🎾 JuanCa

🎾 Sebastian F
🎾 William Rodríguez 

🎾Esteban D
🎾Catalina A
 
TORNEO ABIERTO 1 CUPO
LOS ESPERAMOS!

[10:22] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 13 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Maria Moreno
🎾 Viren

🎾Henrry C ✅
🎾Valeria J

🎾 Freddy
🎾 Ivan A

🎾 Ale 
🎾 JuanCa

🎾 Sebastian F
🎾 William Rodríguez 

🎾Esteban D
🎾Catalina A
 
TORNEO CERRADO
LOS ESPERAMOS!

[13:16] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[13:39] **+57 316 6264600:** [Mensaje de album]

[13:39] **+57 316 6264600:** [Imagen]

[13:39] **+57 316 6264600:** [Imagen]

[13:39] **+57 316 6264600:** [Imagen]

[13:39] **+57 316 6264600:** [Imagen]

[13:39] **+57 316 6264600:** [Mensaje de unknown]

[13:39] **+57 316 6264600:** [Mensaje de unknown]

[13:39] **+57 316 6264600:** [Mensaje de unknown]

[13:39] **+57 316 6264600:** Americano de los Sábados 💪🎾

[13:50] __@lapalaclubdepadel añadió a +1 (352) 615-0721__

[13:50] __Alguien añadió a +1 (352) 615-0721__

[13:50] __+34 672 15 30 49 salieron__

[14:30] **@lapalaclubdepadel:** SABADO 13 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰60k
🎾
🎾
🎾  
🎾 

PARTIDO ABIERTO!!!

[14:37] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[16:25] __@jorge.mesa se unieron mediante el enlace de invitación__

[17:02] **+57 301 6599427:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Freddy Claro

[17:08] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (2 PAREJAS  Y 1 JUGADOR)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[17:40] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢

🟢Luis Zerpa
🟢Marco Camacho

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (1 PAREJAS  Y 1 JUGADOR)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[18:20] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢

🟢Luis Zerpa
🟢Marco Camacho

🟢Oscar M
🟢 Freddy C

TORNEO ABIERTO CUPOS LIMITADOS  (1 JUGADOR)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[19:18] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢
🟢 

TORNEO ABIERTO CUPOS LIMITADOS  (1 PAREJA)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[19:32] **+1 (352) 615-0721:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 

TORNEO ABIERTO CUPOS LIMITADOS  (1 PAREJA)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[19:35] **@lapalaclubdepadel:** SABADO 13 de JUNIO
📈 CATEGORIA: 3ra - 4ta
⌚ 10:00 am a 11:30 Pm
📍La pala 
💰45k
🎾 Daniel Forero
🎾 Jaime Solano
🎾  
🎾 

PARTIDO ABIERTO!!!

[20:23] **+57 310 2123180:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Carlos R

TORNEO ABIERTO CUPOS LIMITADOS  (1 PAREJA)
ANIMO NO TE QUEDES SIN PARTICIPAR!

---

## 14 de junio de 2026

[6:56] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Carlos R

TORNEO CERRADO
LOS ESPERAMOS!

[8:06] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[8:06] **+57 310 5686837:** Ufff que rico

[10:16] **+57 316 6264600:** [Mensaje de album]

[10:16] **+57 316 6264600:** [Imagen]

[10:16] **+57 316 6264600:** [Imagen]

[10:16] **+57 316 6264600:** [Imagen]

[10:16] **+57 316 6264600:** [Imagen]

[10:16] **+57 316 6264600:** [Imagen]

[10:16] **+57 316 6264600:** [Mensaje de unknown]

[10:16] **+57 316 6264600:** [Mensaje de unknown]

[10:16] **+57 316 6264600:** [Mensaje de unknown]

[10:16] **+57 316 6264600:** [Mensaje de unknown]

[10:17] **+57 316 6264600:** Torneo Padelennials Domingo por la Mañana 🙌💪🎾

[15:50] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 

TORNEO ABIERTO
FALTA 1 PALA

[16:39] __@lapalaclubdepadel añadió a +57 323 2241877__

[16:44] **@lapalaclubdepadel:** DOMINGO 13 de JUNIO
📈 CATEGORIA: 5ta
⌚ 07:00 Pm a 08:00 Pm
📍La pala 
💰30k
🎾 Andres Higuera
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

---

## 15 de junio de 2026

[0:01] **@jucaalpa:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Juan Alvarez

TORNEO ABIERTO
FALTA 1 PALA

[7:10] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Yamil Lesmes✅
🟢Ivan Guzman

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Juan Alvarez

TORNEO CERRADO
LOS ESPERAMOS!!!

[8:27] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 
🟢 

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Juan Alvarez

TORNEO ABIERTO (1 PAREJA)
LOS ESPERAMOS!!!

[9:15] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Rafael Vanegas 
🟢 

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Juan Alvarez

TORNEO ABIERTO (1 JUGADOR)
LOS ESPERAMOS!!!

[9:16] **+57 320 4233809:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Rafael Vanegas 
🟢 Lina Ávila 

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Juan Alvarez

TORNEO ABIERTO (1 JUGADOR)
LOS ESPERAMOS!!!

[9:19] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 15 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Viren
🟢 Iriana
 
🟢 Rafael Vanegas 
🟢 Lina Ávila 

🟢 Henrry
🟢Valeria 

🟢 Freddy Claro
🟢 Oscar M

🟢Luis Zerpa
🟢Marco Camacho

🟢 Sandra 
🟢 Juan Alvarez

TORNEO CERRADO
LOS ESPERAMOS!!!

[10:35] **@lapalaclubdepadel:** LUNES 15 de JUNIO
📈 CATEGORIA: 5ta / 6ta - Damas C - Damas D
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾 
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[10:36] **@lapalaclubdepadel:** LUNES 15 de JUNIO
📈 CATEGORIA: 5ta / 6ta - Damas C - Damas D
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰60k
🎾 
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[10:39] **+54 9 2634 68-2037:** LUNES 15 de JUNIO
📈 CATEGORIA: 5ta / 6ta - Damas C - Damas D
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾 Stephanie
🎾 Julieta
🎾  
🎾 

PARTIDO ABIERTO!!!

[10:40] **@lapalaclubdepadel:** LUNES 15 de JUNIO
📈 CATEGORIA: 5ta / 6ta - Damas C - Damas D
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾 Stephanie
🎾 Julieta
🎾  
🎾 
FALTAN (2) PALAS
PARTIDO ABIERTO!!!

[10:51] **+57 317 3727529:** LUNES 15 de JUNIO
📈 CATEGORIA: 5ta / 6ta - Damas C - Damas D
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾 Stephanie
🎾 Julieta
🎾  Laura 
🎾 
FALTAN (2) PALAS
PARTIDO ABIERTO!!!

[10:51] **@lapalaclubdepadel:** LUNES 15 de JUNIO
📈 CATEGORIA: 5ta / 6ta - Damas C - Damas D
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k
🎾 Stephanie
🎾 Julieta
🎾  Laura 
🎾 
FALTAN (1) PALA
PARTIDO ABIERTO!!!

[13:16] **+57 316 6264600:** [Mensaje de album]

[13:16] **+57 316 6264600:** [Imagen]

[13:16] **+57 316 6264600:** [Imagen]

[13:16] **+57 316 6264600:** [Imagen]

[13:16] **+57 316 6264600:** [Imagen]

[13:16] **+57 316 6264600:** [Imagen]

[13:16] **+57 316 6264600:** [Mensaje de unknown]

[13:17] **+57 316 6264600:** [Mensaje de unknown]

[13:17] **+57 316 6264600:** [Mensaje de unknown]

[13:17] **+57 316 6264600:** [Mensaje de unknown]

[13:17] **+57 316 6264600:** Torneo Americano Lunes festivo 🙌💪🎾

---

## 16 de junio de 2026

[7:31] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/33c4100f-81ad-41d4-9fcb-130359e7842b?utm_source=manager

[7:35] **+65 9138 2902:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/33c4100f-81ad-41d4-9fcb-130359e7842b?utm_source=manager

[8:28] **@lapalaclubdepadel:** MARTES 16 de JUNIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[8:49] **+57 315 9279497:** MARTES 16 de JUNIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k
🎾 Ricardo P
🎾 Leandro
🎾 Jose B
🎾 

PARTIDO ABIERTO!!!

[8:51] **@lapalaclubdepadel:** MARTES 16 de JUNIO
📈 CATEGORIA: mixto
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[10:27] **@nanjovas:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 Nancy
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/33c4100f-81ad-41d4-9fcb-130359e7842b?utm_source=manager

[11:21] __@lapalaclubdepadel añadió a @cinthyadussan__

[11:25] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 Nancy
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (10) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/545533c8-f6f9-4645-bcc2-f0fd65f82493?utm_source=manager

[13:32] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 Nancy
🎾 cinthya
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (09) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/545533c8-f6f9-4645-bcc2-f0fd65f82493?utm_source=manager

[14:08] **+57 323 2241877:** MARTES 16 de JUNIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k
🎾 Ricardo P
🎾 Leandro
🎾 Jose B
🎾 Andrés H

PARTIDO ABIERTO!!!

[14:17] **@lapalaclubdepadel:** MARTES 16 de JUNIO
📈 CATEGORIA: mixto
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[14:53] **+57 323 4375935:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[14:53] **+57 323 4375935:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[14:53] **+57 323 4375935:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[14:56] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[14:58] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:59] **@lapalaclubdepadel:** [Reenviado] 🎾🔥 ¡Este junio juega más por menos!

Aprovecha nuestra promoción especial en reserva de cancha de 6:00 p.m. a 7:30 p.m. y de 9:00 p.m. a 10:30 p.m. por solo $50.000 por persona.

Reúne a tu parche, reserva tu cancha y disfruta más tiempo de pádel en La Pala. 💥

📲 Reserva ahora y asegura tu horario

[14:59] **@lapalaclubdepadel:** MARTES 16 de JUNIO
📈 CATEGORIA: 5ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k
🎾Freddy
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[15:36] **@lapalaclubdepadel:** MARTES 16 de JUNIO
📈 CATEGORIA: 5ta ALTA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k
🎾Freddy
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[15:54] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 Nancy
🎾 cinthya
🎾 Juan Manuel✅
🎾 Santiago✅
🎾 Nelson✅
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (06) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/545533c8-f6f9-4645-bcc2-f0fd65f82493?utm_source=manager

[15:55] **@nanjovas:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 cinthya
🎾 Juan Manuel✅
🎾 Santiago✅
🎾 Nelson✅
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (06) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/545533c8-f6f9-4645-bcc2-f0fd65f82493?utm_source=manager

[18:47] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 cinthya
🎾 Juan Manuel✅
🎾 Santiago✅
🎾 Nelson✅
🎾 Pipe
🎾 Valentina
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (04) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/545533c8-f6f9-4645-bcc2-f0fd65f82493?utm_source=manager

[19:33] **@lapalaclubdepadel:** [Reenviado] [Video]

[19:33] **@lapalaclubdepadel:** [Mensaje de unknown]

[20:24] **@nanjovas:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  17 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Viren
🎾 cinthya
🎾 Juan Manuel✅
🎾 Santiago✅
🎾 Nelson✅
🎾 Pipe
🎾 Valentina
🎾 Nancy V 
🎾
🎾
🎾
🎾
 
TORNEO ABIERTO (04) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/545533c8-f6f9-4645-bcc2-f0fd65f82493?utm_source=manager

[21:08] **+57 316 6264600:** [Mensaje de album]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Imagen]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:08] **+57 316 6264600:** [Mensaje de unknown]

[21:09] **+57 316 6264600:** Torneo Padel and Wine Martes 🍷💪🍷🎾🍷

---

## 17 de junio de 2026

[7:03] **@lapalaclubdepadel:** [Reenviado] [Video]

[7:03] **@lapalaclubdepadel:** [Mensaje de unknown]

[7:50] **+57 316 6264600:** [Mensaje de album]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Mensaje de unknown]

[7:50] **+57 316 6264600:** [Mensaje de unknown]

[7:52] **+57 316 6264600:** Americano Madrugadores Miércoles ☕️🥖🎾💪

[8:08] **+57 316 2985422:** Hoy si amanecí descansadita

[8:13] **@patfadul:**
> _+57 316 2985422: Hoy si amanecí descansadita_
[Sticker]

[9:23] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[10:09] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[10:09] __@lapalaclubdepadel añadió a +57 310 6137662__

[10:38] **+57 310 8800142:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 
 
🎾 Gustavo
🎾 William Rodríguez 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[10:46] **@lapalaclubdepadel:** MIERCOLES 17 de JUNIO
📈 CATEGORIA: 5TA
⌚ 04:00 Pm a 6:00 Pm
📍La pala 
💰60k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[10:49] **@lapalaclubdepadel:** MIERCOLES 17 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 04:00 Pm a 6:00 Pm
📍La pala 
💰60k
🎾
🎾 
🎾  
🎾 

PARTIDO ABIERTO!!!

[10:52] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[11:09] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾 Viren
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[19:21] **@rvanegasa:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾 Viren
🎾 
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[21:02] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 Viren
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

---

## 18 de junio de 2026

[6:07] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 Viren
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jonathan
🎾Leidy Diaz

🎾Oscar 
🎾Freddy

🎾Luiz Zerpa
🎾Marco Camacho

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[8:07] **@lapalaclubdepadel:** JUEVES 18 de JUNIO
📈 CATEGORIA: 5TA/6TA
⌚ 12:00 Pm a 2:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[8:32] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[8:43] **@lapalaclubdepadel:** JUEVES 18 de JUNIO
📈 CATEGORIA: 5TA ALTA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Freddy
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[8:51] __@lapalaclubdepadel eliminó a +57 318 3157601__

[10:25] **@lapalaclubdepadel:** JUEVES 18 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Freddy
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[10:33] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[13:19] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 Viren
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jonathan
🎾Leidy Diaz

🎾Oscar 
🎾Freddy

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[13:57] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 Viren
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jonathan
🎾Leidy Diaz

🎾Oscar 
🎾Freddy

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾Ivan Guzman
🎾Yamil Lesmes

 
TORNEO CERRADO
LOS ESPERAMOS!
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/b7de5a3b-ff91-41dd-9d82-ce69f70dbb18?utm_source=manager

[14:50] **+57 301 6599427:** [Reenviado] JUEVES 18 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Freddy
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[15:11] **@lapalaclubdepadel:** JUEVES 18 de JUNIO
📈 CATEGORIA: DAMAS C/D
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[17:18] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[21:50] **+57 316 6264600:** [Mensaje de album]

[21:50] **+57 316 6264600:** [Imagen]

[21:50] **+57 316 6264600:** [Imagen]

[21:50] **+57 316 6264600:** [Imagen]

[21:50] **+57 316 6264600:** [Imagen]

[21:50] **+57 316 6264600:** [Imagen]

[21:50] **+57 316 6264600:** [Mensaje de unknown]

[21:50] **+57 316 6264600:** [Mensaje de unknown]

[21:50] **+57 316 6264600:** [Mensaje de unknown]

[21:50] **+57 316 6264600:** [Mensaje de unknown]

[21:50] **+57 316 6264600:** Pádel and Beer , jueves por la noche 🍻💪🍻🎾🍻

---

## 19 de junio de 2026

[7:54] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[8:04] **+57 320 8584974:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[8:21] **+65 9138 2902:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Viren
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[8:51] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[8:51] **@lapalaclubdepadel:** [Reenviado] 🎾🔥 ¡Este junio juega más por menos!

Aprovecha nuestra promoción especial en reserva de cancha de 6:00 p.m. a 7:30 p.m. y de 9:00 p.m. a 10:30 p.m. por solo $50.000 por persona.

Reúne a tu parche, reserva tu cancha y disfruta más tiempo de pádel en La Pala. 💥

📲 Reserva ahora y asegura tu horario

[9:11] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Viren
🟢

🟢Alejandra T
🟢Sebastian C

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:24] **@lapalaclubdepadel:** VIERNES 19 de JUNIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[11:27] **@lapalaclubdepadel:** VIERNES 19 de JUNIO
📈 CATEGORIA: 5ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[12:12] **@rperdomo3:** VIERNES 19 de JUNIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Rafael P
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[12:37] **+57 320 4233809:** VIERNES 19 de JUNIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Rafael P
🇨🇴 Lina Ávila 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[14:53] **@lapalaclubdepadel:** VIERNES 19 de JUNIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Rafael P
🇨🇴 Lina Ávila 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[14:58] **@alejandromusical:** VIERNES 19 de JUNIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Rafael P
🇨🇴 Lina Ávila 
🇨🇴 David F
🇨🇴 Alejandro C

PARTIDO CERRADO!!!

[15:14] **@lapalaclubdepadel:**
> _@alejandromusical: VIERNES 19 de JUNIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Rafael P
🇨🇴 Lina Ávila 
🇨🇴 David F
🇨🇴 Alejandro C

PARTIDO CERRADO!!!_
cancha # 5 los esperamos!

[17:17] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Viren
🟢

🟢Alejandra T
🟢Sebastian C

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[17:23] **+65 9138 2902:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢
🟢

🟢Alejandra T
🟢Sebastian C

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE

[18:21] **@lapalaclubdepadel:** VIERNES 19 de JUNIO
📈 CATEGORIA: MIXTO C/D 5TA - 6TA
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO CERRADO!!!

[19:42] **@alejandromusical:** VIERNES 19 de JUNIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Rafael P
🇨🇴 Lina Ávila 
🇨🇴 David F
🇨🇴 Alejandro C

PARTIDO CERRADO!!!

[20:46] __@lapalaclubdepadel añadió a +57 316 3358569__

[23:38] **@luismilanaob:** [Imagen]

[23:38] **@luismilanaob:** [Imagen] Vendo Nox EA10 2026 12k 800k , detalle de pintura, NO ES FISURA para más detalle dm

[23:38] **@luismilanaob:** [Video]

---

## 20 de junio de 2026

[7:49] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾 Viren
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jonathan
🎾Leidy Diaz

🎾Oscar 
🎾Freddy

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾Ivan Guzman
🎾Yamil Lesmes

 
TORNEO CERRADO
LOS ESPERAMOS!

[8:31] **@lapalaclubdepadel:** SABADO 20 de JUNIO
📈 CATEGORIA: 5TA
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[8:57] **@lapalaclubdepadel:** SABADO 20 de JUNIO
📈 CATEGORIA: MIXTO
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[9:04] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jonathan
🎾Leidy Diaz

🎾Oscar 
🎾Freddy

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾Ivan Guzman
🎾Yamil Lesmes

 
TORNEO CERRADO
LOS ESPERAMOS!

[9:06] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾Freddy
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jonathan
🎾Leidy Diaz

🎾
🎾

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾Ivan Guzman
🎾Yamil Lesmes

 
TORNEO ABIERTO (1 PAREJA)
LOS ESPERAMOS!

[9:10] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾Freddy
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jonathan
🎾Leidy Diaz

🎾Claudia 
🎾Claudio

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾Ivan Guzman
🎾Yamil Lesmes

 
TORNEO CERRADO
LOS ESPERAMOS!

LISTA DE ESPERA
🎾Jean Michel
🎾

🎾
🎾

[9:43] **@lapalaclubdepadel:** [Video]

[9:58] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾Freddy
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jean Michel
🎾

🎾Claudia 
🎾Claudio

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾Ivan Guzman
🎾Yamil Lesmes

 
TORNEO ABIERTO
LOS ESPERAMOS!

LISTA DE ESPERA
🎾
🎾

🎾
🎾

[10:04] **+57 315 8898433:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[10:16] **@iaquintero:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 20 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Ricardo Gallo✅
🎾Freddy
 
🎾 Gustavo
🎾 William Rodríguez 

🎾Stephanie✅
🎾Julieta

🎾Jonathan N 
🎾 Leidy D
️
🎾 Rafael Vanegas
🎾 Lina Ávila

🎾Jean Michel
🎾 Ivan A 

🎾Claudia 
🎾Claudio

🎾Luiz Zerpa
🎾Marco Camacho

🎾Cinthya D
🎾Biviana M

🎾Ivan Guzman
🎾Yamil Lesmes

 
TORNEO ABIERTO
LOS ESPERAMOS!

LISTA DE ESPERA
🎾
🎾

🎾
🎾

[10:45] **@julian_andrade10:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[10:45] **@julian_andrade10:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[10:45] **@julian_andrade10:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[10:45] **@julian_andrade10:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[12:02] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Sabado 20 de Junio !! 
📈 *Categoría: 5-6 / C-D
⌚6:00 PM A 8:00PM
📍 La Pala
💰50K 


🎾 Adri
🎾Diani
🎾Jorge
🎾 Yamil

🎾 Arturo
🎾 Johana 
🎾
🎾

🎾
🎾
🎾
🎾


Familia, amigos, todos bienvenidos pre votaciones cruciales 💞🙂🙃🫡

[12:17] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢Roberto Contreras
🟢

🟢Alejandra T
🟢Sebastian C

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE

[12:44] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[13:34] **+57 316 6264600:** [Mensaje de album]

[13:34] **+57 316 6264600:** [Imagen]

[13:34] **+57 316 6264600:** [Imagen]

[13:34] **+57 316 6264600:** [Imagen]

[13:34] **+57 316 6264600:** [Imagen]

[13:34] **+57 316 6264600:** [Mensaje de unknown]

[13:34] **+57 316 6264600:** [Imagen]

[13:34] **+57 316 6264600:** [Mensaje de unknown]

[13:34] **+57 316 6264600:** [Mensaje de unknown]

[13:34] **+57 316 6264600:** [Mensaje de unknown]

[13:34] **+57 316 6264600:** Torneo Americano Sábado 🙌💪🎾

[13:45] **@lapalaclubdepadel:** SABADO 20 de JUNIO
📈 CATEGORIA: 5ta
⌚ 03:00 Pm a 04:30 Pm
📍La pala 
💰50k

🇨🇴 Gustavo
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[14:36] **@lapalaclubdepadel:** SABADO 20 de JUNIO
📈 CATEGORIA: 5ta / 6ta | Damas D / Damas C
⌚ 04:00 Pm a 6:00 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[14:36] **@lapalaclubdepadel:** SABADO 20 de JUNIO
📈 CATEGORIA: 5ta / 6ta | Damas D / Damas C
⌚ 6:00 Pm a 8:00 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[15:00] **+57 318 5423534:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢Roberto Contreras
🟢

🟢Alejandra T
🟢Sebastian C

🟢Daniela HC 
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE

[15:04] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢Roberto Contreras
🟢

🟢Alejandra T
🟢Sebastian C

🟢Daniela HC 
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (2 PAREJAS Y 2 JUGADOR)
ANIMO NO TE QUEDES AFUERA

[17:23] **@lapalaclubdepadel:** [Reenviado] [Video]

[17:23] **@lapalaclubdepadel:** ⚽🇨🇴 Este martes 23 de junio, vive toda la emoción de Colombia en La Pala. Reúne a tus amigos, disfruta el mejor ambiente mundialista y alienta a la Selección con nosotros.

Y recuerda: durante todo el Mundial, el parqueadero es GRATIS para nuestros visitantes. 🚗🙌

📍Te esperamos para vivir cada gol, cada jugada y cada emoción como se debe.

[18:48] __@mateofernandeztarazona se unieron mediante el enlace de invitación__

[18:49] __Alguien añadió a @mateofernandeztarazona__

---

## 21 de junio de 2026

[8:04] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  21 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢Roberto Contreras
🟢Daniela HC

🟢Alejandra T
🟢Sebastian C

🟢Jonathan N
🟢Leidy

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (2 PAREJAS Y 2 JUGADOR)
ANIMO NO TE QUEDES AFUERA

[8:20] __@lapalaclubdepadel añadió a +57 310 3029444__

[10:15] **+57 316 6264600:** [Mensaje de album]

[10:15] **+57 316 6264600:** [Imagen]

[10:15] **+57 316 6264600:** [Imagen]

[10:15] **+57 316 6264600:** [Imagen]

[10:15] **+57 316 6264600:** [Imagen]

[10:15] **+57 316 6264600:** [Mensaje de unknown]

[10:15] **+57 316 6264600:** [Mensaje de unknown]

[10:15] **+57 316 6264600:** [Mensaje de unknown]

[10:15] **+57 316 6264600:** Padelennials Domingo por la Mañana 💪🎾

[13:13] __@lapalaclubdepadel añadió a @Jhonnathang__

[13:13] __Alguien añadió a @Jhonnathang__

[13:30] **+57 316 6264600:** [Mensaje de album]

[13:30] **+57 316 6264600:** [Imagen]

[13:30] **+57 316 6264600:** [Imagen]

[13:30] **+57 316 6264600:** [Imagen]

[13:30] **+57 316 6264600:** [Imagen]

[13:30] **+57 316 6264600:** [Mensaje de unknown]

[13:30] **+57 316 6264600:** [Mensaje de unknown]

[13:30] **+57 316 6264600:** [Mensaje de unknown]

[13:30] **+57 316 6264600:** Americano Domingo 🙌💪🎾

[16:49] **@szuleta_1:** [Imagen] À la venta talla 8 M

[16:49] **@szuleta_1:** [Imagen] Talla 6W

[16:49] **@szuleta_1:** [Imagen] Talla 8M y 9M

[16:51] **@lapalaclubdepadel:** hola buenas tardes, por favor se les recuerda que el grupo es para programar partidos.

[16:54] **@lapalaclubdepadel:** DOMINGO 21 de JUNIO
📈 CATEGORIA:MIXTO Damas D - 6TA 
⌚ 6:00 Pm a 8:00 Pm
📍La pala 
💰50k

🇨🇴 Maria Fernanda
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!

[16:56] __@lapalaclubdepadel añadió a @mariafernandamrrr__

---

## 22 de junio de 2026

[6:54] __@lapalaclubdepadel añadió a +52 1 998 242 1401__

[10:04] **@lapalaclubdepadel:** LUNES 22 de JUNIO
📈 CLASE DIRIGIDA máximo 3 perosonas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Víctor Hugo 
🇨🇴 
🇨🇴
🇨🇴

*CLASE ABIERTA!!!

[10:05] **@lapalaclubdepadel:** LUNES 22 de JUNIO
📈 CLASE DIRIGIDA máximo 3 perosonas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Gero 
🇨🇴 
🇨🇴
🇨🇴

*CLASE ABIERTA!!!

[10:07] **+57 316 4917185:** LUNES 22 de JUNIO
📈 CLASE DIRIGIDA máximo 3 perosonas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Gero 
🇨🇴 Paolo 
🇨🇴
🇨🇴

*CLASE ABIERTA!!!

[15:00] **@lapalaclubdepadel:** LUNES 22 de JUNIO
📈 CATEGORIA 5TA - 6TA 
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

*CLASE ABIERTA!!!

[16:17] **@SergioRengifoC:** LUNES 22 de JUNIO
📈 CLASE DIRIGIDA máximo 3 perosonas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Gero 
🇨🇴 Paolo 
🇨🇴 Sergio R.
🇨🇴

*CLASE ABIERTA!!!

[16:37] **+57 310 3029444:** LUNES 22 de JUNIO
📈 CLASE DIRIGIDA máximo 3 perosonas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Gero 
🇨🇴 Paolo 
🇨🇴 Sergio R.
🇨🇴Sebastian C. 

*CLASE ABIERTA!!!

[16:40] **@lapalaclubdepadel:** LUNES 22 de JUNIO
📈 CLASE DIRIGIDA máximo 3 perosonas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Gero 
🇨🇴 Paolo 
🇨🇴 Sergio R.
🇨🇴Sebastian C. 

CLASE CERRADA
CANCHA 3

[18:10] __@lapalaclubdepadel añadió a +57 314 3195528__

[18:11] __Alguien añadió a +57 314 3195528__

---

## 23 de junio de 2026

[6:11] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  24 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ee3c83ca-8781-4e47-851e-76ebf0530e25?utm_source=manager

[7:39] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[7:50] **+57 316 6264600:** [Mensaje de album]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Imagen]

[7:50] **+57 316 6264600:** [Mensaje de unknown]

[7:50] **+57 316 6264600:** [Mensaje de unknown]

[7:50] **+57 316 6264600:** [Mensaje de unknown]

[7:50] **+57 316 6264600:** [Mensaje de unknown]

[7:50] **+57 316 6264600:** [Mensaje de unknown]

[7:50] **+57 316 6264600:** Pádel and Wine Lunes por la noche 🍷💪🍷🎾🍷

[8:50] **@lapalaclubdepadel:** MARTES 23 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

ANIMATE PRE SELECCION COLOMBIANA!!!

[11:54] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  24 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ee3c83ca-8781-4e47-851e-76ebf0530e25?utm_source=manager

[11:54] **+52 1 998 242 1401:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  24 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ee3c83ca-8781-4e47-851e-76ebf0530e25?utm_source=manager_
Premio??👀

[13:10] **@julipri02:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  24 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Julian P 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ee3c83ca-8781-4e47-851e-76ebf0530e25?utm_source=manager

[13:36] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[13:48] **+65 9138 2902:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  24 de JUNIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 Julian P 
🎾 Viren
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic
Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/ee3c83ca-8781-4e47-851e-76ebf0530e25?utm_source=manager

[16:31] **+57 305 2849590:**
> _@lapalaclubdepadel: MARTES 23 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

ANIMATE PRE SELECCION COLOMBIANA!!!_
Carlos Uribe

[16:32] **@lapalaclubdepadel:** MARTES 23 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Carlos U
🇨🇴 
🇨🇴
🇨🇴

ANIMATE PRE SELECCION COLOMBIANA!!!

---

## 24 de junio de 2026

[8:15] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager

[8:29] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager

[8:31] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager

[8:56] **@lapalaclubdepadel:** MIERCOLES 24 de JUNIO
📈 CATEGORIA 4TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Steven
🇨🇴 Thomas
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[9:00] **+65 9138 2902:** MIERCOLES 24 de JUNIO
📈 CATEGORIA 4TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Steven
🇨🇴 Thomas
🇨🇴 Viren
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[9:03] **@SergioRengifoC:** MIERCOLES 24 de JUNIO
📈 CATEGORIA 4TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Steven
🇨🇴 Thomas
🇨🇴 Viren
🇨🇴 Sergio R.

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[9:12] **@lapalaclubdepadel:**
> _@SergioRengifoC: MIERCOLES 24 de JUNIO
📈 CATEGORIA 4TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Steven
🇨🇴 Thomas
🇨🇴 Viren
🇨🇴 Sergio R.

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS_
partido cerrado! cancha #4 los esperamos!

[9:13] **+57 310 3029444:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager

[10:53] **@lapalaclubdepadel:** MIERCOLES 24 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[12:12] **@lapalaclubdepadel:** Si tienes disponible, me ayudarías a subir este partido a ver si alguien se suma porfa?

MIERCOLES 24 de JUNIO
Fem C 
⌚ 09:00 Pm a 10:30 Pm
📍La Pala 
💰50k
🎾 Camila Sepulveda
🎾 Camila Posse 
🎾
🎾

PARTIDO ABIERTO!!!

[13:00] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[13:43] **@lapalaclubdepadel:** [Reenviado] [Video]

[13:43] **@lapalaclubdepadel:** [Mensaje de unknown]

[13:47] **@lapalaclubdepadel:** 🚨 CIERRE DE INSCRIPCIONES: 29 DE JUNIO DEL 2026🚨

🎾 La Liga La Pala está por comenzar.

3 meses de competencia, nuevos rivales y partidos organizados para que juegues con parejas de tu mismo nivel.

⏰ Los horarios de los partidos serán flexibles para mayor comodidad de los jugadores.

📲 Todo se gestiona desde Playtomic: inscripción, programación, resultados y tabla de posiciones.

¿Ya tienes partner? 🔥

[14:44] **@lapalaclubdepadel:** Si tienes disponible, me ayudarías a subir este partido a ver si alguien se suma porfa?

MIERCOLES 24 de JUNIO
Fem C 
⌚ 09:00 Pm a 10:30 Pm
📍La Pala 
💰50k
🎾 Camila Sepulveda
🎾 Camila Posse 
🎾
🎾

PARTIDO ABIERTO!!!
ANIMO!!!

[16:42] **@lapalaclubdepadel:** 25 de JUNIO PADEL MAÑANERO
CATEGORIA: 5ta
⌚ 07:30 am a 9:00 am
📍La pala
💰50k 
🎾 Ricardo
🎾 Leandro
🎾 Jose B
🎾
1 Palas más quien se anima?

[16:52] **+57 312 5456433:** Yo me animo

[16:52] **+57 312 5456433:** Roberto

[17:09] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[17:31] **@lapalaclubdepadel:** 25 de JUNIO PADEL MAÑANERO
CATEGORIA: 5ta
⌚ 07:30 am a 9:00 am
📍La pala
🎾 Ricardo
🎾 Leandro
🎾 Jose B
🎾Roberto Contreras
*PARTIDO CERRADO *
CANCHA 5

[18:01] __@lapalaclubdepadel añadió a +57 310 2134206__

[21:33] **+57 316 6264600:** [Mensaje de album]

[21:33] **+57 316 6264600:** [Imagen]

[21:33] **+57 316 6264600:** [Imagen]

[21:33] **+57 316 6264600:** [Imagen]

[21:33] **+57 316 6264600:** [Imagen]

[21:33] **+57 316 6264600:** [Mensaje de unknown]

[21:33] **+57 316 6264600:** [Mensaje de unknown]

[21:33] **+57 316 6264600:** [Mensaje de unknown]

[21:34] **+57 316 6264600:** Torneo Padel and Beer Miércoles 🍻💪🍻🎾🍻

---

## 25 de junio de 2026

[9:04] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[9:10] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[10:23] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[10:36] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[10:37] **+57 310 8800142:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[10:46] **@pgomila:** JUEVES 25 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Pablo 
🇨🇴 Genner 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[12:48] **+57 320 2043207:** JUEVES 25 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Pablo 
🇨🇴 Genner 
🇨🇴 Alex
🇨🇴 Pedro 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[12:49] **@lapalaclubdepadel:**
> _+57 320 2043207: JUEVES 25 de JUNIO
📈 CATEGORIA 5TA 
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Pablo 
🇨🇴 Genner 
🇨🇴 Alex
🇨🇴 Pedro 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS_
cancha #3 reservada los esperamos

[12:49] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 5TA / MIXTO
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[13:16] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Carlos B
🇨🇴 Tomas B
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[13:29] **+52 1 998 242 1401:**
> _@lapalaclubdepadel: JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Carlos B
🇨🇴 Tomas B
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS_
No podrían más tarde cito ?

[13:34] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰55k

🇨🇴Ivan P
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[13:43] **+57 301 2724773:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Carlos B
🇨🇴 Tomas B
🇨🇴 Felipe C. 
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[13:46] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Felipe C.
🇨🇴 
🇨🇴 
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[13:49] **@juanf1116_:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 Carlos B
🇨🇴 Tomas B
🇨🇴 Felipe C. 
🇨🇴 Juan Felipe Esteban 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[13:49] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰45k

🇨🇴 
🇨🇴 
🇨🇴 Felipe C. 
🇨🇴 Juan Felipe Esteban 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[13:59] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 06:30 Pm a 08:00 Pm
📍La pala 
💰45k

🇨🇴 Carlos B
🇨🇴 Tomas B
🇨🇴 Felipe C. 
🇨🇴 Juan Felipe Esteban 

PARTIDO CERRADO CANCHA #4 !!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[14:09] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[14:22] **+57 310 6898400:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾juan david
🎾tomas

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[14:24] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾Elizabeth
🎾

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾
🎾

*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[14:48] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[15:00] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: JUEVES 25 de JUNIO
📈 CATEGORIA 6ta/mixto
⌚ 08:00 Pm a 09:30 Pm
📍La pala 
💰55k

🇨🇴 Felipe 
🇨🇴 Valentina
🇨🇴 
🇨🇴 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS_
partido cerrado!! cancha #1

[15:03] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾Elizabeth
🎾

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾LuisFer
🎾Daniel

*TORNEO ABIERTO CUPOS LIMITADOS (2 PERSONAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[15:50] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 Elizabeth
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾LuisFer
🎾Daniel

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾
🎾

*TORNEO ABIERTO CUPOS LIMITADOS (1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[16:15] **+57 314 2827926:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰55k

🇨🇴Ivan P
🇨🇴 Sebastian R
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[17:58] __@lapalaclubdepadel añadió a @sariast__

[19:29] **@jeanpenent:**
> _+57 314 2827926: JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰55k

🇨🇴Ivan P
🇨🇴 Sebastian R
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS_
Este partido se podría a las 9?

[19:34] **@lapalaclubdepadel:**
> _@jeanpenent: Este partido se podría a las 9?_
si señor, si estan de acuerdo los otros jugadores

[19:34] **@jeanpenent:** Yo me apunto para las 9 si llegan a estar de acuerdo

[19:36] **@lapalaclubdepadel:**
> _@jeanpenent: Yo me apunto para las 9 si llegan a estar de acuerdo_
ya confirmo

[19:38] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰55k

🇨🇴Jean Michel
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[19:40] **@jeanpenent:**
> _@lapalaclubdepadel: JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰55k

🇨🇴Jean Michel
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS_
JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰55k

🇨🇴Jean Michel
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[19:41] **+65 9138 2902:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰55k

🇨🇴Jean Michel
🇨🇴 Viren
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS

[19:52] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴Jean Michel
🇨🇴 Viren
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[20:26] **@lapalaclubdepadel:** JUEVES 25 de JUNIO
📈 CATEGORIA 4TA
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴Jean Michel
🇨🇴 Viren
🇨🇴Sebastian R
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

---

## 26 de junio de 2026

[8:08] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[13:02] **+57 310 6843763:** Hola, para el domingo habra torneo?

[14:02] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[14:48] **@lapalaclubdepadel:** [Reenviado] TORNEO MIXTO DAMAS Viernes 26 de Junio , por invitación, horario de 06 a 08 pm , valor $ 50k 

CONVOCATORIA

🎾 María Camila Alvarez 
🎾 por Definir 

🎾Iriana 
🎾Sebastián Gutiérrez 

🎾Camila 
🎾David Rodríguez 

🎾 Xiomara 
🎾 José Bran 

🎾
🎾 

🎾
🎾



LISTA DE ESPERA 


🎾
🎾

🎾
🎾

 TORNEO ABIERTO

[14:54] **@lapalaclubdepadel:** VIERNES 26 de JUNIO
📈 CATEGORIA 5ta
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰45k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[15:20] **+57 316 6264600:** TORNEO MIXTO DAMAS Viernes 26 de Junio , por invitación, horario de 06 a 08 pm , valor $ 50k 

CONVOCATORIA

🎾 María Camila Alvarez 
🎾 por Definir 

🎾Iriana 
🎾Sebastián Gutiérrez 

🎾Camila 
🎾David Rodríguez 

🎾 Xiomara 
🎾 José Bran 

🎾
🎾 Julián Prieto 

🎾
🎾

VAMOSSS ANÍMENSE A DISFRUTAR DE UN BUEN PARTIDO 
 TORNEO ABIERTO

[15:51] **@lapalaclubdepadel:** TORNEO MIXTO DAMAS Viernes 26 de Junio , por invitación, horario de 06 a 08 pm , valor $ 50k 

CONVOCATORIA

🎾 María Camila Alvarez 
🎾 por Definir 

🎾Iriana 
🎾Sebastián Gutiérrez 

🎾Camila 
🎾David Rodríguez 

🎾 Xiomara 
🎾 José Bran 

🎾
🎾 Julián Prieto 

🎾 Manuela
🎾Juan Pablo

VAMOSSS ANÍMENSE A DISFRUTAR DE UN BUEN PARTIDO 
 TORNEO ABIERTO

[15:59] **+52 1 998 242 1401:**
> _@lapalaclubdepadel: TORNEO MIXTO DAMAS Viernes 26 de Junio , por invitación, horario de 06 a 08 pm , valor $ 50k 

CONVOCATORIA

🎾 María Camila Alvarez 
🎾 por Definir 

🎾Iriana 
🎾Sebastián Gutiérrez 

🎾Camila 
🎾David Rodríguez 

🎾 Xiomara 
🎾 José Bran 

🎾
🎾 Julián Prieto 

🎾 Manuela
🎾Juan Pablo

VAMOSSS ANÍMENSE A DISFRUTAR DE UN BUEN PARTIDO 
 TORNEO ABIERTO_
Categoría ?

[16:02] **@lapalaclubdepadel:** TORNEO MIXTO DAMAS Viernes 26 de Junio, horario de 06 a 08 pm , valor $ 50k 

CONVOCATORIA

🎾Iriana 
🎾Sebastián Gutiérrez 

🎾Camila 
🎾David Rodríguez 

🎾 Xiomara 
🎾 José Bran 

🎾 Manuela
🎾Juan Pablo

 TORNEO CERRADO

[17:19] **+57 311 7841842:** TORNEO MIXTO DAMAS Viernes 26 de Junio, horario de 06 a 08 pm , valor $ 50k 

CONVOCATORIA

🎾Iriana 
🎾Sebastián Gutiérrez 

🎾Camila 
🎾David Rodríguez 

🎾 
🎾 José Bran 

🎾 Manuela
🎾Juan Pablo

 TORNEO CERRADO

[17:21] **@lapalaclubdepadel:** TORNEO MIXTO DAMAS Viernes 26 de Junio, horario de 06 a 08 pm , valor $ 50k 

CONVOCATORIA

🎾Iriana 
🎾Sebastián Gutiérrez 

🎾Camila 
🎾David Rodríguez 

🎾 Alejandra Terraza
🎾 José Bran 

🎾 Manuela
🎾Juan Pablo

 TORNEO CERRADO

[18:49] __@lapalaclubdepadel añadió a +57 305 7755210__

[19:52] **+57 316 6264600:** [Mensaje de album]

[19:52] **+57 316 6264600:** [Imagen]

[19:52] **+57 316 6264600:** [Imagen]

[19:52] **+57 316 6264600:** [Imagen]

[19:52] **+57 316 6264600:** [Imagen]

[19:52] **+57 316 6264600:** [Mensaje de unknown]

[19:52] **+57 316 6264600:** [Mensaje de unknown]

[19:52] **+57 316 6264600:** [Mensaje de unknown]

[19:52] **+57 316 6264600:** Torneo relámpago Mixto Viernes por la noche 💪🎾

[20:00] **+57 320 8584974:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[20:26] **@lapalaclubdepadel:** SABADO 27 de JUNIO
📈 CATEGORIA 5ta
⌚ 02:00Pm a 04:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[20:28] **@lapalaclubdepadel:** SABADO 27 de JUNIO
📈 CATEGORIA DAMAS C/D
⌚ 02:00Pm a 04:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

---

## 27 de junio de 2026

[7:23] **+57 310 3029444:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[7:25] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 Elizabeth
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾LuisFer
🎾Daniel

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾
🎾

*TORNEO ABIERTO CUPOS LIMITADOS (1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[7:39] **+57 314 3911639:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 Elizabeth
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾LuisFer
🎾Daniel

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾Manish
🎾

*TORNEO ABIERTO CUPOS LIMITADOS (1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[7:44] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:00] **@lapalaclubdepadel:**
> _+57 314 3911639: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 Elizabeth
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾LuisFer
🎾Daniel

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾Manish
🎾

*TORNEO ABIERTO CUPOS LIMITADOS (1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!_
ULTIMO CUPO! 1 JUGADOR!

[9:04] **@iaquintero:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 Elizabeth
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾LuisFer
🎾Daniel

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾Manish
🎾Iván A

*TORNEO ABIERTO CUPOS LIMITADOS (1 PAREJA )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/2c080b11-1739-4fb0-b486-0ba0dbe465d1?utm_source=manager


*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[9:05] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 27 JUNIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Viren
🎾 Elizabeth
 
🎾 Juliana Q
🎾 Mauricio Moreno

🎾Alejandra T.
🎾Sebastian C.

🎾 Gustavo
🎾 William R
️
🎾 Andres B
🎾Carlos R

🎾Ivan P
🎾Francisco A

🎾LuisFer
🎾Daniel

🎾Juan David 
🎾Tomas

🎾Miguel
🎾Valentina

🎾Manish
🎾Iván A

TORNEO CERRADO LOS ESPERAMOS
*NO TE OLVIDES QUE NUESTRO PARQUEADERO DURANTE EL MUNDIAL ES 💯% GRATUITO!!

[9:06] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Sebastian F

[9:06] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:13] **+57 313 3300561:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢Claudia 
🟢Claudio 

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[11:26] __@lapalaclubdepadel añadió a +34 661 99 31 12__

[11:26] __Alguien añadió a +34 661 99 31 12__

[12:11] **+34 661 99 31 12:** Buenas 😊😊 estaré una semana por Bogota y me gustaria echar unos partiditos de padel si necesitais un jugador me apunto😊😊. Que gane Colombia hoy⚽️⚽️

[13:09] **@lapalaclubdepadel:** SABADO 27 de JUNIO
📈 CATEGORIA DAMAS C/D
⌚ 02:00Pm a 04:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[13:09] **@lapalaclubdepadel:** SABADO 27 de JUNIO
📈 CATEGORIA 5ta
⌚ 02:00Pm a 04:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[13:40] **+57 316 6264600:** [Mensaje de album]

[13:40] **+57 316 6264600:** [Imagen]

[13:40] **+57 316 6264600:** [Imagen]

[13:40] **+57 316 6264600:** [Imagen]

[13:40] **+57 316 6264600:** [Imagen]

[13:40] **+57 316 6264600:** [Imagen]

[13:40] **+57 316 6264600:** [Mensaje de unknown]

[13:40] **+57 316 6264600:** [Mensaje de unknown]

[13:40] **+57 316 6264600:** [Mensaje de unknown]

[13:40] **+57 316 6264600:** [Mensaje de unknown]

[13:41] **+57 316 6264600:** Americano Sábado 💪🎾

[21:31] **@mariafernandamrrr:**
> _+57 313 3300561: TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢Claudia 
🟢Claudio 

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
María Fernanda 
Nicolás Sahid

[23:07] **+57 313 2930175:**
> _+57 313 3300561: TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢Claudia 
🟢Claudio 

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Silvana Tovar
Hernán Tovar

---

## 28 de junio de 2026

[6:30] **+65 9138 2902:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢Claudia 
🟢Claudio 

🟢 Viren
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[7:07] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢 Claudia 
🟢 Claudio 

🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢Silvana Tovar
🟢Hernan Tovar

🟢 Viren
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[7:40] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢 Claudia 
🟢 Claudio 

🟢 Silvana Tovar
🟢 Hernan Tovar

🟢 Viren
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (1 PAREJA 1 JUGADOR)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:19] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢 Claudia 
🟢 Claudio 

🟢 Silvana Tovar
🟢 Hernan Tovar

🟢 Viren
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (1 PAREJA 1 JUGADOR)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
ANIMO
FALTA 1 PAREJA

[10:17] **+57 316 6264600:** [Mensaje de album]

[10:17] **+57 316 6264600:** [Imagen]

[10:17] **+57 316 6264600:** [Imagen]

[10:17] **+57 316 6264600:** [Imagen]

[10:17] **+57 316 6264600:** [Imagen]

[10:17] **+57 316 6264600:** [Mensaje de unknown]

[10:17] **+57 316 6264600:** [Mensaje de unknown]

[10:17] **+57 316 6264600:** [Mensaje de unknown]

[10:17] **+57 316 6264600:** Torneo Padelennials Domingo por la mañana 💪🎾👏

[10:49] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢 Claudia 
🟢 Claudio 

🟢 Silvana Tovar
🟢 Hernan Tovar

TORNEO ABIERTO CERRADO
LOS ESPERAMOS

[11:17] **+57 316 6264600:** TORNEO SOCIAL DOMINGO  28 de JUNIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación y parqueadero gratis!. 

🟢 Juan Loaiza
🟢 Valeria León
 
🟢 Laura Sanchez
🟢 Sebastian F

🟢 Claudia 
🟢 Claudio 

🟢 Silvana Tovar
🟢 Hernan Tovar

🟢Patricia Blanco 
🟢Iván 

🟢Viren 
🟢Player 1 

TORNEO ABIERTO CERRADO
LOS ESPERAMOS

[12:37] **+56 9 8218 1963:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[13:29] **+57 316 6264600:** [Mensaje de album]

[13:29] **+57 316 6264600:** [Imagen]

[13:29] **+57 316 6264600:** [Imagen]

[13:29] **+57 316 6264600:** [Imagen]

[13:29] **+57 316 6264600:** [Imagen]

[13:29] **+57 316 6264600:** [Mensaje de unknown]

[13:29] **+57 316 6264600:** [Mensaje de unknown]

[13:29] **+57 316 6264600:** [Mensaje de unknown]

[13:30] **+57 316 6264600:** Americano de los Domingos 💪🎾🙌

[14:45] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:36] **+57 316 4728428:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢 Douglas/ pendiente 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:38] **@lapalaclubdepadel:** DOMINGO 28 de JUNIO
📈 CATEGORIA 5ta/6ta
⌚ 06:00Pm a 08:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[15:41] **+65 9138 2902:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢 Douglas/ pendiente 
🟢 Viren

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:52] **+57 316 4728428:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢 Douglas/Nestor 
🟢 Viren

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[16:58] **+57 310 3398870:** _Se eliminó este mensaje_

[17:01] **+57 314 7713476:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢 Douglas/Nestor 
🟢 Viren

🟢 Sebastián 
🟢 Felipe 

🟢Andrés A
🟢Jorge H

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[17:04] __@lapalaclubdepadel añadió a @a.agudelo2206__

[17:05] **+57 310 3398870:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢 Douglas/Nestor 
🟢 Viren

🟢 Sebastián 
🟢 Felipe 

🟢Andrés A
🟢Jorge H

🟢 Juan C
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[17:06] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢 Douglas/Nestor 
🟢 Viren

🟢 Sebastián 
🟢 Felipe 

🟢Andrés A
🟢Jorge H

🟢 Juan C
🟢 Luis Zerpa

TORNEO CERRADO

[20:04] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 29 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:00 a 1:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Yani
🟢 Alejandra 
 
🟢 Maria Fernanda
🟢 Nicolas Sahid

🟢 Douglas 
🟢 Nestor

🟢 Sebastián 
🟢 Felipe 

🟢Andrés A
🟢Jorge H

🟢 Juan C
🟢 Luis Zerpa

TORNEO CERRADO
Lista De Espera 
🎾 Viren

---

## 29 de junio de 2026

[8:38] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  01 de JULIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS

[9:25] **@lapalaclubdepadel:** LUNES 29 de JUNIO
📈 CATEGORIA 5ta
⌚ 04:00Pm a 06:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[13:23] __@lapalaclubdepadel añadió a @jorgehiguera98__

[13:23] __@lapalaclubdepadel añadió a +57 314 3304304__

[13:24] __Alguien añadió a @jorgehiguera98__

[13:28] **+57 316 6264600:** [Mensaje de album]

[13:28] **+57 316 6264600:** [Imagen]

[13:28] **+57 316 6264600:** [Imagen]

[13:28] **+57 316 6264600:** [Imagen]

[13:28] **+57 316 6264600:** [Mensaje de unknown]

[13:28] **+57 316 6264600:** [Mensaje de unknown]

[13:28] **+57 316 6264600:** Americano Lunes festivo 🙌💪🎾

[13:30] __@lapalaclubdepadel añadió a @YanirisLl__

[14:08] **+57 317 4022948:** Torneo Americano Lunes 29 6-8pm
📍La Pala
50k x Persona
Incluye 🎾 
Todos contra todos
Nivel 4ta -5ta alta


- Luisfer ✅
- Sando✅️
- Cami ✅
- Pipe ✅
- Sebas ✅
- ⁠Paolo ✅️
- ⁠Dani ✅
- ⁠Rafael ✅
- ⁠Manuel F ✅
- Guido✅
- ⁠
- Felipe Gómez✅
- ⁠JuanDa✅
- ⁠Carlos Bautista ✅
- ⁠Óscar Morales ✅
- Camilo Diazgranados ✅

[14:08] **+57 317 4022948:** Un cupo

[14:13] __[Llamada]__

[14:14] **+57 317 4022948:** 🔥🔥🔥Torneo Americano Lunes 29 6-8pm
📍La Pala
50k x Persona
Incluye 🎾 
Todos contra todos
Nivel 4ta -5ta alta


- Luisfer ✅
- Sando✅️
- Cami ✅
- Pipe ✅
- Sebas ✅
- ⁠Paolo ✅️
- ⁠Dani ✅
- ⁠Rafael ✅
- ⁠Manuel F ✅
- Guido✅
- ⁠Germán Bautista✅
- Felipe Gómez✅
- ⁠JuanDa✅
- ⁠Carlos Bautista ✅
- ⁠Óscar Morales ✅
- Camilo Diazgranados ✅
Torneo Cerrado!

[14:32] __@lapalaclubdepadel añadió a @sebastian_castellanos93__

[14:41] **+57 317 4022948:**
> _+57 317 4022948: 🔥🔥🔥Torneo Americano Lunes 29 6-8pm
📍La Pala
50k x Persona
Incluye 🎾 
Todos contra todos
Nivel 4ta -5ta alta


- Luisfer ✅
- Sando✅️
- Cami ✅
- Pipe ✅
- Sebas ✅
- ⁠Paolo ✅️
- ⁠Dani ✅
- ⁠Rafael ✅
- ⁠Manuel F ✅
- Guido✅
- ⁠Germán Bautista✅
- Felipe Gómez✅
- ⁠JuanDa✅
- ⁠Carlos Bautista ✅
- ⁠Óscar Morales ✅
- Camilo Diazgranados ✅
Torneo Cerrado!_
Hay una persona más interesada en jugar, si salen 3 más vamos con las 5 canchas

[14:42] __[Llamada]__

[14:43] **@lapalaclubdepadel:** hola buenas tardes, solo tenemos 4 canchas disponibles

[14:43] **+57 317 4022948:** Entonces olvídenlo

[14:43] **+57 317 4022948:** Torneo cerrado

[14:43] **+57 317 4022948:** Gracias

[14:45] **@lapalaclubdepadel:** con gusto si señor

---

## 30 de junio de 2026

[7:15] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  01 de JULIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS

[8:56] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[9:13] **@lapalaclubdepadel:** MARTES 30 de JUNIO
📈 CATEGORIA 5ta
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[9:54] __@lapalaclubdepadel añadió a +57 305 8745599__

[13:02] **@lapalaclubdepadel:** MARTES 30 de JUNIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[13:21] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:16] **+65 9138 2902:** MARTES 30 de JUNIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Viren
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[14:57] __@lapalaclubdepadel añadió a +57 310 6045469__

[15:22] **@lapalaclubdepadel:** MARTES 30 de JUNIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Viren
🇨🇴 Jorge

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[15:37] **@lapalaclubdepadel:** MARTES 30 de JUNIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Viren
🇨🇴 Jorge

PARTIDO CERRADO
CANCHA 1

[15:41] **@lapalaclubdepadel:** MARTES 30 de JUNIO
📈 CATEGORIA 5ta /6ta
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴 
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!

[15:43] **+34 661 99 31 12:** MARTES 30 de JUNIO
📈 CATEGORIA 5ta /6ta
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Alberto
🇨🇴 
🇨🇴 
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!

[16:18] **+57 310 6898400:** MARTES 30 de JUNIO
📈 CATEGORIA 5ta /6ta
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Alberto
🇨🇴 
🇨🇴 
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!

[17:49] **@lapalaclubdepadel:** *Modalidad: PAREJA FIJA
SUBE Y BAJA*** 
Martes 30 de junio 
⏰: 7:30 pm - 9 :00 pm 
📍La pala
💴 $62.000
* FALTA UNA DAMA QUIEN SE ANIMA?

[18:12] **@lapalaclubdepadel:** **Modalidad: PAREJA FIJA
SUBE Y BAJA*** 
Martes 30 de junio 
⏰: 7:30 pm - 9 :00 pm 
📍La pala
💴 $62.000
 
🎾 Melodie Cabassu / Lida S Torres 
🎾 Cami Posse / Cami Cuellar

🎾 Paty blanco / Caro P 
🎾 Lorena fadul / Lina Novoa 

🎾 Patty G /Adri P
🎾Valeria/ Sandra
 
🎾 Juli P/ Sofia G
🎾Juliana/Valentina

🎾Alicia / Valentina 
🎾Xiomi T / 

“No olvidar el detalle para la ancheta, será el regalo para la pareja ganadora” 🍬 🍷 💝 

FALTA UNA DAMA 
QUIEN SE ANIMA

[19:07] __@lapalaclubdepadel añadió a +57 314 3309605__

[21:16] **+57 316 6264600:** [Mensaje de album]

[21:16] **+57 316 6264600:** [Imagen]

[21:16] **+57 316 6264600:** [Imagen]

[21:16] **+57 316 6264600:** [Imagen]

[21:16] **+57 316 6264600:** [Imagen]

[21:16] **+57 316 6264600:** [Imagen]

[21:16] **+57 316 6264600:** [Mensaje de unknown]

[21:16] **+57 316 6264600:** [Mensaje de unknown]

[21:16] **+57 316 6264600:** [Mensaje de unknown]

[21:16] **+57 316 6264600:** [Mensaje de unknown]

[21:17] **+57 316 6264600:** Pádel and Wine Martes 🍷💪🍷🎾🍷

---

## 1 de julio de 2026

[7:05] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager

[10:32] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[10:40] **+57 315 3535944:** Hay muy tarde 😭😭😭estaré pendiente  en todo caso   abrazo

[11:44] **@lapalaclubdepadel:** MIERCOLES 1 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 
🇨🇴 
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!

[11:46] **@lapalaclubdepadel:** MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[11:57] **+57 316 4917185:** MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Paolo Braccia
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[13:47] **@lapalaclubdepadel:**
> _+57 316 4917185: MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Paolo Braccia
🇨🇴

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO_
uno mas???

[13:48] **+34 661 99 31 12:** Yo😊😊

[13:48] **+34 661 99 31 12:** MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Paolo Braccia
🇨🇴 alberto

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[13:52] **+34 661 99 31 12:**
> _@lapalaclubdepadel: uno mas???_
Cerrado no?

[14:08] **@lapalaclubdepadel:** MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Paolo Braccia
🇨🇴 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO

[14:08] **@lapalaclubdepadel:** MIERCOLES 1 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 Alberto
🇨🇴 
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!

[14:24] __@lapalaclubdepadel añadió a +57 311 2632506__

[14:28] __Alguien añadió a +57 311 2632506__

[16:03] **+57 316 4917185:**
> _@lapalaclubdepadel: MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Paolo Braccia
🇨🇴 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO_
Uno mas?

[16:05] **+34 661 99 31 12:**
> _@lapalaclubdepadel: MIERCOLES 1 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 Alberto
🇨🇴 
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!_
Dos mas?😊😊

[16:10] **+57 310 5611823:**
> _@lapalaclubdepadel: MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Paolo Braccia
🇨🇴 

PARTIDO ABIERTO!!!
APROVECHA NUESTRO PARQUEADERO 100% GRATIS
ANIMO_
Voy

[16:12] **@lapalaclubdepadel:** MIERCOLES de JULIO
📈 CATEGORIA 4ta 
⌚ 06:00Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 Paolo Braccia
🇨🇴 Mateo R

PARTIDO CERRADO!!!
CANCHA 3

[16:13] **+57 314 3304304:** MIERCOLES 1 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 Alberto
🇨🇴 Néstor M
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!

[16:14] **+34 661 99 31 12:**
> _+57 314 3304304: MIERCOLES 1 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 Alberto
🇨🇴 Néstor M
🇨🇴

PARTIDO ABIERTO
ANIMO LOS ESPERAMOS!_
Venga uno maa animense😊😊

[17:10] **@lapalaclubdepadel:** MIERCOLES 1 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 Alberto
🇨🇴 Néstor M
🇨🇴

PARTIDO ABIERTO
FALTA UNA PALA ANIMO!!!

[17:38] **@lapalaclubdepadel:** MIERCOLES 1 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 Alberto
🇨🇴 Néstor M
🇨🇴

PARTIDO CANCELADO

[21:35] **+57 316 6264600:** [Mensaje de album]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Imagen]

[21:35] **+57 316 6264600:** [Mensaje de unknown]

[21:35] **+57 316 6264600:** [Mensaje de unknown]

[21:35] **+57 316 6264600:** Torneo Padel And Beer , Miércoles 🍻💪🍻🎾🍻

---

## 2 de julio de 2026

[6:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager

[10:10] **@lapalaclubdepadel:** JUEVES 2 de JULIO
📈 CATEGORIA 5ta/4ta
⌚ 09:00Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴LuisFer
🇨🇴
🇨🇴 
🇨🇴

[10:50] **@lapalaclubdepadel:** JUEVES 2 de JULIO
📈 CATEGORIA 6ta
⌚ 06:00Pm a 7:30 Pm
📍La pala 
💰50k

🇨🇴Jonathan
🇨🇴 
🇨🇴 
🇨🇴

PARTIDO ABIERTO
ANIMO!!!

[11:59] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[13:02] **@lapalaclubdepadel:** VIERNES 3 de JULIO
📈 CATEGORIA 5ta/C+ MIXTO
⌚ 05:00Pm a 6:30 Pm
📍La pala 
💰45k

🇨🇴Pilar Pachon
🇨🇴Eliana Andrade
🇨🇴 
🇨🇴
2 Palas! animense!!!

[13:04] **@lapalaclubdepadel:** JUEVES 2 de JUNIO
📈 CLASE DIRIGIDA máximo 3 personas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Victor
🇨🇴 
🇨🇴
🇨🇴

*CLASE ABIERTA!!!

[13:18] **@lapalaclubdepadel:** [Reenviado] [Imagen] Este viernes 3 de julio el mejor plan está en La Pala. 🎾⚽

Reúne a tus amigos, juega pádel y vive toda la emoción apoyando a Colombia en un solo lugar.

🔥 Solo por este viernes 3 de julio aprovecha el valor especial de reserva de $100.000 por hora y disfruta de:
✅ Canchas de primer nivel.
🍔 Comida y bebidas.
🎉 El mejor ambiente para compartir.
🚗 Parqueadero gratis.

¡No dejes pasar esta promoción exclusiva!

📍 La Pala Club de Pádel
📅 Válido únicamente el viernes 3 de julio.

[16:00] **@lapalaclubdepadel:** JUEVES 2 de JUNIO
📈 CLASE DIRIGIDA máximo 3 personas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Victor
🇨🇴 Jonathan
🇨🇴 Ibraim
🇨🇴

*CLASE ABIERTA!!!

[16:14] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[16:28] **@SergioRengifoC:** JUEVES 2 de JUNIO
📈 CLASE DIRIGIDA máximo 3 personas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Victor
🇨🇴 Jonathan
🇨🇴 Ibraim
🇨🇴 Sergio R.

*CLASE ABIERTA!!!

[16:35] **@lapalaclubdepadel:** JUEVES 2 de JUNIO
📈 CLASE DIRIGIDA máximo 3 personas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Victor
🇨🇴 Jonathan
🇨🇴 Ibraim
🇨🇴 Sergio R.

*CLASE CERRADA!!
CANCHA 1

[18:32] **@lapalaclubdepadel:** JUEVES 02 de JULIO
📈 CATEGORIA 4ta 
⌚ 07:30Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴Johan Vásquez 
🇨🇴 Juan Diego Torres
🇨🇴 
🇨🇴

FALTAN 2 PALAS 
ANIMO!

[21:09] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Daniel Salinas
🎾 Erika Diaz
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager

---

## 3 de julio de 2026

[7:40] **@lapalaclubdepadel:** [Reenviado] [Imagen] Este viernes 3 de julio el mejor plan está en La Pala. 🎾⚽

Reúne a tus amigos, juega pádel y vive toda la emoción apoyando a Colombia en un solo lugar.

🔥 Solo por este viernes 3 de julio aprovecha el valor especial de reserva de $100.000 por hora y disfruta de:
✅ Canchas de primer nivel.
🍔 Comida y bebidas.
🎉 El mejor ambiente para compartir.
🚗 Parqueadero gratis.

¡No dejes pasar esta promoción exclusiva!

📍 La Pala Club de Pádel
📅 Válido únicamente el viernes 3 de julio.

[8:40] **@lapalaclubdepadel:** VIERNES 3 de JULIO
📈 CATEGORIA 5ta/C+ MIXTO
⌚ 05:00Pm a 6:30 Pm
📍La pala 
💰45k

🇨🇴Pilar Pachon
🇨🇴Eliana Andrade
🇨🇴 
🇨🇴
2 Palas! animense!!!

[8:57] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Daniel Salinas
🎾 Erika Diaz
 
🎾 Viren
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager

[9:07] **+57 310 8800142:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Daniel Salinas
🎾 Erika Diaz
 
🎾 Viren
🎾 William R 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager

[9:20] __@lapalaclubdepadel añadió a +593 99 917 1389__

[10:26] **@lapalaclubdepadel:** VIERNES 3 de JULIO
📈 CATEGORIA 5ta/C+ MIXTO
⌚ 05:00Pm a 6:30 Pm
📍La pala 
💰45k

🇨🇴Pilar Pachon
🇨🇴Eliana Andrade
🇨🇴 
🇨🇴
2 Palas! animense!!!

[10:59] **@dianarojas20:** _Se eliminó este mensaje_

[11:05] **@dianarojas20:**
> _@lapalaclubdepadel: VIERNES 3 de JULIO
📈 CATEGORIA 5ta/C+ MIXTO
⌚ 05:00Pm a 6:30 Pm
📍La pala 
💰45k

🇨🇴Pilar Pachon
🇨🇴Eliana Andrade
🇨🇴 
🇨🇴
2 Palas! animense!!!_
@~Pilar Pachon  estamos  2 chicas jugarían con nosotras

[11:10] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  5 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰65k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[11:11] **@dianarojas20:** VIERNES 3 de JULIO
📈 CATEGORIA 5ta/C+ MIXTO
⌚ 05:00Pm a 6:30 Pm
📍La pala 
💰45k

🇨🇴Pilar Pachon
🇨🇴Eliana Andrade
🇨🇴 Diana rojas 
🇨🇴 Tatiana Muñoz 
2 Palas! animense!!!

[11:14] **@lapalaclubdepadel:**
> _@dianarojas20: VIERNES 3 de JULIO
📈 CATEGORIA 5ta/C+ MIXTO
⌚ 05:00Pm a 6:30 Pm
📍La pala 
💰45k

🇨🇴Pilar Pachon
🇨🇴Eliana Andrade
🇨🇴 Diana rojas 
🇨🇴 Tatiana Muñoz 
2 Palas! animense!!!_
PARTIDO CERRADO CANCHA #3 LAS ESPERAMOS!

[11:51] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[13:50] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[13:57] __@lapalaclubdepadel añadió a +598 98 272 022__

[15:02] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[17:45] __@lapalaclubdepadel añadió a +57 305 8745599__

[21:01] **+57 301 6599427:**
> _+57 310 8800142: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Daniel Salinas
🎾 Erika Diaz
 
🎾 Viren
🎾 William R 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager_
Freddy Claro

---

## 4 de julio de 2026

[6:56] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Daniel Salinas
🎾 Erika Diaz
 
🎾 Viren
🎾 William R 

🎾Freddy Claro
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager

[8:33] **+57 310 8800142:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Daniel Salinas
🎾 Erika Diaz
 
🎾 Viren
🎾 

🎾Freddy Claro
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager

[10:28] **+65 9138 2902:**
> _+57 310 8800142: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 4 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Daniel Salinas
🎾 Erika Diaz
 
🎾 Viren
🎾 

🎾Freddy Claro
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )
Nota: Favor no subirse a la Comunidad si no se ha registrado por Playtomic o solicite su Link de pago y asegure su cupo!!!

Link de inscripción por Playtomic: 
https://app.playtomic.io/tournaments/738ab0c7-3f64-4f9d-80e5-c07fb981f496?utm_source=manager_
¿Freddy y yo contra Erika y Daniel como una pelea normal?

[10:56] **+57 301 6599427:** No contestaron entonces me bajo de la programación gracias.

[11:22] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[11:24] **@lapalaclubdepadel:** SABADO 4 de JULIO
📈 CATEGORIA 5ta
⌚ 04:00Pm a 6:00 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴
🇨🇴 
🇨🇴

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!

[13:54] **@lapalaclubdepadel:** DOMINGO 5 de JULIO
📈 CATEGORIA 5ta
⌚ 09:00Am a 11:00 Am
📍La pala 
💰50k

🇨🇴
🇨🇴
🇨🇴 
🇨🇴

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!

[13:54] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  5 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:44] __@mbarrigag se unieron mediante el enlace de invitación__

[19:07] **+57 310 2229668:** _Se eliminó este mensaje_

[19:08] **@lapalaclubdepadel:** DOMINGO 05 de JULIO
📈 CATEGORIA DAMAS C/C+
⌚ 09:00 am a 11:00 am
📍La pala 
💰50k

🇨🇴 Pilar Pachon
🇨🇴 Eliana Andrade
🇨🇴 
🇨🇴

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!

[20:21] **+57 310 2229668:** DOMINGO 05 de JULIO
📈 CATEGORIA DAMAS C/C+
⌚ 09:00 am a 11:00 am
📍La pala 
💰50k

🇨🇴 Pilar Pachon
🇨🇴 Eliana Andrade
🇨🇴 Patricia Arenas
🇨🇴 María Paula García 

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!

[22:31] **@camilomondragonpersonal:** DOMINGO 5 de JULIO
📈 CATEGORIA 4ta
⌚ 09:00Am a 11:00 Am
📍La pala 
💰50k

🇨🇴 Camilo M
🇨🇴
🇨🇴 
🇨🇴

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!

[22:55] **@cj_quintana:** DOMINGO 5 de JULIO
📈 CATEGORIA 4ta
⌚ 09:00Am a 11:00 Am
📍La pala 
💰50k

🇨🇴 Camilo M
🇨🇴 Tomás V
🇨🇴  Carlos Q
🇨🇴

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!

[23:20] **@rvanegasa:** DOMINGO 5 de JULIO
📈 CATEGORIA 4ta
⌚ 09:00Am a 11:00 Am
📍La pala 
💰50k

🇨🇴 Camilo M
🇨🇴 Tomás V
🇨🇴  Carlos Q
🇨🇴 Rafa Vanegas

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!

---

## 5 de julio de 2026

[7:15] **@camilomondragonpersonal:**
> _@rvanegasa: DOMINGO 5 de JULIO
📈 CATEGORIA 4ta
⌚ 09:00Am a 11:00 Am
📍La pala 
💰50k

🇨🇴 Camilo M
🇨🇴 Tomás V
🇨🇴  Carlos Q
🇨🇴 Rafa Vanegas

RECUERDEN QUE EL PARQUEADERO ES 100% GRATIS PARA NUESTROS JUGADORES!!_
Excelente ahí nos vemos 💪🏽

[7:30] **@rvanegasa:**
> _@camilomondragonpersonal: Excelente ahí nos vemos 💪🏽_
Ok, firme, confirmado

[7:43] **@lapalaclubdepadel:** DOMINGO 5 de JULIO
📈 CATEGORIA 4ta
⌚ 09:00Am a 11:00 Am
📍La pala 
💰50k

🇨🇴 Camilo M
🇨🇴 Tomás V
🇨🇴  Carlos Q
🇨🇴 Rafa Vanegas

PARTIDO CERRADO 
CANCHA 1

[7:44] **@lapalaclubdepadel:** DOMINGO 05 de JULIO
📈 CATEGORIA DAMAS C/C+
⌚ 09:00 am a 11:00 am
📍La pala 
💰50k

🇨🇴 Pilar Pachon
🇨🇴 Eliana Andrade
🇨🇴 Patricia Arenas
🇨🇴 María Paula García 

PARTIDO CERRADO 
CANCHA 5

[17:40] **@lapalaclubdepadel:** DOMINGO 5 de JULIO
📈 CATEGORIA DAMAS C/D
⌚ 07:00Pm a 08:00 Pm
📍La pala 
💰30k

🇨🇴 Maria Fernanda
🇨🇴 
🇨🇴  
🇨🇴 

PARTIDO ABIERO

[17:53] **+57 301 7844671:** DOMINGO 5 de JULIO
📈 CATEGORIA DAMAS C/D
⌚ 07:00Pm a 08:00 Pm
📍La pala 
💰30k

🇨🇴 Maria Fernanda
🇨🇴 Irene C
🇨🇴  
🇨🇴 

PARTIDO ABIERO

---

## 6 de julio de 2026

[7:03] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL AMERICANO 
✨✨MIERCOLES  08 de JULIO ✨✨

📈 *Categoría: (5ta, 6ta masculino, Damas  (C y D)
inscripción individual
⌚6:00AM - 08:00 AM
📍La Pala
💰65k por persona incluye PAN DE YUCA y UN CAFE o Agua, organización, bolas, y premios!

🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾
🎾 
🎾
🎾
🎾
 
TORNEO ABIERTO (12) CUPOS LIMITADOS

[7:22] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[7:31] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[8:14] **@lapalaclubdepadel:** LUNES 06 de JULIO
📈 CLASE DIRIGIDA máximo 3 perosonas 
⌚ 6:00 Pm a 07:00 Pm
📍La pala 
💰50k

🇨🇴 Víctor Hugo 
🇨🇴 
🇨🇴
🇨🇴

*CLASE ABIERTA!!!

[8:14] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[12:29] **@lapalaclubdepadel:** LUNES 06 de JULIO
📈 CATEGORIA 5TA ALTA
⌚ 9:30 Pm a 11:00 Pm
📍La pala 
💰50k

🇨🇴 Alejandro C
🇨🇴 Rafael M
🇨🇴
🇨🇴

PARTIDO ABIERTO RECUERDEN PARQUEADERO 💯% GRATIS PARA NUESTROS JUGADORES

[17:29] **@lapalaclubdepadel:** **Modalidad: PAREJA FIJA
SUBE Y BAJA*** 
Lunes 6 de  julio 
⏰: 7:30 pm - 9 :30 pm 
📍La pala
💴 $62.000
FALTA 1 PAREJA DAMAS C/D 
QUIEN SE ANIMA!!!

[20:28] **@lapalaclubdepadel:** LUNES 06 de JULIO
📈 CATEGORIA 5TA ALTA
⌚ 9:30 Pm a 11:00 Pm
📍La pala 
💰50k

🇨🇴 Alejandro C
🇨🇴 Rafael M
🇨🇴 Juan Gonzalez
🇨🇴

PARTIDO ABIERTO RECUERDEN PARQUEADERO 💯% GRATIS PARA NUESTROS JUGADORES

[20:29] __@lapalaclubdepadel añadió a +57 315 5711582__

---

## 7 de julio de 2026

[8:31] **@lapalaclubdepadel:** MARTES 7 de JULIO
📈 CATEGORIA 5TA ALTA
⌚ 7:30 Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO RECUERDEN PARQUEADERO 💯% GRATIS PARA NUESTROS JUGADORES

[8:33] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[8:33] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[10:00] __@lapalaclubdepadel añadió a +57 322 8272903__

[10:12] **@lapalaclubdepadel:** MARTES 7 de JULIO
📈 CATEGORIA 5TA ALTA
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴
🇨🇴
🇨🇴

PARTIDO ABIERTO RECUERDEN PARQUEADERO 💯% GRATIS PARA NUESTROS JUGADORES

[13:53] **@luis_arangohe:** 7 de JULIO - PADEL - MARTES
CATEGORIA: 5ta - Mixto C
⌚ 07:30 pm a 9:00 pm
📍La pala 
🎾 Nancy
🎾 LuisFer
🎾 
🎾

[16:13] **@rvanegasa:** _Se eliminó este mensaje_

[16:14] **@lapalaclubdepadel:** 7 de JULIO - PADEL - MARTES
CATEGORIA: 5ta - Mixto C
⌚ 07:30 pm a 9:00 pm
📍La pala 
🎾 Nancy
🎾 LuisFer
🎾 Rafa
🎾 Lina

PARTIDO CERRADO
CANCHA 3

[16:16] **@nanjovas:** [Imagen] Buenas tardes , una disculpa ya nos confirmó una pareja

[16:16] **@nanjovas:** Olvidamos actualizar el estado en este chat

[17:03] **@lapalaclubdepadel:** 7 de JULIO - PADEL - MARTES
CATEGORIA: 5ta - Mixto C
⌚ 07:30 pm a 9:00 pm
📍La pala 
🎾 Lina A
🎾 Eliana A
🎾
🎾

PARTIDO ABIERTO

[18:24] **@margararpou:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[18:29] **@lapalaclubdepadel:** muy buenas tardes, tener en cuenta que  el grupo es únicamente para subir torneos o partidos programados.
muchas gracias.

[18:41] **@lapalaclubdepadel:** 7 de JULIO - PADEL - MARTES
CATEGORIA: 5ta - Mixto C
⌚ 07:30 pm a 9:00 pm
📍La pala 
🎾 Lina A
🎾 Eliana A
🎾
🎾

PARTIDO ABIERTO
FALTAN 2 PALAS 
ANIMO!!!

[18:52] **+57 320 4233809:** 7 de JULIO - PADEL - MARTES
CATEGORIA: 5ta - Mixto C
⌚ 07:30 pm a 9:00 pm
📍La pala 
🎾 Lina A
🎾 Eliana A
🎾 Rafael 
🎾

PARTIDO ABIERTO
FALTA 1 PALA 
ANIMO!!!

[18:54] **+57 314 3304304:** 7 de JULIO - PADEL - MARTES
CATEGORIA: 5ta - Mixto C
⌚ 07:30 pm a 9:00 pm
📍La pala 
🎾 Lina A
🎾 Eliana A
🎾 Rafael 
🎾Nestor M

PARTIDO ABIERTO
FALTA 1 PALA 
ANIMO!!!

[18:59] **@lapalaclubdepadel:** 7 de JULIO - PADEL - MARTES
CATEGORIA: 5ta - Mixto C
⌚ 07:30 pm a 9:00 pm
📍La pala 
🎾 Lina A
🎾 Eliana A
🎾 Rafael 
🎾Nestor M

PARTIDO CERRADO
CANCHA 4

[20:39] **+57 315 5758858:** 8 de JULIO - PADEL - MIERCOLES
CATEGORIA: 5ta 4ta
⌚ 08:00 am a 9:30 am
📍La pala 
🎾 Lucas
🎾 
🎾
🎾

PARTIDO ABIERTO

---

## 8 de julio de 2026

[6:37] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  11 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[12:10] __@lapalaclubdepadel añadió a +507 6430-5628__

[14:19] **@lapalaclubdepadel:** MIERCOLES 8 de JULIO
📈 CATEGORIA: 5ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[15:08] **@dairosky:** _Se eliminó este mensaje_

[15:09] **@dairosky:**
> _@lapalaclubdepadel: MIERCOLES 8 de JULIO
📈 CATEGORIA: 5ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO_
MIERCOLES 8 de JULIO
📈 CATEGORIA: 3ra-4ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Dairosky 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[15:33] **+57 315 8994236:** 7:30 hay de cuarta?

[15:35] **@lapalaclubdepadel:**
> _+57 315 8994236: 7:30 hay de cuarta?_
hola buenas tardes, en esa franja tenemos torneo, podemos armar uno de 06:00pm a 07:30pm o de 09:00pm a 10:30pm

[18:18] **@lapalaclubdepadel:** MIERCOLES 8 de JULIO
📈 CATEGORIA: MIXTO Damas C - 5TA
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Lina A
🇨🇴 Rafael 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[19:46] **@lapalaclubdepadel:** MIERCOLES 8 de JULIO
📈 CATEGORIA: MIXTO Damas C - 5TA
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Lina A
🇨🇴 Rafael 
🇨🇴
🇨🇴

PARTIDO ABIERTO
FALTAN 2 PALAS 
ANIMO!!!

[21:18] __@lapalaclubdepadel añadió a +57 314 4364055__

[21:18] __Alguien añadió a +57 314 4364055__

[21:24] **@AdminLaPala:** Pádel & Beer miércoles 08 de julio 🍻💪

[21:24] **@AdminLaPala:** [Reenviado] [Mensaje de album]

[21:24] **@AdminLaPala:** [Reenviado] [Imagen]

[21:24] **@AdminLaPala:** [Reenviado] [Imagen]

[21:24] **@AdminLaPala:** [Reenviado] [Imagen]

[21:24] **@AdminLaPala:** [Reenviado] [Imagen]

[21:24] **@AdminLaPala:** [Reenviado] [Imagen]

[21:24] **@AdminLaPala:** [Reenviado] [Imagen]

[21:24] **@AdminLaPala:** [Mensaje de unknown]

[21:24] **@AdminLaPala:** [Mensaje de unknown]

[21:24] **@AdminLaPala:** [Mensaje de unknown]

[21:24] **@AdminLaPala:** [Mensaje de unknown]

[21:24] **@AdminLaPala:** [Mensaje de unknown]

[21:24] **@AdminLaPala:** [Mensaje de unknown]

---

## 9 de julio de 2026

[9:42] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  11 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[10:37] **@lapalaclubdepadel:** Jueves 9 de JULIO
📈 CATEGORIA: 5ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[12:04] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰55k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[12:14] **+507 6430-5628:** _Se eliminó este mensaje_

[12:28] **@pabrodos:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  11 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Pablo R
🎾 Manuel B
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[12:56] **@lapalaclubdepadel:** Jueves 9 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 7:30 Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos B
🇨🇴 Alejandra
🇨🇴
🇨🇴

PARTIDO ABIERTO

[13:15] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[13:15] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[13:17] **@lapalaclubdepadel:** tenemos clases disponibles! hace tu reserva por PLAYTOMIC  o  a traves de nuestro WHATSAPP 3208519204

[13:39] **@rperdomo3:** Jueves 9 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 7:30 Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos B
🇨🇴 Alejandra
🇨🇴 Rafael P 
🇨🇴

PARTIDO ABIERTO

[14:02] **@lapalaclubdepadel:**
> _@rperdomo3: Jueves 9 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 7:30 Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos B
🇨🇴 Alejandra
🇨🇴 Rafael P 
🇨🇴

PARTIDO ABIERTO_
UNA PALA MAS?

[14:08] **@cdavidmar:** Jueves 9 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 7:30 Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos B
🇨🇴 Alejandra
🇨🇴 Rafael P 
🇨🇴 Cristian

PARTIDO ABIERTO

[14:19] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:22] **@lapalaclubdepadel:**
> _@cdavidmar: Jueves 9 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 7:30 Pm a 09:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos B
🇨🇴 Alejandra
🇨🇴 Rafael P 
🇨🇴 Cristian

PARTIDO ABIERTO_
partido cerrado! cancha #3 los esperamos!

[14:35] **+57 313 3300561:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  11 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Pablo R
🎾 Manuel B
 
🎾 Claudia
🎾 Claudio

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[15:33] **@liniscarrillo:** [Imagen]

[15:33] **@liniscarrillo:** [Imagen]

[15:33] **@liniscarrillo:** 🎾 Tu próximo nivel empieza en La Pala.

Entrena con profesores de alto nivel y mejora tu técnica con clases adaptadas a tu nivel, desde principiantes hasta jugadores de competición.

📲 Agenda tu clase y vive la experiencia La Pala.

[16:34] __@lapalaclubdepadel añadió a +57 310 2251076__

[19:45] **@lapalaclubdepadel:** VIERNES 10 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[19:47] **@lapalaclubdepadel:** VIERNES 10 de JULIO
📈 CATEGORIA: mixto 6ta/ Damas D
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[21:01] **@lapalaclubdepadel:** VIERNES 10 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Giselle
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

---

## 10 de julio de 2026

[7:42] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  11 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Pablo R
🎾 Manuel B
 
🎾 Claudia
🎾 Claudio

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[11:34] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰55k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[11:41] **+57 320 8584974:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰55k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[12:05] **@lapalaclubdepadel:** VIERNES 10 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Giselle
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[14:06] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[14:31] **+57 310 2251076:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Julio Bohorquez, Nicolás Bohórquez y Lina Ferrer

[14:34] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  ( 4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:10] **@lapalaclubdepadel:** Buenas tardes querida comunidad! hoy 7:30pm hasta las 9:30pm falta una pareja para completar un torneo categoria 5ta alta! alguien se anima?

[15:47] **+54 9 2634 68-2037:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢

🟢 Stephanie
🟢 Julieta

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  ( 4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[16:06] __@lapalaclubdepadel añadió a @juligiraldoe__

[18:00] **+57 320 8584974:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  ( 4 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[20:10] **@lapalaclubdepadel:** SABADO 11 de JULIO
📈 CATEGORIA: mixto 5ta/ Damas C
⌚ 10:00 Am a 11:30 Am
📍La pala 
💰45k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[21:04] **@margararpou:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[21:14] **+57 313 3300561:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  11 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰65k por persona incluye Organización, Bolas, Hidratación y Rifas 

🎾 Pablo R
🎾 Manuel B
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[21:57] **@AdminLaPala:** Torneo Pádel & Beer 10 de julio 💪🏼🍻

[21:57] **@AdminLaPala:** [Reenviado] [Mensaje de album]

[21:57] **@AdminLaPala:** [Reenviado] [Imagen]

[21:57] **@AdminLaPala:** [Reenviado] [Imagen]

[21:57] **@AdminLaPala:** [Reenviado] [Imagen]

[21:57] **@AdminLaPala:** [Reenviado] [Imagen]

[21:57] **@AdminLaPala:** [Reenviado] [Imagen]

[21:57] **@AdminLaPala:** [Mensaje de unknown]

[21:57] **@AdminLaPala:** [Mensaje de unknown]

[21:57] **@AdminLaPala:** [Mensaje de unknown]

[21:57] **@AdminLaPala:** [Mensaje de unknown]

[21:57] **@AdminLaPala:** [Mensaje de unknown]

---

## 11 de julio de 2026

[8:16] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢Sebastian Garcia
🟢Juanse C

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  ( 1PAREJA)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:32] **+57 320 2043207:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢Sebastian Garcia
🟢Juanse C

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO ABIERTO CUPOS LIMITADOS  ( 1PAREJA)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:33] **+57 310 8800142:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢Sebastian Garcia
🟢Juanse C

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO ABIERTO CUPOS LIMITADOS  ( 1PAREJA)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[9:57] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[10:09] __@lapalaclubdepadel añadió a @MargaraHidalgo__

[10:10] __Alguien añadió a @MargaraHidalgo__

[10:40] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢Sebastian Garcia
🟢Juanse C

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO CERRADO LOS ESPERAMOS!!

LISTA DE ESPERA
🎾
🎾

🎾
🎾

[10:40] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰55k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza
🟢 Valeria León 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:49] __@lapalaclubdepadel añadió a +57 317 4251164__

[12:19] **@lapalaclubdepadel:** DOMINGO 11 de JULIO
📈 CATEGORIA: mixto 5ta/ C
⌚ 11:00 Am a 12:30 Am
📍La pala 
💰45k

🇨🇴 Gustavo
🇨🇴 Camila 
🇨🇴 Hernan 
🇨🇴 

PARTIDO ABIERTO

[13:12] __@lapalaclubdepadel añadió a +57 311 8685691__

[14:15] **@mariafernandamrrr:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢Sebastian Garcia
🟢Juanse C

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO CERRADO LOS ESPERAMOS!!

LISTA DE ESPERA
🎾
🎾

🎾
🎾_
María Fernanda 
Nicolás Sahid

[14:23] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢Sebastian Garcia
🟢Juanse C

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO CERRADO LOS ESPERAMOS!!

LISTA DE ESPERA
🎾 María Fernanda
🎾 Nicolás Sahid

🎾
🎾

[14:40] **+57 311 8685691:** Puedo jugar el torneo. Si alguien busca pareja . Dm. 
HernanA

[16:06] **@lapalaclubdepadel:** DOMINGO 11 de JULIO
📈 CATEGORIA: mixto 5ta/ C
⌚ 11:00 Am a 12:30 Am
📍La pala 
💰45k

🇨🇴 Gustavo
🇨🇴 Camila 
🇨🇴 Hernan 
🇨🇴 

PARTIDO ABIERTO
FALTA (1) UNA PALA

[16:37] **+57 320 8584974:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 11:30 a 1:30 pm
📍 La Pala
💰55k por persona incluye organización, bolas, premiación. 

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[16:37] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00 a 6:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza 
🟢 Valeria León 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[19:51] **+57 304 3937234:** DOMINGO 11 de JULIO
📈 CATEGORIA: mixto 5ta/ C
⌚ 11:00 Am a 12:30 Am
📍La pala 
💰45k

🇨🇴 Gustavo
🇨🇴 Camila 
🇨🇴 Hernan 
🇨🇴 Camila A

PARTIDO ABIERTO
FALTA (1) UNA PALA

[20:02] **@lapalaclubdepadel:** DOMINGO 11 de JULIO
📈 CATEGORIA: mixto 5ta/ C
⌚ 11:00 Am a 12:30 Am
📍La pala 
💰45k

🇨🇴 Gustavo
🇨🇴 Camila 
🇨🇴 Hernan 
🇨🇴 Camila A

PARTIDO CERRADO
CANCHA #1

---

## 12 de julio de 2026

[7:02] **@lapalaclubdepadel:** DOMINGO 11 de JULIO
📈 CATEGORIA: mixto 5ta/ C
⌚ 11:00 Am a 12:30 Am
📍La pala 
💰45k

🇨🇴 Gustavo
🇨🇴 Camila 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTA (2) UNA PALA

[8:29] __@lapalaclubdepadel añadió a +57 310 8817789__

[9:00] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00 a 6:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza 
🟢 Valeria León 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:46] **@lapalaclubdepadel:** DOMINGO 11 de JULIO
📈 CATEGORIA: mixto 5ta/ C
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰50k

🇨🇴 Hernan A
🇨🇴
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTA (3) UNA PALA

[10:50] __@lapalaclubdepadel añadió a +971 52 957 3236__

[10:59] **+57 315 3599879:**
> _@lapalaclubdepadel: TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00 a 6:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza 
🟢 Valeria León 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Estoy interesado pero me falta pareja para jugar

[11:11] **+54 9 3548 58-1308:** [Mensaje de album]

[11:11] **+54 9 3548 58-1308:** [Imagen] Torneo mañanero padelenialls!! 💃🏽💃🏽🕺🕺

[11:11] **+54 9 3548 58-1308:** [Imagen]

[11:11] **+54 9 3548 58-1308:** [Imagen]

[11:11] **+54 9 3548 58-1308:** [Imagen]

[11:11] **+54 9 3548 58-1308:** [Imagen]

[11:12] **+57 310 3029444:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00 a 6:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza 
🟢 Valeria León 
 
🟢 Alejandra T
🟢 Orlando R

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (5 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[11:15] **@lapalaclubdepadel:**
> _+57 315 3599879: Estoy interesado pero me falta pareja para jugar_
Señor diego, podemos subirlo y le buscamos pareja

[11:16] **+971 52 957 3236:** Yo tambien interesado. Pero no tengo paré

[11:20] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00 a 6:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza 
🟢 Valeria León 
 
🟢 Alejandra T
🟢 Orlando R

🟢 Diego M
🟢 Hernan A

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[11:21] **@lapalaclubdepadel:**
> _+971 52 957 3236: Yo tambien interesado. Pero no tengo paré_
Ya los inscribi

[11:49] **+57 315 3599879:**
> _@lapalaclubdepadel: Señor diego, podemos subirlo y le buscamos pareja_
Si dale

[12:47] **@lapalaclubdepadel:** DOMINGO 11 de JULIO
📈 CATEGORIA: mixto C/D - 5TA /6TA
⌚ 5:00 Pm a 06:00 Am
📍La pala 
💰30k

🇨🇴 Maria Fernanda Melo
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTA (3) UNA PALA

[13:16] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00 a 6:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

🟢 Juan Loaiza 
🟢 Valeria León 
 
🟢 Alejandra T
🟢 Orlando R

🟢 Diego M
🟢 Hernan A

🟢
🟢


TORNEO ABIERTO CUPOS LIMITADOS  (1 PAREJA)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[14:13] **@lapalaclubdepadel:** UNA PAREJA MAS?

[15:30] **@lapalaclubdepadel:** TORNEO SOCIAL DOMINGO  12 de JULIO  DE 2026
                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00 a 6:00 pm
📍 La Pala
💰50k por persona incluye organización, bolas, premiación. 

 

🟢 Diego M
🟢 Hernan A

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO CANCELADO

[17:45] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nicolas Sahid

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO CERRADO LOS ESPERAMOS!!

LISTA DE ESPERA
🎾 
🎾 

🎾
🎾

[21:15] **+57 315 3599879:** Me anotan en lista de espera pf

[21:45] **+57 317 7452053:** Nicolas y Camila en lista de espera porfa.

[22:56] **+971 52 957 3236:**
> _+57 315 3599879: Me anotan en lista de espera pf_
También

---

## 13 de julio de 2026

[7:09] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nicolas Sahid

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO CERRADO LOS ESPERAMOS!!

LISTA DE ESPERA
🎾 Diego Muñoz
🎾 Nicolas

🎾 Camila 
🎾Hernan A

[8:05] **@lapalaclubdepadel:** LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ - 5TA Alta
⌚ 10:00 am a 11:00 am
📍La pala 
💰30k

🇨🇴 Lina Ávila
🇨🇴 Andrés Montoya 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTA (2) UNA PALA

[8:29] **@jeanpenent:** LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ - 5TA Alta
⌚ 10:00 am a 11:00 am
📍La pala 
💰30k

🇨🇴 Lina Ávila
🇨🇴 Andrés Montoya 
🇨🇴 Jean Michel 
🇨🇴 

PARTIDO ABIERTO
FALTA (2) UNA PALA

[8:31] **@lapalaclubdepadel:** LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ - 5TA Alta
⌚ 10:00 am a 12:00 m
📍La pala 
💰60k

🇨🇴 Lina Ávila
🇨🇴 Andrés Montoya 
🇨🇴 Jean Michel 
🇨🇴 

PARTIDO ABIERTO
FALTA (1) UNA PALA

[8:31] **+57 315 3599879:**
> _@jeanpenent: LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ - 5TA Alta
⌚ 10:00 am a 11:00 am
📍La pala 
💰30k

🇨🇴 Lina Ávila
🇨🇴 Andrés Montoya 
🇨🇴 Jean Michel 
🇨🇴 

PARTIDO ABIERTO
FALTA (2) UNA PALA_
Me interesa

[8:31] **+57 313 6519397:** Es una 1 o 2 horas ?

[8:32] **+57 320 4233809:**
> _+57 313 6519397: Es una 1 o 2 horas ?_
2

[8:32] **@lapalaclubdepadel:** LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ - 5TA Alta
⌚ 10:00 am a 12:00 m
📍La pala 
💰60k

🇨🇴 Lina Ávila
🇨🇴 Andrés Montoya 
🇨🇴 Jean Michel 
🇨🇴 Diego Muñoz

PARTIDO CERRADO
CANCHA #4

[8:42] **@lapalaclubdepadel:** LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C / C+ - 5TA / 5TA Alta
⌚ 2:00 pm a 4:00 m
📍La pala 
💰60k

🇨🇴 Nancy Sanchez
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN (3) PALAS

[8:43] **+971 52 957 3236:** LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C / C+ - 5TA / 5TA Alta
⌚ 2:00 pm a 4:00 m
📍La pala 
💰60k

🇨🇴 Nancy Sanchez
🇨🇴 Hernan A 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN (3) PALAS

[8:43] **@lapalaclubdepadel:** LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C / C+ - 5TA / 5TA Alta
⌚ 2:00 pm a 4:00 m
📍La pala 
💰60k

🇨🇴 Nancy Sanchez
🇨🇴 Hernan A 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN (2) PALAS

[9:49] **+57 320 2043207:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nicolas Sahid

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO CERRADO LOS ESPERAMOS!!

LISTA DE ESPERA
🎾 Diego Muñoz
🎾 Nicolas

🎾 Camila 
🎾Hernan A_
Nosotros nos bajamos, Alex y Pedro

[9:52] **+57 317 7452053:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nicolas Sahid

🟢 Alex Sierra
🟢 Pedro Alarcón 

TORNEO CERRADO LOS ESPERAMOS!!

LISTA DE ESPERA
🎾 Diego Muñoz
🎾 Nicolas

🎾 Camila 
🎾Hernan A_
Nosotros Nicolás y Camila también de la lista de espera

[9:52] **+57 317 7452053:** Nos bajamos

[9:55] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nicolas Sahid

🟢 Hernan A
🟢 

FALTA (1) PALA

LISTA DE ESPERA
🎾 
🎾 

🎾 
🎾

[10:12] **+57 318 5423534:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nicolas Sahid

🟢 Hernan A
🟢 Daniela Hoyos

FALTA (1) PALA

LISTA DE ESPERA
🎾 
🎾 

🎾 
🎾

[10:13] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nicolas Sahid

🟢 Hernan A
🟢 Daniela Hoyos

TORNEO CERRADO

LISTA DE ESPERA
🎾 
🎾 

🎾 
🎾

[11:01] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 13 de JUNIO  DE 2026

                    PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 4:00PM a 6:00 pm
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y PARQUEADERO GRATIS 

🟢 Julio Bohorquez
🟢 Lina Ferrer
 
🟢 Nicolas Bohorquez
🟢 William Rodríguez 

🟢 Stephanie
🟢 Julieta

🟢 Juan Loaiza
🟢 Valeria León

🟢 Maria Fernanda
🟢Nancy Sanchez

🟢 Hernan A
🟢 Daniela Hoyos

TORNEO CERRADO

LISTA DE ESPERA
🎾 
🎾 

🎾 
🎾

[12:56] **@nanjovas:** _Se eliminó este mensaje_

[14:53] **@lapalaclubdepadel:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN (2) PALAS

[14:54] **@lapalaclubdepadel:** MARTES LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 5:00 pm a 7:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos M
🇨🇴 Alejandro N
🇨🇴  Iván O
🇨🇴 

PARTIDO ABIERTO
FALTAN (1) PALAS

[15:34] **+57 311 2645512:** MARTES LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 5:00 pm a 7:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos M
🇨🇴 Alejandro N
🇨🇴  Iván O
🇨🇴 

PARTIDO ABIERTO
FALTAN (1) PALAS

[16:35] **@rvanegasa:**
> _+57 311 2645512: MARTES LUNES FESTIVO 13 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 5:00 pm a 7:00 Pm
📍La pala 
💰50k

🇨🇴 Carlos M
🇨🇴 Alejandro N
🇨🇴  Iván O
🇨🇴 

PARTIDO ABIERTO
FALTAN (1) PALAS_
Este es hoy?

[16:42] __+57 310 4202622 se unieron mediante el enlace de invitación__

[16:50] __@IvanBogota11 se unieron mediante el enlace de invitación__

[18:15] **@lapalaclubdepadel:** [Imagen]

[18:15] **@lapalaclubdepadel:** [Imagen]

[18:15] **@lapalaclubdepadel:** [Imagen]

[18:15] **@lapalaclubdepadel:** [Imagen] TORNEO LUNES FESTIVO

[18:15] **@lapalaclubdepadel:** [Mensaje de unknown]

[18:15] **@lapalaclubdepadel:** [Mensaje de unknown]

[18:15] **@lapalaclubdepadel:** [Mensaje de unknown]

[18:15] **@lapalaclubdepadel:** [Mensaje de unknown]

---

## 14 de julio de 2026

[9:24] **@lapalaclubdepadel:** MARTES 14 de JULIO
📈 CATEGORIA: MIXTO Damas C/D - 5TA/6TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[9:56] **@lapalaclubdepadel:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN (2) PALAS

[9:58] __@AdminLaPala eliminó a +57 316 6264600__

[9:58] __@AdminLaPala eliminó a +56 9 8218 1963__

[10:27] **+57 320 4233809:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 Lina Ávila 
🇨🇴 Mario Peralta 

PARTIDO ABIERTO
FALTAN (2) PALAS

[10:31] **@IvanBogota11:** Puedo asistir?

[10:32] **@lapalaclubdepadel:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 Lina Ávila 
🇨🇴 Mario Peralta 

PARTIDO CERRADO
CANCHA 2

[13:44] **+57 320 4233809:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN (2) PALAS

[13:44] **@IvanBogota11:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 Ivan B.
🇨🇴 

PARTIDO ABIERTO
FALTAN (2) PALAS

[13:45] **@lapalaclubdepadel:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 Ivan B.
🇨🇴 

PARTIDO ABIERTO
FALTA (1) PALA

[15:32] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[15:32] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[15:33] **@lapalaclubdepadel:** Haz tu reserva a través de nuestro WhatsApp o nuestra app PLAYTOMIC! Los esperamos!

[15:42] **+57 301 6573017:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto 4TA 
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Paola
🇨🇴 Daniel B
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTA (2) PALA

[16:36] **@lapalaclubdepadel:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto C+ /  5TA Alta
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Nancy 
🇨🇴 Andrés V
🇨🇴 Ivan B.
🇨🇴 Sebastian G

CERRADO!
LOS ESPERAMOS

[16:41] **@lapalaclubdepadel:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto 4TA 
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Paola Sanjuan
🇨🇴 Daniel B
🇨🇴 Noelia
🇨🇴 

PARTIDO ABIERTO
FALTA (1) PALA

[16:50] **+57 321 4346037:** MARTES 14 DE JULIO
📈 CATEGORIA: mixto 4TA 
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Paola Sanjuan
🇨🇴 Daniel B
🇨🇴 Noelia
🇨🇴 Henrry C 

PARTIDO ABIERTO
FALTA (1) PALA

[17:08] **@lapalaclubdepadel:**
> _+57 321 4346037: MARTES 14 DE JULIO
📈 CATEGORIA: mixto 4TA 
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰62.5k

🇨🇴 Paola Sanjuan
🇨🇴 Daniel B
🇨🇴 Noelia
🇨🇴 Henrry C 

PARTIDO ABIERTO
FALTA (1) PALA_
Partido cerrado! Los esperamos!

[22:32] __@lapalaclubdepadel añadió a @jvelandiavacca__

[22:43] __@lapalaclubdepadel añadió a @Gio373__

---

## 15 de julio de 2026

[0:08] **+54 9 3834 05-0377:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[8:18] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾
🎾
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[8:40] **@lapalaclubdepadel:** MIERCOLES 15 DE JULIO
📈 CATEGORIA: DAMAS  D 
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰50k

🇨🇴 Camila S
🇨🇴 Valeria Leon
🇨🇴 Alejandra
🇨🇴 

PARTIDO ABIERTO
FALTA (1) PALA

[11:11] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: MIERCOLES 15 DE JULIO
📈 CATEGORIA: DAMAS  D 
⌚ 6:00 pm a 7:30 pm
📍La pala 
💰50k

🇨🇴 Camila S
🇨🇴 Valeria Leon
🇨🇴 Alejandra
🇨🇴 

PARTIDO ABIERTO
FALTA (1) PALA_
FALTA 1 PALA, QUIEN SE ANIMA!

[12:02] __@lapalaclubdepadel añadió a +31 6 84873308__

[14:30] __@lapalaclubdepadel eliminó a +54 9 3834 05-0377__

[15:29] **@lapalaclubdepadel:** MIERCOLES 15 de JULIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[16:13] **+57 315 8994236:**
> _@lapalaclubdepadel: MIERCOLES 15 de JULIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO_
De cuarta?

[16:14] **@lapalaclubdepadel:** MIERCOLES 15 de JULIO
📈 CATEGORIA: 4ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Jose Ortiz
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[16:14] **+57 315 8994236:**
> _@lapalaclubdepadel: MIERCOLES 15 de JULIO
📈 CATEGORIA: 4ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Luis Ortiz
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO_
José!

[16:38] **@lapalaclubdepadel:** MIERCOLES 15 de JULIO
📈 CATEGORIA: 4ta/5ta alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Juan David Granados
🇨🇴 Jean Michel
🇨🇴Sebastian G
🇨🇴

PARTIDO ABIERTO

[16:46] **+57 315 6450599:** MIERCOLES 15 de JULIO
📈 CATEGORIA: 4ta/5ta alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Juan David Granados
🇨🇴 Jean Michel
🇨🇴Sebastian G
🇨🇴 david F

PARTIDO ABIERTO

[16:50] **@lapalaclubdepadel:**
> _+57 315 6450599: MIERCOLES 15 de JULIO
📈 CATEGORIA: 4ta/5ta alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Juan David Granados
🇨🇴 Jean Michel
🇨🇴Sebastian G
🇨🇴 david F

PARTIDO ABIERTO_
PARTIDO CERRADO, LOS ESPERAMOS! #4

[17:08] **@jvillada97:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[17:24] **@SergioRengifoC:** MIERCOLES 15 de JULIO
📈 CATEGORIA: 4ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Jose Ortiz
🇨🇴 Sergio R 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[18:37] **+57 316 5348415:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[18:39] **+507 6430-5628:** _Se eliminó este mensaje_

[19:45] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martines
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[21:15] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martines
🎾Leonardo

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )

[21:29] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )

---

## 16 de julio de 2026

[7:48] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: MIXTO C/D - 5TA / 6TA
⌚ 02:00 Pm a 04:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[10:00] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: MIXTO C/D - 5TA / 6TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[10:11] **+507 6430-5628:** JUEVES 16 de JULIO
📈 CATEGORIA: MIXTO C/D - 5TA / 6TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴 Nan
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[11:29] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: MIXTO C/D - 5TA / 6TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[11:42] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Sergio Rengifo 
🇨🇴  Luis Eduardo M 
🇨🇴  Cesar Rojas
🇨🇴

PARTIDO ABIERTO

[11:55] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Sergio Rengifo 
🇨🇴  Luis Eduardo M 
🇨🇴  Cesar Rojas
🇨🇴

PARTIDO ABIERTO_
cancha reservada
DISPONIBILIDAD DE 09:00PM A 10:30PM

[11:55] **@juanselopez5_:**
> _@lapalaclubdepadel: JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Sergio Rengifo 
🇨🇴  Luis Eduardo M 
🇨🇴  Cesar Rojas
🇨🇴

PARTIDO ABIERTO_
Juan S López

[11:56] **@lapalaclubdepadel:**
> _@juanselopez5_: Juan S López_
queda disponibilidad a las 09:00pm

[12:17] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Sergio Rengifo 
🇨🇴  Luis Eduardo M 
🇨🇴  Cesar Rojas
🇨🇴 Juan S Lopez

PARTIDO CERRADO
CANCHA 1

[12:21] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA:  5TA / 6TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[12:44] __[Llamada]__

[13:28] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Sergio Rengifo 
🇨🇴  Luis Eduardo M 
🇨🇴  Cesar Rojas
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA ANIMO!

[13:59] __@lapalaclubdepadel añadió a @angelamontero16__

[13:59] __Alguien añadió a @angelamontero16__

[15:26] **+57 315 5758858:** JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Sergio Rengifo 
🇨🇴  Luis Eduardo M 
🇨🇴  Cesar Rojas
🇨🇴 Lucas

PARTIDO CERRADO

[15:29] **@lapalaclubdepadel:**
> _+57 315 5758858: JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Sergio Rengifo 
🇨🇴  Luis Eduardo M 
🇨🇴  Cesar Rojas
🇨🇴 Lucas

PARTIDO CERRADO_
LOS ESPERAMOS!

[15:32] **+57 315 8994236:** Tenes partido de 7:30? Somos dos de cuarta

[15:32] **@lapalaclubdepadel:**
> _+57 315 8994236: Tenes partido de 7:30? Somos dos de cuarta_
podemos convocar uno para las 9pm, 7:30 no tenemos disponibilidad

[15:33] **+57 315 8994236:** Para 6?

[15:33] **@lapalaclubdepadel:** si!

[15:35] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: 4TA
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Jose Ortiz
🇨🇴  
🇨🇴  
🇨🇴 

PARTIDO ABIERTO

[16:09] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA:  5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴
🇨🇴

PARTIDO ABIERTO

[16:29] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Andres Gonzalez
🇨🇴  
🇨🇴  
🇨🇴 

PARTIDO ABIERTO

[16:39] **@carlos.cruz.530111:**
> _@lapalaclubdepadel: JUEVES 16 de JULIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Andres Gonzalez
🇨🇴  
🇨🇴  
🇨🇴 

PARTIDO ABIERTO_
Yo

[16:41] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Andres Gonzalez
🇨🇴  Carlos Narvaez
🇨🇴  
🇨🇴 

PARTIDO ABIERTO

[16:58] **@lapalaclubdepadel:** DOS PALAS

[17:33] **+57 310 2450142:** JUEVES 16 de JULIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰50k

🇨🇴  Andres Gonzalez
🇨🇴  Carlos Narvaez
🇨🇴  Santiago Mora
🇨🇴 

PARTIDO ABIERTO

[17:35] **+57 310 2450142:** Una pala mas

[18:21] **@lapalaclubdepadel:** JUEVES 16 de JULIO
📈 CATEGORIA:  5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Andres G
🇨🇴 Juan S
🇨🇴
🇨🇴

PARTIDO ABIERTO

[18:49] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )

[19:08] **+57 304 4715071:** JUEVES 16 de JULIO
📈 CATEGORIA:  5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Andres G
🇨🇴 Juan S
🇨🇴 Pablo C
🇨🇴

PARTIDO ABIERTO

[19:17] **+34 677 17 38 32:** JUEVES 16 de JULIO
📈 CATEGORIA:  5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Andres G
🇨🇴 Juan S
🇨🇴 Pablo C
🇨🇴 Javier J

PARTIDO CERRADO

[19:40] **@lapalaclubdepadel:**
> _+34 677 17 38 32: JUEVES 16 de JULIO
📈 CATEGORIA:  5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Andres G
🇨🇴 Juan S
🇨🇴 Pablo C
🇨🇴 Javier J

PARTIDO CERRADO_
PARTIDO CERRADO CANCHA #3

[21:42] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS )

---

## 17 de julio de 2026

[6:34] **+57 321 2004293:** Elena

[6:36] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Elena De Luna
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA 1 PALA)

[7:21] **+57 313 3300561:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Elena De Luna
🎾

🎾Claudia
🎾Claudio

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA 1 PALA)

[7:22] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Elena De Luna
🎾

🎾Claudia
🎾Claudio

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PALA)

[7:27] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[9:01] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[9:21] __@lapalaclubdepadel añadió a @etorresrojas__

[9:22] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  4TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 Jose O
🇨🇴 Medicci
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[10:21] **+57 300 3065645:** VIERNES 17 de JULIO
📈 CATEGORIA:  4TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 Jose O
🇨🇴 Medicci
🇨🇴 Juan G
🇨🇴 

PARTIDO ABIERTO

[11:10] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  4TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 Jose O
🇨🇴 Medicci
🇨🇴 Juan G
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA ANIMO!!!

[11:16] __@lapalaclubdepadel añadió a +506 8336 6004__

[11:16] __Alguien añadió a +506 8336 6004__

[11:30] **+57 315 8994236:**
> _@lapalaclubdepadel: VIERNES 17 de JULIO
📈 CATEGORIA:  4TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 Jose O
🇨🇴 Medicci
🇨🇴 Juan G
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA ANIMO!!!_
Cristian

[11:31] **+56 9 5637 0965:**
> _@lapalaclubdepadel: VIERNES 17 de JULIO
📈 CATEGORIA:  4TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 Jose O
🇨🇴 Medicci
🇨🇴 Juan G
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA ANIMO!!!_
Anotado

[11:33] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  4TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 Jose O
🇨🇴 Medicci
🇨🇴 Juan G
🇨🇴 Cristian C

PARTIDO CERRADO
CANCHA 5

[11:39] **@AdminLaPala:** _Se eliminó este mensaje_

[11:39] **@AdminLaPala:** [Imagen] El Mundial está por terminar… pero el mejor partido del viernes todavía lo puedes jugar tú. 🎾🔥

Reúne a tus amigos, reserva la cancha y aprovecha esta oportunidad 

Nos vemos en la cancha. 💚

[11:49] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  Mixto Damas C/D - 5TA / 6TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[11:49] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  5TA 
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[12:22] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  5TA Alta
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k

🇨🇴 David Farro
🇨🇴 Javier Correa
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN 2 PALAS
ANIMO!!!

[12:25] **+57 317 3631403:** _Se eliminó este mensaje_

[13:45] **+57 310 8953948:** VIERNES 17 de JULIO
📈 CATEGORIA:  5TA Alta
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k

🇨🇴 David Farro
🇨🇴 Javier Correa
🇨🇴 Andres Gonzalez
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[14:11] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Claudia 
🎾Claudio

🎾Larry Echeverry 
🎾Zulay Chacon

🎾Elena De Luna
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA 1 PALA)

[14:40] **@alejandromusical:** VIERNES 17 de JULIO
📈 CATEGORIA:  5TA Alta
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k

🇨🇴 David Farro
🇨🇴 Javier Correa
🇨🇴 Andres Gonzalez
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[15:04] __+57 314 3156873 se unieron mediante el enlace de invitación__

[15:09] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:19] **@jpfernandezrod:** VIERNES 17 de JULIO
📈 CATEGORIA:  5TA Alta
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k

🇨🇴 David Farro
🇨🇴 Javier Correa
🇨🇴 Andres Gonzalez
🇨🇴 Juan Pablo 

PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[15:19] **@lapalaclubdepadel:**
> _@alejandromusical: VIERNES 17 de JULIO
📈 CATEGORIA:  5TA Alta
⌚ 04:00 Pm a 06:00 Pm
📍La pala 
💰60k

🇨🇴 David Farro
🇨🇴 Javier Correa
🇨🇴 Andres Gonzalez
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!_
partido cerrado los esperamos

[15:33] **+507 6430-5628:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:34] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  MIXTO
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰65k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[15:34] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[15:37] **@lapalaclubdepadel:** TENEMOS DISPONIBILIDAD EN LAS 2 FRANJAS!

🎾6PM - 8PM

🎾8PM - 10PM

[17:22] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢
🟢

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[18:03] **@lapalaclubdepadel:** VIERNES 17 de JULIO
📈 CATEGORIA:  5ta
⌚ 08:00 Pm a 10:00 Pm
📍La pala 
💰65k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[18:34] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Claudia 
🎾Claudio

🎾Larry Echeverry 
🎾Zulay Chacon

🎾Elena De Luna
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA 1 PALA)

[18:43] **@lapalaclubdepadel:** SABADO 18 de JULIO
📈 CATEGORIA:  5ta
⌚ 08:00 Am a 10:00 Am
📍La pala 
💰50k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[18:47] __@lapalaclubdepadel añadió a +57 317 5949935__

[18:47] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[18:51] **@lapalaclubdepadel:** BUENAS NOCHES QUERIDA COMUNIDAD! QUEREMOS INFORMARLES QUE EL BENEFICIO DEL PARQUEADERO🚗 GRATIS SE EXTENDIO HASTA EL DIA LUNES FESTIVO 21 DE JULIO‼️
LOS ESPERAMOS A TODOS PARA DISFRUTAR DE NUESTRAS PROMOCIONES❕❕❕

[19:13] **+57 304 4715071:** SABADO 18 de JULIO
📈 CATEGORIA:  5ta
⌚ 08:00 Am a 10:00 Am
📍La pala 
💰50k

🇨🇴 Pablo C
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[19:40] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Claudia 
🎾Claudio

🎾Larry Echeverry 
🎾Zulay Chacon

🎾
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS)

[20:04] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: BUENAS NOCHES QUERIDA COMUNIDAD! QUEREMOS INFORMARLES QUE EL BENEFICIO DEL PARQUEADERO🚗 GRATIS SE EXTENDIO HASTA EL DIA LUNES FESTIVO 21 DE JULIO‼️
LOS ESPERAMOS A TODOS PARA DISFRUTAR DE NUESTRAS PROMOCIONES❕❕❕_
20 DE JULIO

[20:18] **+57 315 5758858:** SABADO 18 de JULIO
📈 CATEGORIA:  4ta
⌚ 09:00 Am a 10:30 Am
📍La pala 
💰

🇨🇴 Lucas C (revés) 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[20:46] **+57 310 2338636:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[20:53] **@lapalaclubdepadel:**
> _+57 310 2338636: Imagen: Vendo pala Adidas Metalbone 3.4 2025 con paletero 10/10 $700.000_
Buenas noches, les recordamos que el grupo es solo para la organizacion de partidos, torneos e informacion del club.

---

## 18 de julio de 2026

[7:08] **+57 316 4728428:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢Douglas 
🟢juan Guillermo

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[7:15] **+57 315 5758858:** SABADO 18 de JULIO
📈 CATEGORIA:  4ta
⌚ 09:00 Am a 10:30 Am
📍La pala 
💰

🇨🇴 Lucas C (revés) 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[7:32] **+57 311 2645512:** SABADO 18 de JULIO
📈 CATEGORIA:  4ta
⌚ 09:00 Am a 10:30 Am
📍La pala 
💰

🇨🇴 Lucas C (revés) 
🇨🇴 Carlos M 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[8:03] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Claudia 
🎾Claudio

🎾Larry Echeverry 
🎾Zulay Chacon

🎾
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS)

[9:30] **@lapalaclubdepadel:** SABADO 18 de JULIO
📈 CATEGORIA:  4ta
⌚ 10:00 Am a 11:30 Am
📍La pala 
💰45K

🇨🇴 Lucas C (revés) 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[9:47] **+57 315 5758858:** SABADO 18 de JULIO
📈 CATEGORIA:  4ta
⌚ 11:00 Am a 12:30 pm
📍La pala 
💰45K

🇨🇴 Lucas C (revés) 
🇨🇴 Carlos
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[10:17] **+57 310 6843763:**
> _+57 316 4728428: ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢Douglas 
🟢juan Guillermo

🟢
🟢

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (6 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Alejandro H y Sebastian F

[10:21] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢Douglas 
🟢juan Guillermo

🟢Alejandro H
🟢Sebastian F

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[10:22] **@lapalaclubdepadel:** SABADO 18 de JULIO
📈 CATEGORIA:  4ta
⌚ 11:00 Am a 12:30 pm
📍La pala 
💰45K

🇨🇴 Lucas C (revés) 
🇨🇴 Carlos
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PAREJA
ANIMO!!!

[11:16] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[11:16] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO  18 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰50k por persona incluye Organización, Bolas y Rifas 

🎾 aleja 
🎾 Juanca 
 
🎾 Jesus
🎾 Yesika

🎾Andrea Torres
🎾Xavier Guevara

🎾 Carolina Torres
🎾 Gabriel 
️
🎾 Nicolas Martinez
🎾Leonardo

🎾Yamil
🎾Adriana

🎾Claudia 
🎾Claudio

🎾Larry Echeverry 
🎾Zulay Chacon

🎾
🎾

🎾
🎾
 
*TORNEO ABIERTO CUPOS LIMITADOS ( 2 PAREJAS)_
torneo cerrado! los esperamooos

[12:26] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢Douglas 
🟢juan Guillermo

🟢Alejandro H
🟢Sebastian F

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[13:32] **+57 316 4728428:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢
🟢

🟢Alejandro H
🟢Sebastian F

🟢
🟢

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[14:12] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:12] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:12] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:12] **@lapalaclubdepadel:** [Mensaje de unknown]

[14:12] **@lapalaclubdepadel:** [Mensaje de unknown]

[14:12] **@lapalaclubdepadel:** [Mensaje de unknown]

[14:12] **@lapalaclubdepadel:** TORNEO SOCIAL SABADO 18 DE JULIO! GRACIAS A TODOS!!🏅

[14:17] **@lapalaclubdepadel:** SABADO 18 de JULIO
📈 CATEGORIA:  5TA - 6TA / DAMAS D -  C
⌚ 4:00 Pm a 6:00 pm
📍La pala 
💰50K

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
FALTAN (4) PALAS
ANIMO!!!

[14:18] **+57 314 3304304:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢Douglas 
🟢juan Guillermo

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢
🟢

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:17] **+57 311 7841842:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢Douglas 
🟢juan Guillermo

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO ABIERTO CUPOS LIMITADOS  (3 PAREJAS)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:18] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢

🟢Douglas 
🟢juan Guillermo

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO ABIERTO CUPOS LIMITADOS  (2 JUGADORES)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:43] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢Douglas 
🟢juan Guillermo

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO ABIERTO CUPOS LIMITADOS  (1 JUGADORES)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[17:13] **+57 316 4728428:**
> _@lapalaclubdepadel: ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢Douglas 
🟢juan Guillermo

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO ABIERTO CUPOS LIMITADOS  (1 JUGADORES)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Douglas y Juan Guillermo ya no podemos

[17:13] **+57 316 4728428:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢
🟢

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO ABIERTO CUPOS LIMITADOS  (1 JUGADORES)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[17:20] **@iaquintero:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢 Pollo 🎩 
🟢 Ivan A

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO ABIERTO CUPOS LIMITADOS  (1 JUGADORES)
ANIMO NO TE QUEDES SIN PARTICIPAR!

[20:14] **@lug.contreras:**
> _@iaquintero: ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S. (Busco pareja C/5ta 🤗)
🟢 
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢 Pollo 🎩 
🟢 Ivan A

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO ABIERTO CUPOS LIMITADOS  (1 JUGADORES)
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Hola me gustaría entrar con Nancy si no hay lío

[20:16] **+507 6430-5628:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S
🟢 Lug
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢 Pollo 🎩 
🟢 Ivan A

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO CERRADO CUPOS LIMITADOS
ANIMO NO TE QUEDES SIN PARTICIPAR!

---

## 19 de julio de 2026

[8:07] **+57 318 7757726:**
> _+507 6430-5628: ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S
🟢 Lug
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢 Pollo 🎩 
🟢 Ivan A

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO CERRADO CUPOS LIMITADOS
ANIMO NO TE QUEDES SIN PARTICIPAR!_
Me anoto en lista de espera por si se abre un cupo.

[8:09] **@lapalaclubdepadel:** ATENCION‼️

TORNEO FESTIVO LUNES 20 de JULIO  DE 2026

           PAREJA FIJA‼️
📈 Categoría: 5ta/6ta/ Damas C/D +
inscripción Individual 
⌚Hora: 9:00AM a 11:00 am
📍 La Pala
💰50K INCLUYE BOLAS, ORGANIZACION Y RIFAS

🟢 Nancy S
🟢 Lug
 
🟢 Ernesto T
🟢 Leonardo Perez

🟢 Pollo 🎩 
🟢 Ivan A

🟢Alejandro H
🟢Sebastian F

🟢Nestor
🟢Laura

🟢Xiomara
🟢Mateo

TORNEO CERRADO
LISTA DE ESPERA

🟢Jorge Esquivel
🟢Laura Rojas

[8:10] **+57 300 2984856:** Yo también a la lista de espera 🫶🏻

[10:40] **@AdminLaPala:** [Reenviado] [Mensaje de album]

[10:40] **@AdminLaPala:** [Reenviado] [Imagen]

[10:40] **@AdminLaPala:** [Reenviado] [Imagen]

[10:40] **@AdminLaPala:** [Reenviado] [Imagen]

[10:40] **@AdminLaPala:** [Reenviado] [Imagen]

[10:40] **@AdminLaPala:** Torneo Padelennials Domingo AM 💪👏

[12:07] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[12:08] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[13:47] **@lapalaclubdepadel:** DOMINGO 19 de JULIO
📈 CATEGORIA:  5ta - 6ta
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰50K

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[15:53] **@Julimejia97:** DOMINGO 19 de JULIO
📈 CATEGORIA:  5ta - 6ta
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰50K

🇨🇴  Juliana 
🇨🇴 Nicolás 
🇨🇴 Daniel
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

---

## 20 de julio de 2026

[10:23] **@lapalaclubdepadel:** DISPONIBILIDAD MARTES 21/7

🟢6:00am
❌️7:00am
🟢8:00am
🟢9:00am
❌️10:00am
🟢11:00am

[10:23] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[10:42] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[11:43] **@lapalaclubdepadel:** LUNES 20 de JULIO
📈 CATEGORIA:  4TA
⌚ 05:00 Pm a 06:00 Pm
📍La pala 
💰30K

🇨🇴  Tomas B
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[12:25] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[15:27] __[Notificación del sistema]__

[16:01] __+57 321 3820233 se unieron mediante el enlace de invitación__

[16:39] **@lapalaclubdepadel:** [Mensaje de album]

[16:39] **@lapalaclubdepadel:** [Imagen]

[16:39] **@lapalaclubdepadel:** [Imagen]

[16:39] **@lapalaclubdepadel:** [Imagen]

[16:39] **@lapalaclubdepadel:** [Imagen]

[16:39] **@lapalaclubdepadel:** [Mensaje de unknown]

[16:39] **@lapalaclubdepadel:** [Mensaje de unknown]

[16:39] **@lapalaclubdepadel:** [Mensaje de unknown]

[16:39] **@lapalaclubdepadel:** [Mensaje de unknown]

[16:39] **@lapalaclubdepadel:** Torneo Americano Lunes Festivo

[19:59] **+54 9 3548 58-1308:** [Mensaje de album]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Imagen]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[19:59] **+54 9 3548 58-1308:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Mensaje de album]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Imagen]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

[21:07] **@lapalaclubdepadel:** [Mensaje de unknown]

---

## 21 de julio de 2026

[8:20] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[9:16] **@lapalaclubdepadel:** MARTES 21 de JULIO
📈 CATEGORIA: 5ta / 6ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰62.5K

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!

[16:22] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[16:22] **@lapalaclubdepadel:** [Reenviado] ¡Una nueva incorporación llega a La Pala! 🎾🇦🇷

Nos llena de alegría darle la bienvenida a Charly, quien desde ahora hace parte de la familia La Pala. 💚

Con formación profesional, experiencia en pádel y una metodología enfocada en el desarrollo de cada jugador, Charly llega para acompañarte a llevar tu juego al siguiente nivel.

📅 A partir de mañana ya podrás reservar tus clases con él. 

¡Bienvenido, Charly! Estamos seguros de que juntos viviremos grandes partidos y grandes aprendizajes. 💪🎾

[16:23] __@AdminLaPala añadió a +57 301 2093946__

[16:48] __[Notificación del sistema]__

[16:49] **@lapalaclubdepadel:** MARTES 21 de JULIO
📈 CATEGORIA: 3ra
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[16:50] **@lapalaclubdepadel:** MARTES 21 de JULIO
📈 CATEGORIA: 3ra
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  Sebastian Sanchez
🇨🇴 Juan Felipe Trillos
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[20:13] __@Tefa.93 se unieron mediante el enlace de invitación__

[21:15] __@lapalaclubdepadel añadió a @teomunoz06__

[22:07] __@lapalaclubdepadel añadió a +57 321 3721600__

---

## 22 de julio de 2026

[14:15] **+57 317 4015496:** MIÉRCOLES 22 de JULIO
📈 CATEGORIA: 4a 
Pareja mixta
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  Fernando Jiménez 
🇨🇴 Carolina Martín
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[14:23] **@patfadul:** MIÉRCOLES 22 de JULIO
📈 CATEGORIA: 4a 
Pareja mixta
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  Fernando Jiménez 
🇨🇴 Carolina Martín
🇨🇴 Patty 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[14:58] **@lapalaclubdepadel:**
> _@patfadul: MIÉRCOLES 22 de JULIO
📈 CATEGORIA: 4a 
Pareja mixta
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  Fernando Jiménez 
🇨🇴 Carolina Martín
🇨🇴 Patty 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!_
uno mas?

[15:00] **@lapalaclubdepadel:** MIÉRCOLES 22 de JULIO
📈 CATEGORIA: 4a 
Pareja mixta
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  Fernando Jiménez 
🇨🇴 Carolina Martín
🇨🇴 Patty 
🇨🇴 Daniel

PARTIDO CERRADO
LOS ESPERAMOS!

[15:19] __@felipe_bello29 se unieron mediante el enlace de invitación__

[15:19] **@lapalaclubdepadel:** TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾
🎾 

🎾 
🎾 

🎾
🎾

🎾
🎾

🎾 
🎾

🎾
🎾
 
TORNEO ABIERTO (6 PAREJAS) CUPOS LIMITADOS

[15:24] **@lapalaclubdepadel:** MIERCOLES 22 de JULIO
📈 CATEGORIA: 5ta
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[15:27] **@lapalaclubdepadel:** MIERCOLES 22 de JULIO
📈 CATEGORIA: 4ta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[15:38] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾
🎾 

🎾 
🎾 

🎾
🎾

🎾
🎾

🎾 
🎾

🎾
🎾
 
TORNEO ABIERTO (6 PAREJAS) CUPOS LIMITADOS_
Sebastian F/ Alejandro H

[15:39] **@lapalaclubdepadel:** TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾Sebastian F
🎾 Alejandro H

🎾 
🎾 

🎾
🎾

🎾
🎾

🎾 
🎾

🎾
🎾
 
TORNEO ABIERTO (6 PAREJAS) CUPOS LIMITADOS

[15:41] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾Sebastian F
🎾 Alejandro H

🎾 
🎾 

🎾
🎾

🎾
🎾

🎾 
🎾

🎾
🎾
 
TORNEO ABIERTO (6 PAREJAS) CUPOS LIMITADOS_
Alejandro H y Juanes Z

[15:44] **@lapalaclubdepadel:** TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾Juanes Z
🎾 Alejandro H

🎾 
🎾 

🎾
🎾

🎾
🎾

🎾 
🎾

🎾
🎾
 
TORNEO ABIERTO (5 PAREJAS) CUPOS LIMITADOS

[15:47] **+57 310 6843763:** perdon, son dos parejas. -
Sebastian F y Daniel H
Juanes Z y Alejandro H

[15:51] **@lapalaclubdepadel:** TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾Juanes Z
🎾 Alejandro H

🎾 Sebastian F
🎾 Daniel H

🎾
🎾

🎾
🎾

🎾 
🎾

🎾
🎾
 
TORNEO ABIERTO (4 PAREJAS) CUPOS LIMITADOS

[15:54] **+57 317 4015496:**
> _@lapalaclubdepadel: MIÉRCOLES 22 de JULIO
📈 CATEGORIA: 4a 
Pareja mixta
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5K

🇨🇴  Fernando Jiménez 
🇨🇴 Carolina Martín
🇨🇴 Patty 
🇨🇴 Daniel

PARTIDO CERRADO
LOS ESPERAMOS!_
Cancha 5

[16:20] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[22:19] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[22:19] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[22:20] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[22:21] **@liniscarrillo:** [Mensaje de album]

[22:21] **@liniscarrillo:** [Imagen]

[22:21] **@liniscarrillo:** [Imagen]

[22:21] **@liniscarrillo:** [Imagen]

[22:21] **@liniscarrillo:** [Imagen]

[22:21] **@liniscarrillo:** [Imagen]

[22:28] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[22:29] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[22:29] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[22:30] **@lapalaclubdepadel:** Buenas noches! Recuerden  que el grupo es solo para publicar partidos, torneos e información del club, gracias

---

## 23 de julio de 2026

[7:19] **+57 320 2043207:** TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾Juanes Z
🎾 Alejandro H

🎾 Sebastian F
🎾 Daniel H

🎾 Mauricio S
🎾 Pedro A

🎾
🎾

🎾 
🎾

🎾
🎾
 
TORNEO ABIERTO (4 PAREJAS) CUPOS LIMITADOS

[8:04] __@lapalaclubdepadel añadió a +44 7931 290432__

[8:55] **@lapalaclubdepadel:** TORNEO 5TA CATEGORIA PAREJA FIJA

🎾🎾JUEVES 23 de JULIO 🎾🎾

📈 *Categoría: 5TA🌟
⌚6:00PM - 07:30 PM
📍La Pala
💰64k por persona

🥇PRIMER LUGAR: Bono de $50000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $30000 en Playtomic para la pareja

🎾Juanes Z
🎾 Alejandro H

🎾 Sebastian F
🎾 Daniel H

🎾 Mauricio S
🎾 Pedro A

🎾
🎾

🎾 
🎾

🎾
🎾
 
*TORNEO CANCELADO      *

[14:19] __+49 1520 3975820 se unieron mediante el enlace de invitación__

[17:08] **@lapalaclubdepadel:** JUEVES 23 de JULIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[17:20] **+57 304 4715071:** JUEVES 23 de JULIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Pablo C
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[17:21] **@lapalaclubdepadel:** MIERCOLES de JULIO
📈 CATEGORIA: 3ra
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Sebastian Sanchez
🇨🇴 Juan Felipe Trillos
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[17:30] **@santi.catam:** JUEVES 23 de JULIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Pablo C
🇨🇴 santiago C
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[17:32] **@IvanBogota11:** Ivan Bogota

[17:32] **+44 7931 290432:**
> _@lapalaclubdepadel: MIERCOLES de JULIO
📈 CATEGORIA: 3ra
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Sebastian Sanchez
🇨🇴 Juan Felipe Trillos
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!_
Quiero unirme a este. Cómo se hace?

[17:32] **@IvanBogota11:** JUEVES 23 de JULIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Pablo C
🇨🇴 santiago C
🇨🇴 Ivan Bogota
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[17:35] **+44 7931 290432:**
> _@lapalaclubdepadel: MIERCOLES de JULIO
📈 CATEGORIA: 3ra
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Sebastian Sanchez
🇨🇴 Juan Felipe Trillos
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!_
Este partido es hoy?

[17:39] **@lapalaclubdepadel:** JUEVES 23 de JULIO
📈 CATEGORIA: 3ra
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Sebastian Sanchez
🇨🇴 Juan Felipe Trillos
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[17:39] **+44 7931 290432:** JUEVES 23 de JULIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Pablo C
🇨🇴 santiago C
🇨🇴 Ivan Bogota
🇨🇴 Nicolás Di Domenico

PARTIDO ABIERTO
ANIMO!!!

[17:41] **@lapalaclubdepadel:**
> _+44 7931 290432: JUEVES 23 de JULIO
📈 CATEGORIA: 5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50K

🇨🇴  Pablo C
🇨🇴 santiago C
🇨🇴 Ivan Bogota
🇨🇴 Nicolás Di Domenico

PARTIDO ABIERTO
ANIMO!!!_
partido cerrado cancha 5

[18:40] __@lapalaclubdepadel añadió a +593 99 736 6426__

[19:02] **@lapalaclubdepadel:** VIERNES 24 de JULIO
📈 CATEGORIA: 5TA/6TA
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰70K    2 HORAS!!!

🇨🇴  Christian Vaca
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[19:46] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 25 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾
🎾
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[19:52] **+57 316 3358569:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 25 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾 Santiago Ramírez 
🎾 Tomás Villada 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

---

## 24 de julio de 2026

[10:57] __@lapalaclubdepadel añadió a +57 320 8050516__

[10:58] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 25 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾 Santiago Ramírez 
🎾 Tomás Villada 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

[11:22] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[12:21] **@lapalaclubdepadel:** VIERNES 24 de JULIO
📈 CATEGORIA: 5TA/6TA
⌚ 06:00 Pm a 08:00 Pm
📍La pala 
💰70K    2 HORAS!!!

🇨🇴  Christian Vaca
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[12:24] **@lapalaclubdepadel:** VIERNES 24 de JULIO
📈 CATEGORIA: 5TA/6TA
⌚ 08:00 Pm a 10:00 Pm
📍La pala 
💰70K    2 HORAS!!!

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[13:02] **+57 316 4103202:** VIERNES 24 de JULIO
📈 CATEGORIA:DAMAS C+
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K   

🇨🇴 Eliana A 
🇨🇴 Lina A
🇨🇴 Pilar P
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[13:21] **+57 324 6856357:**
> _+57 316 4103202: VIERNES 24 de JULIO
📈 CATEGORIA:DAMAS C+
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K   

🇨🇴 Eliana A 
🇨🇴 Lina A
🇨🇴 Pilar P
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!_
Yo

[13:26] **@lapalaclubdepadel:** VIERNES 24 de JULIO
📈 CATEGORIA:DAMAS C+
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K   

🇨🇴 Eliana A 
🇨🇴 Lina A
🇨🇴 Pilar P
🇨🇴 Bibiana R

PARTIDO CERRADO
CANCHA 3

[13:27] **+57 320 4233809:**
> _@lapalaclubdepadel: VIERNES 24 de JULIO
📈 CATEGORIA:DAMAS C+
⌚ 06:00 Pm a 07:30 Pm
📍La pala 
💰62.5K   

🇨🇴 Eliana A 
🇨🇴 Lina A
🇨🇴 Pilar P
🇨🇴 Bibiana R

PARTIDO CERRADO
CANCHA 3_
[Sticker]

[14:23] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[14:25] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )_
Sebastian F y Daniel H 
Y 
Juanes Zapata y Alejandro H

[14:26] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:26] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:26] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[14:28] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:32] **+57 310 3029444:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[14:32] **@juanselopez5_:** _Se eliminó este mensaje_

[14:32] **+57 320 8584974:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[14:33] **@juanselopez5_:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 Juan S lopez
🎾 Olmark Mena

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[16:32] **@etorresrojas:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 Juan S lopez
🎾 Olmark Mena

🎾Ernesto Torres
🎾Camilo Pacini 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[16:58] **@juanselopez5_:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 
🎾 

🎾Ernesto Torres
🎾Camilo Pacini 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[17:05] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 Christian Vaca
🎾 

🎾Ernesto Torres
🎾Camilo Pacini 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[17:26] __@lapalaclubdepadel añadió a +57 318 1880065__

[18:01] **@lapalaclubdepadel:** VIERNES 24 de JULIO
📈 CATEGORIA: 4ta
⌚ 07:30 Pm a 09:00 Pm
📍La pala 
💰50K    

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[19:16] **@lapalaclubdepadel:** SABADO 25 de JULIO
📈 CATEGORIA: 4ta
⌚ 08:00 am a 10:00 am
📍La pala 
💰50K    

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[19:17] **@lapalaclubdepadel:** SABADO 25 de JULIO
📈 CATEGORIA: 5TA/MIXTO
⌚11:00 am a 1:00 Om
📍La pala 
💰50K    

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[19:37] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[19:47] **@lapalaclubdepadel:** DOMINGO 26 de JULIO
📈 CATEGORIA:  DAMAS C/D
⌚10:00 am a 11:30 Am
📍La pala 
💰45K    

🇨🇴  Olinda
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

---

## 25 de julio de 2026

[7:13] **@lapalaclubdepadel:** SABADO 25 de JULIO
📈 CATEGORIA: 5TA/MIXTO
⌚09:30 am a 11:30 pm
📍La pala 
💰50K    

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[7:26] **@mbarrigag:** _Se eliminó este mensaje_

[8:17] **+57 318 5423534:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 Christian Vaca
🎾 Daniela H

🎾Ernesto Torres
🎾Camilo Pacini 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[8:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 Christian Vaca
🎾 Daniela H

🎾Ernesto Torres
🎾Camilo Pacini 

 
TORNEO CERRADO LOS ESPERAMOS!!!

LISTA DE ESPERA
🎾
🎾
🎾
🎾

[8:41] **@lapalaclubdepadel:** TORNEO AMERICANO RELAMPAGO⚡⚡
 25 DE JULIO 2026

📈 *Categoría: ( 5ta/6TA DAMAS  C) 
⌚04:00 PM A 06:00PM
📍 La Pala
💰50k por persona  

OBTENE UN 15% DE DESCUENTO EN BRUN POR JUGADOR🍺🧋🌮 HACIENDO UN CONSUMO MAYOR A $30000

🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾
🎾 
🎾 
🎾
🎾


TORNEO ABIEERTO CUPOS LIMITADOS
ANIMO!!!

[10:03] **+1 (352) 615-0721:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 Christian Vaca
🎾 Daniela H

🎾Ernesto Torres
🎾Camilo Pacini 

 
TORNEO CERRADO LOS ESPERAMOS!!!

LISTA DE ESPERA
🎾Valeria
🎾Carlos 
🎾
🎾

[10:09] **+57 313 3343399:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾  Sebastian F
🎾  Daniel H
 
🎾 Juanes Zapata
🎾 Alejandro H

🎾Alejandra T
🎾Orlando R

🎾 Juan Loaiza
🎾 Valeria León 
️
🎾 Christian Vaca
🎾 Daniela H

🎾Ernesto Torres
🎾Camilo Pacini 

 
TORNEO CERRADO LOS ESPERAMOS!!!

LISTA DE ESPERA
🎾Valeria
🎾Carlos 
🎾Bryan R
🎾

[11:00] __+57 317 2399233 se unieron mediante el enlace de invitación__

[11:28] **@lapalaclubdepadel:** TORNEO AMERICANO RELAMPAGO⚡⚡
 25 DE JULIO 2026

📈 *Categoría: ( 5ta/6TA DAMAS  C) 
⌚04:00 PM A 06:00PM
📍 La Pala
💰50k por persona  

OBTENE UN 15% DE DESCUENTO EN BRUN POR JUGADOR🍺🧋🌮 HACIENDO UN CONSUMO MAYOR A $30000

🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾 
🎾
🎾 
🎾 
🎾
🎾


TORNEO ABIEERTO CUPOS LIMITADOS
ANIMO!!!

[13:51] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚04 :00 PM A 6:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $72000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $36000 en Playtomic para la pareja

🎾  
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[14:25] **@lapalaclubdepadel:** SABADO 25 de JULIO
📈 CATEGORIA: 5TA/MIXTO
⌚:4:00 pm a 6:00 pm
📍La pala 
💰50K    

🇨🇴  
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[15:14] **+57 350 7959826:** SABADO 25 de JULIO
📈 CATEGORIA: 5TA/MIXTO
⌚:4:00 pm a 6:00 pm
📍La pala 
💰50K    

🇨🇴  Juli Arango !!! -partner 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[15:24] **@lapalaclubdepadel:** SABADO 25 de JULIO
📈 CATEGORIA: 5TA/MIXTO
⌚:5:00 pm a 6:00 pm
📍La pala 
💰30K    

🇨🇴  Maria Fernanda Melo
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[15:25] **+57 350 7959826:** SABADO 25 de JULIO
📈 CATEGORIA: 5TA/MIXTO
⌚:5:00 pm a 6:00 pm
📍La pala 
💰30K    

🇨🇴  Maria Fernanda Melo
🇨🇴 Juli Arango 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[21:43] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

---

## 26 de julio de 2026

[8:16] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚04 :00 PM A 6:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $72000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $36000 en Playtomic para la pareja

🎾  
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[8:27] __@lapalaclubdepadel añadió a @darozo___

[10:36] **+57 350 7959826:** Buen día a todos Agregar Porfavor a

[10:36] **+57 350 7959826:** [Contacto: BEGIN:VCARD
VERSION:3.0
N:Arango Padel;Juli;;;
FN:Juli Arango Padel
TEL;type=CELL;type=VOICE;waid=573215658933:+57 321 5658933
END:VCARD]

[10:39] **@lapalaclubdepadel:**
> _+57 350 7959826: BEGIN:VCARD
VERSION:3.0
N:Arango Padel;Juli;;;
FN:Juli Arango Padel
TEL;type=CELL;type=VOICE;waid=573215658933:+57 321 5658933
END:VCARD_
hola buenos dias, ya se le hizo llegar la invitacion

[10:42] **+57 315 3599879:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚04 :00 PM A 6:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $72000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $36000 en Playtomic para la pareja

🎾  
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )_
Podrían inscribirme pf

[10:44] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 26 JULIO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚04 :00 PM A 6:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $72000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $36000 en Playtomic para la pareja

🎾 Diego M 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[11:42] **@lapalaclubdepadel:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 5ta Mixto C+
⌚ 06:00 pm a 8:00 pm
📍La pala 
💰 50k 
🎾 LuisFer
🎾 Alejandra
🎾
🎾
PARTIDO ABIERTO
FALTAN 2 PALAS
ANIMO!

[12:20] **@lapalaclubdepadel:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 06:00 pm a 7:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 
🎾
🎾
PARTIDO ABIERTO
FALTAN 3 PALAS
ANIMO!

[13:01] **+57 301 7844671:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 06:00 pm a 7:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Irene C
🎾
🎾
PARTIDO ABIERTO
FALTAN 3 PALAS
ANIMO!

[13:03] **+57 315 3599879:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 06:00 pm a 7:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Irene C
🎾Diego M
🎾
PARTIDO ABIERTO
FALTAN 3 PALAS
ANIMO!

[13:04] **+57 301 7844671:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 06:00 pm a 7:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Irene C
🎾Diego M
🎾 Alvaro S
PARTIDO ABIERTO
FALTAN 3 PALAS
ANIMO!

[13:19] **@lapalaclubdepadel:**
> _+57 301 7844671: 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 06:00 pm a 7:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Irene C
🎾Diego M
🎾 Alvaro S
PARTIDO ABIERTO
FALTAN 3 PALAS
ANIMO!_
cancha disponible reservada mediante la app
si desean lo movemos una hora
de 07:00pm a 08:00pm
me confirman por favor

[13:42] **@lapalaclubdepadel:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 07:00 pm a 8:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Diego M
🎾
🎾 
PARTIDO ABIERTO
FALTAN 2 PALAS
ANIMO!

[14:07] **@msilvarubiano:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 07:00 pm a 8:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Diego M
🎾Fabio 
🎾 Martha 
PARTIDO ABIERTO
FALTAN 2 PALAS
ANIMO!

[14:09] **@lapalaclubdepadel:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 07:00 pm a 8:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Diego M
🎾Fabio 
🎾 Martha 
PARTIDO CERRADO
CANCHA 5 LOS ESPERAMOS

[14:26] **@lapalaclubdepadel:** MAÑANA LUNES 27 de JULIO
📈 CATEGORIA:  DAMAS C/D
⌚06:00pm - 07:30pm 
📍La pala 
💰62.5

🇨🇴 Dani 
🇨🇴 vale 
🇨🇴 aleja 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[14:54] **@luis_arangohe:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 5ta Mixto C+
⌚ 06:00 pm a 8:00 pm
📍La pala 
💰 50k 
🎾 LuisFer
🎾 Alejandra
🎾
🎾
PARTIDO ABIERTO
FALTAN 2 PALAS
ANIMO!

[14:58] **@lapalaclubdepadel:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 5ta Mixto C+
⌚ 06:00 pm a 8:00 pm
📍La pala 
💰 50k 
🎾 LuisFer
🎾 Alejandra
🎾
🎾
PARTIDO ABIERTO
FALTAN 2 PALAS
CANCHA 1 YA RESERVADA VAMOS!!!

[15:43] **+57 314 3304304:**
> _@lapalaclubdepadel: 26 de JULIO PADEL DOMINGO
CATEGORIA: 6ta Mixto D
⌚ 07:00 pm a 8:00 pm
📍La pala 
💰 30k 
🎾 Maria Fernanda M
🎾 Diego M
🎾Fabio 
🎾 Martha 
PARTIDO CERRADO
CANCHA 5 LOS ESPERAMOS_
Les deseo buen juego y q ganen Don Fabio.

[16:01] __@lapalaclubdepadel añadió a +57 321 5658933__

[16:27] **@luis_arangohe:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 5ta Mixto C+
⌚ 06:00 pm a 8:00 pm
📍La pala 
💰 50k 
🎾 LuisFer
🎾 Alejandra
🎾 Juliana Arango
🎾 Gerardo Vargas 
PARTIDO CERRADO

[16:30] **@lapalaclubdepadel:** 26 de JULIO PADEL DOMINGO
CATEGORIA: 5ta Mixto C+
⌚ 06:00 pm a 8:00 pm
📍La pala 
💰 50k 
🎾 LuisFer
🎾 Alejandra
🎾 Juliana Arango
🎾 Gerardo Vargas 
PARTIDO CERRADO
CANCHA 1

[17:25] **@lapalaclubdepadel:** [Mensaje de album]

[17:25] **@lapalaclubdepadel:** [Imagen] TORNEO PADEL SOCIAL 
DOMINGO 26 🥳💪🏼🔥

[17:25] **@lapalaclubdepadel:** [Imagen]

[17:25] **@lapalaclubdepadel:** [Imagen]

[17:25] **@lapalaclubdepadel:** [Imagen]

[17:25] **@lapalaclubdepadel:** [Imagen]

[18:58] __@lapalaclubdepadel añadió a @rafael_debrigard__

[20:31] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[20:33] **@lapalaclubdepadel:** [Mensaje de album]

[20:33] **@lapalaclubdepadel:** [Imagen] TORNEO TGIP DOMINGO 26 🥳💪🏼🔥

[20:33] **@lapalaclubdepadel:** [Imagen]

[20:33] **@lapalaclubdepadel:** [Imagen]

[20:33] **@lapalaclubdepadel:** [Imagen]

---

## 27 de julio de 2026

[8:49] **@lapalaclubdepadel:** 27 de JULIO LUNES
CATEGORIA: 5ta Mixto C+
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 
🎾 
🎾
🎾
PARTIDO ABIERTO
ANIMO!!

[8:50] **@lapalaclubdepadel:** 27 de JULIO LUNES
CATEGORIA: 6ta Mixto D
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 
🎾 
🎾
🎾
PARTIDO ABIERTO
ANIMO!!

[8:55] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[8:58] **@lapalaclubdepadel:** LUNES 27 de JULIO
📈 CATEGORIA: MIXTO C/D - 5TA / 6TA
⌚06:00pm - 07:30pm 
📍La pala 
💰62.5

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[13:04] **@lapalaclubdepadel:** LUNES 27 de JULIO
📈 CATEGORIA:  DAMAS C+
⌚07:30pm - 09:00pm 
📍La pala 
💰62.5

🇨🇴 Lida
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[13:12] **@lapalaclubdepadel:** LUNES 27 de JULIO
📈 CATEGORIA:  DAMAS C+
⌚07:30pm - 09:00pm 
📍La pala 
💰62.5

🇨🇴 Lida
🇨🇴 Pamela
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[14:44] **+57 301 2093946:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[14:45] **+57 301 2093946:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[15:06] __+57 313 3846619 se unieron mediante el enlace de invitación__

[15:46] **@lapalaclubdepadel:** 27 de JULIO LUNES
CATEGORIA: 5ta alta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 
🎾 
🎾
🎾
PARTIDO ABIERTO
ANIMO!!

[20:18] **@jeanpenent:** 27 de JULIO LUNES
CATEGORIA: 5ta alta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 Jean Michel 
🎾 
🎾
🎾
PARTIDO ABIERTO
ANIMO!!

---

## 28 de julio de 2026

[8:28] **@lapalaclubdepadel:** 28 de JULIO MARTES
CATEGORIA: 5ta MIXTO
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 50k 
🎾 Patricia B
🎾 Cristian
🎾
🎾
PARTIDO ABIERTO
ANIMO!!

[9:12] **@alejacastrotorres:** 28 de JULIO MARTES
CATEGORIA: 5ta MIXTO
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 50k 
🎾 Patricia B
🎾 Cristian
🎾 Alejandra 
🎾 Carlos
PARTIDO ABIERTO
ANIMO!!

[9:13] **@lapalaclubdepadel:** 28 de JULIO MARTES
CATEGORIA: 5ta MIXTO
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 50k 
🎾 Patricia B
🎾 Cristian
🎾 Alejandra 
🎾 Carlos
PARTIDO CERRADO
CANCHA 3

[9:37] **+57 314 4364055:** Hola, hay chance de armar uno de cuarta?

[9:39] **@lapalaclubdepadel:**
> _+57 314 4364055: Hola, hay chance de armar uno de cuarta?_
hola buenos dias, disponible 1 cancha a las 06:00pm y otra a las 09:00pm
en que franja desea que lo armemos

[9:39] **+57 314 4364055:** 6pm

[9:44] **@lapalaclubdepadel:** 28 de JULIO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾 Daniel
🎾 
🎾  
🎾 
PARTIDO ABIERTO

[10:10] **@SergioRengifoC:** 28 de JULIO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾 Daniel
🎾 Sergio R.
🎾  
🎾 
PARTIDO ABIERTO

[10:10] **+57 310 2924270:** 28 de JULIO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾 Daniel
🎾 Sergio R.
🎾   
🎾 
PARTIDO ABIERTO

[10:12] **+57 311 6418257:** 28 de JULIO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾 Daniel
🎾 Sergio R.
🎾  eduardo d
🎾 
PARTIDO ABIERTO

[10:12] **+57 311 6418257:** 28 de JULIO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾 Daniel
🎾 Sergio R.
🎾  Patricia Arenas 
🎾 eduardo d
PARTIDO ABIERTO

[10:22] **@juanselopez5_:** Hola @~la pala me pueden abrir otro partido de 4ta para las 6 por favor

[10:22] **@juanselopez5_:** juan S lopez 
Francisco Orrego

[10:24] **@lapalaclubdepadel:** 28 de JULIO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾 Daniel
🎾 Sergio R.
🎾  Patricia Arenas 
🎾 eduardo d
PARTIDO CERRADO
CANCHA 1

[10:26] **@lapalaclubdepadel:**
> _@juanselopez5_: Hola @~la pala me pueden abrir otro partido de 4ta para las 6 por favor_
hola buenos Dias, no me queda disponibilidad en esa franja

[13:08] **@lapalaclubdepadel:** LUNES 28 de JULIO
📈 CATEGORIA:  5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Ricardo
🇨🇴 Leandro 
🇨🇴 Jose B
🇨🇴 

PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[13:16] **+57 310 8800142:** LUNES 28 de JULIO
📈 CATEGORIA:  5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Ricardo
🇨🇴 Leandro 
🇨🇴 Jose B
🇨🇴 William Rodríguez 

PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[13:17] **+507 6430-5628:** _Se eliminó este mensaje_

[13:18] **@lapalaclubdepadel:** MARTES 28 de JULIO
📈 CATEGORIA:  5TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 Ricardo
🇨🇴 Leandro 
🇨🇴 Jose B
🇨🇴 William Rodríguez 

PARTIDO CERRADO
CANCHA 5

[13:42] **carlos Padel 4:** Hola me regalas info del torneo federado ?

[13:53] **@lapalaclubdepadel:** MARTES 28 de JULIO
📈 CATEGORIA: 5TA/6TA
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[14:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾
🎾
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 10 PAREJAS )

[15:15] **@lapalaclubdepadel:** MARTES 28 de JULIO
📈 CATEGORIA: 5ta/DAMAS C
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴Lina A
🇨🇴 Eliana A
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[15:16] **+57 320 4233809:** MARTES 28 de JULIO
📈 CATEGORIA: 5ta/DAMAS C+
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴Lina A
🇨🇴 Eliana A
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[16:09] **@lapalaclubdepadel:** dos mas?????

[16:14] **+57 310 4761805:** Nos anotamos

[16:14] **+57 310 4761805:** MARTES 28 de JULIO
📈 CATEGORIA: 5ta/DAMAS C+
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴Lina A
🇨🇴 Eliana A
🇨🇴 Fabio
🇨🇴 Fernando

PARTIDO ABIERTO

[16:15] **@lapalaclubdepadel:** los esperamos!

[16:17] **@etorresrojas:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 10 PAREJAS )

[17:18] **@lapalaclubdepadel:** MARTES 28 de JULIO
📈 CATEGORIA: 5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[17:22] **+57 310 6554100:** MARTES 28 de JULIO
📈 CATEGORIA: 5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 santiago b
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[17:47] **+971 52 957 3236:** MARTES 28 de JULIO
📈 CATEGORIA: 5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 santiago b
🇨🇴 Hernan 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[17:59] **@SergioRengifoC:**
> _@lapalaclubdepadel: 28 de JULIO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾 Daniel
🎾 Sergio R.
🎾  Patricia Arenas 
🎾 eduardo d
PARTIDO CERRADO
CANCHA 1_
Porfa llego en 5 minutos

[17:59] **@lapalaclubdepadel:** lo esperamos!

[18:29] **@AdminLaPala:** [Imagen]

[18:29] **@AdminLaPala:** [Imagen]

[18:29] **@AdminLaPala:** 🔥 ¡Inscripciones abiertas para la primera parada de Major Pádel Bogotá!

La primera batalla será en La Pala, del 26 al 30 de agosto. Compite por puntos oficiales para el ranking de la Federación Colombiana de Pádel y por más de $16,5 millones en premiación por parada. 🎾🏆

💵 Inscripción: $400.000 por pareja

📲 Conoce todos los detalles e inscríbete en SportSpace:
https://app.sportspace.app/eventos/5821646a-ebf1-4a87-9820-14f59084dbce

Cada sede es una batalla. El circuito define la leyenda. 🔥

[19:08] **@lapalaclubdepadel:** MARTES 28 de JULIO
📈 CATEGORIA: 5TA alta
⌚ 09:00 Pm a 10:30 Pm
📍La pala 
💰50k

🇨🇴 santiago b
🇨🇴 Hernan 
🇨🇴 Pamela
🇨🇴 Esteban

PARTIDO CERRADO CANCHA #1 LOS ESPERAMOS

[19:29] **+57 318 2054394:**
> _@AdminLaPala: Imagen_
Busco partner para 4ta

---

## 29 de julio de 2026

[9:20] __@lapalaclubdepadel añadió a +971 52 355 0247__

[14:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 10 PAREJAS )

[14:42] **@lapalaclubdepadel:** MIERCOLES 29 de JULIO
📈 CATEGORIA: 5TA alta
⌚ 06:00 Pm a 7:30 Pm
📍La pala 
💰62.5k

🇨🇴 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO

[16:03] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 7 PAREJAS )

[18:16] **+57 301 2093946:** [Imagen] Buenas tardes comunidad ❤️
Les cuento que este viernes largamos el primero de muchos americanos que se vienen los días viernes 🥳🥳
Acá debajo les voy a mandar la convocatoria para que se vayan anotando. Tengan en cuenta que el cupo se reserva con el pago del mismo, también voy a enviarles por acá en link de pago para que puedan guardar su lugar, por favor envíen el comprobante a la recepción 🙌🏻🙌🏻

[18:21] **+57 301 2093946:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾
🎾
🎾 
🎾

🎾
🎾
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

🎾
🎾
🎾
🎾

🎾
🎾
🎾
🎾
Anótense 🥳🥳

[18:22] **+57 301 2093946:** [Reenviado] https://checkout.wompi.co/l/VPOS_iFBGeB

---

## 30 de julio de 2026

[7:24] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 7 PAREJAS )_
Sebastian F y Daniel H

[7:26] **+507 6430-5628:** _Se eliminó este mensaje_

[7:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[8:08] **+57 301 6599427:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )_
Freddy Claro

[8:15] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS 1 PALA )

[9:04] **+57 301 6599427:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS 1 PALA )_
Por favor Freddy Claro con Oscar

[9:05] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

[9:30] **@sllamas26:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )

[9:30] __@jpaoforero se unieron mediante el enlace de invitación__

[9:33] __@lapalaclubdepadel añadió a +57 304 5312718__

[9:38] **+57 313 6519397:**
> _+57 301 2093946: Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾
🎾
🎾 
🎾

🎾
🎾
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

🎾
🎾
🎾
🎾

🎾
🎾
🎾
🎾
Anótense 🥳🥳_
El torneo de mañana mixto no salio ?

[9:39] **@lapalaclubdepadel:**
> _+57 313 6519397: El torneo de mañana mixto no salio ?_
hola buenos dias, desea que te apunte empezamos a llenarlo

[9:42] **+57 313 6519397:** Si se arma, si

[9:49] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾
🎾 
🎾

🎾
🎾
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

🎾
🎾
🎾
🎾

🎾
🎾
🎾
🎾

DISPONIBLE  (19 CUPOS)
ANIMO!!!
Anótense 🥳🥳

[10:23] **@lapalaclubdepadel:** 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 Hernan
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[12:03] **+57 316 3358569:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Tomas V
🎾Santiago R

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )

[12:07] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Milton Puente
🎾 Paola Najar

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Tomas V
🎾Santiago R

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 3 PAREJAS )

[12:29] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾 
🎾

🎾
🎾
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

🎾
🎾
🎾
🎾

🎾
🎾
🎾
🎾

DISPONIBLE  (18 CUPOS)
ANIMO!!!
Anótense 🥳🥳

[12:48] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾
🎾
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

🎾
🎾
🎾
🎾

🎾
🎾
🎾
🎾

DISPONIBLE  (16 CUPOS)
ANIMO!!!
Anótense 🥳🥳

[12:49] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )

[13:36] **@lapalaclubdepadel:** 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾Daniel P 
🎾Jimmy
🎾Lucku 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[14:45] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾Daniel P 
🎾Jimmy
🎾Lucku 
🎾 
PARTIDO ABIERTO
ANIMO!!!_
partido cerrado!

[14:45] **@lapalaclubdepadel:** 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 Hernan
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[14:51] **+57 305 2849590:**
> _@lapalaclubdepadel: 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 Hernan
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!_
Carlos uribe

[14:55] **+507 6430-5628:** _Se eliminó este mensaje_

[14:55] **+507 6430-5628:** 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 Hernan
🎾 Carlos Uribe
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[17:26] **@lapalaclubdepadel:** 2 palas mas?

[17:36] **@lapalaclubdepadel:** VIERNES 31 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 62.5k 
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[18:43] **@juancsuarezr:** 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 Hernan
🎾 Carlos Uribe
🎾 Gerardo 
🎾 Juan camiko
PARTIDO ABIERTO
ANIMO!!!

[18:50] **@lapalaclubdepadel:** 30 de JULIO JUEVES
CATEGORIA: 5ta
⌚ 09:00 pm a 10:30 pm
📍La pala 
💰 50k 
🎾 Hernan
🎾 Carlos Uribe
🎾 Gerardo 
🎾 Juan camiko
PARTIDO CERRADO
 LOS ESPERAMOS

[19:03] __@lapalaclubdepadel añadió a +1 (954) 648-1887__

[19:04] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾
🎾
🎾 
🎾 
️
🎾 
🎾
🎾
🎾


DISPONIBLE  (12 CUPOS)
ANIMO!!!
Anótense 🥳🥳

[19:05] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

7 CUPOD DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

[19:24] __@lapalaclubdepadel añadió a @Juanvalfarog__

[19:59] **+1 (954) 648-1887:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

6 CUPOS DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

---

## 31 de julio de 2026

[6:41] **@lapalaclubdepadel:** VIERNES 31 DE AGOSTO
CATEGORIA: 5TA
⌚ 04:00 pm a 06:00 pm
📍La pala 
💰 64k 
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[6:42] **@lapalaclubdepadel:** VIERNES 31 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 08:00 pm
📍La pala 
💰 70k 
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[7:30] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 
🎾 
️
🎾 
🎾
🎾
🎾

6 CUPOS DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

[7:30] **@lapalaclubdepadel:** ES HOY!!!1 LOS ESPERAMOS!

[9:38] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Sebastian G
🎾Felipe R

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )

[9:39] **+507 6430-5628:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Sebastian G
🎾Felipe R

🎾 Nan S.
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )

[9:49] **@lapalaclubdepadel:** VIERNES 31 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm
📍La pala 
💰 70k 
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[9:53] **+57 301 7844671:** _Se eliminó este mensaje_

[9:59] **+57 301 7844671:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 Irene C
🎾 
️
🎾 
🎾
🎾
🎾

6 CUPOS DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

[10:04] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 Irene C
🎾 Felipe Pardo
️
🎾 
🎾
🎾
🎾

4 CUPOS DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

[10:13] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 Irene C
🎾 Felipe Pardo
️
🎾 Santiago Ramirez
🎾Sebastian Duarte
🎾
🎾

4 CUPOS DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

[10:28] **@mbarrigag:**
> _+507 6430-5628: TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Sebastian G
🎾Felipe R

🎾 Nan S.
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )_
Lista de espera , por si Si se abre un cupo para una pareja 
Daniel 
Manuel

[10:30] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Sebastian G
🎾Felipe R

🎾 Nan S.
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
LISTA DE ESPERA
🎾Daniel
🎾Manuel

🎾
🎾

[10:33] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 2 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾  
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[10:36] **+57 301 2093946:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 Irene C
🎾 Felipe Pardo
️
🎾 Santiago Ramirez
🎾Sebastian Duarte
🎾
🎾

2 CUPOS DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

[11:34] **@lapalaclubdepadel:** VIERNES 31 DE AGOSTO
CATEGORIA: 4ta
⌚ 07:30 pm a 09:00 pm
📍La pala 
💰 50k 
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[11:39] **@lapalaclubdepadel:** SOLO POR HOY! JUEGA 90 MINUTOS POR 50K CADA UNO! ($200000 ) QUEDAN LAS ULTIMAS RESERVAS!

[12:17] **@lapalaclubdepadel:** VIERNES 31 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 06:00 pm a 07:30 pm
📍La pala 
💰 50k 
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO
ANIMO!!!

[14:08] **+57 301 2093946:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 Irene C
🎾 Felipe Pardo
️
🎾 Santiago Ramirez
🎾Sebastian Duarte
🎾
🎾

2 CUPOS DISPONIBLES
ANIMO!!!
Anótense 🥳🥳

[14:28] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
 Viernes 31 de Julio de 2026
inscripción individual 
⌚6:00 pm a 8:00 pm
📍 La Pala
💰75k por persona incluye Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza)

🥇PRIMER LUGAR: Bono para el próximo americano 100% off.
🥈SEGUNDO LUGAR: Bono para el próximo americano 50% off. 

🎾Lida
🎾Guiova
🎾Paola Najar 
🎾Milton P

🎾Juan Alfaro
🎾Chiara Volpi
🎾 Irene C
🎾 Felipe Pardo
️
🎾 Santiago Ramirez
🎾Sebastian Duarte
🎾Erica Diaz
🎾Daniel Salinas

TORNEO CERRADO LOS ESPERAMOS🥳🥳

[15:12] __@lapalaclubdepadel añadió a +57 305 7514523__

[15:12] __Alguien añadió a +57 305 7514523__

[16:00] __+57 312 3114830 se unieron mediante el enlace de invitación__

[16:52] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Daniel
🎾Manuel

🎾 Nan S.
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
LISTA DE ESPERA
🎾
🎾

🎾
🎾

[19:11] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Daniel
🎾Manuel

🎾 Nan S.
🎾 Sebastian

 
TORNEO CERRADO
LISTA DE ESPERA

🎾David Rodriguez
🎾Partner

🎾
🎾

[21:44] **+57 301 2093946:** [Imagen] Americano 6ta/7ma gracias a todos por venir 🥳🥳

---

## 1 de agosto de 2026

[6:31] **@mbarrigag:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾David Rodriguez
🎾Partner

🎾 Nan S.
🎾 Sebastian

 
TORNEO CERRADO
LISTA DE ESPERA

🎾
🎾

🎾
🎾

[9:51] **+57 310 5611823:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾David Rodriguez
🎾Partner

🎾 Nan S.
🎾 Sebastian

 
TORNEO CERRADO
LISTA DE ESPERA

🎾Mateo
🎾

🎾
🎾

[9:52] **+57 310 2251076:** Buenos días mañana no tienen nada organizado para la tarde?

[9:52] __@juanp.b se unieron mediante el enlace de invitación__

[10:10] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Mateo
🎾

🎾 Nan S.
🎾 Sebastian

 
TORNEO ABIERTO 1 JUGADOR
LISTA DE ESPERA

🎾
🎾

🎾
🎾

[10:38] **+57 313 3338757:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Mateo
🎾

🎾 Nan S.
🎾 Sebastian

 
TORNEO ABIERTO 1 JUGADOR
LISTA DE ESPERA

🎾 Alejandro
🎾Samuel

🎾
🎾

[10:48] **@lapalaclubdepadel:** 1 AGOSTO - SÁBADO 
CATEGORIA: 5ta Mixto C+
⌚ 06:00 pm a 7:30 pm
📍La pala 
🎾 Nan
🎾 LuisFer
🎾 
🎾 
PARTIDO ABIERTO

[10:54] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
 SABADO 01 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono de $120000 en Playtomic para la pareja ganadora
🥈SEGUNDO LUGAR: Bono de $60000 en Playtomic para la pareja

🎾Ernesto Torres
🎾Riad Karut
 
🎾 Tomas V
🎾 Santiago R

🎾Andres G
🎾Juliana M

🎾 Sebastian F
🎾 Daniel H

🎾 Fredy Claro
🎾 Oscar

🎾 Saskia LL
🎾 Sebastián G

🎾Mateo
🎾Nicolás 

🎾 Nan S.
🎾 Sebastian

 
TORNEO CERRADO LOS ESPERAMOS
LISTA DE ESPERA

🎾 Alejandro
🎾Samuel

🎾
🎾

[11:16] __@lapalaclubdepadel añadió a @riadkarut__

[13:01] __+57 314 2838850 se unieron mediante el enlace de invitación__

[13:01] __@mickhincapie se unieron mediante el enlace de invitación__

[14:26] **@lapalaclubdepadel:** [Imagen]

[14:26] **@lapalaclubdepadel:** [Imagen]

[14:26] **@lapalaclubdepadel:** [Imagen]

[14:26] **@lapalaclubdepadel:** [Imagen] Torneo Social Sábado 1 de agosto!!!

[17:42] __@lapalaclubdepadel añadió a +57 316 0411782__

[17:47] __[Notificación del sistema]__

[17:48] __Alguien añadió a @rogerrodriguez36__

---

## 2 de agosto de 2026

[8:02] **@lug.contreras:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 2 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾  
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )_
Se va a realizar?

[8:20] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
*DOMINGO 2 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Lug C 
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[8:22] **+57 320 8584974:** _Se eliminó este mensaje_

[9:06] **@lapalaclubdepadel:** DOMINGO 02 AGOSTO
📈 CATEGORIA: DAMAS D 
⌚04:00pm - 05:00pm 
📍La pala 
💰30K

🇨🇴 Maria Fernanda M
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[9:07] **@lapalaclubdepadel:** DOMINGO 02 AGOSTO
📈 CATEGORIA: 5TA Alta
⌚04:00pm - 05:00pm 
📍La pala 
💰30K

🇨🇴 Juan Fer 
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[9:11] **@lapalaclubdepadel:** 2 AGOSTO - DOMINGO 
CATEGORIA: 5ta/4ta
⌚ 06:00 pm a 8:00 pm
📍La pala
💰50k
🎾 LuisFer
🎾
🎾 
🎾 
PARTIDO ABIERTO

[9:35] **+57 314 4364055:**
> _@lapalaclubdepadel: 2 AGOSTO - DOMINGO 
CATEGORIA: 5ta/4ta
⌚ 06:00 pm a 8:00 pm
📍La pala
💰50k
🎾 LuisFer
🎾
🎾 
🎾 
PARTIDO ABIERTO_
Daniel M (4ta)

[9:37] **@lapalaclubdepadel:** 2 AGOSTO - DOMINGO 
CATEGORIA: 5ta/4ta
⌚ 06:00 pm a 8:00 pm
📍La pala
💰50k
🎾 LuisFer
🎾 Daniel M
🎾 
🎾 
PARTIDO ABIERTO

[9:46] **+34 677 17 38 32:** 2 AGOSTO - DOMINGO 
CATEGORIA: 5ta/4ta
⌚ 06:00 pm a 8:00 pm
📍La pala
💰50k
🎾 LuisFer
🎾 Daniel M
🎾 Javier J 
🎾 
PARTIDO ABIERTO

[9:52] __@lapalaclubdepadel añadió a @JuanFerRojas__

[10:12] **+57 301 6599427:**
> _+34 677 17 38 32: 2 AGOSTO - DOMINGO 
CATEGORIA: 5ta/4ta
⌚ 06:00 pm a 8:00 pm
📍La pala
💰50k
🎾 LuisFer
🎾 Daniel M
🎾 Javier J 
🎾 
PARTIDO ABIERTO_
Freddy Claro

[10:13] **@lapalaclubdepadel:** 2 AGOSTO - DOMINGO 
CATEGORIA: 5ta/4ta
⌚ 06:00 pm a 8:00 pm
📍La pala
💰50k
🎾 LuisFer
🎾 Daniel M
🎾 Javier J 
🎾 Fredy C
PARTIDO CERRADO
CANCHA 2

[10:40] **@lapalaclubdepadel:** [Mensaje de album]

[10:40] **@lapalaclubdepadel:** [Imagen] TORNEO PADELENNIALS
DOMINGO 02 08:00AM 🥳🔥💪🏼

[10:40] **@lapalaclubdepadel:** [Imagen]

[10:40] **@lapalaclubdepadel:** [Imagen]

[11:14] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Agosto 2 !!
📈 *Categoría: 5-6/ C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰53K

🎾 Jorge C.
🎾 Ivan G
🎾 Erika 
🎾 Julián 

🎾 Ana Paola 
🎾 Oscar
🎾 Patty
🎾 Carolina C

🎾 Alfredo C
🎾 Carlos C
🎾 Juan A
🎾

Invitadísimos todos! 🪂🏅🧩
FALTA 1 PALA

[11:36] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Agosto 2 !!
📈 *Categoría: 5-6/ C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰53K

🎾 Jorge C.
🎾 Ivan G
🎾 Erika 
🎾 Julián 

🎾 Ana Paola 
🎾 Oscar
🎾 Patty
🎾 Carolina C

🎾 Alfredo C
🎾 Carlos C
🎾 Juan A
🎾 Juan Fernado G

Invitadísimos todos! 🪂🏅🧩
TORNEO CERRADO

[11:42] **@lapalaclubdepadel:** DOMINGO 02 AGOSTO
📈 CATEGORIA: MIXTO D / 6TA
⌚04:00pm - 05:00pm 
📍La pala 
💰30K

🇨🇴 Maria Fernanda M
🇨🇴 
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[11:48] **@IvanBogota11:** DOMINGO 02 AGOSTO
📈 CATEGORIA: MIXTO D / 6TA
⌚04:00pm - 05:00pm 
📍La pala 
💰30K

🇨🇴 Maria Fernanda M
🇨🇴 Ivan Bogota
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!

[11:55] **+57 317 7452053:**
> _@IvanBogota11: DOMINGO 02 AGOSTO
📈 CATEGORIA: MIXTO D / 6TA
⌚04:00pm - 05:00pm 
📍La pala 
💰30K

🇨🇴 Maria Fernanda M
🇨🇴 Ivan Bogota
🇨🇴 
🇨🇴 

PARTIDO ABIERTO
ANIMO!!!_
Nicolas C 
Camila V

[11:56] **+57 317 7452053:** DOMINGO 02 AGOSTO
📈 CATEGORIA: MIXTO D / 6TA
⌚04:00pm - 05:00pm 
📍La pala 
💰30K

🇨🇴 Maria Fernanda M
🇨🇴 Ivan Bogota
🇨🇴 Nicolás C 
🇨🇴 Camila V

PARTIDO CERRADO
ANIMO!!!

[11:57] **@lapalaclubdepadel:** DOMINGO 02 AGOSTO
📈 CATEGORIA: MIXTO D / 6TA
⌚04:00pm - 05:00pm 
📍La pala 
💰30K

🇨🇴 Maria Fernanda M
🇨🇴 Ivan Bogota
🇨🇴 Nicolás C 
🇨🇴 Camila V

PARTIDO CERRADO
CANCHA 3

[14:14] __@lapalaclubdepadel añadió a @guiovaPadel__

[14:55] __@lapalaclubdepadel añadió a +57 310 7032367__

[20:57] **@lapalaclubdepadel:** [Mensaje de album]

[20:57] **@lapalaclubdepadel:** [Imagen] Torneo TGIP 🎉🔥💪

[20:57] **@lapalaclubdepadel:** [Imagen]

---

## 3 de agosto de 2026

[9:14] __+57 301 4227323 se unieron mediante el enlace de invitación__

[10:18] **@AdminLaPala:** LUNES 2 Agosto 
*Damas D
 ⏱️5:00 a 6:00 p.m
📍La Pala
 💰32K 

🎾Angie
🎾 Andrea

🎾 
🎾 
*PARTIDO ABIERTO 
CANCHA#

[10:24] **+57 310 3029444:** LUNES 2 Agosto 
*Damas D
 ⏱️5:00 a 6:00 p.m
📍La Pala
 💰32K 

🎾Angie
🎾 Andrea

🎾 Alejandra
🎾 
*PARTIDO ABIERTO 
CANCHA#

[11:13] **@lapalaclubdepadel:** TORNEO AMERICANO MADRUGADORES 5TA
*MIERCOLES 5 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚06:00 AM A 08:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas, Rifas 
 Bebida Caliente (CAFE☕, CHOCOLATE🍫,CAPUCCINO 🧋)

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[11:31] **@AdminLaPala:** MARTES 4 Agosto 
*CUPOS DISPONIBLES ACADEMIA 5TA MASCULINA
 ⏱️6:00 a 7:30 a.m
📍La Pala
 💰75K clase individual 

🎾Cristian Molano
🎾 

🎾 
🎾 
*Pregunta por la opción de mensualidad de academia

[11:35] __[Notificación del sistema]__

[12:38] **@AdminLaPala:** LUNES 3 Agosto 
*Damas D
 ⏱️5:00 a 6:00 p.m
📍La Pala
 💰32K 

🎾Angie
🎾Andrea

🎾 Alejandra
🎾 Olinda 
*PARTIDO CERRADO 
CANCHA# 1

[15:48] **@lapalaclubdepadel:** 3 AGOSTO - LUNES 
CATEGORIA: 5ta/6ta
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO

[17:02] **@juancsuarezr:** TORNEO AMERICANO MADRUGADORES 5TA
*MIERCOLES 5 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚06:00 AM A 08:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas, Rifas 
 Bebida Caliente (CAFE☕, CHOCOLATE🍫,CAPUCCINO 🧋)

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan Camilo Suarez 
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[19:20] __@lapalaclubdepadel añadió a +375 29 138-27-17__

---

## 4 de agosto de 2026

[9:20] **@lapalaclubdepadel:** TORNEO AMERICANO MADRUGADORES 5TA
*MIERCOLES 5 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚06:00 AM A 08:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas, Rifas 
 Bebida Caliente (CAFE☕, CHOCOLATE🍫,CAPUCCINO 🧋)

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan Camilo Suarez 
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[13:15] **+57 321 5658933:** TORNEO AMERICANO MADRUGADORES 5TA
*MIERCOLES 5 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚06:00 AM A 08:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas, Rifas 
 Bebida Caliente (CAFE☕, CHOCOLATE🍫,CAPUCCINO 🧋)

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan Camilo Suarez 
🎾  
 
🎾 Juan Esteban Taborda 
🎾  Juliana Arango 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[13:16] **@juancsuarezr:** TORNEO AMERICANO MADRUGADORES 5TA
*MIERCOLES 5 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚06:00 AM A 08:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas, Rifas 
 Bebida Caliente (CAFE☕, CHOCOLATE🍫,CAPUCCINO 🧋)

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾  
 
🎾 Juan Esteban Taborda 
🎾  Juliana Arango 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[13:29] **@lapalaclubdepadel:** 4 AGOSTO - MARTES 
CATEGORIA: 4ta/5ta
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Jean Michel
🎾 Christian Knoth
🎾 
🎾 
PARTIDO ABIERTO

[14:37] **@lapalaclubdepadel:** 4 AGOSTO MARTES
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO

[15:40] **@luis_arangohe:** 4 AGOSTO - MARTES 
CATEGORIA: 4ta/5ta
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Jean Michel
🎾 Christian Knoth
🎾 Fredy Caro
🎾 Luis Arango 
PARTIDO ABIERTO

[15:42] **@lapalaclubdepadel:** 4 AGOSTO - MARTES 
CATEGORIA: 4ta/5ta
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Jean Michel
🎾 Christian Knoth
🎾 Fredy Caro
🎾 Luis Arango 
PARTIDO CERRADO 
CANCHA 4

[16:49] **@lapalaclubdepadel:** 4 AGOSTO MARTES
CATEGORIA: MIXTO C/D - 5TA /6TA
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO

---

## 5 de agosto de 2026

[11:23] **+54 9 3548 58-1308:** 5 AGOSTO MARTES
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO

[12:16] **+57 317 7452053:**
> _+54 9 3548 58-1308: 5 AGOSTO MARTES
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO_
Nicolas C

[12:17] **+54 9 3548 58-1308:** 5 AGOSTO MARTES
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Nicolas C
🎾
🎾 
🎾 
PARTIDO ABIERTO

[12:30] **+57 315 5758858:** _Se eliminó este mensaje_

[12:30] **+54 9 3548 58-1308:** 5 AGOSTO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Lucas C
🎾
🎾 
🎾 
PARTIDO ABIERTO

[14:28] **+57 315 5758858:**
> _+54 9 3548 58-1308: 5 AGOSTO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Lucas C
🎾
🎾 
🎾 
PARTIDO ABIERTO_
Me bajo! 🙏🏻

[14:32] **@AdminLaPala:** 5 AGOSTO MARTES
CATEGORIA: 4ta
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO

[16:21] **@AdminLaPala:** 5 AGOSTO MIERCOLES
CATEGORIA: 4ta
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Juan O
🎾 Daniel Z
🎾 Juan Z
🎾 
PARTIDO ABIERTO

[16:25] **+57 315 5758858:**
> _@AdminLaPala: 5 AGOSTO MIERCOLES
CATEGORIA: 4ta
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Juan O
🎾 Daniel Z
🎾 Juan Z
🎾 
PARTIDO ABIERTO_
Voy

[16:27] **@lapalaclubdepadel:** 5 AGOSTO MIERCOLES
CATEGORIA: 4ta
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Juan O
🎾 Daniel Z
🎾 Juan Z
🎾 Cano
PARTIDO CERRADO
CANCHA 4

[16:31] **+57 317 7452053:**
> _+54 9 3548 58-1308: 5 AGOSTO MARTES
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Nicolas C
🎾
🎾 
🎾 
PARTIDO ABIERTO_
Me bajo de este, no se llenó. Gracias

[16:45] __@lapalaclubdepadel añadió a +57 320 8567392__

[17:00] **@lapalaclubdepadel:** 5 AGOSTO MIERCOLES
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Noe
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[17:33] **@lapalaclubdepadel:** 5 AGOSTO MIERCOLES
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Noe
🎾 Patricia B
🎾 Cristian
🎾 
PARTIDO ABIERTO

[17:54] **@lapalaclubdepadel:** 5 AGOSTO MIERCOLES
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Noe
🎾 Patricia B
🎾 Cristian
🎾JULIANA 
PARTIDO ABIERTO

[18:13] **@AdminLaPala:** [Reenviado] [Video]

[18:13] **@AdminLaPala:** 🔥 El pádel de Bogotá está a punto de cambiar de nivel.

Por primera vez, cuatro grandes clubes dejan la competencia a un lado para construir juntos Major Pádel Bogotá By Chery: un circuito oficial creado para competir, crecer y llevar nuestro pádel más lejos. 🎾🏆

4 clubes. 4 paradas. Categorías masculinas, femeninas y mixtas. Puntos para el ranking FCP en categorías federadas y más de $16 millones en premios por parada.

Con el respaldo de Chery, Tecnifibre y SportSpace.

📲 Inscripciones a través de SportSpace o al WhatsApp 333 051 5154.

Esto no es un torneo más. Es el comienzo de una nueva historia para el pádel de Bogotá.

[20:12] __@lapalaclubdepadel añadió a +57 320 5982580__

---

## 6 de agosto de 2026

[9:52] **+54 9 3548 58-1308:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾  
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[10:58] **+54 9 3548 58-1308:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

[11:32] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[11:32] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[11:37] **+57 310 2924270:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 
🎾Patricia Arenas  
🎾 
🎾 
PARTIDO ABIERTO

[11:50] **+57 316 5348415:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

[12:43] **@juanp.b:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Juan Pablo
🎾Patricia Arenas  
🎾 
🎾 
PARTIDO ABIERTO

[12:53] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 5ta/damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Sebastian
🎾Natalia
🎾 
🎾 
PARTIDO ABIERTO

[13:09] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

[14:01] **@lapalaclubdepadel:** Hola a todos. Hoy tenemos cupos disponibles para escuela de niños de 5:00 p.m a 6:00 p.m. ¡Los esperamos!

[14:23] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 5ta/damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Sebastian
🎾Natalia
🎾 Patricia B
🎾 
PARTIDO ABIERTO

[14:23] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Juan Pablo
🎾 Patricia Arenas  
🎾 Sebastian G 
🎾 
PARTIDO ABIERTO

[14:51] **+57 310 2924270:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Juan Pablo
🎾   
🎾 Sebastian G 
🎾 
PARTIDO ABIERTO

[15:34] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Juan Pablo
🎾 Noe
🎾 Sebastian G 
🎾 
PARTIDO ABIERTO

[15:38] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 
🎾
🎾
🎾 
PARTIDO ABIERTO!!!
HOLA BUENAS TARDES, DISPONIBILIDAD EN TODAS LAS FRANJAS PARA QUE ARMEN SUS PARTIDOS SEGUN SU CATEGORIA.

[16:36] **+54 9 3548 58-1308:**
> _@lapalaclubdepadel: JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Juan Pablo
🎾 Noe
🎾 Sebastian G 
🎾 
PARTIDO ABIERTO_
Uno mas?

[16:52] **@jeanpenent:**
> _@lapalaclubdepadel: JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Juan Pablo
🎾 Noe
🎾 Sebastian G 
🎾 
PARTIDO ABIERTO_
Yo

[16:53] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Juan Pablo
🎾Alejandro H
🎾 Sebastian G 
🎾 Jean Michel
PARTIDO CERRADO
cancha 2

[17:16] **@patfadul:** JUEVES 6 DE AGOSTO
CATEGORIA: 5ta/damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Sebastian
🎾Natalia
🎾 Patricia B
🎾 Cris M
PARTIDO ABIERTO

[17:17] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 5ta/damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Sebastian
🎾Natalia
🎾 Patricia B
🎾 Cris M
PARTIDO CERRADO
CANCHA 2

[17:21] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾 Jean Michel
🎾Alejandro H
🎾 Sebastian G 
🎾 NOE
PARTIDO CERRADO
CANCHA 2

[17:25] **@AdminLaPala:** INFORMACIÓN IMPORTANTE
Les informamos a toda la comunidad que el parqueadero por el momento deben pagarlo en efectivo o por transferencia ya que se están presentando fallas con redeban para los cobros con tarjeta.

[17:31] **+57 315 3167213:** _Se eliminó este mensaje_

[17:35] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: 5TA/6TA 
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[17:49] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[18:15] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA /5ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala
💰50k
🎾Juan Bertran
🎾Felipe Pedraza
🎾  
🎾
PARTIDO ABIERTO

[18:15] **+57 301 2093946:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾
🎾
 
🎾
🎾
🎾
🎾

Anótense 🥳🥳

[18:16] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA /5ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala
💰50k
🎾Juan Bertran
🎾Felipe Pedraza
🎾  
🎾
PARTIDO ABIERTO

[18:32] **@TomasVilladaBarrios:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA /5ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala
💰50k
🎾Juan Bertran
🎾Felipe Pedraza
🎾Tomás  
🎾
PARTIDO ABIERTO

[19:24] **@lapalaclubdepadel:** JUEVES 6 DE AGOSTO
CATEGORIA: 4TA /5ta
⌚ 9:00 Pm a 10:30 Pm
📍La pala
💰50k
🎾Juan Bertran
🎾Felipe Pedraza
🎾Tomás  
🎾
PARTIDO ABIERTO
1 PALA ANIMO!!!

[21:08] **@jpaoforero:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Paola F
🎾
 
🎾
🎾
🎾
🎾

Anótense 🥳🥳

[21:18] **+57 301 2093946:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾
🎾
🎾
🎾

Anótense 🥳🥳

[21:27] **+57 316 0411782:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾
🎾
🎾

Anótense 🥳🥳

---

## 7 de agosto de 2026

[6:54] **@lapalaclubdepadel:** Buenos dias! tenemos  disponibles dos cupos de 5ta alta para un torneo el dia de hoy, si te interesa escribinos al privado!

[7:52] **+57 315 3167213:**
> _@lapalaclubdepadel: VIERNES 7 DE AGOSTO
CATEGORIA: 4TA
⌚ 10:00 am a 11:30 am
📍La pala
💰48k
🎾 Luis Eduardo M
🎾
🎾  
🎾
PARTIDO CERRADO
CANCHA_
Me bajo.

[9:53] **+57 301 2093946:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾
🎾
🎾

Tres más 🙏🏻🙏🏻🙏🏻

[10:56] __@lapalaclubdepadel añadió a +57 305 7505674__

[11:09] **+57 305 7505674:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾
🎾 Alfredo Ramírez 
🎾 Ivan Ramírez 

Tres más 🙏🏻🙏🏻🙏🏻

[11:11] **@lapalaclubdepadel:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾
🎾 Alfredo Ramírez 
🎾 Ivan Ramírez 

1 más 🙏🏻🙏🏻🙏🏻

[11:18] __@lapalaclubdepadel añadió a @natacontre21__

[11:56] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
ANIMO NO TE QUEDES SIN PARTICIPAR!

[12:08] **+57 312 2993855:**
> _@lapalaclubdepadel: Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾
🎾 Alfredo Ramírez 
🎾 Ivan Ramírez 

1 más 🙏🏻🙏🏻🙏🏻_
Somos una pareja, pero solo queda un cupo, si se baja alguien nos subimos los dos

[12:55] **@lapalaclubdepadel:** VIERNES 7 DE AGOSTO
CATEGORIA: MIXTO C/D - 5ta/6ta
⌚ 02:30 Pm a 04:00 Pm
📍La pala
💰45k
🎾Gabriela Sierra
🎾 Esteban D
🎾  
🎾
PARTIDO ABIERTO
2 PALA ANIMO!!!

[13:29] **+57 305 7505674:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾
🎾  
🎾 

1 más 🙏🏻🙏🏻🙏🏻

[13:34] **@lapalaclubdepadel:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾
🎾  
🎾 

3 más 🙏🏻🙏🏻🙏🏻

[14:07] **+57 305 7505674:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾Alfredo r
🎾  Iván Ramírez 
🎾 

1 más 🙏🏻🙏🏻🙏🏻

[14:21] **@lapalaclubdepadel:** Buen día ❤️
Americano 6ta/7ma Masculino-Femenino
 Viernes 7 de Agosto de 2026
inscripción individual 
⌚4:00 pm a 6:00 pm
📍 La Pala
💰60k por persona ( promoción por ser día festivo 🥳🥳) incluye 
Organización, Bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Duarte 
🎾Guiova
🎾 Paola N
🎾 Milton P

🎾 Sebastián Millán
🎾 Chiara Volpi
🎾 Daniela Riveros
🎾 Juan Alfaro

🎾 Luis 
🎾 Jimmy 
🎾 Sebastian P
🎾 Paola F
 
🎾 Ana Paola
🎾 Alfredo r
🎾 Iván Ramírez 
🎾 Juan Fernando G
TORNEO CERRADO, LOS ESPERAMOS

[14:22] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾

🎾 Viren
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
ANIMO NO TE QUEDES SIN PARTICIPAR!

[15:22] **+44 7931 290432:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾Nicolas D

🎾 Viren
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )
ANIMO NO TE QUEDES SIN PARTICIPAR!

[17:16] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾Nicolas D

🎾 Viren
🎾 Nico
️
🎾 Julio Bohorquez
🎾 Lina

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
ANIMO NO TE QUEDES SIN PARTICIPAR!

[19:23] **+57 317 5949935:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾Nicolas D

🎾 Viren
🎾 Nico
️
🎾 Julio Bohorquez
🎾 Lina

🎾María Moreno 
🎾Luis Eduardo Moreno 

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJA )
ANIMO NO TE QUEDES SIN PARTICIPAR!

[20:46] **+57 315 5758858:** SABADO 8 DE AGOSTO
CATEGORIA: 4TA
⌚ 10:00 am a 11:30 am
📍La pala
💰
🎾 Lcano
🎾
🎾
🎾
PARTIDO ABIERTO
1 PALA ANIMO!!!

[20:59] **+54 9 3548 58-1308:** TORNEO PADEL SOCIAL PAREJA FIJA
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: 5TA/6TA 
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

---

## 8 de agosto de 2026

[8:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: 5TA/6TA 
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

[8:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾Nicolas D

🎾 Viren
🎾 Nico
️
🎾 Julio Bohorquez
🎾 Lina

🎾María Moreno 
🎾Luis Eduardo Moreno 

 
TORNEO CERRADO LOS ESPERAMOS

[9:01] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[10:16] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 8 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Andres
🎾 Alejandra
 
🎾 Jesus
🎾 Yesika

🎾Guiova
🎾Nicolas D

🎾 Viren
🎾 Nico
️
🎾 
🎾 

🎾María Moreno 
🎾Luis Eduardo Moreno 

 
TORNEO CERRADO LOS ESPERAMOS (cupo para una pareja!!)

[10:38] **@lapalaclubdepadel:** TORNEO RELAMPAGO MIXTO!!
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: MIXTO
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 5 PAREJAS )

[12:11] **@lapalaclubdepadel:** TORNEO RELAMPAGO MIXTO!!
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: MIXTO
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 Gustavo
🎾 Maria Paula

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )

[12:55] **@lapalaclubdepadel:** SABADO 8 DE AGOSTO
CATEGORIA: 4TA
⌚ 4:00 pm a 6:00 pm
📍La pala
💰
🎾 
🎾
🎾
🎾
PARTIDO ABIERTO

[12:56] **@lapalaclubdepadel:** SABADO 8 DE AGOSTO
CATEGORIA: 5TA
⌚ 4:00 pm a 6:00 pm
📍La pala
💰
🎾 
🎾
🎾
🎾
PARTIDO ABIERTO

[13:40] **+57 320 8584974:** TORNEO RELAMPAGO MIXTO!!
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: MIXTO
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 Gustavo
🎾 Maria Paula

🎾 Juan Loaiza
🎾 Valeria Leon

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 4 PAREJAS )

[13:41] **@lapalaclubdepadel:** TORNEO RELAMPAGO MIXTO!!
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: MIXTO
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 Gustavo
🎾 Maria Paula

🎾 Juan Loaiza
🎾 Valeria Leon

🎾 
🎾 
️

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )

[14:03] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[14:03] **@lapalaclubdepadel:** Podio de Torneo SOCIAL! gracias!

[16:25] **+57 312 5456433:**
> _@lapalaclubdepadel: TORNEO RELAMPAGO MIXTO!!
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: MIXTO
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 Gustavo
🎾 Maria Paula

🎾 Juan Loaiza
🎾 Valeria Leon

🎾 
🎾 
️

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )_
Yo Roberto 5a  (solo)

[16:29] **@lapalaclubdepadel:** TORNEO RELAMPAGO MIXTO!!
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: MIXTO
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Edymar
🎾 Jesus
 
🎾 Gustavo
🎾 Maria Paula

🎾 Juan Loaiza
🎾 Valeria Leon

🎾 Roberto C
🎾 
️

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )

[16:40] **@lapalaclubdepadel:** SABADO 8 DE AGOSTO
CATEGORIA: 5TA 
⌚ 6:30 pm a 8:00 pm
📍La pala
💰45k
🎾 Nicolas Conde 
🎾
🎾
🎾
PARTIDO ABIERTO

[16:59] **@lapalaclubdepadel:** SABADO 8 DE AGOSTO
CATEGORIA: 5TA 
⌚ 6:30 pm a 8:00 pm
📍La pala
💰45k
🎾 Nicolas Conde 
🎾 Roberto C
🎾
🎾
PARTIDO ABIERTO

---

## 9 de agosto de 2026

[6:35] **+54 9 3548 58-1308:** TORNEO RELAMPAGO MIXTO!!
     SI NO TIENES PAREJA, NOSOTROS TE BUSCAMOS❗️❗️

DOMINGO 9 de AGOSTO 2026

📈 *Categoría: MIXTO
inscripción individual 
⌚08:00 AM A 10:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 Gustavo
🎾 Maria Paula

🎾 Juan Loaiza
🎾 Valeria Leon

🎾 Roberto C
🎾 
️

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 1 PAREJAS )

[10:47] **@lapalaclubdepadel:** DOMINGO 9 DE AGOSTO
CATEGORIA: MIXTA C/D 5TA-6TA 
⌚ 04:00 pm a 06:00 pm
📍La pala
💰50k
🎾  
🎾
🎾
🎾
PARTIDO ABIERTO

[10:47] **@lapalaclubdepadel:** DOMINGO 9 DE AGOSTO
CATEGORIA: MIXTA C/D 5TA-6TA 
⌚ 02:00 pm a 04:00 pm
📍La pala
💰50k
🎾  
🎾
🎾
🎾
PARTIDO ABIERTO

[11:51] __+57 310 3210043 se unieron mediante el enlace de invitación__

[13:39] __@lapalaclubdepadel añadió a @omarp16__

[14:22] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[16:45] __@lapalaclubdepadel añadió a +57 311 4674170__

---

## 10 de agosto de 2026

[7:55] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: MIXTA C/D 5TA-6TA 
⌚ 10:00 Am a 11:00 Am
📍La pala
💰27k
🎾  
🎾
🎾
🎾
PARTIDO ABIERTO

[7:56] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: MIXTA C/D 5TA-6TA 
⌚ 04:00 Pm a 06:00 Pm
📍La pala
💰64k
🎾  
🎾
🎾
🎾
PARTIDO ABIERTO

[11:12] **@lapalaclubdepadel:** TORNEO AMERICANO MADRUGADORES 5TA
*MIERCOLES 12 de AGOSTO 2026

📈 *Categoría: (5ta  masculino) 
inscripción individual 
⌚06:00 AM A 08:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas, Rifas 
 Bebida Caliente (CAFE☕, CHOCOLATE🍫,CAPUCCINO 🧋)

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[12:49] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[14:02] **@lapalaclubdepadel:** TORNEO AMERICANO RELAMPAGO 5TA
  10 DE AGOSTO 2026

📈 *Categoría: (5ta masculino) 
inscripción individual 
⌚8 :00 PM A 10:00PM
📍 La Pala
💰70k por persona incluye Organización, Bolas y Rifas 
BONOS PLAYTOMIC PARA 🥇 y 🥈


🎾 Ernesto
🎾
🎾  
🎾 
🎾
🎾 
🎾 
🎾
️🎾 
🎾
🎾
🎾
 
*TORNEO ABIEERTO CUPOS LIMITADOS ( 11 CUPOS )
 Cupos Limitados. Animo los esperamos.

[14:50] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 08:00 pm a 10:00 pm
📍La pala
💰75k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[16:27] **@lapalaclubdepadel:** TORNEO AMERICANO RELAMPAGO 5TA
  10 DE AGOSTO 2026

📈 *Categoría: (5ta masculino) 
inscripción individual 
⌚8 :00 PM A 10:00PM
📍 La Pala
💰70k por persona incluye Organización, Bolas y Rifas 
BONOS PLAYTOMIC PARA 🥇 y 🥈


🎾 Ernesto
🎾
🎾  
🎾 
🎾
🎾 
🎾 
🎾
🎾 
🎾
🎾
🎾
 
*TORNEO ABIEERTO CUPOS LIMITADOS ( 11 CUPOS )
 Cupos Limitados. Animo los esperamos.

[16:28] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 pm a 8:00 pm
📍La pala
💰75k
🎾  Sergio Rengifo
🎾  
🎾 
🎾 
PARTIDO ABIERTO

[16:30] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 08:00 pm a 10:00 pm
📍La pala
💰75k
🎾 Gabo Marquez
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[16:33] **@lapalaclubdepadel:** TORNEO AMERICANO RELAMPAGO 5TA
  10 DE AGOSTO 2026

📈 *Categoría: (5ta masculino) 
inscripción individual 
⌚8 :00 PM A 10:00PM
📍 La Pala
💰70k por persona incluye Organización, Bolas y Rifas 
BONOS PLAYTOMIC PARA 🥇 y 🥈


🎾 Ernesto
🎾Nicolás Garzón
🎾  
🎾 
🎾
🎾 
🎾 
🎾
🎾 
🎾
🎾
🎾
 
*TORNEO ABIEERTO CUPOS LIMITADOS ( 10 CUPOS )
 Cupos Limitados. Animo los esperamos

[16:37] __[Notificación del sistema]__

[18:13] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 08:00 pm a 10:00 pm
📍La pala
💰75k
🎾 Gabo Marquez
🎾 Noelia Vera
🎾 
🎾 
PARTIDO ABIERTO

[18:37] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 08:00 pm a 10:00 pm
📍La pala
💰75k
🎾 Gabo Marquez
🎾 Noelia Vera
🎾 Álvaro Suarez
🎾 
PARTIDO ABIERTO

[18:57] **+44 7931 290432:** LUNES 10 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 08:00 pm a 10:00 pm
📍La pala
💰75k
🎾 Gabo Marquez
🎾 Noelia Vera
🎾 Álvaro Suarez
🎾 Nicolas D
PARTIDO ABIERTO

[18:59] **@lapalaclubdepadel:** LUNES 10 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 08:00 pm a 10:00 pm
📍La pala
💰75k
🎾 Gabo Marquez
🎾 Noelia Vera
🎾 Álvaro Suarez
🎾 Nicolas D
PARTIDO CERRADO
LOS ESPERAMOS

[19:57] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

---

## 11 de agosto de 2026

[7:15] **@lapalaclubdepadel:** [Imagen]

[7:17] **@lapalaclubdepadel:** disponibilidad profe Juanjo Martes, Miercoles y Jueves
06:00am - 04:00 pm (cualquier franja)

[9:50] **@lapalaclubdepadel:** TORNEO AMERICANO MADRUGADORES 5TA
*MIERCOLES 12 de AGOSTO 2026

📈 *Categoría: (5ta  masculino) 
inscripción individual 
⌚06:00 AM A 08:00AM
📍 La Pala
💰60k por persona incluye Organización, Bolas, Rifas 
 Bebida Caliente (CAFE☕, CHOCOLATE🍫,CAPUCCINO 🧋)

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾  
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾

🎾
🎾

 
*TORNEO ABIERTO CUPOS LIMITADOS ( 6 PAREJAS )

[9:56] __+57 318 2702802 se unieron mediante el enlace de invitación__

[10:28] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[10:29] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta / Damas C
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[12:12] **@AdminLaPala:** [Reenviado] [Video] 🔥 La primera parada de Major Pádel Bogotá by Chery está cada vez más cerca… y los cupos también están cada vez más limitados.

📍 La Pala
📅 26 al 30 de agosto
🏆 Más de $16,5 millones en premios entre efectivo y bonos
🎾 Todas las categorías + categorías FCP que suman al ranking nacional

¿Vas a competir o te lo van a contar? 👀

📲 Inscríbete ahora en SportSpace o solicita información al WhatsApp 333 051 5154.

#MajorPadelBogotá #PadelBogotá #LaPala #FCP #SportSpace

[13:48] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾Noelia 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[14:16] **+57 312 5456433:**
> _@lapalaclubdepadel: MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾Noelia 
🎾 
🎾 
🎾 
PARTIDO ABIERTO_
Me anoto para las 6 pm 5a alta

[14:27] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾Noelia 
🎾Roberto C
🎾 
🎾 
PARTIDO ABIERTO

[14:43] **+57 320 4233809:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾Noelia 
🎾Carlos C
🎾 Lina Ávila
🎾 
PARTIDO ABIERTO

[14:49] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾Noelia 
🎾Roberto C
🎾 Lina Ávila
🎾 
PARTIDO ABIERTO

[15:24] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[15:41] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta/5ta
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾Christian Knoth
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[15:57] **+57 310 8800142:** MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾Noelia 
🎾Roberto C
🎾 Lina Ávila
🎾 William Rodríguez
PARTIDO ABIERTO

[16:04] **@lapalaclubdepadel:**
> _+57 310 8800142: MARTES 11 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾Noelia 
🎾Roberto C
🎾 Lina Ávila
🎾 William Rodríguez
PARTIDO ABIERTO_
partido  cerrado! los esperamos! cancha #3

[16:36] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta/5ta
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾Christian Knoth
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[16:36] **@ccmo_1030:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta/5ta
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾Christian Knoth
🎾 Cristian Molano 
🎾 
🎾 
PARTIDO ABIERTO

[17:18] **+57 315 5758858:** _Se eliminó este mensaje_

[17:32] **+57 321 3820233:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta/5ta
⌚ 07:30 pm a 9:00 pm
📍La pala
💰62.5k
🎾Christian Knoth
🎾 Alejandro 
🎾 Mateo 
🎾 
PARTIDO ABIERTO

[17:36] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta/5ta
⌚ 9:00 pm a 10:30 pm
📍La pala
💰62.5k
🎾Christian Knoth
🎾 Alejandro 
🎾 Mateo 
🎾 Cristian Molano 
PARTIDO CERRADO

[17:36] **@lapalaclubdepadel:** Los esperamos en la cancha #3

[17:50] **+57 321 3820233:** Uy pero a las 9?

[17:51] **+57 321 3820233:** Yo puedo a las 7:30 con Mateo

[17:55] **@lapalaclubdepadel:** Una disculpa contigo Alejandro, pero ya no contamos con canchas disponibles en ese horario, te ofrecemos 9:00 p.m.

[18:03] **+57 321 3820233:** Gracias entonces no podemos

[18:04] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta/5ta
⌚ 9:00 pm a 10:30 pm
📍La pala
💰62.5k
🎾Christian Knoth
🎾 Cristian Molano 
🎾 
🎾 
PARTIDO ABIERTO

[19:01] **@lapalaclubdepadel:** MARTES 11 DE AGOSTO
CATEGORIA: 4ta/5ta
⌚ 9:00 pm a 10:30 pm
📍La pala
💰62.5k
🎾Christian Knoth
🎾 Cristian Molano 
🎾 
🎾 
PARTIDO ABIERTO
Solo nos faltan 2 palas

---

## 12 de agosto de 2026

[8:49] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[8:49] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA:Mixto C / 5ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[9:10] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA:Mixto C+ / 5ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Nan
🎾LuisFer 
🎾 
🎾 
PARTIDO ABIERTO

[9:53] **+57 310 2924270:** MIERCOLES 12 DE AGOSTO
CATEGORIA:Mixto C+ / 5ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Nan
🎾LuisFer 
🎾 Patricia Arenas 
🎾 
PARTIDO ABIERTO

[9:55] **+57 314 4364055:**
> _@lapalaclubdepadel: MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO_
Este podría ser de 4ta? Y hay chance de q sea mas temprano?

[9:57] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 4ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Daniel Morales
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[10:21] **+57 310 2924270:** MIERCOLES 12 DE AGOSTO
CATEGORIA:Mixto C+ / 5ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Nan
🎾LuisFer 
🎾 
🎾 
PARTIDO ABIERTO

[10:23] **@rperdomo3:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 4ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Daniel Morales
🎾 
🎾 Rafael P
🎾 Camilo B
PARTIDO ABIERTO

[10:24] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 4ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Daniel Morales
🎾 Daniel B
🎾 Rafael P
🎾 Camilo B
PARTIDO CERRADO
CANCHA 3
LOS ESPERAMOS

[10:24] **+57 314 4364055:**
> _@lapalaclubdepadel: MIERCOLES 12 DE AGOSTO
CATEGORIA: 4ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Daniel Morales
🎾 Daniel B
🎾 Rafael P
🎾 Camilo B
PARTIDO CERRADO
CANCHA 3
LOS ESPERAMOS_
Daniel B juega

[11:09] **@AdminLaPala:** [Imagen] En La Pala seguimos trabajando para que tu experiencia sea cada vez mejor 🎾💚

Ahora contamos con un convenio de parqueadero con beneficios especiales para quienes tienen actividad en el club. Recuerda revisar las condiciones, conservar tus sellos y tener en cuenta los tiempos establecidos para disfrutar del beneficio.

Gracias por hacer parte de La Pala. ¡Te esperamos para seguir jugando, disfrutando y compartiendo! 🎾

[11:25] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA:Mixto C+ / 5ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Nan
🎾LuisFer 
🎾Camila Posse
🎾 
PARTIDO ABIERTO

[11:54] __@lapalaclubdepadel añadió a @SSilva23__

[12:10] **@luis_arangohe:** MIERCOLES 12 DE AGOSTO
CATEGORIA:Mixto C+ / 5ta 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾Nan
🎾LuisFer 
🎾Camila Posse
🎾 Rodrigo D. 
PARTIDO CERRADO

[12:10] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[12:48] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO CERRADO LOS ESPERAMOS (cupo para una pareja!!)

[12:56] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO LOS ESPERAMOS

[13:30] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 4ta
⌚ 05:00 pm a 6:00 pm
📍La pala
💰32k
🎾Cano
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[13:34] **+57 321 5658933:** _Se eliminó este mensaje_

[13:40] **+57 316 5348415:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO LOS ESPERAMOS

[13:41] **+57 310 8800142:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO LOS ESPERAMOS

[14:08] **@etorresrojas:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO LOS ESPERAMOS

[14:45] **+57 310 2199159:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾
🎾

 
TORNEO ABIERTO LOS ESPERAMOS

[15:03] **+57 320 2043207:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

 
TORNEO ABIERTO LOS ESPERAMOS

[15:07] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO LOS ESPERAMOS

[15:26] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[15:48] **+57 316 3358569:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Santiago 
🎾Tomas 

🎾
🎾

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO LOS ESPERAMOS

[16:01] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 4ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[16:15] **+57 321 5658933:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan Camilo
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[16:35] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: MIXTO
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[16:46] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 6TA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[16:47] **@lug.contreras:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾
🎾

🎾
🎾

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO LOS ESPERAMOS_
Me gustaría subirme,
No tengo partner

[17:15] **@lapalaclubdepadel:** Si estas de acuerdo, nosotros te buscamos una pareja.

[17:16] **+57 310 6843763:** Yo juego y tmpoco tengo pareja

[17:16] **@lapalaclubdepadel:** Si estan de acuerdo, pueden jugar los 2

[17:18] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾 
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾
🎾

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO LOS ESPERAMOS

[17:25] **@lug.contreras:**
> _@lapalaclubdepadel: Si estan de acuerdo, pueden jugar los 2_
Perfecto

[17:54] **+44 7931 290432:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan Camilo
🎾 Nicolás D
🎾 
🎾 
PARTIDO ABIERTO

[18:43] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾
🎾

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO LOS ESPERAMOS

[18:44] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan Camilo
🎾 Nicolás D
🎾 
🎾 
PARTIDO ABIERTO
Solo faltan dos palas. Ánimo 💪🏼⚡

[18:52] **+1 (647) 778-0735:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan Camilo
🎾 Nicolás D
🎾 Juan Corral
🎾 
PARTIDO ABIERTO
Solo faltan dos palas. Ánimo 💪🏼⚡

[18:56] **@lapalaclubdepadel:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan Camilo
🎾 Nicolás D
🎾 Juan Corral
🎾 
PARTIDO ABIERTO
Solo faltan una pala. Ánimo 💪🏼⚡

[20:00] **+1 (647) 778-0735:** MIERCOLES 12 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan Camilo
🎾 Nicolás D
🎾
🎾 
PARTIDO ABIERTO
Solo faltan dos palas. Ánimo 💪🏼⚡

---

## 13 de agosto de 2026

[8:56] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:
MASCULINO ACADEMIA 6TA
⌚ 06:00 pm a 07:30 pm
📍La pala
💰85k
🎾 
🎾 
🎾 
🎾 
4 CUPOS DISPONIBLES
ANIMO!!!

[10:00] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!!

[10:13] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:Mixto 5TA / Damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!!

[10:14] **+57 320 8584974:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Juan L
🎾 Valeria L

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO LOS ESPERAMOS

[10:16] **@TomasVilladaBarrios:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Juan L
🎾 Valeria L

🎾 Tomás
🎾 Santiago

🎾
🎾
 
TORNEO ABIERTO LOS ESPERAMOS

[10:17] **+44 7931 290432:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Juan L
🎾 Valeria L

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾
 
TORNEO ABIERTO LOS ESPERAMOS

[10:23] __@lapalaclubdepadel añadió a @marcodelolmo__

[10:23] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Juan L
🎾 Valeria L

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾
 
TORNEO ABIERTO LOS ESPERAMOS
1 PALA QUIEN SE ANIMA!!!

[10:43] **+57 320 8584974:** JUEVES 13 DE AGOSTO
CATEGORIA:Mixto 5TA / Damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan L
🎾 Daniel H
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!!

[10:56] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 16 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾

🎾
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[10:59] __@lapalaclubdepadel añadió a +57 316 6204082__

[11:36] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Juan L
🎾 Valeria L

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾Juliana Q
 
TORNEO CERRADO
LOS ESPERAMOS!!!

[15:24] **+57 320 8584974:** JUEVES 13 DE AGOSTO
CATEGORIA:Mixto 5TA / Damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan L
🎾 Daniel H
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!!

[15:34] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:4TA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Noelia
🎾 
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!!

[16:15] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:4TA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Noelia
🎾 Gabo Marquez
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!! solo nos faltan 2 palas ⚡💪🏼

[16:50] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:Mixto 5TA / Damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan L
🎾 Daniel H
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!!

[17:38] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:4TA
⌚ 06:00 pm a 7:30 pm
📍La pala
💰62.5k
🎾 Noelia
🎾 Gabo Marquez
🎾 
🎾 
PARTIDO ABIERTO!
ANIMO!!! solo nos faltan 2 palas ⚡💪🏼

[17:40] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:Mixto 5TA / Damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan L
🎾 Daniel H
🎾 Alejandro Hoyos 
🎾 
PARTIDO ABIERTO!
ANIMO!!!

[18:40] **@lapalaclubdepadel:** JUEVES 13 DE AGOSTO
CATEGORIA:Mixto 5TA / Damas C
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juan L
🎾 Daniel H
🎾 Alejandro Hoyos 
🎾 Gabo Márquez 
PARTIDO CERRADO
LOS ESPERAMOS

---

## 14 de agosto de 2026

[8:49] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA:5TA Alta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO!

[9:05] __[Notificación del sistema]__

[9:17] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 6ta
⌚ 03:00 pm a 04:00 pm
📍La pala
💰32k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO!

[9:55] **+1 (202) 423-8490:** 📅 SÁBADO 15 DE AGOSTO 6:00 pm a 8:00 pm (120min)
Categoría: 4ta
 ✅ Alejandro Hoyos
 ✅ Alfonso Guzman
 ⚪ ??
 ⚪ ??
PARTIDO ABIERTO

Estamos buscando 2 jugadores más. Ojalá alguien se anime

[10:01] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[10:11] **+57 318 5423534:** [Video]

[10:12] **@lapalaclubdepadel:** 📅 SÁBADO 15 DE AGOSTO 6:00 pm a 8:00 pm (120min)
Categoría: 4ta
 ✅ Alejandro Hoyos
 ✅ Alfonso Guzman
 ⚪ 
 ⚪ 
PARTIDO ABIERTO
ANIMO!!!
Estamos buscando 2 jugadores más. Ojalá alguien se anime

[11:30] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Juan L
🎾 Valeria L

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾Juliana Q
 
TORNEO CERRADO
LOS ESPERAMOS!!!
LISTA DE ESPERA:
🎾Gerardo

[11:35] **@AdminLaPala:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 16 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾

🎾
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[11:41] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 16 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Gerado
🎾 
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾

🎾
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[12:12] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 6ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO!

[12:12] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO!

[12:17] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Juan L
🎾 Valeria L

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾Juliana Q
 
TORNEO CERRADO
LOS ESPERAMOS!!!
LISTA DE ESPERA:
🎾Gerardo
🎾Daniel

[12:17] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 16 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Gerado
🎾 Daniel 
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾

🎾
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[14:02] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lorena Puerta
🎾 Carlos Vasquez
🎾 
🎾 
PARTIDO ABIERTO!

[14:03] __@lapalaclubdepadel añadió a +1 (407) 274-2000__

[14:08] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 Esteban 
🎾
🎾 
🎾 
PARTIDO ABIERTO!

[14:09] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 Esteban 
🎾
🎾 
🎾 
PARTIDO ABIERTO!

[14:23] **+54 9 3548 58-1308:** VIERNESS 14 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 Esteban 
🎾Julian
🎾 Sebastian G
🎾 
PARTIDO ABIERTO!

[14:23] **+1 (407) 274-2000:**
> _+54 9 3548 58-1308: VIERNESS 14 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 Esteban 
🎾Julian
🎾 Sebastian G
🎾 
PARTIDO ABIERTO!_
👏🏼👏🏼

[14:24] **+1 (202) 423-8490:**
> _+54 9 3548 58-1308: VIERNESS 14 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 Esteban 
🎾Julian
🎾 Sebastian G
🎾 
PARTIDO ABIERTO!_
Yo juego

[14:26] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 Esteban 
🎾Julian
🎾 Sebastian G
🎾 Alejandro  
PARTIDO CERRADO
CANCHA5
LOS ESPERAMOS

[14:27] **+1 (407) 274-2000:**
> _@lapalaclubdepadel: VIERNESS 14 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k
🎾 Esteban 
🎾Julian
🎾 Sebastian G
🎾 Alejandro  
PARTIDO CERRADO
CANCHA5
LOS ESPERAMOS_
[Sticker]

[14:27] **+1 (407) 274-2000:** [Sticker]

[14:55] **@AdminLaPala:** Hola a todos

Nos falta un jugador de 5ta para completar un torneo hoy de 7:30 p.m. a 9:30 p.m. ¿Quién se anima?

[16:52] **+44 7931 290432:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lorena Puerta
🎾 Carlos Vasquez
🎾 Nicolás D
🎾 
PARTIDO ABIERTO!

[17:08] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta alta - C+
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lina Ávila
🎾 Eliana Andrade 
🎾
🎾 
PARTIDO ABIERTO!

[17:28] **@AdminLaPala:**
> _@AdminLaPala: Hola a todos

Nos falta un jugador de 5ta para completar un torneo hoy de 7:30 p.m. a 9:30 p.m. ¿Quién se anima?_
Hola a todos. Nos queda un cupo más ¿quién se anima?

[17:29] **+44 7931 290432:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lorena Puerta
🎾 Carlos Vasquez
🎾 
🎾 
PARTIDO ABIERTO!

[17:29] **+44 7931 290432:**
> _@AdminLaPala: Hola a todos. Nos queda un cupo más ¿quién se anima?_
Yo me apunto: Nicolás D

[17:31] **+57 316 4103202:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta alta - C+
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lina Ávila
🎾 Eliana Andrade 
🎾 Pilar Pachón 
🎾 
PARTIDO ABIERTO!

[17:33] **@AdminLaPala:**
> _+44 7931 290432: Yo me apunto: Nicolás D_
Listo, te esperamos 7:30 p.m.

[17:36] **@IvanBogota11:**
> _+44 7931 290432: VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lorena Puerta
🎾 Carlos Vasquez
🎾 Nicolás D
🎾 
PARTIDO ABIERTO!_
Logro ir a este?

[17:44] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[17:44] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[17:45] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lorena Puerta
🎾 Carlos Vasquez
🎾 Iván 
🎾 
PARTIDO ABIERTO!

[18:08] **@AdminLaPala:** [Reenviado] [Imagen]

[18:21] **+57 320 4233809:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta alta - C+
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lina Ávila
🎾 Eliana Andrade 
🎾 Pilar Pachón 
🎾 
PARTIDO ABIERTO!

[18:28] **+57 324 6856357:**
> _+57 320 4233809: VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta alta - C+
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lina Ávila
🎾 Eliana Andrade 
🎾 Pilar Pachón 
🎾 
PARTIDO ABIERTO!_
Yop

[18:29] **@lapalaclubdepadel:** VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta alta - C+
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lina Ávila
🎾 Eliana Andrade 
🎾 Pilar Pachón 
🎾 Bibiana Rodríguez
PARTIDO CERRADO

[18:30] **+57 310 2229668:**
> _@lapalaclubdepadel: VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta alta - C+
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lina Ávila
🎾 Eliana Andrade 
🎾 Pilar Pachón 
🎾 Bibiana Rodríguez
PARTIDO CERRADO_
Confirmadas todas?

[18:30] **+57 320 4233809:**
> _+57 310 2229668: Confirmadas todas?_
Yies

[19:09] **@IvanBogota11:**
> _@lapalaclubdepadel: VIERNESS 14 DE AGOSTO
CATEGORIA: 5ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k
🎾 Lorena Puerta
🎾 Carlos Vasquez
🎾 Iván 
🎾 
PARTIDO ABIERTO!_
Esto esta confirmado?

[19:11] **+57 311 4674170:**
> _@IvanBogota11: Esto esta confirmado?_
No, nos bajamos porq no se completo 🥲

[19:11] **@IvanBogota11:** Ok

[23:14] **+57 320 8584974:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Gerardo
🎾 Daniel

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾Juliana Q
 
TORNEO CERRADO
LOS ESPERAMOS!!!
LISTA DE ESPERA:

[23:15] **+57 320 8584974:** Nos tuvimos que retirar, pero subí a Gerardo y Daniel que estaban en lista de espera

---

## 15 de agosto de 2026

[6:38] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Gerardo
🎾 Daniel

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾Juliana Q
 
TORNEO CERRADO
LOS ESPERAMOS!!!
LISTA DE ESPERA: Viren

[9:50] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[9:54] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 15 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Giova
🎾  Juan C
 
🎾 Yesika
🎾 Jesus

🎾 Pilar C
🎾 William R

🎾 Riad
🎾 Ernesto 
️
🎾 Yamil 
🎾 Iván G

🎾 Mauricio
🎾 Pedro 

🎾Lug Contreras
🎾Sebastián F 

🎾 Gerardo
🎾 Daniel

🎾 Tomás
🎾 Santiago

🎾 Nicolás D
🎾Juliana Q
 
TORNEO CERRADO

[10:56] __@lapalaclubdepadel añadió a +57 321 4331327__

[11:19] **@lug.contreras:** Llegando en 15 el trafico del sábado

[11:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 16 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚02 :00 AM A 04:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾  
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[11:28] **+57 310 2199159:**
> _@lug.contreras: Llegando en 15 el trafico del sábado_
X2

[11:56] **+57 312 4036433:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 16 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚02 :00 PM A 04:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Matías Ñ
🎾 Milton P
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[12:11] **@lapalaclubdepadel:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta 
⌚ 03:00 pm a 04:00 pm
📍La pala
💰30k
🎾Fernando J
🎾Ricardo 
🎾
🎾 
PARTIDO ABIERTO

[12:30] **@IvanBogota11:** Puedo ir pero no se si mi nivel sea de cuarta?

[12:36] **+56 9 5637 0965:** Hola!
Como se reserva cancha?

[12:40] **@lapalaclubdepadel:**
> _+56 9 5637 0965: Hola!
Como se reserva cancha?_
Hola muy buenas tardes, mediante la plataforma de PLAYTOMIC puedes hacer pagos y reservas

[12:41] **+56 9 5637 0965:** Gracias!

[12:41] **@lapalaclubdepadel:**
> _+56 9 5637 0965: Gracias!_
con gusto si señor

[13:10] **+1 (202) 423-8490:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰60.0k
🎾 Alejandro 
🎾 Alfonso
🎾 
🎾 
PARTIDO ABIERTO!

[13:38] **+57 321 4331327:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰60.0k
🎾 Alejandro 
🎾 Alfonso
🎾 Lukas
🎾 
PARTIDO ABIERTO!

[13:38] **+65 9138 2902:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰60.0k
🎾 Alejandro 
🎾 Alfonso
🎾 Lukas
🎾 Viren
PARTIDO ABIERTO!

[14:03] **+57 317 4015496:**
> _@lapalaclubdepadel: SABADO 15 DE AGOSTO
CATEGORIA: 4ta 
⌚ 03:00 pm a 04:00 pm
📍La pala
💰30k
🎾Fernando J
🎾Ricardo 
🎾
🎾 
PARTIDO ABIERTO_
CANCELADO!

[14:13] **@lapalaclubdepadel:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾Fernando J
🎾
🎾
🎾 
PARTIDO ABIERTO

[14:14] **+57 317 4015496:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾Fernando J
🎾Ricardo L
🎾
🎾 
PARTIDO ABIERTO

[14:43] **+57 321 4331327:** _Se eliminó este mensaje_

[15:00] **@lapalaclubdepadel:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Alejandro 
🎾 Alfonso
🎾 Lukas
🎾 Viren
PARTIDO CERRADO
CANCHA 3

[15:32] **+65 9138 2902:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Alejandro 
🎾 Alfonso
🎾 Lukas
🎾
PARTIDO CERRADO
CANCHA 3

[15:49] **@lapalaclubdepadel:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Alejandro 
🎾 Alfonso
🎾 Lukas
🎾
PARTIDO ABIERTO
FALTA 1 PALA 
QUIEN SE ANIMA!!!

[15:49] **@STIDJ:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Alejandro 
🎾 Alfonso
🎾 Lukas
🎾 Stid J
PARTIDO ABIERTO
FALTA 1 PALA 
QUIEN SE ANIMA!!!

[15:53] **@lapalaclubdepadel:** SABADO 15 DE AGOSTO
CATEGORIA: 4ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Alejandro 
🎾 Alfonso
🎾 Lukas
🎾 Stid J
PARTIDO CERRADO
CANCHA 2

[16:08] **+57 312 4036433:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 16 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚02 :00 PM A 04:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[16:18] __@lapalaclubdepadel añadió a +57 304 6741686__

[16:54] __@lapalaclubdepadel añadió a +56 9 5320 9581__

[16:54] **@lapalaclubdepadel:** [Mensaje de message_history_notice]

[17:10] **+57 317 4015496:**
> _+57 317 4015496: SABADO 15 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾Fernando J
🎾Ricardo L
🎾
🎾 
PARTIDO ABIERTO_
CANCELADO!

[17:23] __@lapalaclubdepadel añadió a +1 (305) 497-5667__

[17:25] **@lapalaclubdepadel:** SABADO 15 DE AGOSTO
CATEGORIA: 5ta - 6ta
⌚ 06:30 pm a 08:00 pm 
📍La pala
💰45k
🎾 Jose Manuel
🎾 Partner
🎾 
🎾
PARTIDO ABIERTO
FALTAN 2 PALAS 
ANIMO!!!

[19:44] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[20:08] **+57 320 8584974:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 
🎾 

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[20:19] **+57 310 3210043:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

---

## 16 de agosto de 2026

[8:16] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[8:18] **@lapalaclubdepadel:** DOMINGO 16 DE AGOSTO
CATEGORIA: 6ta
⌚ 04:00 pm a 06:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[8:29] **@lapalaclubdepadel:** DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[9:07] **+1 (437) 242-7288:** Me gustaría jugar; soy de nivel 5.ª o 6.ª categoría para el partido de las 6 p. m. Me llamo Fadil.

[9:07] **@lapalaclubdepadel:** Con gusto ya te inscribimos

[9:07] **@lapalaclubdepadel:** DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[9:14] **@lapalaclubdepadel:** DOMINGO 16 DE AGOSTO
CATEGORIA: Damas C 
⌚ 04:00 pm a 06:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[9:36] **@IvanBogota11:** DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 Ivan B.
🎾 
🎾 
PARTIDO ABIERTO

[11:18] **@lapalaclubdepadel:** DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 Ivan B.
🎾 
🎾 
PARTIDO ABIERTO
Solo faltan 2 palas. Ánimo!! 💪🏼⚡

[12:04] **+57 312 5456433:**
> _@lapalaclubdepadel: DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 Ivan B.
🎾 
🎾 
PARTIDO ABIERTO
Solo faltan 2 palas. Ánimo!! 💪🏼⚡_
Me apunto para juego de 6pm 5ta

[12:05] **@lapalaclubdepadel:** DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 Ivan B.
🎾 Roberto C
🎾 
PARTIDO ABIERTO
Solo faltan 1 pala. Ánimo!! 💪🏼⚡

[12:07] __@lapalaclubdepadel añadió a +57 321 5419099__

[13:14] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[13:46] **+57 310 6843763:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾
🎾 

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!_
Juanes z y sebastian f

[14:00] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾
🎾  
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[14:13] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camino P 
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[14:26] **+1 (437) 242-7288:**
> _@lapalaclubdepadel: DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 Ivan B.
🎾 Roberto C
🎾 
PARTIDO ABIERTO
Solo faltan 1 pala. Ánimo!! 💪🏼⚡_
Hi is there a 4 th

[15:02] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[15:11] **@lapalaclubdepadel:**
> _+1 (437) 242-7288: Hi is there a 4 th_
Not yet; we're waiting for someone to step up.

[15:32] **+57 321 3820233:**
> _@lapalaclubdepadel: DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 Ivan B.
🎾 Roberto C
🎾 
PARTIDO ABIERTO
Solo faltan 1 pala. Ánimo!! 💪🏼⚡_
Me apunto para jugar

[15:33] **@lapalaclubdepadel:** DOMINGO 16 DE AGOSTO
CATEGORIA: 5ta
⌚ 06:00 pm a 08:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Fadil 
🎾 Ivan B.
🎾 Roberto C
🎾 Alejandro Arias
PARTIDO CERRADO 💪🏼⚡

[15:34] **+1 (437) 242-7288:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 
🎾 

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!_
I can play here too tomorrow

[15:35] **@lapalaclubdepadel:**
> _+1 (437) 242-7288: I can play here too tomorrow_
Okay! I'll sign you up now.

[15:36] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 Fadil
🎾 María Isabel Salcedo

🎾
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[16:37] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 Fadil
🎾 María Isabel Salcedo

🎾Andrés Guataqui
🎾
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[19:21] **+57 311 7841842:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 Fadil
🎾 María Isabel Salcedo

🎾Andrés Guataqui
🎾Xiomara T
 
 
TORNEO ABIERTO LOS ESPERAMOS
ANIMO!!!

[19:22] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 Fadil
🎾 María Isabel Salcedo

🎾Andrés Guataqui
🎾Xiomara T
 
 
TORNEO CERRADO LOS ESPERAMOS

[20:56] **+57 311 7841842:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 Fadil
🎾 María Isabel Salcedo

🎾Andrés Guataqui
🎾
 
 
TORNEO CERRADO LOS ESPERAMOS

---

## 17 de agosto de 2026

[8:46] **@IvanBogota11:** Si puedo, yo voy en el cupo que queda!

[8:48] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
LUNES 17 FESTIVO de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:00 AM A 01:00PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtomic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Juan L
🎾 Valeria L
 
🎾 Alejandro S
🎾 Fernando S

🎾Juanes Z 
🎾 Sebastián F

🎾Ernesto T
🎾 Camilo P 
️
🎾 Fadil
🎾 María Isabel Salcedo

🎾Andrés Guataqui
🎾Ivan  B 
 
 
TORNEO CERRADO LOS ESPERAMOS

[9:39] **@lapalaclubdepadel:** LUNES 17 DE AGOSTO
CATEGORIA: 4ta
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[9:41] **@lapalaclubdepadel:** LUNES 17 DE AGOSTO
CATEGORIA: Damas C
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[9:45] **@lapalaclubdepadel:** LUNES 17 DE AGOSTO
CATEGORIA: 6ta y 7ma
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[10:06] **@lapalaclubdepadel:** LUNES 17 DE AGOSTO
5CATEGORIA: 5ta ALTA 
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[10:11] **@jeanpenent:** LUNES 17 DE AGOSTO
CATEGORIA: 4ta
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Jean Michel 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[10:12] **+57 312 5456433:**
> _@lapalaclubdepadel: LUNES 17 DE AGOSTO
5CATEGORIA: 5ta ALTA 
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡_
Me apunto a este juego

[10:12] **+57 304 4715071:** LUNES 17 DE AGOSTO
CATEGORIA: 4ta
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Jean Michel 
🎾 Pablo C
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[10:21] **@lapalaclubdepadel:** LUNES 17 DE AGOSTO
CATEGORIA: 4ta
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Jean Michel 
🎾 Pablo C
🎾 
🎾 
PARTIDO ABIERTO 
2 PALAS MÁS 💪🏼⚡

[10:34] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Agosto 17!!
📈 *Categoría: Quinta-Sexta C-D
⌚4:00 PM A 6:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Camilo
🎾 Jorge Caro.
🎾 Estefa R

🎾Paola C
🎾 Yamil
🎾 Nico Mor
🎾 Moritz

🎾 Oscar
🎾 Patty
🎾 Caro C
🎾María A Pallares

🎾Terry P
🎾Juan A
🎾 Juan Jaramillo
🎾 Sebas

🎾 Mijail 
🎾 Valentina M
🎾 Ana Paola
🎾

🇨🇴🇨🇴🇨🇴 ! 


Lista de espera:
🎾

[10:54] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Agosto 17!!
📈 *Categoría: Quinta-Sexta C-D
⌚4:00 PM A 6:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Camilo
🎾 Jorge Caro.
🎾 Estefa R

🎾Paola C
🎾 Yamil
🎾 Nico Mor
🎾 Moritz

🎾 Oscar
🎾 Patty
🎾 Caro C
🎾María A Pallares

🎾Terry P
🎾Juan A
🎾 Juan Jaramillo
🎾 Sebas

🎾 Mijail 
🎾 Valentina M
🎾 Ana Paola
🎾Juan Diego Vila 

🇨🇴🇨🇴🇨🇴 ! 


Lista de espera:
🎾

[10:57] **@lapalaclubdepadel:** TORNEO Thanks God its Padel
Agosto 17!!
📈 *Categoría: Quinta-Sexta C-D
⌚4:00 PM A 6:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Camilo
🎾 Jorge Caro.
🎾 Estefa R

🎾Paola C
🎾 Yamil
🎾 Nico Mor
🎾 Moritz

🎾 Oscar
🎾 Patty
🎾 Caro C
🎾María A Pallares

🎾Terry P
🎾Juan A
🎾 Juan Jaramillo
🎾 Sebas

🎾 Mijail 
🎾 Valentina M
🎾 Ana Paola
🎾Juan Diego Vila 

🇨🇴🇨🇴🇨🇴 ! 


Lista de espera:
🎾Daniela Posada

[12:20] **+57 310 7032367:** LUNES 17 DE AGOSTO
5CATEGORIA: 5ta ALTA 
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Gabo Márquez 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[12:23] **@lapalaclubdepadel:** LUNES 17 DE AGOSTO
5CATEGORIA: 5ta ALTA 
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Gabo Márquez 
🎾 Roberto C
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[13:09] **+57 304 4715071:** LUNES 17 DE AGOSTO
5CATEGORIA: 5ta ALTA 
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Gabo Márquez 
🎾 Roberto C
🎾 Pablo C
🎾 Jean Michel
PARTIDO ABIERTO 💪🏼⚡

[13:10] **+57 304 4715071:** LUNES 17 DE AGOSTO
CATEGORIA: 4ta
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 
4 PALAS MÁS 💪🏼⚡

[13:11] **@lapalaclubdepadel:** LUNES 17 DE AGOSTO
5CATEGORIA: 5ta ALTA 
⌚ 02:00 pm a 04:00 pm (2 HORAS)
📍La pala
💰50k
🎾 Gabo Márquez 
🎾 Roberto C
🎾 Pablo C
🎾 Jean Michel
PARTIDO CERRADO 💪🏼⚡

[13:39] **@elifrancogomez:** https://www.instagram.com/reel/DcJr2q1RGCY/?igsh=b2N1MHM0Z2VxeWtr

[13:39] **@elifrancogomez:** 🇨🇴⚽ ¡LEVANTEMOS A COLOMBIA!

Este viernes 21 de agosto tenemos una cita que va mucho más allá del fútbol.

Nos encontramos en el Estadio El Campín para convertir nuestra pasión en solidaridad y nuestra solidaridad en ayuda real para miles de familias colombianas que hoy necesitan volver a empezar. ❤️‍🩹

Compra tu boleta, invita a tu familia, a tus amigos, a los futboleros y a todos los que quieran sumarse.

📅 Viernes 21 de agosto
⏰ 7:30 p. m.
📍 Estadio El Campín, Bogotá
🎟️ Boletas desde $25.000

El fútbol nos ha unido muchas veces. Esta vez nos une para levantar a Colombia. 🇨🇴

Compra tus boletas aquí 👇
https://tuboleta.com/es/eventos/partido-levantemos-colombia

Cada boleta es una forma de ayudar. Cada persona en el estadio cuenta.

#LevantemosAColombia

[18:22] **@lapalaclubdepadel:** [Mensaje de album]

[18:22] **@lapalaclubdepadel:** [Imagen]

[18:22] **@lapalaclubdepadel:** [Imagen]

[18:22] **@lapalaclubdepadel:** [Imagen]

[18:22] **@lapalaclubdepadel:** [Imagen]

[18:23] **@lapalaclubdepadel:** TORNEO TGIP 🔥🥳 LUNES FESTIVO

---

## 18 de agosto de 2026

[8:23] **+1 (437) 242-7288:** Is there any games today ?

[8:26] **@lapalaclubdepadel:** Hi, Fadil Yes.

[8:27] **+57 314 4364055:** Hola me podrias ayudar porfa si hay, con uno de cuarta 6pm

[8:31] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: 4ta  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[8:34] **@AdminLaPala:** MARTES 18 agosto
*Damas D
 ⏱️5:00 a 6:00 p.m
📍La Pala
 💰32K 

🎾Angie
🎾Andrea

🎾 
🎾 
*PARTIDO ABIERTO

[8:44] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: Mixto damas C 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[9:04] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: 5ta  ALTA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰62.5k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[9:17] **@lapalaclubdepadel:** [Reenviado] [Video] 🔥 Inscribirte a Major Pádel Bogotá te toma menos de dos minutos.

Entra a SportSpace, busca el torneo en “Próximos eventos”, elige tu categoría y selecciona si quieres pagar la inscripción completa o únicamente tu parte. Tu partner podrá pagar la suya desde su propia cuenta y con el medio de pago que prefiera. 🎾📲

Revisa los datos, realiza el pago ¡y listo! Tu pareja queda preparada para entrar al circuito.

Inscríbete aquí:
https://app.sportspace.app/eventos/5821646a-ebf1-4a87-9820-14f59084dbce

Ahora sí, pónganse a entrenar… porque el nivel va a estar 🔥

#MajorPadelBogotá #SportSpace #PadelBogotá #TorneoDePadel

[11:59] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: 4ta  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰62.5k
🎾 Alejo
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[12:22] **+507 6430-5628:** _Se eliminó este mensaje_

[12:22] **+507 6430-5628:** _Se eliminó este mensaje_

[13:33] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: C 
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62k? 
🎾 
🎾 Alicia 
🎾 Cinthya
🎾 Nan 

PARTIDO ABIERTO 💪🏼⚡
SOLO FALTA UNA PALA

[14:27] **@luismilanaob:** [Imagen]

[14:28] **@luismilanaob:** [Imagen]

[14:29] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[14:30] **@lapalaclubdepadel:** Buenas tardes, se les recuerda que el grupo es para programación de partidos y torneos

[14:34] **@luismilanaob:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[16:31] __@lapalaclubdepadel añadió a +57 316 7541019__

[16:31] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: C 
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62k? 
🎾 
🎾 Alicia 
🎾 Cinthya
🎾 Nan 

PARTIDO ABIERTO 💪🏼⚡
SOLO FALTA UNA PALA
ANIMO!!!

[16:35] **+57 310 7032367:** MARTES 18 DE AGOSTO
CATEGORIA: 4ta  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰62.5k
🎾 Alejo
🎾 Gabo Márquez 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[18:06] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: 5ta  ALTA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jose
🎾 Sebastian
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[18:26] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: 5ta  ALTA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jose
🎾 Sebastian
🎾 Gabo M
🎾 
PARTIDO ABIERTO 💪🏼⚡

[18:31] **+507 6430-5628:**
> _@lapalaclubdepadel: MARTES 18 DE AGOSTO
CATEGORIA: C 
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62k? 
🎾 
🎾 Alicia 
🎾 Cinthya
🎾 Nan 

PARTIDO ABIERTO 💪🏼⚡
SOLO FALTA UNA PALA
ANIMO!!!_
Cancelado

[18:31] **+65 9138 2902:** MARTES 18 DE AGOSTO
CATEGORIA: 4ta  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰62.5k
🎾 Alejo
🎾 Gabo Márquez 
🎾 Viren
🎾 
PARTIDO ABIERTO

[18:36] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: 4ta  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰62.5k
🎾 Alejo
🎾 Viren
🎾 
🎾 
PARTIDO ABIERTO

[18:56] **@lapalaclubdepadel:** MARTES 18 DE AGOSTO
CATEGORIA: 5ta  ALTA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jose
🎾 Sebastian
🎾 Gabo M
🎾  Juan Fernando
PARTIDO CERRADO 💪🏼⚡
CANCHA 4

---

## 19 de agosto de 2026

[7:31] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 4TA  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[8:47] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 6TA Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Alejandra Terraza
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[8:52] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 6TA Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Alejandra Terraza
🎾 Yani
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[8:52] **+57 310 3029444:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 6TA Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Alejandra Terraza
🎾 Yani
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[10:24] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 6TA Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Alejandra Terraza
🎾 Yani
🎾 Andrea
🎾 
PARTIDO ABIERTO 💪🏼⚡

[10:38] __@AdminLaPala eliminó a +57 301 2093946__

[10:42] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 4TA  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[11:23] **@jeanpenent:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 4TA  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jean Michel 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[11:29] __+57 320 4908833 se unieron mediante el enlace de invitación__

[11:40] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 6TA Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Alejandra Terraza
🎾 Yani
🎾 Andrea
🎾 
PARTIDO ABIERTO 💪🏼⚡
UNA PALA MÁS. ÁNIMO 💯

[12:02] **+57 304 4715071:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 4TA  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jean Michel 
🎾 Pablo C
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[12:27] **+54 9 3548 58-1308:** Buenas tardes comunidad! Tenemos cupos disponibles para torneo 7:30 pm 5ta masculino, los esperamos! Comunicarse por privado

[12:28] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 6TA Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Alejandra Terraza
🎾 Yani
🎾 Andrea
🎾 Olinda 
PARTIDO CERRADO 💪🏼⚡ 💯

[14:26] **@lapalaclubdepadel:** Hola buenas tardes tardes.
Tenemos un cupo disponible para damas C
Quien se anima!!!

[14:46] **@AdminLaPala:** Hola a todos. Tenemos un cupo para 5ta categoría para un torneo hoy a las 7:30 p.m.

[14:47] **@IvanBogota11:** Como  funciona?

[14:59] **@lapalaclubdepadel:** Hola buenas tardes tardes.
Tenemos un cupo disponible para damas C
Quien se anima!

[15:40] **+54 9 3548 58-1308:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 4TA  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jean Michel 
🎾 Pablo C
🎾 Sebastian G
🎾 
PARTIDO ABIERTO 💪🏼⚡

[15:46] **+57 310 7032367:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 4TA  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jean Michel 
🎾 Pablo C
🎾 Sebastian G
🎾 Gabo Márquez 
PARTIDO ABIERTO 💪🏼⚡

[15:51] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 4TA  
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 Jean Michel 
🎾 Pablo C
🎾 Sebastian G
🎾 Gabo Márquez 
PARTIDO ABIERTO 💪🏼⚡
CANCHA 4

[16:47] **@lapalaclubdepadel:** MIÉRCOLES 19 DE AGOSTO
CATEGORIA: 5TA  ALTA
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[17:16] **@lapalaclubdepadel:** MAÑANA JUEVES 20 DE AGOSTO
CATEGORIA: 5TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Jorge Caro 
🎾Andres Vega
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[18:40] **@AdminLaPala:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 
🎾
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[18:48] **@AdminLaPala:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[18:52] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[18:59] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[19:22] **+57 316 0411782:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[21:32] **+57 301 6573017:** _Se eliminó este mensaje_

---

## 20 de agosto de 2026

[7:39] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: Damas C
⌚ 3:00 pm a 04:30 pm 
📍La pala
💰48k
🎾Carolina Martin 
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[7:47] **@lapalaclubdepadel:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[8:23] **+57 316 2985422:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[8:48] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: MIXTO 5TA DAMAS C 
⌚ 6:00 pm a 07:30 pm 
📍La pala
💰62.5k
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[8:49] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 5TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Jorge Caro 
🎾Andres Vega
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[8:51] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[9:05] **+57 314 2838850:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[9:08] **+57 305 7755210:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 Daniela Riveros 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[9:50] **@sllamas26:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 Daniela Riveros 
🎾 Olinda
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[9:54] **@sllamas26:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 Daniela Riveros 
🎾 Olinda
 
🎾 Diana Meza
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[9:55] **@afpardol:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 Daniela Riveros 
🎾 Olinda
 
🎾 Diana Meza
🎾 Felipe Pardo
🎾 
🎾 
ANÓTENSE 🥳🥳

[10:03] __@lapalaclubdepadel añadió a +1 (646) 385-3382__

[10:04] **@lapalaclubdepadel:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 Daniela Riveros 
🎾 Olinda
 
🎾 Diana Meza
🎾 Felipe Pardo
🎾 Douglas 
🎾 
ANÓTENSE 🥳🥳

[10:11] **+57 310 3029444:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 Daniela Riveros 
🎾 Olinda
 
🎾 Diana Meza
🎾 Felipe Pardo
🎾 Douglas 
🎾 Alejandra T
ANÓTENSE 🥳🥳

[10:23] __@lapalaclubdepadel añadió a +57 321 4231431__

[10:24] **@lapalaclubdepadel:** Buenos días🥳🥳
Americano 6ta/7ma Masculino-Femenino
 Viernes 21 de Agosto de 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic para reservas de práctica libre

🎾 Daniel Salinas 
🎾 Erika Díaz 
🎾 Juan Alfaro
🎾 Sandra F

🎾 Sebastián Duarte
🎾 Saskia
🎾 Ana Paola
🎾Guiova 

🎾 Juan Camilo Franco
🎾 María Fernanda Triviño
🎾 Daniela Riveros 
🎾 Olinda
 
🎾 Diana Meza
🎾 Felipe Pardo
🎾 Douglas 
🎾 Alejandra T
TORNEO CERRADO. LOS ESPERAMOS

[11:11] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: Damas C
⌚ 4:00 pm a 06:00 pm 
📍La pala
💰55k
🎾Carolina Martin 
🎾Fernanda Calderon  
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[11:14] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 
🎾 
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[11:43] **@lapalaclubdepadel:** [Imagen]

[12:24] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Alejo
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[12:28] **+57 314 4364055:**
> _@lapalaclubdepadel: JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Alejo
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡_
Daniel M

[12:30] **+57 310 8800142:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[12:33] **+65 9138 2902:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾 

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[12:35] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾 

🎾Guiova
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[12:36] **+57 310 6843763:** Yo!

[12:36] **+57 310 6843763:** Sebatian F

[12:41] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾 

🎾Guiova
🎾Sebastián F 

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[12:49] **+507 6430-5628:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[12:49] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[12:51] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 6TA/ 7MA
⌚ 6:00 pm a 07:30 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[13:13] **@SergioRengifoC:**
> _@lapalaclubdepadel: JUEVES 20 DE AGOSTO
CATEGORIA: 6TA/ 7MA
⌚ 6:00 pm a 07:30 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡_
Este es posible de 4ta?

[13:15] **@lapalaclubdepadel:** Si señor

[13:16] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4ta
⌚ 6:00 pm a 07:30 pm 
📍La pala
💰62.5k
🎾Sergio Rengifo
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[13:41] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 6TA/ 7MA
⌚ 6:00 pm a 07:30 pm 
📍La pala
💰62.5k
🎾 Douglas Vil
🎾
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[13:43] **+57 312 8214097:** _Se eliminó este mensaje_

[13:43] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO

[14:03] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 5TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Jorge Caro 
🎾Andres Vega
🎾 Camilo J.
🎾 
PARTIDO ABIERTO 💪🏼⚡

[14:11] **+57 318 2702802:** JUEVES 20 DE AGOSTO
CATEGORIA: 5TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Jorge Caro 
🎾Andres Vega
🎾 Camilo J.
🎾 Sebastián O 
PARTIDO ABIERTO 💪🏼⚡

[14:12] **+57 314 4364055:**
> _+57 314 4364055: Daniel M_
Este si se va a dar?

[14:12] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[14:17] **+507 6430-5628:** JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Alejo
🎾 Daniel M 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[15:07] __@lapalaclubdepadel añadió a +57 313 8213142__

[15:27] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Felipe Pedraza
🎾Juan Sebastian B
🎾
🎾 
PARTIDO ABIERTO 💪🏼⚡

[15:37] **+57 304 4715071:** JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Felipe Pedraza
🎾Juan Sebastian B
🎾Pablo Cuartas
🎾 
PARTIDO ABIERTO 💪🏼⚡

[15:37] **+57 314 4364055:**
> _+57 304 4715071: JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Felipe Pedraza
🎾Juan Sebastian B
🎾Pablo Cuartas
🎾 
PARTIDO ABIERTO 💪🏼⚡_
Daniel M

[15:38] **+57 315 6450599:** JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Felipe Pedraza
🎾Juan Sebastian B
🎾Pablo Cuartas
🎾 David F
PARTIDO ABIERTO 💪🏼⚡

[15:38] **+57 314 4364055:** Y si me puedes sacar del otro porfa para llenar este ultimo

[15:46] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾
🎾
PARTIDO ABIERTO 💪🏼⚡

[15:56] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Daniel Morales
🎾
🎾
🎾
PARTIDO ABIERTO 💪🏼⚡

[16:07] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4TA 
⌚ 9:00 pm a 10:30 pm 
📍La pala
💰50k
🎾Felipe Pedraza
🎾Juan Sebastian B
🎾Pablo Cuartas
🎾 David F
PARTIDO CERRADO 💪🏼⚡
CANCHA 3

[16:09] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: MIXTO C / 5TA
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾Carolina Martin 
🎾Fernanda Calderon  
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡

[16:15] **@lug.contreras:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 
🎾 

🎾
🎾

 
TORNEO ABIERTO_
Me subo pero no tengo partner

[16:18] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: MIXTO C / 5TA
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾Carolina Martin 
🎾Fernanda Calderon  
🎾 Douglas
🎾 
PARTIDO ABIERTO 💪🏼⚡
1 PALA ANIMO!!!

[16:23] **@lapalaclubdepadel:**
> _@lug.contreras: Me subo pero no tengo partner_
TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Lug Contreras
🎾 

🎾
🎾

 
TORNEO ABIERTO

[16:25] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: MIXTO C / 5TA
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾Carolina Martin 
🎾Fernanda Calderon  
🎾 Douglas
🎾 Sebastian Orjuela
PARTIDO CERRADO 💪🏼⚡
CANCHA 3

[17:02] **+57 301 6573017:** JUEVES 20 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Daniel Morales
🎾Alejandro Cortez
🎾 Daniel B
🎾
PARTIDO ABIERTO 💪🏼⚡

[17:30] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Daniel Morales
🎾Alejandro Cortez
🎾 Daniel B
🎾
PARTIDO ABIERTO 💪🏼⚡
FALTA 1 PALA 
QUIEN SE ANILA!!!

[17:31] **+57 315 7868953:** JUEVES 20 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Daniel Morales
🎾Alejandro Cortez
🎾 Daniel B
🎾 Daniel C
PARTIDO ABIERTO 💪🏼⚡
FALTA 1 PALA 
QUIEN SE ANILA!!!

[17:32] **@lapalaclubdepadel:** JUEVES 20 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Daniel Morales
🎾Alejandro Cortez
🎾 Daniel B
🎾 Daniel C
PARTIDO CERRADO
CANCHA 5

[19:07] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[19:10] __@lapalaclubdepadel añadió a +57 317 3633041__

[19:23] **+57 314 4364055:**
> _@lapalaclubdepadel: JUEVES 20 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Daniel Morales
🎾Alejandro Cortez
🎾 Daniel B
🎾 Daniel C
PARTIDO CERRADO
CANCHA 5_
Voy 5 mins tarde, disculpen la demora

[19:24] **@lapalaclubdepadel:**
> _+57 314 4364055: Voy 5 mins tarde, disculpen la demora_
entendido si señor

[21:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Lug Contreras
🎾

 
TORNEO ABIERTO
FALTA 1 PALA 
QUIEN SE ANIMA

[21:40] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

---

## 21 de agosto de 2026

[2:41] **@IvanBogota11:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Lug Contreras
🎾

 
TORNEO ABIERTO
FALTA 1 PALA 
QUIEN SE ANIMA_
Ivan b.

[6:25] **+54 9 3548 58-1308:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Lug Contreras
🎾Ivan B

 
TORNEO ABIERTO
FALTA 1 PALA 
QUIEN SE ANIMA

[6:27] **+1 (646) 385-3382:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Lug Contreras
🎾

 
TORNEO ABIERTO
FALTA 1 PALA 
QUIEN SE ANIMA_
Yo me subo a este

[6:28] **+1 (646) 385-3382:** Yo

[6:34] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Lug Contreras
🎾Ivan B

🎾 Douglas Vil 
🎾

🎾 
🎾
 
TORNEO ABIERTO

[6:58] **@marcodelolmo:** Buenos días. Estoy intentando inscribirme al torneo a través de sportspace pero al intentar crear la cuenta nunca me llega el mensaje de texto sms para verificar el celular. Cómo puedo inscribirme a través de otra plataforma?

[6:58] **@lapalaclubdepadel:** Hola Marco muy buenos días. Ya te escribimos por interno para ayudarte

[7:37] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[7:56] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[7:59] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: MIXTO DAMAS C
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[9:28] **+54 9 3548 58-1308:** VIERNES 21 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Sebastian G
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[12:23] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: 5ta 
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾Sebastian Orjuela
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[12:44] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Lug Contreras
🎾Ivan B

🎾 Douglas Vil 
🎾

🎾 Carlos Vasquez
🎾Lorena Puerta
 
TORNEO ABIERTO

[13:41] **@lug.contreras:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Lug Contreras
🎾Ivan B

🎾 Douglas Vil 
🎾

🎾 Carlos Vasquez
🎾Lorena Puerta
 
TORNEO ABIERTO_
Me tengo que bajar x motives laborales 😩

[13:46] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 
🎾
 
TORNEO ABIERTO

[14:15] **@AdminLaPala:** VIERNES 21 DE AGOSTO
CATEGORIA: 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[14:36] **@AdminLaPala:** VIERNES 21 DE AGOSTO
CATEGORIA: Mixtos Damas C+ / 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾 Lina A
🎾 Eliana 
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[15:50] **+57 305 3702448:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 Camilo ₿itcoin
🎾 Pareja
 
TORNEO ABIERTO

[16:08] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 Camilo ₿itcoin
🎾 Pareja

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO

[17:14] **@lapalaclubdepadel:** Muy buenas tardes Comunidad PADELERA disponibilidad de cancha desde las 06:00pm en adelante.
PROGRAMEN SUS PARTIDOS EN CUELQUIERA DE NUESTRAS FRANJAS.
(TARIFA 09:00PM 50MIL C/U)

[17:14] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[17:58] **+65 9138 2902:** VIERNES 21 DE AGOSTO
CATEGORIA: Mixtos Damas C+ / 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾 Lina A
🎾 Eliana 
🎾 Viren
🎾
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[18:05] **+57 315 4587182:** VIERNES 21 DE AGOSTO
CATEGORIA: Mixtos Damas C+ / 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾 Lina A
🎾 Eliana 
🎾 Viren
🎾 Mane
PARTIDO ABIERTO 💪🏼⚡
ANIMO!!!

[18:08] **@lapalaclubdepadel:** VIERNES 21 DE AGOSTO
CATEGORIA: Mixtos Damas C+ / 4ta
⌚ 7:30 pm a 9:00 pm 
📍La pala
💰62.5k
🎾 Lina A
🎾 Eliana 
🎾 Viren
🎾 Mane
PARTIDO CERRADO 💪🏼⚡
CANCHA 3

[18:14] **+57 305 8745599:** _Se eliminó este mensaje_

[18:16] **+57 312 5456433:**
> _+57 305 8745599: Sabado 22 DE AGOSTO
CATEGORIA:  Masculino 5 alta 4 baja 
⌚ 10:00 am a 11:30 am 
📍La pala
💰62.5k
🎾 Sebas g
🎾 manuel  
🎾
🎾 
PARTIDO abierto 💪🏼⚡
CANCHA por reservar_
Me apunto a este

[18:16] **+57 305 3702448:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 Camilo ₿itcoin
🎾 Pareja

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO_
Busco pareja 👀

[18:17] **@AdminLaPala:** _Se eliminó este mensaje_

[18:36] **+57 305 8745599:** _Se eliminó este mensaje_

[19:05] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[19:05] **@lapalaclubdepadel:** Cuando más nos necesitan, estar presentes también es parte de lo que somos. 💚

Desde *La Pala* estamos gestionando ayudas y donaciones para que puedan llegar a las personas y familias damnificadas por el terremoto que sacudió a nuestro país.

Hoy queremos sumar esfuerzos, unirnos como comunidad y aportar un poco de esperanza a quienes están atravesando momentos difíciles. 🙏

*Porque una ayuda puede parecer pequeña, pero juntos podemos hacer una gran diferencia.*

[19:20] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 Camilo ₿itcoin
🎾 Pareja

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO
faltan 2 parejas 
NO TE QUEDES POR FUERA

[19:37] **+57 305 3702448:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 Camilo ₿itcoin
🎾 Adriana Puig

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO
faltan 2 parejas 
NO TE QUEDES POR FUERA

[21:04] **+57 323 4375935:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[21:04] **+57 323 4375935:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[21:26] **@lapalaclubdepadel:** Buenas noches, por favor tener en cuenta que el grupo es únicamente para programar partidos y torneos.

---

## 22 de agosto de 2026

[8:18] **@lapalaclubdepadel:** SÁBADO 22 DE AGOSTO
CATEGORIA: 5TA ALTA 
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[8:20] **@lapalaclubdepadel:** SÁBADO 22 DE AGOSTO
CATEGORIA: 4TA  
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[8:29] **@lapalaclubdepadel:** SÁBADO 22 DE AGOSTO
CATEGORIA: MIXTO (6TA) DAMAS D 
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[10:01] **@lapalaclubdepadel:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 Camilo ₿itcoin
🎾 Pareja

🎾
🎾

🎾
🎾
 
TORNEO ABIERTO
faltan 2 parejas 
NO TE QUEDES POR FUERA_
Muy buenos días a todos, los esperamos con toda la energía para disfrutar de un sábado con mucho pádel. 💯🎾

[11:05] __@lapalaclubdepadel añadió a +57 312 4318594__

[11:08] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 22 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Pilar C
🎾 William R
 
🎾 Viren
🎾  Sebastián Orjuela 

🎾Guiova
🎾Sebastián F 

🎾 Nan S
🎾 Leonardo Perez
️
🎾 Miguel M 
🎾 Giancarlo B

🎾 Douglas Vil
🎾Ivan B

🎾 Carlos Vasquez
🎾Lorena Puerta

🎾 Camilo ₿itcoin
🎾 Adriana Puig

🎾Lili Marquez 
🎾Juan Baquero 

🎾Sebastián Millán 
🎾Pareja 
 
TORNEO CERRADO

[11:27] **+507 6430-5628:**
> _@lapalaclubdepadel: Imagen_
Gracias La Pala y Dany por la iniciativa. Ya deje en recepción. Aún se necesita la ayuda 🫶.

[14:20] **@lapalaclubdepadel:** SÁBADO 22 DE AGOSTO
CATEGORIA: 5TA ALTA 
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 LuisFer
🎾 Carlos B
🎾 Néstor G
🎾
PARTIDO ABIERTO 🏅💯

[14:34] **+57 310 6843763:**
> _@lapalaclubdepadel: SÁBADO 22 DE AGOSTO
CATEGORIA: 5TA ALTA 
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 LuisFer
🎾 Carlos B
🎾 Néstor G
🎾
PARTIDO ABIERTO 🏅💯_
Yo

[14:37] **@lapalaclubdepadel:** SÁBADO 22 DE AGOSTO
CATEGORIA: 5TA ALTA 
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 LuisFer
🎾 Carlos B
🎾 Néstor G
🎾Sebastian F 
PARTIDO CERRADO 🏅💯
CANCHA #2

[14:41] **@lapalaclubdepadel:** SÁBADO 22 DE AGOSTO
CATEGORIA: 4TA  
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[16:11] **+31 6 84873308:** SÁBADO 22 DE AGOSTO
CATEGORIA: 4TA  
⌚ 6:00 pm a 8:00 pm (2 HORAS) 
📍La pala
💰50k
🎾 Cliff
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[16:50] **+57 301 6450021:** _Se eliminó este mensaje_

[17:21] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: MIXTO (6TA) DAMAS D 
⌚ 10:00 am a 12:00  (2 HORAS) 
📍La pala
💰60k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[17:25] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 5ta ALTA 
⌚ 10:00 am a 12:00  (2 HORAS) 
📍La pala
💰60k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[17:30] **+57 318 2702802:** DOMINGO 23 DE AGOSTO
CATEGORIA: 5ta ALTA 
⌚ 10:00 am a 12:00  (2 HORAS) 
📍La pala
💰60k
🎾 Sebastián O
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[17:38] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: DAMAS C
⌚ 10:00 am a 12:00 
📍La pala
💰60k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[20:08] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 23 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:30  A 1:30 PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic
 
 
🎾 
🎾   

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

🎾 
🎾
 
TORNEO ABIERTO

[20:09] **+54 9 3548 58-1308:** _Se eliminó este mensaje_

---

## 23 de agosto de 2026

[8:49] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 5TA ALTA
⌚ 04:00 Pm a 06:00 Pm
📍La pala
💰50k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[8:58] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 23 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11:30  A 1:30 PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic
 
 
🎾 
🎾   

🎾
🎾

🎾 
🎾 
️
🎾 
🎾 

🎾
🎾

🎾 
🎾
 
TORNEO ABIERTO
ANIMO
RECUERDA TENEMOS PROMO DE PARQUEADERO

[8:58] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 5ta ALTA 
⌚ 10:00 am a 12:00  (2 HORAS) 
📍La pala
💰60k
🎾 Sebastián O
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[10:37] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: MIXTO 5TA / DAMAS C
⌚ 04:00 Pm a 06:00 Pm
📍La pala
💰50k
🎾 
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[11:11] **@lapalaclubdepadel:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾

Quien más se anima!!! 💞🪂
FALTA 1 PALA!

[11:12] **@IvanBogota11:** Voy

[11:13] **@lapalaclubdepadel:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾Ivan B

TORNEO CERRADO
LOS ESPERAMOS

[11:22] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 5ta 
⌚ 06:00 pm a 08:00  (2 HORAS) 
📍La pala
💰50k
🎾 Douglas V
🎾  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[11:24] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 5ta 
⌚ 06:00 pm a 08:00  (2 HORAS) 
📍La pala
💰50k
🎾 Douglas V
🎾 Daniel Contreras  
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[13:10] **@lapalaclubdepadel:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾Ivan B
🎾
🎾
🎾
🎾

TORNEO ABIERTO!!! (4)
LOS ESPERAMOS

[13:15] **+57 317 6398789:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾Ivan B

🎾 Sebas
🎾
🎾
🎾

TORNEO ABIERTO!!! (3)
LOS ESPERAMOS

[13:23] **+57 318 2702802:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾Ivan B

🎾 Sebas
🎾 Sebastián Orjuela 
🎾
🎾

TORNEO ABIERTO!!! (3)
LOS ESPERAMOS

[13:24] **@luisda14:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾Ivan B

🎾 Sebas
🎾 Sebastián Orjuela 
🎾 Luisda
🎾

TORNEO ABIERTO!!! (3)
LOS ESPERAMOS

[13:25] **@lapalaclubdepadel:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾Ivan B

🎾 Sebas
🎾 Sebastián Orjuela 
🎾 Luisda
🎾

TORNEO ABIERTO!!!
FALTA 1 PALA! 
LOS ESPERAMOS

[13:50] **@lapalaclubdepadel:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Oscar
🎾 Patty
🎾Ivan B

🎾 Sebas
🎾 Luis Da
🎾 
🎾

TORNEO ABIERTO!!!
FALTA 2 PALA! 
LOS ESPERAMOS

[13:56] **+57 317 6398789:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Sebas
🎾 Camila P
🎾Ivan B

🎾 Luis Da
🎾 
🎾
🎾

Quien más se anima

[13:56] **+57 313 6519397:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Sebas
🎾 Camila P
🎾Ivan B

🎾 Luis Da
🎾 Lida
🎾 Carlos 
🎾

Quien más se anima

[13:58] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 
🎾
PARTIDO ABIERTO 🏅💯

[14:24] **+57 313 6519397:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Sebas
🎾 Camila P
🎾Ivan B

🎾 Luis Da
🎾 
🎾 
🎾

Quien más se anima

[14:25] **+57 315 6450599:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 David F
🎾
PARTIDO ABIERTO 🏅💯

[14:29] **+49 1520 3975820:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 David F
🎾 Christian K

[14:30] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 David F
🎾 Christian K
PARTIDO CERRADO
CANCHA1

[14:31] **+57 315 6450599:**
> _@lapalaclubdepadel: DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 David F
🎾 Christian K
PARTIDO CERRADO
CANCHA1_
Puede ser otra cancha?

[14:33] **@lapalaclubdepadel:** me queda la 1 disponible

[14:35] **@lapalaclubdepadel:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Sebas
🎾 Camila P
🎾Ivan B

🎾 Luis Da
🎾 Daniel Contreras 
🎾 Douglas V
🎾

Quien más se anima
1 pala mas!

[14:43] **@cafdmilo:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Sebas
🎾 Camila P
🎾Ivan B

🎾 Luis Da
🎾 Daniel Contreras 
🎾 Douglas V
🎾 Camilo F

🎾 Pablo Sanchez

Quien más se anima
1 pala mas!

[14:44] **@lapalaclubdepadel:** TORNEO Thanks God its Padel TGIP!!
Agosto 23!!
📈 *Categoría: 5-6 & C-D
⌚6:00 PM A 8:00PM
📍La Pala
💰50K

🎾 Adriana 
🎾 Juan A
🎾 Valentina M 
🎾 Yamil

🎾 Alfredo C
🎾 Caro C
🎾 Erika
🎾 Nico Mor

🎾 Carlos C
🎾 Sebas
🎾 Camila P
🎾Ivan B

🎾 Luis Da
🎾 Daniel Contreras 
🎾 Douglas V
🎾 Camilo F

TORNEO CERRADO
lista de espera:

🎾 Pablo Sanchez

[14:59] **+57 315 6450599:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 
🎾 Christian K
PARTIDO CERRADO
CANCHA1

[15:01] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 Christian K
🎾 
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[16:12] **@rvanegasa:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 Christian K
🎾 Rafa Vanegas
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[16:14] **@lapalaclubdepadel:** DOMINGO 23 DE AGOSTO
CATEGORIA: 4TA
⌚ 06:00 pm a 08:00 pm
📍La pala
💰50k
🎾 Fernando Jimenez
🎾 Ricardo L
🎾 Christian K
🎾 Rafa Vanegas
PARTIDO CERRADO
CANCHA 1

[17:07] __@lapalaclubdepadel añadió a @sebastiangomez00__

---

## 24 de agosto de 2026

[9:38] **@lapalaclubdepadel:** LUNES 24 DE AGOSTO
CATEGORIA: 5TA - DAMAS C
⌚ 02:00 pm a 04:00 pm
📍La pala
💰64k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[13:22] **@lapalaclubdepadel:** LUNES 24 DE AGOSTO
CATEGORIA: 5TA Alta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[14:15] **+57 301 6573017:**
> _@lapalaclubdepadel: LUNES 24 DE AGOSTO
CATEGORIA: 5TA Alta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!_
Hay disponibilidad 7:30?

[14:15] **@lapalaclubdepadel:**
> _+57 301 6573017: Hay disponibilidad 7:30?_
hola buenas tardes, disponibilidad de 09:00pm a 10:30pm por un valor de 200mil la hora y media

[15:02] **@lapalaclubdepadel:** LUNES 24 DE AGOSTO
CATEGORIA: 4TA 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[15:07] **+57 304 4715071:** LUNES 24 DE AGOSTO
CATEGORIA: 4TA 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Pablo Cuartas
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[15:17] **@lapalaclubdepadel:** LUNES 24 DE AGOSTO
CATEGORIA: 4TA 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 Juanca 
🎾 iregui 
🎾 Preciado 
🎾 Iván 
PARTIDO CERRADO
CANCHA #3!!!

[16:37] **@lapalaclubdepadel:** LUNES 24 DE AGOSTO
CATEGORIA: 5TA Alta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[17:03] **@AdminLaPala:** Hola a todos

Nos hacen falta dos jugadores de 4ta categoría para un torneo hoy de 6:00 p.m. a 9:00 p.m. ¿quién se anima?

[17:25] __@lapalaclubdepadel añadió a +57 301 8266240__

[17:44] __+57 301 8266240 se unieron mediante el enlace de invitación__

[19:20] **@lapalaclubdepadel:** Hola muy buenas noches a toda nuestra comunidad, les recordamos que mañana martes 25 de agosto a las 6:00 AM, tenemos escuela para adultos, categoría 6ta. Para quienes se quieran inscribir los estaremos esperando. Nos quedan 2 cupos.

---

## 25 de agosto de 2026

[8:30] __@lapalaclubdepadel añadió a +57 301 7851216__

[9:12] **@lapalaclubdepadel:** MARTES 25 DE AGOSTO
CATEGORIA: 5TA Alta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾  Douglas V
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[9:14] **@lapalaclubdepadel:** MARTES 25 DE AGOSTO
CATEGORIA: 4ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[14:14] **+57 317 4015496:** MARTES 25 DE AGOSTO
CATEGORIA: 5TA Alta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾  Douglas V
🎾 
🎾 Fernando J
🎾 Carolina M
PARTIDO ABIERTO
ANIMO!!!

[14:20] **@IvanBogota11:**
> _+57 317 4015496: MARTES 25 DE AGOSTO
CATEGORIA: 5TA Alta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾  Douglas V
🎾 
🎾 Fernando J
🎾 Carolina M
PARTIDO ABIERTO
ANIMO!!!_
Voy!

[14:21] **@lapalaclubdepadel:** MARTES 25 DE AGOSTO
CATEGORIA: 5TA Alta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾  Douglas V
🎾 Ivan B
🎾 Fernando J
🎾 Carolina M
PARTIDO CERRADO
CANCHA 3

[15:39] __@lapalaclubdepadel añadió a +57 318 7220024__

[16:06] **@AdminLaPala:** MARTES 25 DE AGOSTO
CATEGORIA: 4ta / Mixto C+ 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[16:10] **@AdminLaPala:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 
🎾
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[16:12] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[16:14] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[16:32] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[17:06] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 Cinthya Dussan

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[17:08] **+57 316 3358569:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 Cinthya Dussan

🎾 Santiago Ramírez 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[17:18] __@lapalaclubdepadel añadió a +57 314 3656895__

[18:18] **@AdminLaPala:** MIÉRCOLES 26 DE AGOSTO
CATEGORIA: Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Andrea
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡
 ÁNIMO

[18:32] **@msilvarubiano:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 Cinthya Dussan

🎾 Santiago Ramírez 
🎾 Fabio Ch
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[18:35] **@lapalaclubdepadel:** MARTES 25 DE AGOSTO
CATEGORIA: 4ta / Mixto C+ 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[18:55] **@juancafranco23:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 Cinthya Dussan

🎾 Santiago Ramírez 
🎾 Fabio Ch
🎾 Juan C Franco G
🎾 

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[20:46] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 Cinthya Dussan

🎾 Santiago Ramírez 
🎾 Fabio Ch
🎾 Juan C Franco G
🎾 

ANÓTENSE 🥳🥳
FALTA UNA PALA

[22:14] **@msilvarubiano:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 Cinthya Dussan

🎾 Santiago Ramírez 
🎾 Fabio Ch
🎾 Juan C Franco G
🎾  Martha S

ANÓTENSE 🥳🥳
FALTA UNA PALA

[22:16] **@AdminLaPala:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Juliana Velandia
🎾 Cinthya Dussan

🎾 Santiago Ramírez 
🎾 Fabio Ch
🎾 Juan C Franco G
🎾  Martha S

TORNEO CERRADO. LOS ESPERAMOS

[22:40] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino
Miércoles 26 de Agosto de 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Daniel Nariño 
🎾Sebastián Duarte
🎾 Douglas Vil
🎾 Cinthya Dussan

🎾 Santiago Ramírez 
🎾 Fabio Ch
🎾 Juan C Franco G
🎾  Martha S

TORNEO CERRADO. LOS ESPERAMOS

---

## 26 de agosto de 2026

[9:44] **@lapalaclubdepadel:** Miercoles 26 DE AGOSTO
CATEGORIA: 5ta / Mixto C+ 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[12:11] __+57 310 8224147 se unieron mediante el enlace de invitación__

[12:11] __+57 312 5883025 se unieron mediante el enlace de invitación__

[12:15] __@AdminLaPala añadió a +57 315 4683571__

[12:59] **@AdminLaPala:** MIÉRCOLES 26 DE AGOSTO
CATEGORIA: Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Andrea
🎾 
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡
 ÁNIMO 💯

[13:17] **@lapalaclubdepadel:** Miercoles 26 DE AGOSTO
CATEGORIA: 4ta 
⌚ 05:00 pm a 06:00 pm
📍La pala
💰32k
🎾 Gabo
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[13:22] **@AdminLaPala:** MIÉRCOLES 26 DE AGOSTO
CATEGORIA: Damas D
⌚ 5:00 pm a 06:00 pm 
📍La pala
💰32k
🎾 Andrea
🎾 Olinda
🎾 
🎾 
PARTIDO ABIERTO 💪🏼⚡
 ÁNIMO 💯

[14:14] **@lapalaclubdepadel:** Miercoles 26 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[14:17] **@lapalaclubdepadel:** Miercoles 26 DE AGOSTO
CATEGORIA: 4ta Mixta Damas B
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[14:32] **@lapalaclubdepadel:** Hola muy buenas tardes a todos. Contamos con disponibilidad de clases con el profe Juanjo. 🎾💪🏼

[14:33] **@lapalaclubdepadel:** [Imagen]

[18:58] **@lapalaclubdepadel:** Miercoles 26 DE AGOSTO
CATEGORIA: 5ta ALTA
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

---

## 27 de agosto de 2026

[12:21] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 6ta
⌚ 10:00 am a 12:00 pm
📍La pala
💰54k
🎾 Andres  
🎾 Jorge
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[16:16] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[16:27] **@lapalaclubdepadel:** [Imagen] 🏆 ¡Estos días vivimos el pádel a otro nivel!

Nuestra casa se prepara para recibir a los jugadores en el Major de Pádel Bogotá. 💥🎾

Gracias a toda nuestra comunidad por su comprensión y por acompañarnos en estos momentos que hacen crecer el pádel en Bogotá. ❤️

¡Nos vemos en la cancha! 🔥

[17:04] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 6ta
⌚ 10:00 am a 12:00 pm
📍La pala
💰54k
🎾 Andres  
🎾 Jorge
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[17:06] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 5ta 
⌚ 08:00 am a 10:00 pm
📍La pala
💰54k
🎾
🎾
🎾 
🎾
PARTIDO ABIERTO
ANIMO!!!

[21:16] __@lapalaclubdepadel añadió a +57 324 6151472__

---

## 28 de agosto de 2026

[8:42] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 6ta
⌚ 10:00 am a 12:00 pm
📍La pala
💰54k
🎾 Andres  
🎾 Jorge
🎾 
🎾
PARTIDO ABIERTO
FALTAN 2 PALAS
ANIMO!!!

[9:31] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 
🎾
🎾
🎾 

🎾 
🎾 
🎾 
🎾 

🎾
🎾
🎾
🎾

TORNEO ABIERTO. 
LOS ESPERAMOS

[10:53] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 6ta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾   
🎾 
🎾 
🎾

PARTIDO ABIERTO
ANIMO!!!

[10:54] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA:MIXTO C / 5ta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾   
🎾 
🎾 
🎾

PARTIDO ABIERTO
ANIMO!!!

[10:57] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾   
🎾 
🎾 
🎾

PARTIDO ABIERTO
ANIMO!!!

[11:40] **+57 310 7032367:** VIERNES 28 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾   Gabo Márquez 
🎾 
🎾 
🎾

PARTIDO ABIERTO
ANIMO!!!

[11:42] **@pabrodos:** VIERNES 28 DE AGOSTO
CATEGORIA:MIXTO C / 5ta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾   Pablo R
🎾 Manuel B
🎾 
🎾

PARTIDO ABIERTO
ANIMO!!!

[11:42] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA:MIXTO C / 5ta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾   Pablo R
🎾 Manuel B
🎾 
🎾

PARTIDO ABIERTO
FALTAN 2 PALAS ANIMO!!!

[12:26] **@pabrodos:**
> _+57 310 7032367: VIERNES 28 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾   Gabo Márquez 
🎾 
🎾 
🎾

PARTIDO ABIERTO
ANIMO!!!_
Hola porfa méteme a pablo y a Manuel acá en este partido mejor

[12:30] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 6ta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾  Camilo N 
🎾 
🎾 
🎾

PARTIDO ABIERTO
ANIMO!!!

[12:31] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾 Gabo Márquez 
🎾 Pablo 
🎾 Manuel 
🎾

PARTIDO ABIERTO
ANIMO!!!

[12:58] **@lapalaclubdepadel:** VIERNES 28 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 02:00 am a 04:00 pm
📍La pala
💰64k

🎾 Gabo Márquez 
🎾 Pablo 
🎾 Manuel 
🎾 Sebastian O

PARTIDO CERRADO 
CANCHA 4

---

## 29 de agosto de 2026

[7:44] **@nicko.cardenas:** Partido hoy de 5a? :)

[7:51] **@lapalaclubdepadel:** Muy buenos dias a nuestra comunidad.
Durante el dia de hoy y mañana Doningo se estará realizando el torneo de MAJOR, por lo cual no disponemos de cancha para reservas.
Dia LUNES disponible para que programen sus partidos

[10:44] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 06:00 am a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

---

## 30 de agosto de 2026

[8:39] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: MIXTO 5TA- DAMAS C
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[8:41] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 6ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[8:42] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: DAMAS D
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[8:52] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 6ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Sebastian Duarte
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[11:57] __@lapalaclubdepadel añadió a +57 321 3962007__

[13:26] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 6ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Sebastian Duarte
🎾 Juan Alfaro
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[13:50] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 6ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Sebastian Duarte
🎾 Juan Alfaro
🎾 Leandro Sanchez
🎾 David Sarmiento

PARTIDO CERRADO
CANCHA #3
LOS ESPERAMOS

[13:50] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: MIXTO 4TA- DAMAS C+
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[13:53] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: MIXTO 5TA
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[20:46] __@lapalaclubdepadel añadió a +57 315 6908371__

---

## 31 de agosto de 2026

[8:28] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: MIXTO 4TA- DAMAS C+
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[8:29] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: DAMAS D
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[8:29] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta alta
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[9:34] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Douglas V 
🎾 Andrés V 
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[9:47] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 am a 07:30 pm
📍La pala
💰62.5k

🎾 Eduardo
🎾 Daniel
🎾 
🎾 

PARTIDO ABIERTO
ANIMO!!!

[10:03] **+57 304 4715071:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Douglas V 
🎾 Andrés V 
🎾 Pablo C
🎾 

PARTIDO ABIERTO
ANIMO!!!

[10:14] **+57 321 4346037:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 am a 07:30 pm
📍La pala
💰62.5k

🎾 Eduardo
🎾 Daniel
🎾 HC
🎾 

PARTIDO ABIERTO
ANIMO!!!

[10:31] **@SergioRengifoC:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 am a 07:30 pm
📍La pala
💰62.5k

🎾 Eduardo
🎾 Daniel
🎾 HC
🎾 Sergio R.

PARTIDO ABIERTO
ANIMO!!!

[10:34] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta 
⌚ 06:00 am a 07:30 pm
📍La pala
💰62.5k

🎾 Eduardo
🎾 Daniel
🎾 HC
🎾 Sergio R.

PARTIDO CERRADO
ANIMO!!!

[10:50] **+54 9 3548 58-1308:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Douglas V 
🎾 Andrés V 
🎾 Pablo C
🎾 

PARTIDO ABIERTO
ANIMO!!!

[12:36] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[12:36] **@lapalaclubdepadel:** [Reenviado] [Imagen]

[12:36] **@lapalaclubdepadel:** [Reenviado] ¡La primera batalla ya quedó atrás y dejó la vara muy alta… pero esto apenas comienza! 🔥🎾

Tras el éxito y la emoción vivida en la primera parada, es momento de mirar hacia el próximo gran desafío: Distrito Pádel será el escenario de la segunda fecha del Major Pádel Bogotá by Chery. 🎾⚡

📍 Distrito Pádel
📅 Del 30 de septiembre al 4 de octubre
🏆 Más de $16,5 millones en premios
💵 Premiación 100 % en efectivo en todas las categorías

El circuito continúa. Nuevos partidos, nuevas historias y otra oportunidad para dejar tu nombre en la cancha.

Arma tu pareja y asegura tu lugar a través de SportSpace.

Cada sede es una batalla. El circuito define la leyenda.

#MajorPadelBogotá #DistritoPadel #SegundaParada #PadelBogotá #sportspace

[13:49] **+57 305 2849590:**
> _+54 9 3548 58-1308: LUNES 31 DE AGOSTO
CATEGORIA: 5ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Douglas V 
🎾 Andrés V 
🎾 Pablo C
🎾 

PARTIDO ABIERTO
ANIMO!!!_
carlos uribe

[13:52] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta 
⌚ 09:00 pm a 10:30 pm
📍La pala
💰50k

🎾 Douglas V 
🎾 Andrés V 
🎾 Pablo C
🎾 Carlos Uribe 

PARTIDO CERRADO

[14:02] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 
🎾
🎾
🎾 

🎾 
🎾 
🎾 
🎾 

🎾
🎾
🎾
🎾

TORNEO ABIERTO. 
LOS ESPERAMOS

[14:28] __@lapalaclubdepadel añadió a +57 317 3291091__

[14:28] **@lapalaclubdepadel:** [Mensaje de message_history_notice]

[14:31] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta - Damas C 
⌚ 06:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO

[15:48] **@juancafranco23:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Juan Franco
🎾
🎾
🎾 

🎾 
🎾 
🎾 
🎾 

🎾
🎾
🎾
🎾

TORNEO ABIERTO. 
LOS ESPERAMOS

[16:41] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta - Damas C 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO

[16:43] **+57 314 4364055:**
> _@lapalaclubdepadel: LUNES 31 DE AGOSTO
CATEGORIA: 5ta - Damas C 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO_
Este puede ser de 4ta?

[16:45] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta - Damas C 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 Juliana Prieto
🎾 
🎾 
🎾 

PARTIDO ABIERTO

[16:45] **@lapalaclubdepadel:** UNO DE 4TA A LAS 06:00PM DESEAS PARTICIPAR

[16:49] **+57 314 4364055:** no alcanzo a llegar

[16:50] **@lapalaclubdepadel:** entendido

[16:55] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 Daniel Morales
🎾 
🎾 
🎾 

PARTIDO ABIERTO

[16:56] **@TomasVilladaBarrios:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 Daniel Morales
🎾 Tomás
🎾 Santiago
🎾 

PARTIDO ABIERTO

[16:56] **@santi.catam:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 Daniel Morales
🎾 Tomás
🎾 Santiago
🎾 santiago c

PARTIDO ABIERTO

[16:59] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 4ta
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 Daniel Morales
🎾 Tomás
🎾 Santiago
🎾 santiago c

PARTIDO  CERRADO
CANCHA 5

[17:22] **@jvelandiavacca:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Juan Franco
🎾 Juliana V 
🎾
🎾 

🎾 
🎾 
🎾 
🎾 

🎾
🎾
🎾
🎾

TORNEO ABIERTO. 
LOS ESPERAMOS

[18:10] __@lapalaclubdepadel añadió a +57 315 3026615__

[18:13] **@lapalaclubdepadel:** LUNES 31 DE AGOSTO
CATEGORIA: 5ta - Damas C 
⌚ 07:30 pm a 09:00 pm
📍La pala
💰62.5k

🎾 Juliana Prieto
🎾 
🎾 
🎾 

PARTIDO CANCELADO

[19:05] __@lapalaclubdepadel añadió a +57 318 7292472__

---

## 1 de septiembre de 2026

[9:01] **@lapalaclubdepadel:** MARTES 01 DE SEPTIEMBRE
CATEGORIA: 5ta - Damas C 
⌚ 6:30 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO

[9:07] **@IvanBogota11:** _Se eliminó este mensaje_

[9:08] **@IvanBogota11:**
> _@lapalaclubdepadel: MARTES 01 DE SEPTIEMBRE
CATEGORIA: 5ta - Damas C 
⌚ 6:30 pm a 07:30 pm
📍La pala
💰62.5k

🎾 
🎾 
🎾 
🎾 

PARTIDO ABIERTO_
Voy con un amigo!

[9:19] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[9:29] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: MIXTO C+/5ta
9:00 pm a 10:30 pm 
📍La pala
💰50K
🎾Nancy
🎾LuisFer
🎾
🎾
PARTIDO ABIERTO

[9:33] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾
🎾
🎾
🎾
PARTIDO ABIERTO

[9:40] **@jvelandiavacca:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Juan Franco
🎾 Juliana V 
🎾 Juan Se 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾
🎾
🎾
🎾

TORNEO ABIERTO. 
LOS ESPERAMOS

[10:24] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA ALTA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 juan falla
🎾
🎾
PARTIDO ABIERTO

[12:07] **@nanjovas:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: MIXTO C+/5ta
9:00 pm a 10:30 pm 
📍La pala
💰50K
🎾Nancy
🎾LuisFer
🎾NEstor G
🎾Maria M
PARTIDO CERRADO🔒

[12:43] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Juan Franco
🎾 Juliana V 
🎾 Juan Se 
🎾 Karen 

🎾 Daniel Nariño
🎾 
🎾 
🎾 

🎾
🎾
🎾
🎾

TORNEO ABIERTO. 
LOS ESPERAMOS

[12:45] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Juan Franco
🎾 Juliana V 
🎾 Juan Se 
🎾 Karen 

🎾 Daniel Nariño
🎾 Sebastián Duarte
🎾 
🎾 

🎾
🎾
🎾
🎾

TORNEO ABIERTO. 
LOS ESPERAMOS

[13:00] **@SergioRengifoC:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA ALTA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 juan falla
🎾 Sergio R.
🎾
PARTIDO ABIERTO

[13:01] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA ALTA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 juan falla
🎾 Sergio R.
🎾
PARTIDO ABIERTO
FALTA UNA PALA! ÁNIMO!!

[13:02] **+57 315 7868953:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA ALTA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 juan falla
🎾 Sergio R.
🎾 Daniel
PARTIDO ABIERTO
FALTA UNA PALA! ÁNIMO!!

[13:03] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA ALTA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 juan falla
🎾 Sergio R.
🎾 Daniel
PARTIDO CERRADO
CANCHA #1

[14:43] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 juan falla
🎾 Alejo Cortés
🎾
PARTIDO ABIERTO

[15:05] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 juan falla
🎾 Alejo Cortés
🎾Daniel Contreras
PARTIDO CERRADO
CANCHA 1

[15:17] **@IvanBogota11:**
> _@lapalaclubdepadel: MARTES 01 DE SEPTIEMBRE
CATEGORIA: 5ta - Damas C 
⌚ 6:00 pm a 07:30 pm
📍La pala
💰62.5k

🎾 Iván B 
🎾 Amigo Iván 
🎾 
🎾 

PARTIDO ABIERTO_
Este?

[15:18] **@lapalaclubdepadel:**
> _@IvanBogota11: Este?_
no queda disponibilidad de cancha en esa franja, disponible de 09:00pm a 10:30pm por un valor de 200mil

[15:26] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 Daniel Contreras
🎾 Alejo Cortés
🎾
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[15:26] **+57 321 3697094:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[15:27] **@TomasVilladaBarrios:**
> _@lapalaclubdepadel: MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 Daniel Contreras
🎾 Alejo Cortés
🎾
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!_
Esto es 9 pm cierto?

[15:28] **@lapalaclubdepadel:**
> _@TomasVilladaBarrios: Esto es 9 pm cierto?_
es de 06:00pm a 07:30pm

[15:38] **@IvanBogota11:**
> _@lapalaclubdepadel: MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 Daniel Contreras
🎾 Alejo Cortés
🎾
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!_
yo podria pero no soy de esa categoria

[15:38] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 Daniel Contreras
🎾 Alejo Cortés
🎾Daniel Carrasco
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[16:00] **@lapalaclubdepadel:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
6:00 pm a 07:30 pm 
📍La pala
💰6.5K
🎾 luis felipe
🎾 Daniel Contreras
🎾 Sergio Rengifo 
🎾Daniel Carrasco
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[16:07] __@lapalaclubdepadel añadió a @munirjaller__

[16:54] **@AdminLaPala:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Juan Franco
🎾 Juliana V 
🎾 Juan Se 
🎾 Karen 

🎾 Daniel Nariño
🎾 Sebastián Duarte
🎾 
🎾 

2 PALAS MÁS!!!
TORNEO ABIERTO. 
LOS ESPERAMOS

[17:15] **+57 301 6573017:** MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
07:30 pm a 09:00 pm 
📍La pala
💰6.5K
🎾 Alejandro Cortez
🎾 Daniel B
🎾 David
🎾
PARTIDO ABIERTO
FALTAN 1 PALA
ANIMO!!!

[18:39] **@IvanBogota11:**
> _+57 301 6573017: MARTES 1 de SEPTIEMBRE
CATEGORÍA: 4TA
07:30 pm a 09:00 pm 
📍La pala
💰6.5K
🎾 Alejandro Cortez
🎾 Daniel B
🎾 David
🎾
PARTIDO ABIERTO
FALTAN 1 PALA
ANIMO!!!_
Voy

[18:39] **@IvanBogota11:** Pero no soy de 4

[20:28] **@lapalaclubdepadel:** Buenas noches a nuestra querida comunidad, 2 personas que se sumen al torneo de el dia de mañana categoria 6ta / 7ma
de 06:00am a 08:00am, QUIEN SE ANIMA!!!

[21:40] **@lapalaclubdepadel:** Americano 6ta/7ma Masculino-Femenino
Miércoles 02 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚6:00 a.m. a 8:00 a.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (americano/chocolate/capuchino).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Juan Franco
🎾 Juliana V 
🎾 Juan Se 
🎾 Karen 

🎾 Daniel Nariño
🎾 Sebastián Duarte
🎾 
🎾 
TORNEO CANCELADO

[21:43] **@lapalaclubdepadel:** MIERCOLES 2 de SEPTIEMBRE
CATEGORÍA: 6TA - 7MA
6:00 Am a 07:00 Am 
📍La pala
💰32K
🎾 Juan Camilo Franco
🎾 Juliana V
🎾 Juan S 
🎾
PARTIDO ABIERTO
FALTA 1 PALA
ANIMO!!!

[22:18] **@lapalaclubdepadel:** MIERCOLES 2 de SEPTIEMBRE
CATEGORÍA: 6TA - 7MA
6:00 Am a 07:00 Am 
📍La pala
💰32K
🎾 Juan Camilo Franco
🎾 Juliana V
🎾 Juan S 
🎾Julio
PARTIDO CERRADO

---

## 2 de septiembre de 2026

[7:07] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[7:30] **@lapalaclubdepadel:** MIERCOLES 2 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
9:00 pm a 10:30 pm 
📍La pala
💰50K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[8:10] **@AdminLaPala:** _Se eliminó este mensaje_

[9:05] **@AdminLaPala:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 
🎾 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[9:39] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 Sebastian Duarte
🎾 Daniela Riveros 
🎾 
🎾 
 
🎾 
🎾 
🎾 
🎾 
ANÓTENSE 🥳🥳

[9:46] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 Sebastian Duarte
🎾 Daniela Riveros 
🎾 Guiova
🎾 Paola N 
 
🎾 Milton P 
🎾 Diana Meza
🎾 
🎾 
ANÓTENSE 🥳🥳

[9:50] **+507 6430-5628:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 Sebastian Duarte
🎾 Daniela Riveros 
🎾 Guiova
🎾 Paola N 
 
🎾 Milton P 
🎾 Diana Meza
🎾 Nan S 
🎾 
ANÓTENSE 🥳🥳

[9:51] **+507 6430-5628:** Torneo social 5ta/6ta Masculino-Femenino
Sábado 05 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚11:30 a.m. a 1:30 p.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y rifas. 

🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic para consumir en práctica libre

🎾 Nan S
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 


TORNEO ABIERTO

[9:53] **@guiovaPadel:**
> _+507 6430-5628: Torneo social 5ta/6ta Masculino-Femenino
Sábado 05 DE SEPTIEMBRE DEL 2026
inscripción individual 
⌚11:30 a.m. a 1:30 p.m.
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y rifas. 

🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic para consumir en práctica libre

🎾 Nan S
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 


TORNEO ABIERTO_
Hola, este ya no va pareja fija ?

[10:01] **@juancafranco23:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 Sebastian Duarte
🎾 Daniela Riveros 
🎾 Guiova
🎾 Paola N 
 
🎾 Milton P 
🎾 Diana Meza
🎾 Nan S 
🎾 Juan Franco
ANÓTENSE 🥳🥳

[10:04] **@AdminLaPala:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 Sebastian Duarte
🎾 Daniela Riveros 
🎾 Guiova
🎾 Paola N 
 
🎾 Milton P 
🎾 Diana Meza
🎾 Nan S 
🎾 Juan Franco
TORNEO CERRADO. LOS ESPERAMOS!!!

[10:12] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾
 
🎾 
🎾  

🎾
🎾 

🎾 
🎾 
️
🎾  
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[10:16] **+57 317 5949935:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 
🎾  

🎾
🎾 

🎾 
🎾 
️
🎾  
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[10:17] **@sebastian_castellanos93:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾
🎾 

🎾 
🎾 
️
🎾  
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[10:35] **@juanp.b:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 
🎾 
️
🎾  
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[10:45] **@guiovaPadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 sebastian millan
🎾 guiova
️
🎾  
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[10:46] **+1 (352) 615-0721:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  
🎾 

🎾 
🎾

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[10:58] **+57 316 0411782:**
> _@AdminLaPala: Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 Sebastian Duarte
🎾 Daniela Riveros 
🎾 Guiova
🎾 Paola N 
 
🎾 Milton P 
🎾 Diana Meza
🎾 Nan S 
🎾 Juan Franco
TORNEO CERRADO. LOS ESPERAMOS!!!_
quedo en lista de espera si alguien se baja 🙋🏻‍♀️

[11:00] __@lapalaclubdepadel añadió a +57 313 3939575__

[11:30] **@lapalaclubdepadel:** MIERCOLES 2 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
9:00 pm a 10:30 pm 
📍La pala
💰50K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[11:32] **+507 6430-5628:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino Viernes 4 de septiembre 2026
inscripción individual 
⌚5:30 a 7:30 pm
📍 La Pala
💰75 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Mafe Triviño 
🎾 Santiago Ramírez 
🎾 Camilo N 
🎾 Daniel Salinas 

🎾 Erika Díaz 
🎾 Sandra F
🎾 Beatriz F
🎾 Maribelle E

🎾 Sebastian Duarte
🎾 Daniela Riveros 
🎾 Guiova
🎾 Paola N 
 
🎾 Milton P 
🎾 Diana Meza
🎾 Nan S 
🎾 Juan Franco

Lista de espera: 
🎾 Ana Puerta

TORNEO CERRADO. LOS ESPERAMOS!!!

[11:40] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Jorge Caro 
🎾 Andrés Vega 
🎾 
🎾
PARTIDO ABIERTO

[11:51] **@guiovaPadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 
🎾

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[12:20] __@lapalaclubdepadel añadió a +57 320 2813608__

[12:26] __@lapalaclubdepadel añadió a @sebsmillan__

[15:10] **@lapalaclubdepadel:** MIERCOLES 2 de SEPTIEMBRE
CATEGORÍA: 5TA - DAMAS C
9:00 pm a 10:30 pm 
📍La pala
💰50K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[15:22] **@AdminLaPala:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[15:48] **@lapalaclubdepadel:** MIERCOLES 2 de SEPTIEMBRE
ACADEMIA 7MA
06:00 pm a 07:30 pm 
📍La pala
💰85K
🎾Natalia C
🎾 
🎾 
🎾
PARTIDO ABIERTO

[22:10] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾
🎾

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[23:28] **+57 311 5011236:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

---

## 3 de septiembre de 2026

[5:52] **@IvanBogota11:**
> _+57 311 5011236: TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO_
Voy!

[6:03] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Ivan B
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[6:04] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Ivan B
🎾

🎾
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[6:50] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Ivan B
🎾

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 
🎾 
 
TORNEO ABIERTO

[6:55] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Ivan B
🎾

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 
🎾 
 
TORNEO ABIERTOTORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 
🎾

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO ABIERTO

[7:55] **@lapalaclubdepadel:** TORNEO ABIERTOTORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 
🎾

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO ABIERTO

[8:44] **@lapalaclubdepadel:** TORNEO ABIERTOTORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de AGOSTO 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 JuanSe Cas
🎾  Santi G

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO CERRADO

[8:47] **+57 315 5758858:** _Se eliminó este mensaje_

[8:56] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[8:56] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[8:57] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[9:18] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[9:18] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
MIXTO 5TA DAMAS C
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[9:19] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾Douglas V
🎾 Andrés V 
🎾 
🎾
PARTIDO ABIERTO

[11:53] **@AdminLaPala:** _Se eliminó este mensaje_

[11:53] **@AdminLaPala:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾Douglas V
🎾 Andrés V 
🎾 
🎾
2 PALAS MAS!! ÁNIMO
PARTIDO ABIERTO

[11:56] **+57 301 6573017:**
> _@lapalaclubdepadel: JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO_
JUEVES 3 DE SEPTIEMBRE
CATEGORIA 4TA 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾Daniel B
🎾 David A
🎾 
🎾
PARTIDO ABIERTO

[11:58] **+57 311 6418257:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 4TA 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾Daniel B
🎾 David A
🎾 Eduardo D
🎾
PARTIDO ABIERTO

[12:18] **+57 315 5758858:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[12:18] **+57 304 4715071:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Pablo Cuartas
🎾 
🎾 
🎾
PARTIDO ABIERTO

[14:10] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 4TA 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾Daniel B
🎾 David A
🎾 Eduardo D
🎾Yamid Casallas
PARTIDO CERRADO

[15:44] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA - Damas C
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Juliana Prieto
🎾 
🎾 
🎾
PARTIDO ABIERTO

[16:31] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Pablo Cuartas
🎾 Douglas V 
🎾 Andres V
🎾
PARTIDO ABIERTO

[16:47] **+57 305 7133797:**
> _@lapalaclubdepadel: JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Pablo Cuartas
🎾 Douglas V 
🎾 Andres V
🎾
PARTIDO ABIERTO_
Me apunto

[16:51] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 
🎾 Douglas V 
🎾 Andres V
🎾Daniel Contreras
PARTIDO ABIERTO

[16:53] **+57 313 3939575:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Jorge Caro 
🎾 Andrés Vega 
🎾 
🎾
PARTIDO ABIERTO

[17:01] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[17:03] **+57 304 4715071:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 
🎾 Douglas V 
🎾 Andres V
🎾Daniel Contreras
PARTIDO

[17:05] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Jorge Caro 
🎾 Andrés Vega 
🎾 
🎾
PARTIDO ABIERTO
QUIEN SE ANIMA???

[17:06] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 
🎾 Douglas V 
🎾 Andres V
🎾Daniel Contreras
PARTIDO ABIERTO

[17:20] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾Paula
🎾Sebastian  
🎾 
🎾
PARTIDO ABIERTO

[17:35] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[17:37] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA - Damas C
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Juliana Prieto
🎾 
🎾 
🎾
PARTIDO ABIERT

[18:01] **@lapalaclubdepadel:** BUENAS TARDES COMUNIDAD
1 CANCHA DISPONIBLE DE 07:30PM A 09:00PM  (2 HORAS DE PARQUEADERO POR 5MIL)
VAMOS!!!

[18:20] **@sanchezr.gustavo:**
> _@lapalaclubdepadel: JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾Paula
🎾Sebastian  
🎾 
🎾
PARTIDO ABIERTO_
Me apunto

[18:42] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾
🎾 
🎾 Gustavo S
🎾 Ivan Bogota
PARTIDO ABIERTO
FALTAN DOS PALAS
QUIEN SE ANIMA

[18:45] **@IvanBogota11:**
> _@lapalaclubdepadel: JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾
🎾 
🎾 Gustavo S
🎾 Ivan Bogota
PARTIDO ABIERTO
FALTAN DOS PALAS
QUIEN SE ANIMA_
Voy!

[18:49] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾
🎾 
🎾 Gustavo S
🎾 Ivan Bogota
PARTIDO ABIERTO
FALTAN DOS PALAS
QUIEN SE ANIMA

[18:55] **+507 6430-5628:**
> _@sanchezr.gustavo: Me apunto_
JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾Paula
🎾Sebastian  
🎾 Gustavo Sánchez 
🎾

FALTA 1 PALA!  
PARTIDO ABIERTO

[19:14] **@andres.guataqui:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Andres G
🎾 Douglas V 
🎾 Andres V
🎾Daniel Contreras
PARTIDO ABIERTO

[19:14] **@lapalaclubdepadel:** JUEVES 3 DE SEPTIEMBRE
CATEGORIA 5TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Andres G
🎾 Douglas V 
🎾 Andres V
🎾Daniel Contreras
PARTIDO CERRADO
CANCHA 5

[19:16] **@lapalaclubdepadel:**
> _+507 6430-5628: JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾Paula
🎾Sebastian  
🎾 Gustavo Sánchez 
🎾

FALTA 1 PALA!  
PARTIDO ABIERTO_
FALTA 1 PALA PARA CERRARLO

[19:22] **@lapalaclubdepadel:**
> _+507 6430-5628: JUEVES 3 DE SEPTIEMBRE
CATEGORIA 6TA 
07:30 pm a 09:30 pm 
📍La pala
💰62.5kK
🎾Paula
🎾Sebastian  
🎾 Gustavo Sánchez 
🎾

FALTA 1 PALA!  
PARTIDO ABIERTO_
cancelado

---

## 4 de septiembre de 2026

[9:16] **@lapalaclubdepadel:** VIERNES 4  DE SEPTIEMBRE
CATEGORIA 5TA 
07:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[9:18] **@lapalaclubdepadel:** VIERNES 4  DE SEPTIEMBRE
CATEGORIA: DAMAS C
07:30 pm a 09:00 pm 
📍La pala
💰62.5kK
🎾
🎾 
🎾 
🎾 
PARTIDO ABIERTO

[9:18] **+57 313 3939575:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Jorge Caro 
🎾 Andrés Vega 
🎾 
🎾
PARTIDO ABIERTO
QUIEN SE ANIMA???

[9:26] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 
🎾  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Henri 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO ABIERTO
FALTAN 2 PALAS. ÁNIMO!!!

[9:32] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾
🎾
 
🎾 
🎾  

🎾
🎾

🎾
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[9:39] **+57 321 4346037:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 
🎾  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO ABIERTO
FALTAN 2 PALAS. ÁNIMO!!!

[9:49] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 Ernesto 
🎾 Natalia  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO ABIERTO
FALTA 1 PALA. ÁNIMO!!!

[9:54] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 Ernesto 
🎾 Natalia  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Juan Diego Vila 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO CERRADO

[10:23] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 Ernesto 
🎾 Natalia  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Juan Diego Vila 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Rolo
🎾 Andrea

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO CERRADO

LISTA DE ESPERA
🎾
🎾

[11:01] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[11:04] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Jorge Caro 
🎾 Andrés Vega 
🎾 
🎾
PARTIDO ABIERTO
QUIEN SE ANIMA???

[11:11] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: MIXTO 6TA/DAMA D
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[12:37] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: MIXTO 6TA/DAMA D
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Andrea S 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[13:04] **+57 311 5011236:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 Ernesto 
🎾 Natalia  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Juan Diego Vila 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾
🎾

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO CERRADO

LISTA DE ESPERA
🎾
🎾

[13:06] **@juancafranco23:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 Ernesto 
🎾 Natalia  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Juan Diego Vila 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Franco
🎾

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO CERRADO

LISTA DE ESPERA
🎾
🎾

[13:08] **@lapalaclubdepadel:** TORNEO AMERICANO RELAMPAGO 5TA / 4TA
  4 DE SEPTIEMBRE 2026

📈 *Categoría: (5ta/ 4TA masculino) 
inscripción individual 
⌚7 :30 PM A 09:00PM
📍 La Pala
💰62k por persona incluye Organización, Bolas y Rifas 

🎾 
🎾
🎾  
🎾 
🎾
🎾 
🎾 
🎾
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
 
*TORNEO ABIEERTO CUPOS LIMITADOS (  12 CUPOS )
 Cupos Limitados. Animo los esperamos

[13:37] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: MIXTO 6TA/DAMA D
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Andrea S 
🎾Sebastian O
🎾Paula Gabriel 
🎾
PARTIDO ABIERTO

[13:37] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: MIXTO 6TA/DAMA D
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Andrea S 
🎾 Sebastian Orjuela
🎾 Paula Gabriel
🎾
PARTIDO ABIERTO

[13:39] **+57 311 5011236:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 Ernesto 
🎾 Natalia  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Juan Diego Vila 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Franco
🎾 Santiago G

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO CERRADO

LISTA DE ESPERA
🎾
🎾

[13:41] **+54 9 3548 58-1308:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 4ta
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Noelia
🎾 
🎾 
🎾
PARTIDO ABIERTO

[13:43] **@TomasVilladaBarrios:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 4ta
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Noelia
🎾Tomás 
🎾 
🎾
PARTIDO ABIERTO

[15:03] **@lapalaclubdepadel:** SABADO 5 DE SEPTIEMBRE 
CATEGORÍA: 5TA
7:00 am a 8:30 am
📍La pala
💰45K
🎾
🎾 
🎾 
🎾
PARTIDO ABIERTO

[15:05] **+54 9 3548 58-1308:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 4ta
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Noelia
🎾Tomás 
🎾 Bratt
🎾
PARTIDO ABIERTO

[15:34] **+57 321 3820233:** SABADO 5 DE SEPTIEMBRE 
CATEGORÍA: 5TA
7:00 am a 8:30 am
📍La pala
💰45K
🎾 Alejandro
🎾 Mateo 
🎾 
🎾
PARTIDO ABIERTO

[16:29] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
SABADO 05 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾 Nan S
🎾Maria Moreno
 
🎾 Ernesto 
🎾 Natalia  

🎾JuanP
🎾 Ivan B

🎾 Valeria 
🎾 Juan Diego Vila 

🎾  sebastian millan
🎾 guiova

🎾 Santiago C
🎾 Katerine R

🎾 Franco
🎾 Santiago G

🎾 Douglas V
🎾Luisda

🎾 Nicolás Bohórquez
🎾 Julio Bohórquez

🎾 Sebastián Orjuela 
🎾 Paula Gabriel
 
TORNEO CERRADO

LISTA DE ESPERA
🎾Diana G
🎾

[16:34] **+54 9 3548 58-1308:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾
🎾
 
🎾 
🎾  

🎾
🎾

🎾
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[16:40] **@maozar777:** SABADO 5 DE SEPTIEMBRE 
CATEGORÍA: 5TA
7:00 am a 8:30 am
📍La pala
💰45K
🎾 Alejandro
🎾 Mateo 
🎾 Mauricio 
🎾Pedro 
PARTIDO ABIERTO

[16:53] **@lapalaclubdepadel:**
> _@maozar777: SABADO 5 DE SEPTIEMBRE 
CATEGORÍA: 5TA
7:00 am a 8:30 am
📍La pala
💰45K
🎾 Alejandro
🎾 Mateo 
🎾 Mauricio 
🎾Pedro 
PARTIDO ABIERTO_
SABADO 5 DE SEPTIEMBRE 
CATEGORÍA: 5TA
7:00 am a 8:30 am
📍La pala
💰45K
🎾 Alejandro
🎾 Mateo 
🎾 Mauricio 
🎾Pedro 
PARTIDO CERRADO
LOS ESPERAMOS MAÑANA

[17:36] **+57 321 3697094:**
> _+54 9 3548 58-1308: VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 4ta
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Noelia
🎾Tomás 
🎾 Bratt
🎾
PARTIDO ABIERTO_
Voy

[17:36] **+57 321 3697094:** Aun esta?

[17:52] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Jorge Caro 
🎾 Andrés Vega 
🎾 
🎾
PARTIDO ABIERTO
QUIEN SE ANIMA???

[17:54] **@lapalaclubdepadel:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 4ta
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Luis Felipe R
🎾 
🎾 
🎾
PARTIDO ABIERTO

[18:14] **+57 313 3939575:** VIERNES  4 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA 
7:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾Jorge Caro 
🎾 Andrés Vega 
🎾 
🎾
PARTIDO CANCELADO

[18:51] **+57 312 8214097:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾 
🎾  

🎾
🎾

🎾
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[20:35] __@lapalaclubdepadel añadió a +52 1 442 322 6612__

[20:56] **@lapalaclubdepadel:** MAÑANA SABADO 5 de SEPTIEMBRE
CATEGORÍA: 4ta
02:00 pm a 04:00 pm 
📍La pala
💰50K
🎾 Ruben
🎾 
🎾 
🎾
PARTIDO ABIERTO

[21:00] **@lapalaclubdepadel:** MAÑANA SABADO 5 de SEPTIEMBRE
CATEGORÍA: 5ta
08:30 am a 10:00 am 
📍La pala
💰48K
🎾 Pechi Alvis
🎾 
🎾 
🎾
PARTIDO ABIERTO

[23:05] **+57 312 5456433:**
> _@lapalaclubdepadel: MAÑANA SABADO 5 de SEPTIEMBRE
CATEGORÍA: 5ta
08:30 am a 10:00 am 
📍La pala
💰48K
🎾 Pechi Alvis
🎾 
🎾 
🎾
PARTIDO ABIERTO_
Voy en esta

[23:07] **+507 6430-5628:** MAÑANA SABADO 5 de SEPTIEMBRE
CATEGORÍA: 5ta
08:30 am a 10:00 am 
📍La pala
💰48K
🎾 Pechi Alvis
🎾 Roberto Contreras
🎾 
🎾
PARTIDO ABIERTO

---

## 5 de septiembre de 2026

[7:12] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾 
🎾  

🎾
🎾

🎾
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[7:27] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾 Samael
🎾  

🎾
🎾

🎾
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[8:50] **@lapalaclubdepadel:** SABADO 5 de SEPTIEMBRE
CATEGORÍA: MIXTO 6ta/DAMAS D
05:00 pm a 7:00 pm 
📍La pala
💰50K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[10:18] **@JhonABastidas:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾 Samael
🎾  

🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[12:22] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 

🎾
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[13:21] **@lapalaclubdepadel:** SABADO 5 de SEPTIEMBRE
CATEGORÍA: MIXTO 6ta/DAMAS D
05:00 pm a 7:00 pm 
📍La pala
💰50K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[16:04] **@lapalaclubdepadel:** DOMIGO 6 de SEPTIEMBRE
CATEGORÍA: MIXTO 6ta/DAMAS D
05:00 pm a 7:00 pm 
📍La pala
💰50K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[17:34] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[17:35] **+52 1 442 322 6612:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[17:48] **@lug.contreras:**
> _+52 1 442 322 6612: TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO_
Me sumo a este

[17:48] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[17:55] **+507 6430-5628:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 
🎾 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[18:43] **@lapalaclubdepadel:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[19:30] __+57 301 6945358 se unieron mediante el enlace de invitación__

[20:05] **+1 (646) 385-3382:**
> _@lapalaclubdepadel: TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO_
Yo me subo a este

[20:09] **+54 9 3548 58-1308:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

[22:16] **@JhonABastidas:** TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 Felipe Díaz 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO

---

## 6 de septiembre de 2026

[5:00] __[Notificación del sistema]__

[7:59] **@lapalaclubdepadel:** BUENOS DIAS!
TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 Felipe Díaz 

🎾 
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO
ANIMO NO TE QUEDES SIN PARTICIPAR!!!

[8:16] **+57 310 6843763:** Yo ( sebastian F)

[8:18] **@lapalaclubdepadel:** BUENOS DIAS!
TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 Felipe Díaz 

🎾 Sebastian F
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO
ANIMO NO TE QUEDES SIN PARTICIPAR!!!

[8:33] **@jumanco:**
> _@lapalaclubdepadel: BUENOS DIAS!
TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 Felipe Díaz 

🎾 Sebastian F
🎾

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO
ANIMO NO TE QUEDES SIN PARTICIPAR!!!_
Voy Juan M

[8:33] **@lapalaclubdepadel:** BUENOS DIAS!
TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 Felipe Díaz 

🎾 Sebastian F
🎾 Juan M

🎾 
🎾 

🎾 
🎾 
 
TORNEO ABIERTO
ANIMO NO TE QUEDES SIN PARTICIPAR!!!

[8:43] **+54 9 3548 58-1308:** _Se eliminó este mensaje_

[8:43] **+54 9 3548 58-1308:** _Se eliminó este mensaje_

[8:43] **+54 9 3548 58-1308:** _Se eliminó este mensaje_

[10:22] **+57 311 5011236:** BUENOS DIAS!
TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 Felipe Díaz 

🎾 Sebastian F
🎾 Juan M

🎾 Rolo
🎾 Andrea

🎾 
🎾 
 
TORNEO ABIERTO
ANIMO NO TE QUEDES SIN PARTICIPAR!!!

[11:06] **@IvanBogota11:** Juego!

[11:07] **@lapalaclubdepadel:** DOMINGO 6 de SEPTIEMBRE
CATEGORÍA: DAMAS C+
03:00 pm a 4:30 pm 
📍La pala
💰45K
🎾 Lina 
🎾 Eliana 
🎾 Patricia
🎾
PARTIDO ABIERTO

[11:07] **+57 311 5011236:** BUENOS DIAS!
TORNEO PADEL SOCIAL PAREJA FIJA
DOMINGO 06 de SEPTIEMBRE 2026

📈 *Categoría: (5ta / 6ta masculino) /(Damas C / D +)
inscripción individual 
⌚11 :30 AM A 1:30PM
📍 La Pala
💰60k por persona incluye Organización, Bolas y Rifas 

🥇PRIMER LUGAR: Bono Playtimic
🥈SEGUNDO LUGAR: Bono Playtomic

🎾Carlos Vergara
🎾Pechy Alvis 
 
🎾Jhon Bastidas
🎾 Sebastián Caicedo

🎾Samael
🎾 Rubén

🎾Sebastián Orjuela 
🎾Mauricio Orjuela  

🎾 Lug Contreras
🎾 Nan S 

🎾 Laura Pachon 
🎾 David Sarmiento 

🎾 Douglas V
🎾 Felipe Díaz 

🎾 Sebastian F
🎾 Juan M

🎾
🎾

🎾 
🎾 
 
TORNEO ABIERTO
ANIMO NO TE QUEDES SIN PARTICIPAR!!!

[11:08] **+57 310 2924270:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[11:42] **@lapalaclubdepadel:** DOMINGO 6 de SEPTIEMBRE
CATEGORÍA: DAMAS C+
03:00 pm a 4:30 pm 
📍La pala
💰45K
🎾 Lina 
🎾 Eliana 
🎾 Patricia
🎾
PARTIDO ABIERTO
FALTA 1 PALA QUIEN SE ANIMA!

[13:59] __@lapalaclubdepadel añadió a @pedroccc__

[14:43] __@lapalaclubdepadel añadió a @GFelipeDiazB__

[17:39] __+57 311 4408260 se unieron mediante el enlace de invitación__

[17:41] **@lapalaclubdepadel:** [Mensaje de album]

[17:41] **@lapalaclubdepadel:** [Imagen]

[17:41] **@lapalaclubdepadel:** [Imagen]

[17:41] **@lapalaclubdepadel:** [Imagen]

[17:41] **@lapalaclubdepadel:** [Imagen]

[17:42] **@lapalaclubdepadel:** TORNEO PAEEL SOCIAL 06 DE SEPTIEMBRE.       💪🏼🔥🥳

---

## 7 de septiembre de 2026

[10:29] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino LUNES 7 de septiembre 2026
inscripción individual 
⌚7:30 a 9:00 pm
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Orjuela
🎾Paula Gabriel
🎾 Alejandro Gabriel
🎾 Diana Cortes

🎾 
🎾 
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

ANÓTENSE 🥳🥳

[10:30] **+57 314 4364055:** hola, se podría montar uno de cuarta a las 7:30 hoy?

[10:35] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 4ta
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Daniel Morales
🎾 
🎾 
🎾
PARTIDO ABIERTO

[10:35] **+54 9 3548 58-1308:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino LUNES 7 de septiembre 2026
inscripción individual 
⌚7:30 a 9:00 pm
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾 Sebastian Orjuela
🎾Paula Gabriel
🎾 Alejandro Gabriel
🎾 Diana Cortes

🎾 Juan Alfaro
🎾 Edgar Corradine
🎾 
🎾 

🎾 
🎾 
🎾 
🎾 

ANÓTENSE 🥳🥳

[10:38] **@TomasVilladaBarrios:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 4ta
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Daniel Morales
🎾 Tomás
🎾 
🎾
PARTIDO ABIERTO

[10:45] **+57 310 2924270:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 4ta
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Daniel Morales
🎾 Tomás
🎾 Patricia Arenas 
🎾
PARTIDO ABIERTO

[11:25] **+57 314 4364055:**
> _+57 310 2924270: LUNES  7 de SEPTIEMBRE
CATEGORÍA: 4ta
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Daniel Morales
🎾 Tomás
🎾 Patricia Arenas 
🎾
PARTIDO ABIERTO_
Daniel B para completarlo

[11:26] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 4ta
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Daniel Morales
🎾 Tomás
🎾 Patricia Arenas 
🎾 Daniel B
PARTIDO CERRADO
CANCHA 2

[11:34] __@lapalaclubdepadel añadió a +971 58 246 1287__

[11:37] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino LUNES 7 de septiembre 2026
inscripción individual 
⌚7:30 a 9:00 pm
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾Beatriz
🎾Paula Gabriel
🎾Juan Alfaro
🎾Edgar Corradine

🎾Sandra
🎾Valeria 
🎾Sebastian Duarte
🎾 

🎾  
🎾 
🎾 
🎾 

ANÓTENSE 🥳🥳

[12:53] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino LUNES 7 de septiembre 2026
inscripción individual 
⌚7:30 a 9:00 pm
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾Beatriz
🎾Paula Gabriel
🎾Juan Alfaro
🎾Edgar Corradine

🎾Sandra
🎾Valeria 
🎾Sebastian Duarte
🎾 Maribelle 

🎾  
🎾 
🎾 
🎾 

ANÓTENSE 🥳🥳

[13:12] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino LUNES 7 de septiembre 2026
inscripción individual 
⌚7:30 a 9:00 pm
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾Beatriz
🎾Paula Gabriel
🎾Juan Alfaro
🎾Edgar Corradine

🎾Sandra
🎾Valeria 
🎾Sebastian Duarte
🎾 Maribelle 

🎾  Erika Diaz
🎾 Daniel Salinas 
🎾 
🎾 

ANÓTENSE 🥳🥳

[13:45] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino LUNES 7 de septiembre 2026
inscripción individual 
⌚7:30 a 9:00 pm
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾Beatriz
🎾Paula Gabriel
🎾Juan Alfaro
🎾Edgar Corradine

🎾Sandra
🎾Valeria 
🎾Sebastian Duarte
🎾 Maribelle 

🎾  Erika Diaz
🎾 Daniel Salinas 
🎾 Olinda
🎾 

ANÓTENSE 🥳🥳

[14:02] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Jorge (profe)
🎾 
🎾  
🎾 
PARTIDO ABIERTO

[14:03] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juan Pablo (profe)
🎾 
🎾  
🎾 
PARTIDO ABIERTO

[14:05] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 Jorge (profe)
🎾 
🎾  
🎾 
PARTIDO ABIERTO

[14:07] **@jeanpenent:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juan Pablo (profe)
🎾 Jean Michel 
🎾  
🎾 
PARTIDO ABIERTO

[14:07] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Jorge (profe)
🎾 Mario
🎾  
🎾 
PARTIDO ABIERTO

[14:18] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 6ta
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾  
🎾 
PARTIDO ABIERTO

[14:19] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 5ta
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾  
🎾 
PARTIDO ABIERTO

[14:25] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Jorge (profe)
🎾 Mario
🎾 Diego P 
🎾 
PARTIDO ABIERTO

[14:32] **@lapalaclubdepadel:** Buenas tardes🥳🥳
Americano 6ta/7ma Masculino-Femenino LUNES 7 de septiembre 2026
inscripción individual 
⌚7:30 a 9:00 pm
📍 La Pala
💰65 k por persona.
incluye  organización, bolas y 1 hidratación por persona (agua/Gatorade/cerveza).


🥇PRIMER Y🥈SEGUNDO LUGAR, bonos por Playtomic.

🎾Beatriz
🎾Paula Gabriel
🎾Juan Alfaro
🎾Edgar Corradine

🎾Sandra
🎾Valeria 
🎾Sebastian Duarte
🎾 Maribelle 

🎾  Erika Diaz
🎾 Daniel Salinas 
🎾 Olinda
🎾 Diana Meza

TORNEO CERRADO 🥳🥳
LOS ESPERAMOS!

[14:58] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 5TA alta
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Douglas V
🎾 
🎾  
🎾 
PARTIDO ABIERTO

[14:58] **@IvanBogota11:** Voy

[14:59] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 5TA alta
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Douglas V
🎾 Ivan B 
🎾  
🎾 
PARTIDO ABIERTO

[16:37] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Jorge (profe)
🎾 Mario
🎾 Sebastian Rivera 
🎾 Camilo G
PARTIDO CERRADO

[16:42] **+57 301 6450021:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 5TA alta
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Douglas V
🎾 Ivan B 
🎾  Daniel o
🎾 
PARTIDO ABIERTO

[16:51] **@andres.guataqui:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 5TA alta
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Douglas V
🎾 Ivan B 
🎾  Daniel o
🎾 Andres G
PARTIDO ABIERTO

[16:55] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 5TA alta
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Douglas V
🎾 Ivan B 
🎾  Daniel o
🎾 Andres G
PARTIDO CERRADO

[16:57] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[17:05] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Jean Mich
🎾 Diego P 
🎾 
PARTIDO ABIERTO

[17:40] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
07:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾
🎾
PARTIDO ABIERTO

[17:42] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: MIXTO 6TA/7MA DAMAS D
06:30 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾
🎾
PARTIDO ABIERTO

[17:44] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 
🎾
🎾 
🎾 
PARTIDO ABIERTO

[19:46] **@AdminLaPala:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Jean Mich
🎾 Diego P 
🎾 
UNA PALA MÁS!!! ¿Quién se anima?

[20:20] **@lapalaclubdepadel:** LUNES  7 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Jean Mich
🎾 Diego P 
🎾 Fernando Bejarano
PARTIDO CERRADO

[21:34] __@lapalaclubdepadel añadió a +57 314 4456817__

---

## 8 de septiembre de 2026

[8:09] **@lapalaclubdepadel:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 
🎾 
🎾
PARTIDO CERRADO

[8:35] **@maozar777:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
07:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾 Pedro
🎾 Mauricio
🎾
🎾
PARTIDO ABIERTO

[8:44] **@lapalaclubdepadel:**
> _@maozar777: MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
07:30 pm a 9:00 pm 
📍La pala
💰62.5K
🎾 Pedro
🎾 Mauricio
🎾
🎾
PARTIDO ABIERTO_
muy buenos dias, en esa franja no tenemos disponibilidad.
si desean 06:00pm o 09:00pm

[8:49] **@maozar777:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Pedro
🎾 Mauricio
🎾
🎾
PARTIDO ABIERTO

[9:19] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[9:24] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 6TA 
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾
🎾
PARTIDO ABIERTO

[9:44] **@AdminLaPala:** [Imagen] 🎾 ¡LLEVA TU JUEGO AL SIGUIENTE NIVEL! 🔥

Este sábado 12 de septiembre tienes una cita en La Pala. Llega nuestra Clínica de Pádel, una oportunidad para aprender, mejorar tu juego y compartir cancha junto a nuestros nuevos profes. 💚


📅 Sábado 12 de septiembre
⏰ 10:00 a 11:30 a. m.
💰 Sin costo
🎾 Cupos limitados

¿Quieres ser parte? ¡Inscríbete ahora! 🙌

📲 Más información: 320 851 9204
¡Nos vemos en la cancha! 🔥🎾

[10:14] **+57 311 4674170:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 6TA 
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Carlos V
🎾 
🎾
🎾
PARTIDO ABIERTO

[10:35] **@guiovaPadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 6TA 
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Carlos V
🎾 Guiova
🎾
🎾
PARTIDO ABIERTO

[11:25] **@lapalaclubdepadel:** 🎾💖 ¡PÁDEL AND WINE C/D MES AMOR Y AMISTAD! 💕✨

Porque no hay mejor manera de celebrar el amor y la amistad que jugando pádel, compartiendo entre amigas y, por supuesto, ¡pasándola increíble! 🎾🥰

Las esperamos este martes 8 de septiembre para disfrutar juntas de un TORNEO PÁDEL AND WINE lleno de pádel, risas y mucho amor 💕🎾

👗✨ Dress code ¡vengan con sus mejores outfits alusivos al Amor y la Amistad! Queremos verlas DIVINAS y súper creativas 💘🌸

🎁 Y no olviden traer su detalle para la ancheta🧺💝

🎾 Pádel + amigas + competencia + risas + amor y amistad = El mejor plan💕✨

Las esperamos 
Hora: 7:30 a 9:00 pm

🎾Camila C 
🎾Alicia G
🎾Valentina A
🎾 Nan Sanz
🎾 Jeny 
🎾 Camila A 
🎾 Sofia M
🎾Elena
🎾Martha Silva
🎾
🎾
🎾

3 cupos

[11:46] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: ACADEMIA 5TA
06:00 pm a 7:30 pm 
📍La pala
💰85K
🎾 Sebastian F
🎾 Nancy S
🎾
🎾
2 CUPOS DISPONIBLES

[11:52] **@lapalaclubdepadel:** Buenos Dias🥳🥳
Americano 5ta/6ta Masculino-Femenino JUEVES 10 de septiembre 2026
inscripción individual 
⌚09:00AM -  11:00 AM
📍 La Pala
💰45 k por persona.
incluye  organización y bolas

🎾
🎾
🎾
🎾

🎾
🎾 
🎾
🎾 

🎾  
🎾  
🎾 
🎾 

TORNEO ABIERTO 🥳🥳
LOS ESPERAMOS!

[11:53] **@jumanco:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Pedro
🎾 Mauricio
🎾 Juan M
🎾
PARTIDO ABIERTO

[12:13] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 6TA 
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Carlos V
🎾 Guiova
🎾
🎾
PARTIDO ABIERTO
FALTAN 2 PALAS ANIMO!!!!

[12:14] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Pedro
🎾 Mauricio
🎾 Juan M
🎾
PARTIDO ABIERTO
FALTA 1 PALA ANIMO!!!

[12:15] **@lapalaclubdepadel:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 
🎾 
🎾
PARTIDO ABIERTO

[12:18] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[12:40] **+57 318 2702802:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Pedro
🎾 Mauricio
🎾 Juan M
🎾 Sebastián O 
PARTIDO ABIERTO
FALTA 1 PALA ANIMO!!!

[12:41] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: ACADEMIA 5TA
06:00 pm a 7:30 pm 
📍La pala
💰85K
🎾 Sebastian F
🎾 Nancy S
🎾Ernesto
🎾
1 CUPO DISPONIBLES

[12:42] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA alta
06:00 pm a 7:30 pm 
📍La pala
💰62.5K
🎾 Pedro
🎾 Mauricio
🎾 Juan M
🎾 Sebastián O 
PARTIDO CERRADO
CANCHA 1

[13:46] **@lapalaclubdepadel:** 🎾💖 ¡PÁDEL AND WINE C/D MES AMOR Y AMISTAD! 💕✨

Porque no hay mejor manera de celebrar el amor y la amistad que jugando pádel, compartiendo entre amigas y, por supuesto, ¡pasándola increíble! 🎾🥰

Las esperamos este martes 8 de septiembre para disfrutar juntas de un TORNEO PÁDEL AND WINE lleno de pádel, risas y mucho amor 💕🎾

👗✨ Dress code ¡vengan con sus mejores outfits alusivos al Amor y la Amistad! Queremos verlas DIVINAS y súper creativas 💘🌸

🎁 Y no olviden traer su detalle para la ancheta🧺💝

🎾 Pádel + amigas + competencia + risas + amor y amistad = El mejor plan💕✨

Las esperamos 
Hora: 7:30 a 9:00 pm

🎾Camila C 
🎾Alicia G
🎾Valentina A
🎾 Nan Sanz
🎾 Camila A 
🎾 Sofia M
🎾Elena
🎾Martha Silva
TORNEO CERRADO! LAS ESPERAMOSSSSS!!!

[13:49] **@lapalaclubdepadel:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
07:30 pm a 09:00 pm 
📍La pala
💰62.5K
🎾 Jorge (profe)
🎾 
🎾 
🎾
PARTIDO ABIERTO

[15:30] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: 5TA ALTA
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[15:31] **@lapalaclubdepadel:** MARTES 8 de SEPTIEMBRE
CATEGORÍA: MIXTO 6TA/DAMA D
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[16:17] **+57 304 4715071:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Pablo C
🎾 
🎾
PARTIDO ABIERTO

[17:54] **@AdminLaPala:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 4ta 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Noe
🎾 
🎾 
🎾
PARTIDO ABIERTO

[17:57] **@AdminLaPala:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Pablo C
🎾 
🎾
PARTIDO ABIERTO

[18:05] **@AdminLaPala:** Buenos Dias🥳🥳
Americano 5ta/6ta Masculino-Femenino JUEVES 10 de septiembre 2026
inscripción individual 
⌚09:00AM -  11:00 AM
📍 La Pala
💰45 k por persona.
incluye  organización y bolas

🎾Andrea S
🎾
🎾
🎾

🎾
🎾 
🎾
🎾 

🎾  
🎾  
🎾 
🎾 

TORNEO ABIERTO 🥳🥳
LOS ESPERAMOS!

[18:09] **@AdminLaPala:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 4ta 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Noe
🎾 Sebastián Orjuela
🎾 
🎾
PARTIDO ABIERTO

[18:42] **@ccmo_1030:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 4ta 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Noe
🎾 Sebastián Orjuela
🎾 Juan Pablo 
🎾 Cristian 
PARTIDO ABIERTO

[18:43] **@lapalaclubdepadel:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 4ta 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Noe
🎾 Sebastián Orjuela
🎾 Juan Pablo 
🎾 Cristian 
PARTIDO CERRADO

[18:50] **@jeanpenent:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Pablo C
🎾 Jean Michel 
🎾
PARTIDO ABIERTO

[20:30] **+57 304 4715071:** MARTES  8 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 
🎾 Jean Michel 
🎾
PARTIDO ABIERTO

---

## 9 de septiembre de 2026

[7:37] __[Notificación del sistema]__

[8:09] **@AdminLaPala:** [Imagen] ❤️💚 AMOR, AMISTAD Y MUCHO PÁDEL 🎾🔥

Este sábado 26 de septiembre la cancha se convierte en el punto de encuentro para disfrutar, competir, conocer gente y, por supuesto, ¡terminar la jornada con fiesta! 🥳

🏆 Torneo Americano de Amor y Amistad
📅 Sábado 26 de septiembre
⏰ 1:30 p. m. a 6:00 p. m. + fiesta
🎾 Categoría mixto C Puedes armar tu pareja así: 5ta – Damas C o 6ta – Damas C+
💰 $70.000 por persona
👫 10 parejas por cada color de manilla

Y aquí viene lo divertido 👀👇
🔴 Manilla roja: tienes pareja fija
🟢 Manilla verde: vienes sin pareja y ¡el torneo se encarga de la magia! 😉

Incluye bolas, organización, cóctel de bienvenida, DJ y fiesta. 🎶🍹

🔥 Los cupos son limitados. ¡Arma tu parche y asegura tu lugar!

📲 Más información: 320 851 9204

Nos vemos en la cancha para jugar, conectar y celebrar. 💚🎾

[9:03] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 5ta ALTA 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[9:35] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 6ta 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[9:37] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: DAMAS C+ 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾 
🎾 
🎾
PARTIDO ABIERTO

[10:29] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[10:30] **+57 315 6908371:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 6ta 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 Raúl Gallardo
🎾 Victoria González 
🎾 
🎾
PARTIDO ABIERTO

[10:31] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 6ta 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 Raúl Gallardo
🎾 Victoria González 
🎾 Giova
🎾
PARTIDO ABIERTO
faltan 1 pala
ANIMO!!!

[11:19] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 6ta 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 Raúl Gallardo
🎾 Victoria González 
🎾 Giova
🎾Jose M
PARTIDO CERRADO
ANIMO!!!

[11:20] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 6ta 
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 Raúl Gallardo
🎾 Victoria González 
🎾 Giova
🎾Jose M
PARTIDO CERRADO
CANCHA 3

[13:09] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 4ta ALTA - 3ra
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juan P (Profe)
🎾 
🎾 
🎾
PARTIDO ABIERTO

[13:10] **@lapalaclubdepadel:** _Se eliminó este mensaje_

[13:12] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Pablo C
🎾 
🎾
PARTIDO ABIERTO
FALTAN 2 PALAS 
QUIEN SE ANIMA

[13:15] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 4TA 
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Jorge (Profe)
🎾 
🎾 
🎾
PARTIDO ABIERTO

[13:26] **+57 321 4734039:** _Un admin., @lapalaclubdepadel, eliminó este mensaje._

[13:31] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Pablo C
🎾 Miguel 
🎾 Orlando
PARTIDO CERRADO

[14:53] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾
🎾 Miguel 
🎾 Orlando
PARTIDO ABIERTO

[15:16] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 6ta  
06:00 pm a 07:30 pm 
📍La pala
💰62.5K
🎾 
🎾
🎾 
🎾
PARTIDO ABIERTO
Si quieres jugar, y te quedaste por fuera, esta es tu oportunidad.

[15:19] **@lapalaclubdepadel:** MIERCOLES  9 de SEPTIEMBRE
CATEGORÍA: 3ra / 4ta ALTA
09:00 pm a 10:30 pm 
📍La pala
💰50K
🎾 Juanpa (profe)
🎾 Pablo C
🎾 Miguel 
🎾 Orlando
PARTIDO CERRADO

[16:01] __@lapalaclubdepadel añadió a +57 315 3356897__
