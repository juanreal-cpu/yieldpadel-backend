# Exportación de chat de WhatsApp: PadelTown Nuestro Bogotá 🎾
Fecha de exportación: 9 de septiembre de 2026 a las 16:15

---

## 16 de julio de 2026

[16:57] __@StivenAJDesign creó el grupo__

---

## 2 de septiembre de 2026

[13:43] __[Notificación del sistema]__

[13:43] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[14:10] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[14:17] **Benoît:**
> _@PadelTownNB: 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones._
Roberto  y Benoît

[14:17] **+57 305 8142422:**
> _@PadelTownNB: 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones._
Jarid y Frangel

[14:34] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[14:41] **+57 321 3141622:** Juan Pablo Castellanos y Felipe Castellanos

[14:43] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[14:44] **+52 1 998 428 8398:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 2/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Carolina
🎾 Emily
🎾 
🎾 

2 palas más!!, ¿quién se anima? 🔥🎾☝🏻

[14:57] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Busca Partner
6. 🎾
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[15:23] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 2/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Carolina
🎾 Emily
🎾 Samuel
🎾 

1 pala más!!, ¿quién se anima? 🔥🎾☝🏻

[15:23] **+57 313 2294892:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 2/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Carolina
🎾 Emily
🎾 Samuel
🎾 

1 pala más!!, ¿quién se anima? 🔥🎾☝🏻_
Voy

[15:24] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 2/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Carolina
🎾 Emily
🎾 Samuel
🎾 Andrés

Partido cerrado. ¡Los esperamos!🔥🎾☝🏻

[15:26] **+57 317 4404697:**
> _@PadelTownNB: 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Busca Partner
6. 🎾
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones._
🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Busca Partner
6. 🎾 gerardo vargas / parnert
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[15:33] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Busca Partner
6. 🎾 gerardo vargas / parnert
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[15:34] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Busca Partner
6. 🎾 gerardo vargas / parnert
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[15:48] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 2/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Carolina
🎾 Emily
🎾 Andrés
🎾 

1 pala mas. ¡Los esperamos!🔥🎾☝🏻

[15:49] **@esteban_lizcano_:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 2/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Carolina
🎾 Emily
🎾 Andrés
🎾 Esteban 

1 pala mas. ¡Los esperamos!🔥🎾☝🏻

[15:51] **@PadelTownNB:**
> _@esteban_lizcano_: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 2/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Carolina
🎾 Emily
🎾 Andrés
🎾 Esteban 

1 pala mas. ¡Los esperamos!🔥🎾☝🏻_
Partido cerrado,Traigan su mejor actitud competitiva🎾🌟

[15:54] __@MarcoMurillo07 se unieron mediante el enlace de invitación__

[16:00] __+57 313 2221416 se unieron mediante el enlace de invitación__

[17:41] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Busca Partner
6. 🎾 gerardo vargas / parnert
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[21:15] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / parnert
7. 🎾
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[21:16] **+57 313 2640810:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / parnert
7. 🎾 Los Pablos
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[21:19] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / Busca partner
7. 🎾 Los Pablos
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[21:20] **@PadelTownNB:** 1 persona mas y cerramos☝🏻🎾

[22:09] **+57 301 6402834:**
> _@PadelTownNB: 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / Busca partner
7. 🎾 Los Pablos
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones._
Si hay cupo, acá hay una pareja fija.

---

## 3 de septiembre de 2026

[7:39] **@PadelTownNB:** ¡El torneo de hoy está encendido! 🔥🎾 Queda solo un cupo disponible para completar las 8 parejas que lucharán por la gloria, las Gift Cards y el codiciado Brazalete oficial de Campeón 🏆

¿Listo para medir nivel, disfrutar de pizza gratis 🍕 y defender la cancha?

[7:39] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / Busca partner
7. 🎾 Los Pablos
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[8:39] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  Hoy 3/09/2026
🕘 10:00AM - 11:00AM
📌 Cancha 1
🏷️ Categoría: 6TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 
🎾 
🎾 

3 pala mas. ¡Los esperamos!🔥🎾☝🏻

[9:16] **+57 317 4404697:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / carlos
7. 🎾 Los Pablos
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[9:18] **@PadelTownNB:** Cerramos Torneo,mucha suerte a todos los participantes🎾🔥

[10:30] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 
2. 🎾 
3. 🎾 
4. 🎾 
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[10:34] **@nicolas_bernalm:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[10:36] **@PadelTownNB:**
> _@nicolas_bernalm: 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones._
5 parejas mas,¿quien se anima? ☝🏻🔥

[10:48] **@lore_farfan:**
> _@PadelTownNB: 5 parejas mas,¿quien se anima? ☝🏻🔥_
Samu yo con @~Hernán Dario Triviño

[10:51] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Lore-Hernan Dario Triviño
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[12:13] __+57 311 8775719 se unieron mediante el enlace de invitación__

[12:42] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Lore-Hernan Dario Triviño
5. 🎾 Johan - Enrique
6. 🎾 Noel - Duvan
7. 🎾 
8. 🎾
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[12:45] **@PadelTownNB:**
> _@PadelTownNB: 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Lore-Hernan Dario Triviño
5. 🎾 Johan - Enrique
6. 🎾 Noel - Duvan
7. 🎾 
8. 🎾
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones._
Dos parejas mas y cerramos☝🏻🔥

[16:01] **+57 313 2640810:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / carlos
7. 🎾 Juan Pa / Busca Partner 👀
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[16:02] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / carlos
7. 🎾 Juan Pa / Busca Partner 👀
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[16:13] __[Notificación del sistema]__

[17:01] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 gerardo vargas / carlos
7. 🎾 Juan Pa / Reservado 👀
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.
🔒TORNEO CERRADO ¡LOS ESPERAMOS! 🔥

Aplican términos y condiciones.

[17:16] **@PadelTownNB:** 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 Gerardo Vargas / Jose
7. 🎾 Juan Pa / Stefani
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.
🔒TORNEO CERRADO ¡LOS ESPERAMOS! 🔥

Aplican términos y condiciones.

[18:05] __[Notificación del sistema]__

[18:10] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Lore-Hernan Dario Triviño
5. 🎾 Andrés/Abraham
6. 🎾 Noel/Duván
7. 🎾 Jesús/León
8. 🎾Johan / Enrique

Lista de espera
🎾Ismael / busca partner
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[18:54] **@PadelTownNB:**
> _@PadelTownNB: 🏆🍕 TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PIZZA 🍕😎

📅 03/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🍕 ADEMÁS, EL TORNEO INCLUYE PIZZA PARA LOS PARTICIPANTES

💰Inscripción: $68.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pizza 🍕

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Roberto/Benoit
2. 🎾 Jarid/Frangel
3. 🎾 Juan Pablo C/Felipe C
4. 🎾 Juan Osorio/Edwin M
5. 🎾 Andrés Perdomo/Mauricio Cardenas
6. 🎾 Gerardo Vargas / Jose
7. 🎾 Juan Pa / Stefani
8. 🎾Juan Camilo osorio/Fabian mojica

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.
🔒TORNEO CERRADO ¡LOS ESPERAMOS! 🔥

Aplican términos y condiciones._
Buenas noches  a todos Familia PadelTown, Les recordamos su puntualidad para la iniciacion de la mejor forma en este grandioso torneo.

[21:26] **@PadelTownNB:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

Aplican términos y condiciones del beneficio del brazalete.

---

## 4 de septiembre de 2026

[7:36] **@PadelTownNB:** ¡El torneo no se detiene! 🏆

El torneo en Padel Town continúa mañana con las mejores emociones en la cancha. No te quedes fuera de esta jornada llena de puntos intensos, gran ambiente y puro pádel.

[7:37] **@PadelTownNB:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena 🍃/ Lu 🍃
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾
13. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

*Aplican términos y condiciones del beneficio del brazalete

[8:07] **@PadelTownNB:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena 🍃/ Lu 🍃
2. 🎾Jeny / Busca Partner
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾
13. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

*Aplican términos y condiciones del beneficio del brazalete

[8:25] **@PadelTownNB:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

*Aplican términos y condiciones del beneficio del brazalete

[8:35] **@PadelTownNB:** [Imagen] ¡Felicitaciones a los tres ganadores del Torneo 5ta — Parejas Fijas! que compitieron el dia de ayer ¡Mucha fuerza y a seguir con toda!🏆🎾

[9:30] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Hernan Dario Triviño-Busca Partner
5. 🎾 Andrés/Abraham
6. 🎾 Noel/Duván
7. 🎾 Jesús/León
8. 🎾Johan / Enrique

Lista de espera
🎾Ismael / busca partner
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[10:54] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Hernan Dario Triviño-Busca Partner
5. 🎾 Andrés/Abraham
6. 🎾 Noel/Duván
7. 🎾 Jesús/León
8. 🎾Johan / Enrique

Lista de espera
🎾Ismael / busca partner
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:22] **+57 313 2640810:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾Camila
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

*Aplican términos y condiciones del beneficio del brazalete

[11:42] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:00 PM A 11:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Andres Núñez-Ismael
5. 🎾 Andrés/Abraham
6. 🎾 Noel/Duván
7. 🎾 Jesús/León
8. 🎾Johan / Enrique

Lista de espera
🎾Ismael / busca partner
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:43] **@PadelTownNB:** _Se eliminó este mensaje_

[12:35] **@PadelTownNB:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾Camila
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

*Aplican términos y condiciones del beneficio del brazalete

[12:47] __+57 313 8789934 se unieron mediante el enlace de invitación__

[14:44] __[Notificación del sistema]__

[15:21] __@carl_oscer se unieron mediante el enlace de invitación__

[17:33] __[Notificación del sistema]__

[18:04] **@PadelTownNB:** 🏆🥖 TORNEO 6TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON PANDEBONO 🥖😎

📅 04/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 1 hora de cancha gratis — hora valle

🥉 3.º PUESTO
🎁 Obsequio PadelTown

🥖 ADEMÁS, EL TORNEO INCLUYE PANDEBONBO PARA LOS PARTICIPANTES

💰Inscripción: $60.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Pandebono

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Yesid-Abril
2. 🎾 Juan Diego-Lizcano
3. 🎾 Esteban-Bernal
4. 🎾 Andres Núñez-Ismael
5. 🎾 Andrés/Abraham
6. 🎾 Noel/Duván
7. 🎾 Jesús/León
8. 🎾Johan / Enrique

TORNEO CERRADO ¡LOS ESPERAMOS! 🔥
👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[18:23] **@teomunoz06:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾Camila
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

Aplican términos y condiciones del beneficio del brazalete

[20:13] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅  MAÑANA: 05/09/2026
🕘 10:30AM - 12:00PM
📌 Cancha 1
🏷️ Categoría: 6TA
💰 Precio por jugador: 37.500 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Samu M
🎾 
🎾 
🎾  

3 palas más. ¿Quién se anima?🔥🎾☝🏻

[21:00] **+57 320 8884585:**
> _@teomunoz06: 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾Camila
5. 🎾
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

Aplican términos y condiciones del beneficio del brazalete_
Yo 🙌

[21:10] **@PadelTownNB:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾Camila
5. 🎾 Shaki
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

Aplican términos y condiciones del beneficio del brazalete

---

## 5 de septiembre de 2026

[7:33] **@PadelTownNB:** 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾Camila
5. 🎾 Shaki
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

Aplican términos y condiciones del beneficio del brazalete

[7:34] **@PadelTownNB:** 🔥 ¡ATENCIÓN JUGADORAS DE PÁDEL! 🔥

¿Listas para demostrar de qué están hechas en la cancha? 🎾👑 El Torneo Femenino 6ta C-D en PadelTown Nuestro Bogotá ya está listo

[10:12] **@PadelTownNB:** ☀️🧡 ¡Buenos días, familia Padel Town!🧡🌞

¡Llegó el sábado! 🙌 Hoy es perfecto para compartir, jugar y disfrutar un buen rato. 🎾⚽

¡Los esperamos para vivir un gran día juntos! 🔥

[10:12] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 4:00PM - 5:00PM
📌 Cancha 1
🏷️ Categoría: 6ta
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mathew
🎾 
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[10:13] **@teomunoz06:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 4:00PM - 5:00PM
📌 Cancha 1
🏷️ Categoría: 6ta
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mathew
🎾 
🎾 
🎾

Partido abierto, ¿quiénes se animan?_
Voy

[10:15] **@PadelTownNB:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 4:00PM - 5:00PM
📌 Cancha 1
🏷️ Categoría: 6ta
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mathew
🎾 
🎾 
🎾

Partido abierto, ¿quiénes se animan?_
3 palas mas,quien se anima☝🏻🔥

[13:29] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 4:00PM - 5:00PM
📌 Cancha 1
🏷️ Categoría: 6ta
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mathew
🎾 
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[14:40] **@castro_estefania:**
> _@PadelTownNB: 👑🎾 TORNEO FEMENINO 6TA C-D 🎾👑
MODALIDAD AMERICANO INDIVIDUAL SUBE Y BAJA

🔥 12 JUGADORAS - UNA CAMPEONA

📅 SÁBADO 5 DE SEPTIEMBRE
🕐 6:00 pm a 8:00 pm 
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $60.000 por persona.

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA PARA TODAS LAS PARTICIPANTES

💰Inscripción: $60.000 por jugadora
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada 🥟

🏆 PREMIOS

🥇 CAMPEONA DE 6TA C-D
👑 Brazalete oficial de Campeona
🎾 Beneficio de cancha mientras mantenga el título
💳 Gift Card PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎁 Obsequio Pádel Town 

🥉 3.º PUESTO
🎁 Inscripción gratuita al próximo torneo

🎾 SOLO 12 CUPOS

1. 🎾Lorena
2. 🎾Lu
3. 🎾Jeny
4. 🎾Camila
5. 🎾 Shaki
6. 🎾
7. 🎾
8. 🎾
9. 🎾
10. 🎾
11. 🎾
12. 🎾

👑 LLEGA SOLA. COMPITE. SUMA. CONVIÉRTETE EN LA CAMPEONA.

📲 Inscríbete y asegura tu cupo.

Aplican términos y condiciones del beneficio del brazalete_
Buenas tardes, el torneo se va a hacer?

[14:42] **@PadelTownNB:**
> _@castro_estefania: Buenas tardes, el torneo se va a hacer?_
Buenas tardes, por cantidad de chicas el torneo femenino de hoy quedaria aplazado.

[16:01] **@PadelTownNB:** 🎾🧡 CHICAS, QUEREMOS DISCULPARNOS

Lamentamos que el torneo programado para hoy no se haya podido realizar. Sabemos que tenían todas las ganas de jugar, así que… ¡no queremos dejarlas sin pádel! 🎾🔥

Por eso tendremos:

🎾 PARTIDO ABIERTO FEMENINO 6TA C-D
🕕 6:00 pm - 7:00 pm
💰 $20.000 por jugadora
Cancha:3

1. 🎾 Lorena
2. 🎾 Lu
3. 🎾
4. 🎾 

🧡 Las chicas que querían jugar hoy están súper invitadas.

[16:28] __+57 350 4244910 se unieron mediante el enlace de invitación__

[16:28] **@PadelTownNB:** 🎾🧡 CHICAS, QUEREMOS DISCULPARNOS

Lamentamos que el torneo programado para hoy no se haya podido realizar. Sabemos que tenían todas las ganas de jugar, así que… ¡no queremos dejarlas sin pádel! 🎾🔥

Por eso tendremos:

🎾 PARTIDO ABIERTO FEMENINO 6TA/MIXTO C-D
🕕 6:00 pm - 7:00 pm
💰 $20.000 por jugador(a)

Cancha: 3

1. 🎾 Lorena
2. 🎾 Lu
3. 🎾 Matthew
4. 🎾 

🧡 Las chic@s que querían jugar hoy están súper invitad@s.

[17:07] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 6:00PM - 7:00PM
📌 Cancha 1
🏷️ Categoría: 6ta
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mathew
🎾 Lu
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[17:11] __+57 315 6080339 se unieron mediante el enlace de invitación__

[18:00] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 1
🏷️ Categoría: 6TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan M
🎾 
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[18:37] **+57 310 3265396:** alguien 5?

[18:39] **@DJ7GA:**
> _+57 310 3265396: alguien 5?_
Ya?

[18:41] **+57 310 3265396:** a la hora que se pueda somos dos

[18:42] **@PadelTownNB:**
> _+57 310 3265396: a la hora que se pueda somos dos_
¡Buenas noches, José! ¿A qué hora deseas jugar?

[18:55] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 1
🏷️ Categoría: 6TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan M
🎾 Lu
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[18:57] **+57 310 3265396:**
> _@PadelTownNB: ¡Buenas noches, José! ¿A qué hora deseas jugar?_
9-10

[18:58] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 2
🏷️ Categoría: 5TA-4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 José L
🎾 José S
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[19:23] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 2
🏷️ Categoría: 5TA-4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 José L
🎾 José S
🎾 Juan F
🎾

Partido abierto, ¿quiénes se animan? ¡Una pala más! 🔥

[19:35] **@esteban_lizcano_:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 2
🏷️ Categoría: 5TA-4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 José L
🎾 José S
🎾 Juan F
🎾 Esteban L

Partido abierto, ¿quiénes se animan? ¡Una pala más! 🔥

[19:40] **@PadelTownNB:** 🌟🎾 PARTIDO CERRADO 🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 2
🏷️ Categoría: 5TA-4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 José L
🎾 José S
🎾 Juan F
🎾 Esteban L

Partido cerrado. ¡Los esperamos! 🔥

[19:41] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 3
🏷️ Categoría: 5TA-4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel C
🎾 
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[19:44] **+57 310 2627441:**
> _@PadelTownNB: 🌟🎾 PARTIDO CERRADO 🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 2
🏷️ Categoría: 5TA-4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 José L
🎾 José S
🎾 Juan F
🎾 Esteban L

Partido cerrado. ¡Los esperamos! 🔥_
Pueden a las 8:30

[19:45] **+57 310 2627441:** ?

[19:47] **@PadelTownNB:**
> _+57 310 2627441: Pueden a las 8:30_
Juan F, no puede a las 8:30 pm. ¿Los otros chicos qué dicen?

[19:52] **@PadelTownNB:** 🌟🎾 PARTIDO CERRADO 🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 05/09/2026
🕘 8:30PM - 9:30PM
📌 Cancha 2
🏷️ Categoría: 5TA-4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 José L
🎾 José S
🎾 David G
🎾 Esteban L

Partido cerrado. ¡Los esperamos! 🔥

[21:16] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

---

## 6 de septiembre de 2026

[7:46] **@PadelTownNB:** 🏆 Tu momento de jugar es hoy en Padel Town

Canchas top, excelente ambiente y el partido perfecto esperándote. Elige la hora que mejor se adapte a tu agenda y asegura tu cancha hoy mismo.

[8:42] __+57 316 8342986 se unieron mediante el enlace de invitación__

[8:52] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 06/09/2026
🕘 10:00AM - 11:00AM
📌 Cancha 2
🏷️ Categoría: 5TA-
💰 Precio por jugador: 25.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Samuel
🎾 
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[10:15] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[10:30] **+57 320 4067603:** Buenos dias juan osorio

[10:32] **+57 320 4067603:** Edwin mendez

[10:32] **+57 320 4067603:** Andres perdomo

[10:32] **+57 320 4067603:** Porfavor

[10:41] **@PadelTownNB:** esa es la actitud

[10:44] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Juan Osorio
2. 🎾Edwin Mendez
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾
6. 🎾
7. 🎾
8. 🎾

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[11:53] **+57 316 8070239:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Juan Osorio
2. 🎾Edwin Mendez
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾
8. 🎾

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[11:58] **@PadelTownNB:** ¿Quien mas se anima a participar?☝🏻🔥

[12:12] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Juan Osorio
2. 🎾Edwin Mendez
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[12:31] **+57 318 7686502:** Yo

[12:31] **+57 318 7686502:** en 6

[12:32] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Juan Osorio
2. 🎾Edwin Mendez
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[12:32] **@PadelTownNB:** Asi cerramos 6ta🔥😁

[12:33] **@PadelTownNB:** ¿Quien de 5ta categoria se anima?☝🏻🔥

[14:27] **+57 320 4067603:**
> _@PadelTownNB: ¿Quien de 5ta categoria se anima?☝🏻🔥_
Les da miedo sentir el kit de la categoría 6ta

[14:27] **+57 322 8911700:**
> _@PadelTownNB: ¿Quien de 5ta categoria se anima?☝🏻🔥_
Voy en 5ta

[14:27] **+57 320 4067603:**
> _+57 322 8911700: Voy en 5ta_
Esoooo

[14:28] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾
3. 🎾
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Juan Osorio
2. 🎾Edwin Mendez
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[14:29] **@PadelTownNB:** Vamos chicos, quienes mas se unen!!!

[14:39] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[14:52] **+57 300 5526808:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[15:31] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[16:03] **+57 322 8911700:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Rubén s
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[17:46] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[20:42] **+57 322 3997442:**
> _@PadelTownNB: 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo._
Gerardo 5ta

[20:42] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[21:37] **@PadelTownNB:** [Imagen]

---

## 7 de septiembre de 2026

[0:20] __@teomunoz06 añadió a +57 313 4453672__

[8:05] **+57 302 4612036:** Buenos días!

[8:17] **@teomunoz06:**
> _+57 302 4612036: Buenos días!_
¡Hola, Andrés! Buenos días. ¿Cómo te podemos ayudar?

[8:18] **@teomunoz06:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo.

[10:50] **@teomunoz06:**
> _@teomunoz06: 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾
8. 🎾

6TA ⚫

1. 🎾Diego Rojas
2. 🎾Hernan T
3. 🎾Andres Perdomo
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

📲 Inscríbete y asegura tu cupo._
¡DOS PALAS MÁS, FAMILIA! ¿QUIÉN SE UNE? 🔥

[11:47] **+57 310 5899189:** Hola

[11:47] **+57 310 5899189:** Somos dos de sexta

[11:57] **@teomunoz06:** Hola, Stefani. ¿Cómo estás? 

¿Nos regalas los nombres de ambos, por favor?

[11:58] **+57 310 5899189:** 6ta 
Stefani
Tatiana

[12:02] **@teomunoz06:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾 Diego Rojas
8. 🎾 Andrés Perdomo 

6TA ⚫

1. 🎾Stefani
2. 🎾Hernan T
3. 🎾Tatiana
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

TORNEO CERRADO, ¡LOS ESPERAMOS!🔒🔒🔒

📲 Inscríbete y asegura tu cupo.

[12:06] **@teomunoz06:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 07/09/2026
🕘 4:30PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 6TA-5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andrés N
🎾 David C
🎾 Samu
🎾

Partido abierto, ¿quiénes se animan?

[13:03] **+57 315 8520389:**
> _@teomunoz06: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 07/09/2026
🕘 4:30PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 6TA-5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andrés N
🎾 David C
🎾 Samu
🎾

Partido abierto, ¿quiénes se animan?_
Uno mas para este juego

[13:13] **+57 316 8342986:** Hola, estoy empezando a jugar y todavía tengo poca experiencia en partidos. ¿La categoría 6.ª acepta principiantes desde cero o requiere cierto nivel de juego?

[13:16] **@diegogomezc96:**
> _@teomunoz06: 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾 Diego Rojas
8. 🎾 Andrés Perdomo 

6TA ⚫

1. 🎾Stefani
2. 🎾Hernan T
3. 🎾Tatiana
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

TORNEO CERRADO, ¡LOS ESPERAMOS!🔒🔒🔒

📲 Inscríbete y asegura tu cupo._
Si alguien se baja soy de quinta y voy 😌

[13:34] **@teomunoz06:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Juan Osorio
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾 Diego Rojas
8. 🎾 Andrés Perdomo 

6TA ⚫

1. 🎾Stefani
2. 🎾Hernan T
3. 🎾Tatiana
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban

LISTA DE ESPERA 🚨
🎾 Diego G 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

TORNEO CERRADO, ¡LOS ESPERAMOS!🔒🔒🔒

📲 Inscríbete y asegura tu cupo.

[13:35] **@teomunoz06:**
> _+57 316 8342986: Hola, estoy empezando a jugar y todavía tengo poca experiencia en partidos. ¿La categoría 6.ª acepta principiantes desde cero o requiere cierto nivel de juego?_
¡Ya te respondemos por interno, desde nuestra línea corporativa!

[13:46] **+57 316 8342986:**
> _@teomunoz06: ¡Ya te respondemos por interno, desde nuestra línea corporativa!_
Gracias

[14:23] __+57 311 5013629 se unieron mediante el enlace de invitación__

[14:52] __@INNOVACARPASSAS se unieron mediante el enlace de invitación__

[15:10] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 07/09/2026
🕘 5:00PM - 6:00PM
📌 Cancha 1
🏷️ Categoría: 6TA-5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Johan
🎾 Enrique
🎾 David
🎾Andres Nuñez

Partido Cerrado

[15:13] __+57 315 2712631 añadió a @enrique.tejera__

[16:28] **@PadelTownNB:** https://chat.whatsapp.com/BtX1KzU444HKVEJiZ23yLN

[16:28] **@PadelTownNB:** ¡Únete y pasa la voz! 🚀

Hemos creado este espacio para estar más cerca, compartir información clave y construir una comunidad cada vez más activa.

[16:32] __@betico204 se unieron mediante el enlace de invitación__

[16:34] __+57 319 5480306 se unieron mediante el enlace de invitación__

[18:02] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Diego G 
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾 Diego Rojas
8. 🎾 Andrés Perdomo 

6TA ⚫

1. 🎾Stefani
2. 🎾Hernan T
3. 🎾Tatiana
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban

LISTA DE ESPERA 🚨
🎾 

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

TORNEO CERRADO, ¡LOS ESPERAMOS!🔒🔒🔒

📲 Inscríbete y asegura tu cupo.

[18:20] **@PadelTownNB:** 🔥🎾 LA PREVIA PADELTOWN — SUMA 11 🎾🔥
MODALIDAD INDIVIDUAL

⚡ 8 DE 5TA + 8 DE 6TA — 16 CUPOS

📅 LUNES 7 DE SEPTIEMBRE
🕗 8:00 pm a 10:00 pm
📍 PadelTown Nuestro Bogotá
💰 Inscripción: $25.000 por jugador

🎾 ¿CÓMO SE JUEGA?

🟠 8 jugadores de 5TA
⚫ 8 jugadores de 6TA
🤝 5TA + 6TA = SUMA 11

✔️ Inscripción individual — no necesitas pareja
✔️ Partidos a 28 puntos
✔️ Cada jugador acumula sus puntos individualmente

🏆PREMIO DE LA PREVIA

🥇 MEJOR PUNTAJE 5TA
🎟️ 20% DCTO en el torneo de 5ta de esa semana

🥇 MEJOR PUNTAJE 6TA
🎟️ 20% DCTO en el torneo de 6ta de esa semana

🎾 SOLO 16 CUPOS

5TA 🟠

1. 🎾Jose Rhenals
2. 🎾Diego G 
3. 🎾Edwin Mendez
4. 🎾Juan diego R
5. 🎾Ruben S
6. 🎾Gerardo
7. 🎾 Diego Rojas
8. 🎾 Andrés Perdomo 

6TA ⚫

1. 🎾Stefani
2. 🎾Hernan T
3. 🎾Tatiana
4. 🎾Fabian Rueda
5. 🎾Jeny
6. 🎾Mayra M
7. 🎾Lu🍃
8. 🎾Juan Esteban

LISTA DE ESPERA 🚨
🎾 Esteban Lizcano

🔥 ENTRENA CON TODOS. ADÁPTATE. LLEGA LISTO AL TORNEO.

TORNEO CERRADO, ¡LOS ESPERAMOS!🔒🔒🔒

📲 Inscríbete y asegura tu cupo.

---

## 8 de septiembre de 2026

[7:07] __+57 315 7817117 se unieron mediante el enlace de invitación__

[10:45] **@PadelTownNB:** 🎾 Buenos días Familia PadelTown!
¡Hoy tenemos canchas disponibles en PadelTown Nuestro Bogotá!
Arma tu grupo, ven a jugar y pasa un buen rato con nosotros. 🧡

Escríbenos y reserva tu cancha.

[11:33] **+57 318 4642929:** Hola grupo alguno interesado en una pala siux ?

[11:45] **@PadelTownNB:** Buenas tardes, si deseas nos puedes enviar una foto y las especificaciones

[11:46] **+57 318 4642929:** [Imagen]

[11:46] **+57 318 4642929:** Esta es la pala

[11:46] **+57 318 4642929:** Es de ataque

[15:58] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Matthew M
🎾 
🎾 
🎾

Partido Abierto. ¿Quiénes más se animan?

[16:06] __[Notificación del sistema]__

[16:19] __Andres Rodriguez Padel se unieron mediante el enlace de invitación__

[16:29] **+57 321 3141622:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Matthew M
🎾 
🎾 
🎾

Partido Abierto. ¿Quiénes más se animan?_
Puedo pero a las 6:30

[16:32] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:30PM - 8:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Matthew M
🎾 Felipe C
🎾 
🎾

Partido Abierto. ¿Quiénes más se animan?

[16:33] **+57 311 5013629:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:30PM - 8:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Matthew M
🎾 Felipe C
🎾 
🎾

Partido Abierto. ¿Quiénes más se animan?_
Voy… Ismael A

[16:34] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:30PM - 8:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Matthew M
🎾 Felipe C
🎾 Ismael A
🎾

Partido Abierto. ¿Quiénes más se animan?

[16:52] **+57 310 3265396:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:30PM - 8:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Matthew M
🎾 Felipe C
🎾 Ismael A
🎾

Partido Abierto. ¿Quiénes más se animan?_
Voy

[16:53] **@teomunoz06:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:30PM - 8:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 Felipe C
🎾 Ismael A
🎾 Jose

Partido Abierto. ¿Quiénes más se animan? ¡Una pala más! 🔥

[16:55] **+57 311 5013629:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:30PM - 8:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 Felipe C
🎾 
🎾 Jose

Partido Abierto. ¿Quiénes más se animan? ¡Una pala más! 🔥

[17:30] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 6:30PM - 8:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan M
🎾 
🎾 
🎾 Jose

Partido Abierto. ¿Quiénes más se animan? ¡Dos palas más! 🔥

[18:35] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 3
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan M
🎾 
🎾 
🎾 

Partido Abierto. ¿Quiénes más se animan? ¡Tres palas más! 🔥

[18:35] **@davidmaring1:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan M
🎾  David M
🎾 
🎾 

Partido Abierto. ¿Quiénes más se animan? ¡Tres palas más! 🔥

[18:36] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan M
🎾 David M
🎾 
🎾 

Partido Abierto. ¿Quiénes más se animan? ¡Dos palas más! 🔥

[19:34] **@PadelTownNB:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 08/09/2026
🕘 9:00PM - 10:00PM
📌 Cancha 1
🏷️ Categoría: 5TA Alta
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan M
🎾 David M
🎾 
🎾 

Partido Abierto. ¿Quiénes más se animan? ¡Dos palas más! 🔥_
¡Dos palas más!

[20:13] **@PadelTownNB:** [Imagen] ¡Les compartimos el calendario de la semana en Pádel Town Nuestro Bogotá! 🔥🎾

[23:08] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 MAÑANA: 09/09/2026
🕘 12:00PM - 1:30PM
📌 Cancha 1
🏷️ Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan F
🎾 
🎾 
🎾 

Partido Abierto. ¿Quiénes más se animan? ¡Tres palas más! 🔥

---

## 9 de septiembre de 2026

[8:57] **@PadelTownNB:** [Imagen] 🎾Buenos días Familia PadelTown, hoy contamos con canchas libres, animate a reservar y diviertete con tus amigos!!🎾

[9:49] **@PadelTownNB:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 
3. 🎾 
4. 🎾 
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[10:25] **@PadelTownNB:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 
4. 🎾 
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[10:43] **+57 305 8142422:** Jarid y Frangel

[10:44] **@teomunoz06:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[10:58] **@PadelTownNB:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 
6. 🎾 
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:11] **@davidmaring1:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David m /
6. 🎾 
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:13] **@PadelTownNB:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Busca partner
6. 🎾 
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:14] **+57 304 1210250:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Busca partner
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:17] **@PadelTownNB:** [Imagen] 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Busca partner
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:56] **+57 317 4404697:**
> _@PadelTownNB: Imagen: 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Busca partner
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones._
🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Busca partner
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 Carlos/ gerardo
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:58] **Paola C Padel Lopez:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Paola López 
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 Carlos/ gerardo
8. 🎾

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:59] **+57 316 8070239:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Paola López 
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 Carlos/ gerardo
8. 🎾 Jose / Rubén 

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Aplican términos y condiciones.

[11:59] **@PadelTownNB:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Paola López 
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 Carlos/ gerardo
8. 🎾 Jose / Rubén

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Lista de espera
🎾

🔒 TORNEO CERRADO🔒
¡¡Los esperamos!!
Aplican términos y condiciones.

[12:56] **@PadelTownNB:** 🏆TORNEO 5TA — PAREJAS FIJAS 🎾🔥

COMPITE, DISFRUTA Y CIERRA LA NOCHE CON EMPANADA ARGENTINA 🥟😎

📅 JUEVES: 10/09/2026
🕢 7:30 PM A 10:00 PM
📍 PadelTown Nuestro Bogotá
🎾 Solo 8 parejas

🥇 CAMPEONES
🏆 Brazalete oficial de Campeón
🎾 Beneficio de cancha mientras mantengan el título
💳 $200.000 en Gift Cards PadelTown
📸 Reconocimiento oficial

🥈 2.º PUESTO
🎾 Obsequio PadelTown

🥉 3.º PUESTO
🎁 50% de DSTC de cancha cualquier franja

🥟 ADEMÁS, EL TORNEO INCLUYE EMPANADA ARGENTINA PARA LOS PARTICIPANTES

💰Inscripción: $65.000 por jugador
🔶 Orange: 20% DCTO
⬛ Black: 30% DCTO

✔️ Organización
✔️ Palas y pelotas
✔️ Grabación en vivo
✔️ Empanada Argentina 🥟

🔥 8 PAREJAS. UN SOLO TÍTULO.

1. 🎾 Juan Osorio/Edwin Méndez
2. 🎾 José/Felipe
3. 🎾 Jarid/Frangel
4. 🎾 Pipe/Esteban
5. 🎾 David M / Paola López 
6. 🎾 Camilo Pérez/ Daniel Q
7. 🎾 Carlos/ gerardo
8. 🎾 Jose / Rubén

👑 GÁNALO. PORTA EL BRAZALETE. DEFIÉNDELO.

Lista de espera
🎾 David/Andrés

🔒 TORNEO CERRADO🔒
¡¡Los esperamos!!
Aplican términos y condiciones.

[13:30] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 5:30PM - 7:00PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 
🎾

Partido abierto, ¿quiénes se animan?

[14:47] **+57 315 8520389:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 5:30PM - 7:00PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 
🎾

Partido abierto, ¿quiénes se animan?_
Quien para jugar este

[14:47] **+57 315 8520389:** 2 que se animen

[15:02] **@PadelTownNB:** 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 Angel
🎾

Partido abierto, una pala mas ¿quienes se animan?🔥🔥

[15:03] **@PadelTownNB:** [Sticker]

[15:30] __@JorgeQuimbay se unieron mediante el enlace de invitación__

[15:31] **@AngelMendez2:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 Angel
🎾

Partido abierto, una pala mas ¿quienes se animan?🔥🔥_
[Sticker]

[15:40] **+57 315 8520389:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 Angel
🎾

Partido abierto, una pala mas ¿quienes se animan?🔥🔥_
Uno mas para que nonse pierda la jugada

[15:41] **@teomunoz06:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 Angel
🎾

Partido abierto, una pala mas ¿quienes se animan?🔥🔥_
¡Una pala más, familia!

[15:46] **@AngelMendez2:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 Angel
🎾

Partido abierto, una pala mas ¿quienes se animan?🔥🔥_
Una mas!!!!

[15:54] **@PadelTownNB:**
> _@PadelTownNB: 🌟🎾 PARTIDO ABIERTO🎾🌟
📍 Pádel Town Nuestro Bogotá 
📅 Hoy: 09/09/2026
🕘 6:00PM - 7:30PM
📌 Cancha 1
🏷️ Categoría: 5ta
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres
🎾 David 
🎾 Angel
🎾

Partido abierto, una pala mas ¿quienes se animan?🔥🔥_
@all Una pala mas chicos!!
