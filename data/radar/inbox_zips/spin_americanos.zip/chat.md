# Exportación de chat de WhatsApp: Torneos Americanos
Fecha de exportación: 9 de septiembre de 2026 a las 16:19

---

## 29 de julio de 2025

[19:35] __+57 301 1388105 creó el grupo__

---

## 7 de septiembre de 2026

[13:01] __[Notificación del sistema]__

[13:36] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[20:27] __[Notificación del sistema]__

[21:03] __[Notificación del sistema]__

[21:12] __[Notificación del sistema]__

[21:15] __[Notificación del sistema]__

---

## 8 de septiembre de 2026

[9:11] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Samuel V
🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 

🎾 Felipe Robayo
🎾
🎾
🎾

TORNEO ABIERTO 🔓

[9:32] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 
🎾 
🎾 

TORNEO ABIERTO 🔓

[11:52] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M
🎾 
🎾 

TORNEO ABIERTO 🔓

[14:24] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 

TORNEO ABIERTO 🔓

[16:19] **+57 301 1388105:** 🚨ULTIMO CUPO
🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 

TORNEO ABIERTO 🔓

[16:21] **@camilo.cruzh:** 🚨ULTIMO CUPO
🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 Sebastian R

TORNEO ABIERTO 🔓

[16:24] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 Sebastian R

TORNEO CERRADO 🔒

[18:10] __[Notificación del sistema]__

---

## 9 de septiembre de 2026

[8:22] __[Notificación del sistema]__
