# Exportación de chat de WhatsApp: MIXTO C
Fecha de exportación: 9 de septiembre de 2026 a las 16:19

---

## 7 de septiembre de 2026

[13:02] __[Notificación del sistema]__

[13:08] __[Notificación del sistema]__

[13:36] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[21:03] __[Notificación del sistema]__

[21:12] __[Notificación del sistema]__

[21:15] __[Notificación del sistema]__

---

## 8 de septiembre de 2026

[16:31] __[Notificación del sistema]__

[21:03] __[Notificación del sistema]__

---

## 9 de septiembre de 2026

[12:56] **+57 301 1388105:** Miércoles 9 de septiembre   
 Categoría: Mixtos C
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Iván
🎾 Nicole
🎾 
🎾  

Partido Abierto 🔓
