# Exportación de chat de WhatsApp: PadelTown Nomad Salitre 🎾
Fecha de exportación: 9 de septiembre de 2026 a las 16:20

---

## 11 de mayo de 2026

[14:23] **+57 318 5358260:** 🎾 ¡Buenas Tardes, familia Padel Nomad! ☀️

Les contamos que ya tenemos nuestras canchas disponibles para que vengan a disfrutar, competir y pasar un gran rato entre amigos y familia 🙌🔥

No se queden sin su espacio, reserven desde ya y vengan a vivir la mejor experiencia de pádel con nosotros 🧡🧡🎾

¡Los esperamos en cancha! 💪

[14:45] **+57 318 5358260:** 🎾 ¡Familia Padel Nomad! 

¿Ya conocían nuestras membresías? 👀🔥
Tenemos beneficios exclusivos, descuentos y muchas ventajas para que disfruten aún más sus partidos y entrenamientos 🎾🙌

Pregunten por nuestros planes y únanse a la experiencia Padel Nomad 💪

[14:45] **+57 318 5358260:** [Imagen]

[14:45] **+57 318 5358260:** [Imagen]

[15:53] **+57 319 2671945:** _Se eliminó este mensaje_

[16:21] __+57 311 5305453 se unieron mediante el enlace de invitación__

[17:38] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 11 De Mayo
Categoria:  *5TA *
Valor: 10.000 Por persona 
⌚  9:00pm  - /10:00pm

🎾 
🎾
🎾  
🎾 

NOS VEMOS EN LA CANCHA!!! 🔥🎾

[19:42] **+57 318 5358260:** [Imagen] Familia, recuerden que ya contamos con Profesor, para que puedan agendar sus clases Ya...

---

## 12 de mayo de 2026

[7:58] **+57 318 5358260:** [Imagen] 🎾 ¡Buenos Días, Familia Padel Nomad! 

¿Ya conocían nuestras membresías? 👀🔥
Tenemos beneficios exclusivos, descuentos y muchas ventajas para que disfruten aún más sus partidos y entrenamientos 🎾🙌

Pregunten por nuestros planes y únanse a la experiencia Padel Nomad

[7:58] **+57 318 5358260:** [Imagen]

[16:37] __+57 314 4820827 se unieron mediante el enlace de invitación__

[18:10] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 11 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  9:00pm  - /10:00pm

🎾 Sergio 
🎾 Nicolas
🎾  
🎾 

NOS VEMOS EN LA CANCHA!!! 🔥🎾

---

## 13 de mayo de 2026

[7:59] __+57 320 8953525 se unieron mediante el enlace de invitación__

[8:09] **+57 318 5358260:** 🧡🎾 ¡Hola familia PadelTown!🎾🧡

Queremos agradecerles por hacer parte de esta increíble comunidad que sigue creciendo cada día. 🙌🔥
Por eso, queremos recordarles que nuestra promo de $10.000 por persona sigue disponible hasta el 15 de mayo 🗓️✨

Es el momento perfecto para venir a jugar, compartir con amigos, mejorar su nivel y disfrutar del mejor ambiente dentro y fuera de la cancha 💪🎾

¡No dejen pasar esta oportunidad y hagan su reserva desde ya!

[8:09] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  8:00pm  - /10:00pm

🎾 
🎾 
🎾  
🎾 

NOS VEMOS EN LA CANCHA!!! 🔥🎾

[9:00] **+57 318 5358260:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  8:00pm  - /10:00pm

🎾 
🎾 
🎾  
🎾 

NOS VEMOS EN LA CANCHA!!! 🔥🎾_
Partido cancelado, por disponibilidad de canchas

[14:54] **+57 318 5358260:** [Imagen] ¿Conoces los beneficios de nuestras membresías?

[15:14] **+57 311 4982613:** Buenas... para programar un partidito de 7 a 9pm faltarian dos mechudos de 5ta, quien se apunta?

[15:15] **+57 318 5358260:**
> _+57 311 4982613: Buenas... para programar un partidito de 7 a 9pm faltarian dos mechudos de 5ta, quien se apunta?_
Buenas tardes Daniel, ya te abrimos el partido, regalame los nombres

[15:15] **+57 311 4982613:** Daniel Robles - Diego Hernandez

[15:18] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 20.000 Por persona 
⌚  7:00pm  - / 9:00pm

🎾 Daniel Robles
🎾 Diego Hernandez
🎾  
🎾 

NOps faltan 2 palas, Quien se anima!!! 🔥🎾

[15:38] **@diegoahernandezsilva:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 20.000 Por persona 
⌚  7:00pm  - / 9:00pm

🎾 Daniel Robles
🎾 Diego Hernandez
🎾  
🎾 

NOps faltan 2 palas, Quien se anima!!! 🔥🎾_
Puedes apuntar a Jhon Caldas por favor

[15:39] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 20.000 Por persona 
⌚  7:00pm  - / 8:00pm

🎾 Daniel Robles
🎾 Diego Hernandez
🎾 Jhon Caldas
🎾 Diego Alvilar

Nos vemos en la Cancha!!! 🔥🎾

[15:41] **+57 323 3659144:** Yo

[15:45] **+57 318 5358260:** PARTIDO CERRADO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  7:00pm  - / 8:00pm

🎾 Daniel Robles
🎾 Diego Hernandez
🎾 Jhon Caldas
🎾 Diego Alvilar

Nos vemos en la Cancha!!! 🔥🎾

[15:57] **@diegoahernandezsilva:**
> _+57 318 5358260: PARTIDO CERRADO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  7:00pm  - / 8:00pm

🎾 Daniel Robles
🎾 Diego Hernandez
🎾 Jhon Caldas
🎾 Diego Alvilar

Nos vemos en la Cancha!!! 🔥🎾_
Puedes modificar las horas, te quedó 7 - 8 y es 7 a 9, para evitar confusiones, por favor

[15:57] **@diegoahernandezsilva:** Gracias!!

[15:59] **+57 318 5358260:**
> _@diegoahernandezsilva: Puedes modificar las horas, te quedó 7 - 8 y es 7 a 9, para evitar confusiones, por favor_
Diego lo que pasa es que solo contamos con disponibilidad de 1 hora

[16:00] **@diegoahernandezsilva:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 20.000 Por persona 
⌚  7:00pm  - / 9:00pm

🎾 Daniel Robles
🎾 Diego Hernandez
🎾  
🎾 

NOps faltan 2 palas, Quien se anima!!! 🔥🎾_
Generó confusión porque colocaste acá las dos horas que te pidió Daniel

[16:01] **+57 318 5358260:**
> _@diegoahernandezsilva: Generó confusión porque colocaste acá las dos horas que te pidió Daniel_
si si señor, lo que pasa es que no habia verificado la plataforma y al verificar me di cuenta que solo tenemos disponibilidad de una hora, que pena generarles la confusion.

[16:04] __+57 311 2924242 se unieron mediante el enlace de invitación__

[16:21] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 13 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  7:00pm  - / 8:00pm

🎾 Diego Alvilar
🎾 
🎾 
🎾 

Nos vemos en la Cancha!!! 🔥🎾

[17:40] **+57 315 0618200:** _Un admin., +57 318 5358260, eliminó este mensaje._

[18:10] __+57 324 4344305 se unieron mediante el enlace de invitación__

[21:11] **@Camilo.act:** _Un admin., +57 318 5358260, eliminó este mensaje._

[21:13] **+57 318 5358260:** [Imagen] ¿Conoces los beneficios de nuestras membresías?

[21:14] **+57 318 5358260:** [Imagen] Tenemos beneficios exclusivos, descuentos y muchas ventajas para que disfruten aún más sus partidos y entrenamientos 🎾🙌

Pregunten por nuestros planes y únanse a la experiencia Padel Nomad

[21:14] **+57 318 5358260:** [Imagen]

---

## 14 de mayo de 2026

[10:06] **Julio Montenegro Padel:** Buenos días  hay disponibilidad de canchas de 6 a 8 pm. Para buscar un juego de 4ta?

[10:23] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA
Valor: 10.000 Por persona 
⌚  5:30pm  - / 7:00pm

🎾 Jorge C
🎾 Julio M
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾

[12:25] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  5TA
Valor: 10.000 Por persona 
⌚  5:00pm  - / 7:00pm

🎾 Valeria
🎾 Neiber
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾

[12:28] **+57 320 2392108:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA
Valor: 10.000 Por persona 
⌚  5:30pm  - / 7:00pm

🎾 Jorge C
🎾 Julio M
🎾 Nico Rivera 
🎾 Sergio Camargo 

QUIEN SE ANIMA!!! 🔥🎾

[12:29] **@marlon.iragorri:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  5TA
Valor: 10.000 Por persona 
⌚  5:00pm  - / 7:00pm

🎾 Valeria
🎾 Neiber
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾_
Yo

[12:29] **+57 323 3659144:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  5TA
Valor: 10.000 Por persona 
⌚  5:00pm  - / 7:00pm

🎾 Valeria
🎾 Neiber
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾_
Yo

[12:34] __Julio Montenegro Padel añadió a Jorge😎 Pádel__

[12:37] **+57 318 5358260:** PARTIDO CERRADO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA
Valor: 10.000 Por persona 
⌚  5:30pm  - / 7:00pm

🎾 Jorge C
🎾 Julio M
🎾 Nico Rivera 
🎾 Sergio Camargo 

NOS VEMOS EN LA CANCHA!!! 🔥🎾

[12:38] **+57 318 5358260:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  5TA
Valor: 10.000 Por persona 
⌚  5:00pm  - / 7:00pm

🎾 Valeria
🎾 Neiber
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾_
Partido CANCELADO por falta de espacio

[12:45] **@gdanderino:** A q horas en la tarde tienen disponibilidad de cancha

[12:46] **+57 320 3454700:** Hola tienes. Cancha. A las 6

[12:47] **+57 318 5358260:**
> _@gdanderino: A q horas en la tarde tienen disponibilidad de cancha_
Hola, tenemos disponibilidad desde la 1pm hasta las 6pm

[12:48] **+57 318 5358260:**
> _+57 320 3454700: Hola tienes. Cancha. A las 6_
Hola, no señor, ya tenemos todo reservado, que pena contigo

[12:48] **@marlon.iragorri:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA
Valor: 10.000 Por persona 
⌚  5:30pm  - / 7:00pm

🎾 Jorge C
🎾 Julio M
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾_
Qué tal de 4 a 6?

[12:50] **+57 318 5358260:** PARTIDO CERRADO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA
Valor: 10.000 Por persona 
⌚  5:30pm  - / 7:00pm

🎾 Jorge C
🎾 Julio M
🎾 Juan R
🎾 Jorge F

NOS VEMOS EN LA CANCHA!!! 🔥🎾

[12:52] **+57 318 5358260:**
> _@marlon.iragorri: Qué tal de 4 a 6?_
Si me queda espacio, pero todos tienen que confirmar

[12:53] **@marlon.iragorri:** Por mi parte puedo

[12:54] **@marlon.iragorri:** Si los tres faltantes confirman Ready

[12:54] **@marlon.iragorri:** [Sticker]

[12:54] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾

[13:21] **+57 312 3297466:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾_
Yo puedo

[13:21] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 
🎾 

QUIEN SE ANIMA!!! 🔥🎾

[13:38] **+57 312 3297466:** Valeria no puede, si alguien se anima, bienvenido

[13:40] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 
🎾 

NOS FALTAN DOS PALAS!!! 🔥🎾

[13:43] **@icemberth:**
> _+57 318 5358260: PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 
🎾 

NOS FALTAN DOS PALAS!!! 🔥🎾_
yo podría ir, Mike

[13:43] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 Miguel L
🎾 

NOS FALTAN UNA PALA!!! 🔥🎾

[15:00] **+57 318 5358260:** Quien se anima!!!

PARTIDO ABIERTO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 Miguel L
🎾 

NOS FALTAN UNA PALA!!! 🔥🎾

[15:11] **+57 323 3659144:** Yo

[15:13] **@marlon.iragorri:** Ready

[15:13] **+57 318 5358260:** Quien se anima!!!

PARTIDO CERRADO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 Miguel L
🎾 Diego A

NOS VEMOS EN LA CANCHA!!! 🔥🎾

[15:20] **+57 318 5358260:** [Imagen] 💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾
🎾
🎾
🎾
🎾
🎾

[15:25] **+57 314 4820827:**
> _+57 318 5358260: Imagen: 💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾
🎾
🎾
🎾
🎾
🎾_
Yo ✌🏽😊

[15:26] **+57 318 5358260:** 💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾 Alejandra Londoño
🎾
🎾
🎾
🎾
🎾

[15:26] **@angiefuentes16:**
> _+57 318 5358260: 💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾 Alejandra Londoño
🎾
🎾
🎾
🎾
🎾_
Angelica Fuentes

[15:27] **+57 318 5358260:** 💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾 Alejandra Londoño
🎾 Angelica Fuentes
🎾
🎾
🎾
🎾

[15:29] **@laubarbosav:** Yo

[15:30] __@JorgeQuimbay añadió a @TatianaMH08__

[15:30] **+57 318 5358260:** 💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾 Alejandra Londoño
🎾 Angelica Fuentes
🎾 Laura Carvajal
🎾
🎾
🎾

[15:30] **@TatianaMH08:** 💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾 Alejandra Londoño
🎾 Angelica Fuentes
🎾 Laura Carvajal
🎾Tatiana Machete 
🎾
🎾

[15:33] **+57 318 5358260:** Clase Cerrada 🔐🔐🔐


💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾 Alejandra Londoño
🎾 Angelica Fuentes
🎾 Laura Carvajal
🎾Tatiana Machete 
🎾 Maria Paula Villa Marin
🎾 Danna Valentina

[15:47] __@romario___2002 se unieron mediante el enlace de invitación__

[16:02] **+57 318 5358260:**
> _+57 318 5358260: Quien se anima!!!

PARTIDO CERRADO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 Miguel L
🎾 Diego A

NOS VEMOS EN LA CANCHA!!! 🔥🎾_
Hola Chicos, los estamos esperando

[16:02] **@marlon.iragorri:**
> _+57 318 5358260: Quien se anima!!!

PARTIDO CERRADO
📍 PadelTown Nomad Salitre 
Hoy: 14 De Mayo
Categoria:  4TA - 5TA
Valor: 10.000 Por persona 
⌚  4:00pm  - / 6:00pm

🎾 Marlon I
🎾 Neiber P
🎾 Miguel L
🎾 Diego A

NOS VEMOS EN LA CANCHA!!! 🔥🎾_
Llegando

[19:09] **+57 318 5358260:** [Imagen] ¡Comunidad PadelTown! 🎾🔥

Disfruten porque ya solo nos queda mañana para terminar esta increíble promoción 🙌
Aprovechen el plan perfecto en Nomad Salitre por solo $10.000 por persona.

Desde ya pueden reservar y asegurar su cancha para no quedarse por fuera 💥
¡Los esperamos para vivir la mejor experiencia dentro y fuera de la cancha!

[19:30] __+57 310 7902444 se unieron mediante el enlace de invitación__

---

## 15 de mayo de 2026

[9:04] __@julianacruzh5 se unieron mediante el enlace de invitación__

[9:04] __Alguien añadió a @julianacruzh5__

[9:06] __+57 311 2920003 se unieron mediante el enlace de invitación__

[10:06] **+57 318 5358260:** [Video] Familia a PadelTown Nomad llega 

 *¡GRAN CONCURSO DE LANZAMIENTO!* 🚀

¡Llegó el momento que estabas esperando!
Participa y sé uno de los primeros en vivir esta nueva experiencia. 🔥

[10:22] **+57 318 5358260:** [Imagen]

[15:31] **+57 318 5358260:** [Imagen] Familia PadelTown.

Aprovechen!!!!

[16:07] **+57 312 5549788:** Disponibilidad de Clases 
Paldel Town Nomad 
Sábado 16 de Mayo
O9:00 am
10:00 am
11:00 am
12:00 m
 1:00 pm
Info y Reservas x Inbox
👍🏆🎾

[16:13] __+57 311 8632792 se unieron mediante el enlace de invitación__

[17:44] __+57 321 4851257 se unieron mediante el enlace de invitación__

[20:41] **+57 318 5358260:** _Se eliminó este mensaje_

[20:46] **+57 318 5358260:** [Imagen]

[20:46] **+57 318 5358260:** Familia a PadelTown Nomad llega 

 *¡GRAN CONCURSO DE LANZAMIENTO!* 🚀

¡Llegó el momento que estabas esperando!
Participa y sé uno de los primeros en vivir esta nueva experiencia. 🔥

---

## 16 de mayo de 2026

[9:13] __+57 317 4992523 se unieron mediante el enlace de invitación__

[10:53] **+57 318 5358260:** [Imagen] FAMILIAAA PADEL NOMAD!!!

GRAN CONCURSO DE LANZAMIENTO! 🚀

¡Llegó el dia!

Participa y se uno de los primeros en vivir esta nueva experiencia. 🎾🔥

[14:11] **+57 310 2192130:** Buenas tardes 
Por dónde se reserva ? 
Que precios tienen ?

[14:12] **+57 318 5358260:** Hola, ya te ayudo al interno

[14:14] **+57 315 7860273:** Precio tiene la reserva

[14:16] **+57 318 5358260:** _Se eliminó este mensaje_

[14:16] **+57 318 5358260:** _Se eliminó este mensaje_

[14:46] **+57 310 2192130:** Borraron los precios,  los van a revisar ? Suben o bajan ?
🤪

[14:49] **+57 318 5358260:** [Imagen]

[14:50] **+57 311 8475699:** Hola buenas tardes, me queda la incertidumbre por qué preciso estaba yendo a jugar allá por el precio, ya que estaba más económico de lo que hay por el sector, aunque en mi caso al venir del norte siempre es un poco complicado el transporte hacia ese lado donde estan ubicados, lastima, muchas gracias

[14:53] **+57 318 5358260:**
> _+57 318 5358260: Imagen_
[Imagen]

[15:18] **+57 318 5358260:** 🎾🔥 Familia PadelTown 🔥🎾

Les recordamos que la clase de hoy inicia a las 4:00 p.m. ⏰

⚠️ A tener en cuenta:
Daremos inicio con los participantes que estén PUNTUALES en la cancha 🔥

Arrancamos puntuales y le sacamos todo el provecho a la jornada 💪😎
¡Nos vemos en cancha! 🎾🔥

[16:00] **+57 318 5358260:**
> _+57 318 5358260: Clase Cerrada 🔐🔐🔐


💖🎾 Comunidad PadelTown, especialmente mujeres… ¡llegó lo que tanto estaban esperando! 🎾💖

Este sábado 16 de mayo tendremos una clase de pádel femenina GRATIS en PadelTown Nomad 🙌🏼✨

No importa si nunca has jugado, esta clase es para aprender, divertirte, conocer nuevas personas y pasar un rato increíble 💗

📅 Sábado 16 de mayo
🕓 4:00 PM
📍 PadelTown Nomad

¡Las esperamos para jugar en grande! 💪🏼🎾
 
Cupos Limitados!!!
Inscríbete aquí: 

🎾 Jesica Garcia
🎾 Juanita Rojas
🎾 Alejandra Londoño
🎾 Angelica Fuentes
🎾 Laura Carvajal
🎾Tatiana Machete 
🎾 Maria Paula Villa Marin
🎾 Danna Valentina_
HOLA CHICAS LAS ESTAMOS ESPERANDO🥳🔥

[16:12] **+57 305 7120798:**
> _+57 311 8475699: Hola buenas tardes, me queda la incertidumbre por qué preciso estaba yendo a jugar allá por el precio, ya que estaba más económico de lo que hay por el sector, aunque en mi caso al venir del norte siempre es un poco complicado el transporte hacia ese lado donde estan ubicados, lastima, muchas gracias_
X2

[16:18] **+57 310 2192130:**
> _+57 305 7120798: X2_
X3

[16:21] **@diegoahernandezsilva:** X4

[16:24] **+57 318 5358260:** Buenas tardes, esta promoción iba inicialmente hasta el 30 de Abril, pensando en ustedes la alargamos hasta el 15 de mayo por el tema de inauguración, ya vamos a quedar con los precios enviados anteriormente pero igual seguimos lanzando promociones como lo son
* Membresias
* Torenos
* Clases gratis 
* Concurso para ganar una membresia 
Y muchisimas sorpresas mas.

[16:24] **@NicolasDuarteB:** X5

[16:54] **+57 315 7860273:** X6

[17:07] **+57 318 5358260:** PARTIDO ABIERTO
📍 Pádel Town Nomad  
📅  16 de mayo  
🕘 06:00 P.M-08:00 P.M
Categoría: 4ta - 5ta
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾  
🎾 
Quien se apuntaa ?🔥

[17:35] **+57 311 2924242:**
> _+57 305 7120798: X2_
X7

[17:36] **Julio Montenegro Padel:** X8

[17:36] **+57 311 4982613:** X9

[17:36] **+57 315 0618200:** x10

[17:36] **@sebastian_chip:** X11

[17:36] **@sebastian_chip:** _Se eliminó este mensaje_

[17:36] **@sebastian_chip:** [Sticker]

[17:37] **@andcordero:** X12

[17:38] **+57 313 3009091:** X13

[17:53] **+57 311 4741908:** [Mensaje de album]

[17:53] **+57 311 4741908:** _Se eliminó este mensaje_

[17:53] **+57 311 4741908:** _Se eliminó este mensaje_

[17:53] **+57 311 4741908:** _Se eliminó este mensaje_

[17:53] **+57 311 4741908:** _Se eliminó este mensaje_

[18:09] **+57 318 5358260:** FAMILIA PADELTOWN🧡🎾

✨ Así vivimos nuestra increíble clase gratis femenina ✨

Gracias a todas las mujeres que hicieron parte de este espacio lleno de energía, aprendizaje, risas y mucho pádel 💕🎾

Nos encanta ver cómo sigue creciendo esta hermosa comunidad, donde cada punto, cada conversación y cada momento dentro de la cancha se convierte en una experiencia única.

Esto apenas comienza… gracias por confiar en nosotros y ser parte de la familia PadelTown 🔥🎾.

[18:09] **+57 318 5358260:** [Reenviado] [Imagen]

[18:09] **+57 318 5358260:** [Reenviado] [Imagen]

[18:09] **+57 318 5358260:** [Reenviado] [Imagen]

[18:09] **+57 318 5358260:** [Reenviado] [Imagen]

---

## 17 de mayo de 2026

[0:23] **+57 311 5915669:** X14

[7:25] **+57 310 2192130:**
> _+57 311 5915669: X14_
👍

[7:33] **+57 318 5358260:** 🎾✨ ¡Buenos Días, Comunidad  PadelTown Nomad! ✨🎾

Queremos recordarles que desde ya pueden reservar su cancha y venir a disfrutar de un día increíble junto a sus amigos, familia y toda nuestra comunidad de pádel. 🫶🔥

Nada mejor que compartir buenos momentos, competir, reír y vivir la pasión por este deporte que tanto nos une. 💙

Además, aprovechen para participar en nuestro Concurso de Lanzamiento y no perderse la oportunidad de ganar increíbles sorpresas. 👀🎁

¡Los esperamos en cancha para seguir creando grandes momentos juntos! 🎾✨

[7:35] **+57 318 5358260:** [Imagen] FAMILIAAA PADEL NOMAD!!!

GRAN CONCURSO DE LANZAMIENTO! 🚀

¡Llegó el dia!

Participa y se uno de los primeros en vivir esta nueva experiencia. 🎾🔥

[9:43] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  17 de mayo  
🕘 03:00 P.m 05:00 P.m
Categoría: 4ta - 5ta
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾  
🎾 

Quien se Apunta ?🔥

[15:27] __@juangomez518 se unieron mediante el enlace de invitación__

[15:27] __Alguien añadió a @juangomez518__

[15:32] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  17 de mayo  
🕘 7:00 P.m 9:00 P.m
Categoría:  5ta
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan Gomez
🎾  
🎾  
🎾 

Quien se Apunta ?🔥

[21:04] **+57 318 2184996:** Por favor hay disponibilidad de cancha para mañana 11am ?

[21:19] **+57 318 5358260:** Hola, si señor, ya te colaboro

[21:20] **+57 318 2184996:** Muchas gracias

---

## 18 de mayo de 2026

[10:48] **+57 314 4800124:** Me das la ubicación de nomad?

[10:48] __+57 313 3045701 se unieron mediante el enlace de invitación__

[10:54] **+57 318 5358260:** Carrera 66 No. 19-71

[12:49] **+57 310 2192130:** Buenas tardes 
Una pareja de cuarta para jugar en la tarde o tarde-noche 
Si quieren apostamos la cancha

[14:21] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾  
🎾 

Quien se Apunta ?🔥

[14:26] **@jesus_danielg:**
> _+57 318 5358260: PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾  
🎾 

Quien se Apunta ?🔥_
Me apunto✌🏼

[14:26] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  
🎾  
🎾 

Quien se Apunta ?🔥

[14:37] **@juangomez518:**
> _+57 318 5358260: PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  
🎾  
🎾 

Quien se Apunta ?🔥_
Yo

[14:38] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  Juan Gomez
🎾  
🎾 

Quien se Apunta ?🔥

[15:12] **+57 318 5358260:** [Imagen] FAMILIAAA PADEL NOMAD!!!

GRAN CONCURSO DE LANZAMIENTO! 🚀

¡Llegó el dia!

Participa y se uno de los primeros en vivir esta nueva experiencia. 🎾🔥

[15:22] __+57 317 3357647 se unieron mediante el enlace de invitación__

[15:33] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  Juan Gomez
🎾  Laura Carvajal
🎾 

Nos falta una pala, Quien se Apunta ?🔥

[16:29] **+57 310 2192130:**
> _+57 310 2192130: Buenas tardes 
Una pareja de cuarta para jugar en la tarde o tarde-noche 
Si quieren apostamos la cancha_
?

[16:30] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 6:00 P.m a  8:00 P.m
Categoría:  4TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marcel 
🎾 Simon
🎾  
🎾 

Quien se Apunta ?🔥

[16:32] **+57 318 5358260:** Familia nos falta una pala para completar el partido, Quien se anima???

PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  Juan Gomez
🎾  Laura Carvajal
🎾 

Nos falta una pala, Quien se Apunta ?🔥

[16:35] **@jesus_danielg:**
> _+57 318 5358260: Familia nos falta una pala para completar el partido, Quien se anima???

PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  Juan Gomez
🎾  Laura Carvajal
🎾 

Nos falta una pala, Quien se Apunta ?🔥_
Uno más💪🏼

[17:25] **+57 318 5358260:** Familia nos falta una pala para completar el partido, Quien se anima???

PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  Juan Gomez
🎾  Laura Carvajal
🎾 

Nos falta una pala, Quien se Apunta ?🔥

[18:55] **@DsebasMG:**
> _+57 318 5358260: Familia nos falta una pala para completar el partido, Quien se anima???

PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  Juan Gomez
🎾  Laura Carvajal
🎾 

Nos falta una pala, Quien se Apunta ?🔥_
🖐🏻

[18:56] **+57 318 5358260:** PARTIDO CERRADO

📍 Pádel Town Nomad  
📅  18 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesus Daniel
🎾  Juan Gomez
🎾  Laura Carvajal
🎾  Sebas M

Nos vemos en la Cancha🔥

[20:55] __+57 318 5358260 añadió a @jhonatanvillada__

---

## 19 de mayo de 2026

[7:37] **+57 318 5358260:** [Imagen] FAMILIAAA PADEL NOMAD!!!

GRAN CONCURSO DE LANZAMIENTO! 🚀

¡Llegó el dia!

Participa y se uno de los primeros en vivir esta nueva experiencia. 🎾🔥

[12:09] **+57 318 5358260:** _Se eliminó este mensaje_

[13:30] **+57 318 5358260:** _Se eliminó este mensaje_

[14:19] **+57 323 3659144:**
> _+57 318 5358260: PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  19 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾  
🎾 

Quien se Apunta ?🔥_
Oscar 
Diego 
Cristian 
Londoño

[14:21] **+57 318 5358260:** PARTIDO CERRADO

📍 Pádel Town Nomad  
📅  19 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Oscar
🎾 Diego
🎾 Cristian  
🎾 Londoño

Nos vemos en la cancha🔥

[16:33] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📅  19 de mayo  
🕘 6:00 P.m 8:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾  
🎾  

Quien se anima!!!🔥

[17:54] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ reservado
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾
🎾
🎾

[18:06] __@MaoBs se unieron mediante el enlace de invitación__

[18:08] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ reservado
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[18:09] __Bienvenidos a PadelTown🎾🏆.

Nuestra dirección Cra. 66 #19-71

Reserva fácil y rápido: https://wa.me/573185358260

LOS ESPERAMOS__

[18:09] __[Notificación del sistema]__

---

## 20 de mayo de 2026

[7:12] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ reservado
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾 Tato/Reservado
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[7:15] __+57 322 7098313 se unieron mediante el enlace de invitación__

[7:16] **+57 322 7098313:** Que dijeron ... Se va el torneo y el tato se queda por fuera ..

[7:16] **+57 322 7098313:** Jai papa

[7:16] **+57 322 7098313:** Vamos por julio y Jorge de postre

[7:18] **+57 318 5358260:** 🧡🎾BUENOS DIAS FAMILIA PADELTOWN 🧡
🎾
Nos encanta ver la pasión, la energía y el compañerismo que se vive día a día. Más que jugadores, somos una familia que disfruta del deporte y de grandes experiencias juntos.

Gracias por confiar en nosotros y por seguir llenando nuestras canchas de buena vibra. ¡Nos vemos en cancha para seguir creando momentos increíbles! 🔥🎾

¡QUEDAN POCOS CUPOS PARA NUESTRO TORNEO, ANIMESE Y NO SE PIERDAN DE ESTA GRAN CELEBRACIÓN!🔥🏆💳

[7:21] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾 Jaime / Jesus 
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[7:47] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾

Quien se Anima!!!🔥🥳🎾💳

[7:59] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Juan Camilo / Jorge 
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[7:59] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Juan Camilo / Jorge 
🎾 Camilo Rojas / Reservado
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[8:00] __@KART23 se unieron mediante el enlace de invitación__

[8:04] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Juan Camilo / Jorge 
🎾 Camilo Rojas / Jesus
🎾 
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[15:42] **+57 318 5358260:** [Imagen] 🔥 ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Julio Montenegro / Jorge
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Juan Camilo / Jorge 
🎾 Camilo Rojas / Jesus
🎾 
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[16:00] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  20 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 67.500 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾  
🎾 

Quien se Apunta!!! 🔥

[17:00] **+57 318 5358260:** PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  20 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 67.500 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾  
🎾 

Quien se Apunta!!! 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  20 de mayo  
🕘 6:00 P.m 8:00 P.m
Categoría:  5TA / 6TA
💰 Precio por jugador: 67.500 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾  
🎾 

Quien se Apunta!!! 🔥

[18:08] **+57 318 5358260:** ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Juan Camilo / Jorge 
🎾 Camilo Rojas / Jesus
🎾 
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[19:54] **+57 310 2192130:** Pueden dar más información? 
Cuantos partidos mínimo son ? 
Cómo es el sistema de juego ?
A cuantos sets? 
Hay grupos o todos contra todos ? 
Más información por favor, gracias

[19:54] **+57 318 5358260:** Hola Marcel buenas noches

[19:54] **+57 310 2192130:** Buenas noches

[20:06] **+57 318 5358260:**
> _+57 310 2192130: Buenas noches_
El torneo de Inaguración se jugara en un Formato Round Robin (todos contra todos). Fase de grupos 3 grupos de 4 parejas.

[20:09] **+57 320 2329180:** Partidos completos?
De esos 12 cuantos clasifican?

[20:09] **+57 320 2329180:** Y como sigue el cuadro?

[20:11] **+57 320 2329180:** Sería Sabado y Domingo?

[20:12] **+57 318 5358260:**
> _+57 320 2329180: Sería Sabado y Domingo?_
Hola buenas noches Ernesto, no señor se jugara solo el día Sabado, mañana les enviaremos la programación.

[20:27] **+57 318 5358260:** ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Camilo Rojas / Jesus
🎾 
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[21:39] **+57 311 4982613:** buenas noches para una reserva el día de mañana de 4  a 6pm

[21:51] **+57 318 5358260:**
> _+57 311 4982613: buenas noches para una reserva el día de mañana de 4  a 6pm_
Buenas noches Daniel, ya te colaboramos

[21:53] **+57 318 5358260:** _Se eliminó este mensaje_

---

## 21 de mayo de 2026

[8:16] **+57 318 5358260:** [Imagen] 🎾🔥 Comunidad de PadelTown Nomad, este es el momento de aprovechar 🔥🎾

Seguimos activos con nuestro concurso de lanzamiento y queremos que todos participen. 💥

El ganador será la persona que más reservas realice, así que desde ya los invitamos a reservar sus canchas, jugar, sumar horas y disfrutar al máximo esta experiencia. 🙌

Entre más reserves, más oportunidades tendrás de ganar. 🏆
¡No se queden por fuera y empiecen a sumar desde hoy! 🚀

[10:06] __@aristi_lau se unieron mediante el enlace de invitación__

[10:27] **+57 318 5358260:** ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[10:33] **+57 318 5358260:** ¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ reservado
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Marlon / Neiber
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[14:14] **+57 318 5358260:** Familia Aun contamos con Cupos Disponibles, Quien se Anima!!!

¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ Alberto
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Marlon / Neiber
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[14:20] __+57 302 6055008 se unieron mediante el enlace de invitación__

[14:42] **+57 318 5358260:** Familia Aun contamos con Cupos Disponibles, Quien se Anima!!!

¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ Alberto
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Marlon / Busca Partner
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[14:57] **+57 318 5358260:** Familia Aun contamos con Cupos Disponibles, Quien se Anima!!!

¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ Alberto
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Marlon / Camilo
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[15:18] **+57 318 5358260:** Familia Nos falta una Pala, Quien dijo Yo!!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  21 de mayo  
🕘 5:00 P.m 7:00 P.m
Categoría:  4TA / 5TA
💰 Precio por jugador: 50.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Daniel
🎾 Camilo
🎾 

Quien se Apunta!!! 🔥

[16:05] **+57 318 5358260:** Familia Nos falta una Pala, Quien dijo Yo!!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  21 de mayo  
🕘 5:00 P.m 7:00 P.m
Categoría:  4TA / 5TA
💰 Precio por jugador: 50.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Daniel
🎾 Camilo
🎾 

Quien se Apunta!!! 🔥

[16:08] **+57 305 7120798:** _Se eliminó este mensaje_

[16:08] **+57 305 7120798:** _Se eliminó este mensaje_

[16:08] **+57 305 7120798:** _Se eliminó este mensaje_

[16:22] __+57 317 5750249 se unieron mediante el enlace de invitación__

[16:22] **+57 318 5358260:** Familia Nos falta una Pala, Quien dijo Yo!!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  21 de mayo  
🕘 5:00 P.m 7:00 P.m
Categoría:  4TA / 5TA
💰 Precio por jugador: 50.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Daniel
🎾 Camilo
🎾 

Quien se Apunta!!! 🔥

[17:18] **+57 318 5358260:**
> _+57 318 5358260: Familia Nos falta una Pala, Quien dijo Yo!!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  21 de mayo  
🕘 5:00 P.m 7:00 P.m
Categoría:  4TA / 5TA
💰 Precio por jugador: 50.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Daniel
🎾 Camilo
🎾 

Quien se Apunta!!! 🔥_
Partido CANCELADO

[18:18] __+57 301 7547488 se unieron mediante el enlace de invitación__

[19:06] __+57 313 2640889 se unieron mediante el enlace de invitación__

---

## 22 de mayo de 2026

[7:15] **+57 318 5358260:** Familia Aun contamos con Cupos Disponibles, Quien se Anima!!!

¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ Alberto
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Marlon / Busca Partner
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[7:20] **+57 318 5358260:** Familia Aun contamos con Cupos Disponibles, Quien se Anima!!!

¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ Alberto
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Marlon / Camilo
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[9:28] __+57 319 3973676 añadió a @stivenyq__

[11:07] **+57 318 5358260:** 🧡FAMILIA PADELTOWN🧡

Queremos invitarlas a ser parte de nuestro nuevo grupo exclusivo de chicas jugadoras de pádel 🎾🎀
Un lugar para compartir, aprender, jugar, hacer nuevas amistades y seguir creciendo juntas dentro y fuera de la cancha.

No importa si apenas estás empezando o si ya llevas tiempo jugando, aquí siempre habrá buena energía, apoyo y muchas ganas de disfrutar este deporte que tanto nos une 💪🏼💕

Anímense a ser parte de esta comunidad increíble y vivamos juntas la pasión por el pádel 🔥🎾🎀

https://chat.whatsapp.com/KRxoT0Nb7k0BubuLuP1i3S

[14:35] **+57 318 5358260:** Familia Aun contamos con Cupos Disponibles, Quien se Anima!!!

¡Llega el torneo que marcará el inicio de una nueva historia en Nomad Salitre! 🔥

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 23 de mayo – 5:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados, así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 

🎾 Camilin/ reservado
🎾 Daniel Alujere/ Tato
🎾 Mao/ Alberto
🎾 Daniel Preciado/ reservado
🎾 Jaime / Jesus 
🎾 Andrés Marín / Mauricio Clavijo
🎾 Marlon / Camilo
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[16:34] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  22 de mayo  
🕘 7:00 P.m 9:00 P.m
Categoría:  4TA / 5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[16:47] **+57 318 5358260:** 🔥 ¡Comunidad PadelTown Nomad Salitre! 🔥

Recuerden que seguimos con nuestro CONCURSO DE LANZAMIENTO y cada reserva, clase o entrenamiento los acerca más a ganar una membresía Orange por $500.000 COP 🧡🎾

🏆 Así va nuestro TOP 3 del Concurso de Lanzamiento 🏆

🥇 Diego Alviar — 3 puntos
🥈 Juan Pablo Gomez — 3 puntos
🥉 Brandon Bates — 2,5 puntos

🔥 La competencia está cada vez mejor y todavía estás a tiempo de subir en el ranking.

Recuerda:

🎾 Por cada Reserva suma 1 punto.
🎾 Por cada Academia suma 1 punto.
🎾Por cada Clase Personalizada suma 2 puntos.

📅 Tienes hasta el 31 de mayo para participar.
¡Vamos por más! 💪🧡

[18:37] __+57 321 9017596 se unieron mediante el enlace de invitación__

[22:22] __@andy.suarez se unieron mediante el enlace de invitación__

[22:22] __Alguien añadió a @andy.suarez__

---

## 23 de mayo de 2026

[0:08] **@marlon.iragorri:** _Se eliminó este mensaje_

[11:31] **+57 318 5358260:** 🌟🎾 CLASE PERSONALIZADA DE PÁDEL 🎾🌟
📍 Pádel Town Nomad
📅 23/05/2026   
🕘 05:00 PM- 06:00 PM
🥎 Cancha Uno
🏷️ Categoría: 5ta- 6ta
💰 Precio por jugador: 42.000 

🎾
🎾 
🎾 
🎾

Quien se anima??

[12:18] **+57 318 5358260:** 🌟🎾 CLASE PERSONALIZADA DE PÁDEL 🎾🌟
📍 Pádel Town Nomad
📅 23/05/2026   
🕘 05:00 PM- 06:00 PM
🥎 Cancha Uno
🏷️ Categoría: 5ta- 6ta
💰 Precio por jugador: 42.000 

🎾
🎾 
🎾 
🎾

QUIEN SE APUNTA?? 🔥🔥

---

## 24 de mayo de 2026

[10:42] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  24 de mayo  
🕘 6:00 P.m 8:00 P.m
Categoría:  5TA
💰 Precio por jugador: 40,000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Gustavo 
🎾 David 
🎾 
🎾 

Dos palas más, quién se anima 🔥🔥

Quien se Apunta!!! 🔥

[11:47] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  24 de mayo  
🕘 13:00 P.m 14:00 P.m
Categoría:  6TA
💰 Precio por jugador: 20,000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

Quien se Apunta!!! 🔥

[14:25] **+57 318 5358260:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  24 de mayo  
🕘 6:00 P.m 8:00 P.m
Categoría:  5TA
💰 Precio por jugador: 40,000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Gustavo 
🎾 David 
🎾 
🎾 

Dos palas más, quién se anima 🔥🔥

Quien se Apunta!!! 🔥_
PARTIDO CANCELADO

---

## 25 de mayo de 2026

[11:35] **+57 311 8475699:** Hola buenos días

[11:35] **+57 311 8475699:** Para separar cancha para hoy en la tarde

[11:35] **+57 311 8475699:** De 5 a 6 y media

[12:02] **+57 310 2937073:**
> _+57 311 8475699: Hola buenos días_
Hola buenas tardes Edgardo,  nuestro horario hoy es de 2pm a 10pm, con gusto a las 2 te ayudamos con la reserva 🥳🎾

[13:30] __@Emelyn_DMR se unieron mediante el enlace de invitación__

[14:17] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  25 de mayo  
🕘 5:00 P.m 6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 42.500 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Marlon
🎾Amado 1
🎾Amado 2
🎾Edgardo

Nos vemos en la cancha!!! 🔥

[15:00] **+57 318 5358260:** 🔥 ¡Comunidad PadelTown Nomad Salitre! 🔥

Recuerden que seguimos con nuestro CONCURSO DE LANZAMIENTO y cada reserva, clase o entrenamiento los acerca más a ganar una membresía Orange por $500.000 COP 🧡🎾

🏆 Así va nuestro TOP 3 del Concurso de Lanzamiento 🏆

🥇 Juanita Rojas — 3.5 puntos
🥈 Mariana Vargas — 3.0 puntos
🥉 Juan Poveda — 3.0 puntos

🔥 La competencia está cada vez mejor y todavía estás a tiempo de subir en el ranking.

Recuerda:

🎾 Por cada Reserva suma 1 punto.
🎾 Por cada Academia suma 1 punto.
🎾Por cada Clase Personalizada suma 2 puntos.

📅 Tienes hasta el 31 de mayo para participar.
¡Vamos por más! 💪🧡

[15:15] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  25 de mayo  
🕘 5:00 P.m 6:00 P.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Marlon
🎾Amado 1
🎾Amado 2
🎾Edgardo

Nos vemos en la cancha!!! 🔥

[18:02] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  25 de mayo  
🕘 9:00 P.m 10:00 P.m
Categoría:  4TA/5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾
🎾

Quien se Anima!!! 🔥

[19:47] __+57 311 8413849 se unieron mediante el enlace de invitación__

[20:29] **+57 318 5358260:** [Imagen] 🎾 ¡Familia Padel Nomad! 

¿Ya conocían nuestras membresías? 👀🔥
Tenemos beneficios exclusivos, descuentos y muchas ventajas para que disfruten aún más sus partidos y entrenamientos 🎾🙌

Pregunten por nuestros planes y únanse a la experiencia Padel Nomad 💪

[20:30] **+57 318 5358260:** _Se eliminó este mensaje_

[20:30] **+57 318 5358260:** [Imagen]

[20:41] **@DsebasMG:** _Se eliminó este mensaje_

[20:41] **@DsebasMG:** _Se eliminó este mensaje_

[20:41] **@DsebasMG:** _Se eliminó este mensaje_

[21:13] **+57 318 5358260:** La inauguración de PadelTown Nomad se vive a lo grande y queremos que tú seas parte de este torneo que marcará el inicio de una nueva historia para nuestra comunidad 🎾🧡

Prepárate para competir, disfrutar un ambiente increíble y luchar por  $1.000.000 en membresías. Cada punto contará, cada partido será una experiencia y cada jugador hará parte de algo especial 🙌

⚡ Categoría 5ta – Parejas Fijas
⚡ Cupos limitados- (Round Robin)
⚡ Incluye choripán 🌭
⚡ Viernes 29 de mayo – 6:30 PM

Reúne a tu dupla, inscríbete y vive con nosotros esta gran inauguración. ¡Nos vemos en la cancha! 💥🎾

[21:16] **+57 318 5358260:** [Imagen] Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ reservado
🎾 Joseph Avendaño / David Gamboa
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

---

## 26 de mayo de 2026

[7:33] **+57 318 5358260:** Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 Sábado 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾 
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[8:44] __+57 311 5302421 se unieron mediante el enlace de invitación__

[8:44] **+57 318 5358260:** Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[8:49] **+57 322 7098313:** _Se eliminó este mensaje_

[8:49] **+57 322 7098313:** _Se eliminó este mensaje_

[9:50] __+57 316 7439601 se unieron mediante el enlace de invitación__

[10:47] **+57 318 5358260:** Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa / Fabia Barbosa
🎾
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[11:10] **+57 318 5358260:** Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa / Fabia Barbosa
🎾  Jaime Lozano / Jesús González
🎾
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[11:27] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 26 de mayo  
🕘 8:00 P.m 90:00 P.m
Categoría:  4TA/5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾
🎾

Quien se Anima!!! 🔥

[12:36] __@juanrr24 se unieron mediante el enlace de invitación__

[12:36] __@juanrr24 añadió a +57 350 5925007 y +57 312 4829489__

[12:48] **+57 318 5358260:** Una pala mas familia, quien se anima!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 26 de mayo  
🕘 5:30 P.m 7:00 P.m
Categoría:  4TA/5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Juan D.
🎾 Juan M.
🎾

Quien se Anima!!! 🔥

[13:00] **@marlon.iragorri:**
> _+57 318 5358260: Una pala mas familia, quien se anima!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 26 de mayo  
🕘 5:30 P.m 7:00 P.m
Categoría:  4TA/5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Juan D.
🎾 Juan M.
🎾

Quien se Anima!!! 🔥_
Yo

[13:01] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  HOY 26 de mayo  
🕘 5:30 P.m 7:00 P.m
Categoría:  4TA/5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Juan D.
🎾 Juan M.
🎾 Marlon 

NOS VEMOS EN LA CANCHA 🔥

[15:26] **+57 318 5358260:** Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa / Fabia Barbosa
🎾  Jaime Lozano / Jesús González
🎾  Cristian Gomez/ Fabian Barbosa
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[17:18] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa / Fabia Barbosa
🎾  Jaime Lozano / Jesús González
🎾  Cristian Gomez/ Fabian Barbosa
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[17:24] **+57 318 5358260:**
> _+57 318 5358260: 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  HOY 26 de mayo  
🕘 5:30 P.m 7:00 P.m
Categoría:  4TA/5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Juan D.
🎾 Juan M.
🎾 Marlon 

NOS VEMOS EN LA CANCHA 🔥_
Familia ya los estamos esperando, para este gran partido

[17:25] **+57 350 5925007:** Qué pena

[17:25] **+57 350 5925007:** Nunca habíamos venido

[17:25] **+57 350 5925007:** No sabíamos que era trancado llegar

[17:25] **+57 350 5925007:** [Imagen] Estamos al lado

[19:31] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa / Fabia Barbosa
🎾  Jaime Lozano / Jesús González
🎾  Cristian Gomez/ Fabian Barbosa
🎾
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[19:38] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa /Julian Avíla
🎾  Jaime Lozano / Jesús González
🎾  Cristian Gomez/ Fabian Barbosa
🎾 Cristian Cortes / Alfonso Cortes
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

---

## 27 de mayo de 2026

[11:04] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa /Julian Avíla
🎾  Jaime Lozano / Jesús González
🎾  Cristian Gomez/ Fabian Barbosa
🎾 Cristian Cortes / Alfonso Cortes
🎾
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[11:16] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
 
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa /Julian Avíla
🎾  Jaime Lozano / Jesús González
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[11:38] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳
🎾 Cristian Gomez/ Fabian Barbosa ☑️
🎾  Mao/ Alberto☑️
🎾 Daniel Alujere/ Tato
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  David Barbosa /Julian Avíla
🎾  Jaime Lozano / Jesús González
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[11:59] **+57 318 5358260:** 🔥 ¡Comunidad PadelTown Nomad Salitre! 🔥

Recuerden que seguimos con nuestro CONCURSO DE LANZAMIENTO y cada reserva, clase o entrenamiento los acerca más a ganar una membresía Orange por $500.000 COP 🧡🎾

🏆 Así va nuestro TOP 3 del Concurso de Lanzamiento 🏆

🥇 Diego Alvilar - 4.0 Puntos
🥈 Juanita Rojas — 3.5 Puntos
🥉  Mariana Vargas — 3.0 Puntos

🔥 La competencia está cada vez mejor y todavía estás a tiempo de subir en el ranking.

Recuerda:

🎾 Por cada Reserva suma 1 punto.
🎾 Por cada Academia suma 1 punto.
🎾Por cada Clase Personalizada suma 2 puntos.

📅 Tienes hasta el 31 de mayo para participar.
¡Vamos por más! 💪🧡

[15:14] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Alujere/ Tato
🎾 Mao/ Reservado
🎾 Daniel Preciado/ Daniel Quiroga 
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[15:43] __+57 319 6132748 se unieron mediante el enlace de invitación__

[15:44] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Daniel Alujere/ Tato
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[15:48] **+57 310 2192130:** Pueden dar más detalles ? Cuantos partidos se juegan mínimo ?  A cuántos set? 
Como Es el formato general del torneo ?

[16:06] **+57 318 5358260:**
> _+57 310 2192130: Pueden dar más detalles ? Cuantos partidos se juegan mínimo ?  A cuántos set? 
Como Es el formato general del torneo ?_
Buenas tardes Marcel.

El formato es Round robin, segun el numero de participantes va a ver un 3 grupos de 4 parejas o 4 grupos de 3 parejas. y de cada cuadro pasan 2 parejas.

[16:10] **+57 310 2192130:** Cuantos partidos mínimo ? 
A cuántos set?

[18:12] **+57 318 5358260:**
> _+57 310 2192130: Cuantos partidos mínimo ? 
A cuántos set?_
En cuadro de 4 parejas mínimos 3 partidos. Y en cuadro de 3 mínimo 2 partidos

[18:15] **+57 318 5358260:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Daniel Alujere/ Tato
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾
🎾

Quien se Anima!!!🔥🥳🎾💳

[18:25] **+57 311 8475699:** Cada partido de cuántos set son?

[18:30] **+57 318 5358260:**
> _+57 311 8475699: Cada partido de cuántos set son?_
Buenas tardes Edgardo, sera de 1 Set

[19:54] **@_Capi_00:** Aun contamos con cupos, Quien dijo YO!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Daniel Alujere/ Tato
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / busca partner 

Quien se Anima!!!🔥🥳🎾💳

[19:56] **+57 318 5358260:** Familia nos falta una pala para completar el Torneo, Quien se anima!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Daniel Alujere/ Tato
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / busca partner 

Quien se Anima!!!🔥🥳🎾💳

[19:58] **@_Capi_00:** Familia nos falta una pala para completar el Torneo, Quien se anima!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Daniel Alujere/ Tato
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾 Cristian Cortes / Alfonso Cortes
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado

Quien se Anima!!!🔥🥳🎾💳

[20:00] **+57 318 5358260:** TORNEO CERRADO 🔐🔐🔐
Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾 Joseph Avendaño / David Gamboa
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado

Nos vemos en la Cancha🔥🥳🎾💳

[20:30] **+57 318 5358260:** Nos falta una pareja para completar el torneo
Quien se anima!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado
🎾

Quien dijo Yoo!!?🔥🥳🎾💳

[20:40] **+57 318 5358260:** Nos falta una pareja para completar el torneo

Quien se anima!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado
🎾

Quien dijo Yoo!!?🔥🥳🎾💳

[20:46] **+57 321 4823713:** Cristian Ortiz

[20:46] **+57 321 4823713:** Lo aluengas porfa

[20:47] **+57 318 5358260:**
> _+57 321 4823713: Cristian Ortiz_
Claro Daniel, y Quien seria el partner

[20:47] **+57 318 5358260:** Nos falta una pareja para completar el torneo

Quien se anima!!!

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado
🎾 Cristian Ortiz/ reservado

Quien dijo Yoo!!?🔥🥳🎾💳

[20:56] **+57 322 7098313:** Pero yo veo 12 , porque falta una ?

[20:59] **+57 318 5358260:**
> _+57 322 7098313: Pero yo veo 12 , porque falta una ?_
Que pena nos equivocamos

[21:00] **+57 318 5358260:** TORNEO CERRADO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado
🎾 Cristian Ortiz/ reservado

Nos vemos en la Cancha!!🔥🥳🎾💳

---

## 28 de mayo de 2026

[9:46] **+57 318 5358260:** 🧡BUENOS DIAS FAMILIA PADELTOWN 🧡
🔥 ¡Hoy es el día para volver a la cancha! 🔥

En PadelTown cada partido es una oportunidad para mejorar, competir y disfrutar con la mejor energía. No dejes que otro ocupe tu lugar en la pista: reserva hoy, reúne a tu partner y ven a vivir la intensidad del pádel como se debe. 🎾

📅 Las canchas se llenan rápido… ¡asegura tu reserva y hagamos que hoy se juegue a otro nivel! 🚀

[12:06] **+57 318 5358260:** _Se eliminó este mensaje_

[12:32] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾 
🎾

Quien se Anima!!! 🔥

[12:47] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Daniel Quiroga  
🎾 
🎾

Quien se Anima!!! 🔥_
Yo

[12:48] **+57 318 5358260:** _Se eliminó este mensaje_

[12:49] **+57 318 5358260:** _Se eliminó este mensaje_

[12:51] **+57 314 2854357:**
> _+57 318 5358260: Nos Falta una pala, quien dijo YOOO

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Daniel Quiroga  
🎾 Marlon Irragorri 
🎾

Quien se Anima!!! 🔥_
Hay disponibilidad

[12:51] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾 Daniel
🎾

Quien se Anima!!! 🔥

[12:51] **+57 318 5358260:**
> _+57 314 2854357: Hay disponibilidad_
si sr

[12:51] **+57 318 5358260:** deseas unirte al partido

[13:19] **+57 314 2854357:** Si

[13:24] **+57 318 5358260:** _Se eliminó este mensaje_

[13:45] **+57 304 1210250:**
> _+57 318 5358260: 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Daniel Quiroga  
🎾 Marlon Irragorri 
🎾 Daniel Aljure

Nos vemos en la cancha!!! 🔥_
Me toca bajarme, no alcanzo a llegar 😔

[13:46] **+57 318 5358260:** _Se eliminó este mensaje_

[13:55] **+57 321 9801846:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾 Daniel
🎾

Quien se Anima!!! 🔥_
Alejandro

[13:57] **+57 318 5358260:** _Se eliminó este mensaje_

[13:57] **+57 321 9801846:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾 Daniel
🎾

Quien se Anima!!! 🔥_
Aca decia 6pm

[13:58] **@marlon.iragorri:** [Sticker]

[13:58] **+57 318 5358260:**
> _+57 321 9801846: Aca decia 6pm_
perdon, me equivoque ya lo corrijo

[13:59] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾 Daniel
🎾 Alejandro

Nos vemos en la cancha!!! 🔥

[14:34] **+57 318 5358260:** _Se eliminó este mensaje_

[14:39] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

Nos vemos en la cancha!!! 🔥

[14:50] **+57 318 5358260:** Nos faltan Dos pala, Quien se Anima

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾
🎾 

Nos vemos en la cancha!!! 🔥

[15:02] **+57 318 5358260:** Nos faltan Dos pala, Quien se Anima

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 8:00P.m 9:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾
🎾 

Nos vemos en la cancha!!! 🔥

[16:49] **+57 318 5358260:**
> _+57 318 5358260: Nos faltan Dos pala, Quien se Anima

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 28 de mayo  
🕘 8:00P.m 9:30 P.m
Categoría:  5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾
🎾 

Nos vemos en la cancha!!! 🔥_
Partido Cancelado

[18:18] **+57 318 5358260:** 🔥 ¡Comunidad PadelTown Nomad Salitre! 🔥

Recuerden que seguimos con nuestro CONCURSO DE LANZAMIENTO y cada reserva, clase o entrenamiento los acerca más a ganar una membresía Orange por $500.000 COP 🧡🎾

🏆 Así va nuestro TOP 3 del Concurso de Lanzamiento 🏆

🥇 Diego Alvilar - 5.0 Puntos
🥈 Juanita Rojas — 3.5 Puntos
🥉  Mariana Vargas — 3.0 Puntos

🔥 La competencia está cada vez mejor y todavía estás a tiempo de subir en el ranking.

Recuerda:

🎾 Por cada Reserva suma 1 punto.
🎾 Por cada Academia suma 1 punto.
🎾Por cada Clase Personalizada suma 2 puntos.

📅 Tienes hasta el 31 de mayo para participar.
¡Vamos por más! 💪🧡

[19:18] __+57 324 5114438 se unieron mediante el enlace de invitación__

[19:55] __+57 311 2870982 se unieron mediante el enlace de invitación__

---

## 29 de mayo de 2026

[7:19] **+57 318 5358260:** Familia nos queda una pareja más, quien se anima!!!

TORNEO ABIERTO

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado
🎾 

Nos vemos en la Cancha!!🔥🥳🎾💳

[7:53] __@_Capi_00 añadió a @Arquiteck__

[7:53] __Alguien añadió a @Arquiteck__

[7:57] **+57 318 5358260:** Familia nos queda una pareja más, quien se anima!!!

TORNEO ABIERTO

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / BUSCA PARTNER  
🎾 

Nos vemos en la Cancha!!🔥🥳🎾💳

[9:45] __@_Capi_00 añadió a +57 311 5147146__

[10:52] **+57 318 5358260:** Familia nos queda una persona buscando PARTNER, quien se animaa!!!
TORNEO ABIERTO

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / BUSCA PARTNER  
🎾 Camilin / reservado 

Nos vemos en la Cancha!!🔥🥳🎾💳

[11:33] **+57 311 4741908:** _Un admin., +57 318 5358260, eliminó este mensaje._

[12:05] **@Arquiteck:**
> _+57 318 5358260: Familia nos queda una persona buscando PARTNER, quien se animaa!!!
TORNEO ABIERTO

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / BUSCA PARTNER  
🎾 Camilin / reservado 

Nos vemos en la Cancha!!🔥🥳🎾💳_
Busco PARTNER

[13:06] **@_Capi_00:** Familia nos queda una persona buscando PARTNER, quien se animaa!!!
TORNEO ABIERTO

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / Reservado 
🎾 Camilin / reservado 

Nos vemos en la Cancha!!🔥🥳🎾💳

[13:10] **+57 318 5358260:** TORNEO CERRADO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾 Daniel Alujere/ Tato
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado
🎾 Camilin / reservado 

Nos vemos en la Cancha!!🔥🥳🎾💳

[13:28] **+57 318 5358260:** 🎾🔥 Familia PadelTown 🔥🎾

Les recordamos que el torneo de hoy inicia a las 7:00 p.m. ⏰
Lleguemos 6:30 pm para calentar nuestros motores 🔥

⚠️ A tener en cuenta:
Daremos inicio con los participantes que estén PUNTUALES en la cancha 🔥

Arrancamos puntuales y le sacamos todo el provecho a la jornada 💪😎

¡Nos vemos en cancha! 🎾🔥

Les recordamos que esta es nuestra dirección

[13:28] **+57 318 5358260:** Ubicación: 4.6426581, -74.1114628 — https://maps.google.com/?q=4.6426581,-74.1114628

[16:12] **+57 318 5358260:** Familia nos falta una pareja para completar el torneo, quien dijo Yoo!!!

TORNEO ABIERTO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / reservado
🎾 Camilin / reservado 
🎾 

Nos vemos en la Cancha!!🔥🥳🎾💳

[16:28] **@jesus_danielg:** Que precio tiene?

[16:31] **+57 318 5358260:**
> _@jesus_danielg: Que precio tiene?_
Buenas tardes Jesus, 100.000 pesos por jugador

[16:43] **@_Capi_00:** Familia nos falta una pareja para completar el torneo, quien dijo Yoo!!!

TORNEO ABIERTO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / Busca partner
🎾 Camilin / reservado 
🎾 

Nos vemos en la Cancha!!🔥🥳🎾💳

[16:44] **@gdanderino:** ☝️yo pero busco partner

[16:46] **+57 318 5358260:** Familia nos falta una pareja para completar el torneo, quien dijo Yoo!!!

TORNEO ABIERTO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / Gustavo Danderino
🎾 Camilin / reservado 
🎾 

Nos vemos en la Cancha!!🔥🥳🎾💳

[16:58] **+57 318 5358260:** Familia nos falta una pareja para completar el torneo, quien dijo Yoo!!!

TORNEO ABIERTO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / Busca Partner
🎾 Camilin / reservado 
🎾 

Nos vemos en la Cancha!!🔥🥳🎾💳

[17:06] **+57 318 5358260:** Familia nos falta una persona para completar el torneo, quien dijo Yoo!!!

TORNEO ABIERTO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / Busca Partner
🎾 Camilin / reservado 
🎾 Harold/ Joseph avendaño 

Nos vemos en la Cancha!!🔥🥳🎾💳

[17:17] **+57 318 5358260:** Familia les compartimos la ubicación

[17:17] **+57 318 5358260:** Ubicación: 4.6426459, -74.1114376 — https://maps.google.com/?q=4.6426459,-74.1114376

[17:27] **+57 318 5358260:** Familia nos falta una persona para completar el torneo, quien dijo Yoo!!!

TORNEO ABIERTO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / Gustavo Danderino
🎾 Camilin / reservado 
🎾 Harold/ Joseph avendaño 

Nos vemos en la Cancha!!🔥🥳🎾💳

[17:36] **+57 318 5358260:** TORNEO CERRADO🔐🔐🔐

Prepárate para vivir una jornada llena de competencia, emoción y mucho pádel en nuestro Torneo Inauguración Nomad 🎾💙

🏆 Compite por $1.000.000 en membresías
👥 Categoría: 5ta – Parejas Fijas
🌭 La inscripción incluye choripán
📍 Sede: Nomad Salitre
📅 VIERNES 29 de mayo – 6:30 PM

🏆🔥 PREMIOS 🔥🏆

🥇 1er lugar pareja
Membresia Orange para cada jugador

Será el espacio perfecto para compartir con la comunidad, disfrutar grandes partidos y celebrar juntos esta nueva etapa de PadelTown y Nomad.

⚠️ Cupos limitados ( Round Robin), así que asegura tu lugar cuanto antes.
📲 Inscripciones: 318 5358260
 ¡Arma tu dupla y aseguren su lugar YA! 🥳

🎾  David Barbosa /Julian Avíla☑️
🎾  Cristian Gomez/ Fabian Barbosa ☑️
🎾 Daniel Preciado/ Daniel Quiroga  ☑️
🎾 Mao/ Reservado ☑️
🎾 Cristian Cortes / Alfonso Cortes☑️
🎾  David Medina / Diego Castillo 
🎾  Jaime Lozano / Jesús González
🎾  Marlon / Neiber 
🎾 Daniel R / Alex Pinzón 
🎾 Pablo Rodriguez / Gustavo Danderino
🎾 Camilin / reservado 
🎾 Harold/ Joseph avendaño 

Nos vemos en la Cancha!!🔥🥳🎾💳

---

## 30 de mayo de 2026

[9:40] **+57 318 5358260:** [Imagen] 🎾⚽️ ¡Hoy PadelTown tiene el plan perfecto para ti! 🔥

Si todavía no sabes qué hacer este sábado, ya tienes excusa 😎

Nos espera una jornada llena de emoción con la Final de Champions, nuestro combo especial de choripán + bebida + sobre Panini por solo $20.000, la cambiatón Panini para completar el álbum y toda la mejor energía de nuestra comunidad 💚

Y para cerrar la tarde, disfrutaremos de nuestro torneo de 5ta categoría, donde el pádel será el gran protagonista 🎾✨

Hoy es un día para compartir con amigos, venir en familia, disfrutar del deporte y pasarla bueno dentro y fuera de la cancha.

📍Te esperamos en PadelTown Plaza de las Américas. ¡Nos vemos en el club!🎾🔥

[10:02] **+57 310 2192130:** Tienen Fotos del Torneo de anoche ?

[12:33] **+57 314 2854357:** Don Albertico como amaneció

---

## 31 de mayo de 2026

[10:52] **+57 318 5358260:** [Imagen] 🇨🇴Hoy premiamos tu compromiso con Colombia🇨🇴¿Ya votaste? Presenta tu
certificado electoral en PadelTown y recibe $10.000 de descuento en nuestros servicios (no aplica para alimentos) .Es la excusa perfecta para salir de casa, disfrutar un gran partido de pádel y aprovechar este beneficio especial. 🔥
Te esperamos en PadelTown📍
¡Ven a jugar, compartir y vivir un domingo diferente! 🎾

[11:14] **+57 321 9801846:** [Mensaje de album]

[11:14] **+57 321 9801846:** [Imagen] En venta

[11:14] **+57 321 9801846:** [Imagen]

[13:56] **+57 318 5358260:** Nos faltan Dos pala, Quien se Anima

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 31 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾
🎾 

Nos vemos en la cancha!!! 🔥

[13:58] **@Josebrm:**
> _+57 318 5358260: Nos faltan Dos pala, Quien se Anima

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 31 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾
🎾 

Nos vemos en la cancha!!! 🔥_
🙋🏼‍♂️

[13:58] **+57 318 5358260:** Nos faltan una pala, Quien se Anima

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 31 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾 Jose 
🎾 

Nos vemos en la cancha!!! 🔥

[14:01] **+57 323 3659144:**
> _+57 321 9801846: [album]_
A cómo ?

[14:48] **+57 310 2578035:** Voy

[14:48] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  HOY 31 de mayo  
🕘 6:00P.m 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Sergio
🎾 Jose 
🎾 Enrique

Nos vemos en la cancha!!! 🔥

[16:55] **+57 310 2578035:** Buenas tardes , todos confirmados ???

[16:56] **+57 316 3099922:** confirmo Sebastian y Sergio

[16:56] **@Josebrm:** 🙋🏼‍♂️

[16:58] **+57 318 5358260:** Los esperamos en la cancha

[17:08] **+57 310 2578035:** Y José??

[17:14] **+57 310 2578035:** Ok

[17:37] **+57 310 2578035:** Me envías la ubicación

[17:38] **+57 318 5358260:** Ubicación: 4.642352, -74.1115154 — https://maps.google.com/?q=4.642352,-74.1115154

---

## 1 de junio de 2026

[14:10] **+57 318 5358260:** 🎾 ¡Hola, comunidad de PadelTown! 🎾

Esperamos que estén teniendo una excelente semana. Queremos agradecerles por ser parte de esta gran comunidad que comparte la pasión por el pádel, el deporte, la amistad y los buenos momentos en la cancha.

Además, les contamos que tenemos disponibilidad de pistas y horarios para que vengan a jugar, entrenar o disfrutar de un buen partido con amigos. 💪🔥

No dejen pasar la oportunidad de seguir mejorando su juego y pasar un rato increíble. ¡Los esperamos en la cancha!

📅 Reserva tu espacio y ven a disfrutar del mejor pádel con nosotros. ¡Nos vemos pronto! 🎾😊

[14:12] **+57 318 5358260:** Familia nos faltan 2 palas para que se de este partido, Quien dijo YOOO!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 5:00P.m 6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Reservado 
🎾 
🎾 

Nos vemos en la cancha!!! 🔥

[14:13] **@sebastian_chip:** Familia nos faltan 2 palas para que se de este partido, Quien dijo YOOO!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 5:00P.m 6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Reservado 
🎾 Sebastian D. 
🎾 

Nos vemos en la cancha!!! 🔥

[14:13] **+57 318 5358260:**
> _@sebastian_chip: Familia nos faltan 2 palas para que se de este partido, Quien dijo YOOO!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 5:00P.m 6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Reservado 
🎾 Sebastian D. 
🎾 

Nos vemos en la cancha!!! 🔥_
Familia nos falta 1 pala, Quien se Apunta!!!

[14:14] **@marlon.iragorri:**
> _@sebastian_chip: Familia nos faltan 2 palas para que se de este partido, Quien dijo YOOO!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 5:00P.m 6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Reservado 
🎾 Sebastian D. 
🎾 

Nos vemos en la cancha!!! 🔥_
Yo

[14:14] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 5:00P.m 6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Reservado 
🎾 Sebastian D. 
🎾 Marlon 

Nos vemos en la cancha!!! 🔥

[14:15] **@marlon.iragorri:**
> _+57 318 5358260: Familia nos faltan 2 palas para que se de este partido, Quien dijo YOOO!!!

🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 5:00P.m 6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan A.
🎾 Reservado 
🎾 Sebastian D. 
🎾 Marlon 

Nos vemos en la cancha!!! 🔥_
Ya no faltan palas jejeje dice que faltan dos

[14:17] **+57 318 5358260:**
> _@marlon.iragorri: Ya no faltan palas jejeje dice que faltan dos_
ya lo arregle, jaj que pena con ustedes

[15:17] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 7:00 P.m 9:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!! 🔥

[19:26] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 01 de Junio
🕘 8:00 P.m 10:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!! 🔥

---

## 2 de junio de 2026

[7:54] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 02 de Junio
🕘 10:00A.m-11:00 A.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!

[14:17] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 02 de Junio
🕘 5:00P.m-6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!

[16:14] **+57 321 9801846:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 02 de Junio
🕘 5:00P.m-6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!_
Alejandro

[16:18] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 02 de Junio
🕘 5:00P.m-6:30 P.m
Categoría:  5TA
💰 Precio por jugador: 35.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Alejandro
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!

[16:29] **+57 318 5358260:** _Se eliminó este mensaje_

[16:35] **+57 314 2854357:** Sábado am no se puede

[16:37] **+57 318 5358260:** **Encuesta: 🎾 ¡Queremos escuchar a nuestra comunidad de PadelTown Nomad! 🎾Estamos organizando un Torneo Americano Individual Categoría 5ta y queremos saber cuál horario prefieren para participar.📅 ¿Qué día te queda mejor?**
- Sabado 11:00 Am 1:00 PM
- Sabado 8:00 Pm 10:00 PM
- Domingo 6:00 Pm 8:00 Pm
- Lunes 3:00 Pm 5:00Pm

---

## 3 de junio de 2026

[15:57] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 03 de Junio
🕘 6:00P.m - 7:30 P.m
Categoría:  5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!

[19:10] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 03 de Junio
🕘 8:30P.m - 10:00 P.m
Categoría:  5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!

---

## 4 de junio de 2026

[16:14] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 04 de Junio
🕘 8:00P.m - 10:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!

---

## 5 de junio de 2026

[14:41] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 05 de Junio
🕘 6:00P.m - 8:00 P.m
Categoría:  5TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!

[14:52] __+57 312 4284273 se unieron mediante el enlace de invitación__

[18:37] __+57 320 4949095 se unieron mediante el enlace de invitación__

[18:38] __Alguien añadió a +57 320 4949095__

---

## 6 de junio de 2026

[7:42] **+57 318 5358260:** 🔥*PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 06 de Junio
🕘 12:00 P.m - 2:00 P.m
Categoría:  5TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!*

[11:11] **+57 318 5358260:** 🔥*PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  HOY 06 de Junio
🕘 4:00 P.m - 6:00 P.m
Categoría:  6TA / 5TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Nos vemos en la cancha!!!*

---

## 7 de junio de 2026

[8:50] **+57 318 5358260:** [Imagen] ☀️ ¡Feliz domingo! Hoy es un día perfecto para disfrutar del sol, compartir con amigos y vivir grandes momentos.

🎾 Ven y disfruta de un emocionante partido de pádel en nuestras instalaciones. Y además, queremos ayudarte a completar tu álbum del Mundial. ⚽🌎

 Por cada reserva que realices, te obsequiamos *2 sobres de monas* para que estés cada vez más cerca de llenarlo.

Aprovecha este domingo para divertirte, hacer deporte y seguir sumando figuras a tu colección.

 ¡Haz tu reserva ahora y disfruta del mejor pádel mientras completas tu álbum del Mundial!

[9:26] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  7 de Junio  
🕘 12:00 P.m 13:00 P.m
Categoría: 5TA- 6TA
💰 Precio por jugador: 20,000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

Quien se Apunta!!! 🔥

[15:55] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆  7 de Junio  
🕘 6:00 P.m 8:00 P.m
Categoría: 5TA- 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

Quien se Apunta!!! 🔥

---

## 8 de junio de 2026

[9:10] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 8 De Junio
Categoría:  5ta-6ta
Valor: 20.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  12:00 pm A 1:00 pm
🎾       
🎾          
🎾          
🎾  

Partido Abierto 💥

[15:25] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 8 De Junio
Categoría:  5ta-6ta
Valor: 40.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  06:00 pm A 8:00 pm
🎾       
🎾          
🎾          
🎾  

Partido Abierto 💥

[18:33] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 8 De Junio
Categoría:  5TA
Valor: 40.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  08:00 pm A 10:00 pm
🎾       
🎾          
🎾          
🎾  

Partido Abierto 💥

---

## 9 de junio de 2026

[7:52] **+57 318 5358260:** 🎾🔥 ¡Hoy es un gran día para jugar pádel! 🔥🎾

Cada partido es una oportunidad para mejorar, competir, compartir con amigos y disfrutar de este deporte que tanto nos apasiona.
No dejes que otro ocupe tu espacio en la cancha. Reserva hoy, ponte los tenis, toma tu pala y ven a vivir la emoción de cada punto. 💪🏽

Recuerda: los grandes partidos comienzan con una simple decisión... ¡reservar tu cancha! 🎯

Te esperamos para seguir construyendo juntos esta gran comunidad de pádel. 🧡

📲 ¡Reserva ahora y nos vemos en la cancha!

[17:35] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 8 De Junio
Categoría:  5TA
Valor: 60.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  08:00 pm A 10:00 pm
🎾       
🎾          
🎾          
🎾  

Partido Abierto 💥

[17:57] **+57 318 5358260:** **Encuesta: 🎾 ¡Queremos escuchar a nuestra comunidad de PadelTown Nomad! 🎾Estamos organizando un Torneo Americano Individual Categoría 5ta y queremos saber cuál horario prefieren para participar.📅 ¿Qué día te queda mejor?**
- Viernes 8:00 Pm a 10:00 Pm
- Sabado 11:00 Am 1:00 Pm
- sabado 8: 00 Pm a 10:00 pm
- Lunes 4:00 Pm 6:00 pm

---

## 10 de junio de 2026

[12:30] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 10 De Junio
Categoría:  5TA
Valor: 60.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  08:00 pm A 10:00 pm
🎾       
🎾          
🎾          
🎾  

Partido Abierto 💥

[17:09] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 10 De Junio
Categoría:  6Ta / 5Ta
Valor: 60.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  07:00 pm A 9:00 pm
🎾       
🎾          
🎾          
🎾  

Partido Abierto 💥

[18:00] __@figuesito se unieron mediante el enlace de invitación__

---

## 11 de junio de 2026

[16:03] __+57 310 7673415 se unieron mediante el enlace de invitación__

[18:31] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 11 De Junio
Categoría:  5TA
Valor: 60.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  08:00 pm A 10:00 pm
🎾       
🎾          
🎾          
🎾  
Quien se Anima!!

[19:14] **+57 318 5358260:** **Encuesta: Familia PadelTown Nomad 🔥🎾 Tendremos Torneo Americano 5TA Categoria INDIVIDUAL el dia sabado 13 de Junio, Queremos saber en que horario les queda mejor.**
- Sabado 9:00 Am 11:00Am
- Sabado 11:00 Am 1:00 Pm

---

## 12 de junio de 2026

[9:23] **+57 318 5358260:** [Imagen] 🔥 HOY ESTAMOS EN MODO MUNDIAL 🔥
Pantalla encendida, ambiente mundialista y el mejor parche en PadelTown ⚽🎾

📺 Partidos de hoy (hora Colombia):
🇨🇦 Canadá 🆚 🇧🇦 Bosnia y Herzegovina — 2:00 p.m.
🇺🇸 Estados Unidos 🆚 🇵🇾 Paraguay — 8:00 p.m.

Ven a jugar, quédate a ver el partido y vive el Mundial como se debe 🧡🏆

[15:36] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 12 De Junio
Categoría:  5TA
Valor: 50.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  05:00 pm A 7:00 pm
🎾       
🎾          
🎾          
🎾  
Quien se Anima!!

[20:56] __+57 322 8380216 se unieron mediante el enlace de invitación__

[20:56] __Alguien añadió a +57 322 8380216__

---

## 13 de junio de 2026

[7:27] __+52 1 984 254 2912 se unieron mediante el enlace de invitación__

[7:27] __Alguien añadió a +52 1 984 254 2912__

[9:57] **+57 318 5358260:** PARTIDO ABIERTO
📍 PadelTown Nomad

Hoy: 13 De Junio
Categoría:  5TA
Valor: 40.000 por persona 
🟠 Miembros Orange : 20% DCTO
⚫ Miembros Black: 30% DCTO 
⌚  07:00 pm A 9:00 pm
🎾       
🎾          
🎾          
🎾  
Quien se Anima!!

[15:33] __@PadelTownSantafe se unieron mediante el enlace de invitación__

[15:37] __+57 310 5949695 se unieron mediante el enlace de invitación__

---

## 14 de junio de 2026

[10:37] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad Salitre  
📆  14 de Junio  
🕘 03:00 P.m 04:00 P.m
Categoría: 5TA- 6TA
💰 Precio por jugador: 20,000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

Quien se Apunta!!! 🔥

[19:14] __@linacandia se unieron mediante el enlace de invitación__

[19:14] __Alguien añadió a @linacandia__

---

## 15 de junio de 2026

[10:57] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad Salitre  
📆  15 de Junio  
🕘 05:00 P.m 07:00 P.m
Categoría: 5TA- 6TA
💰 Precio por jugador: 40.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

Quien se Apunta!!! 🔥

[15:26] __+57 310 5045707 se unieron mediante el enlace de invitación__

---

## 16 de junio de 2026

[14:06] **+57 318 5358260:** [Imagen] ¡Familia Nomad! 🔥

¿Qué mejor manera de vivir el Mundial que combinando pádel, amigos y unas buenas cervezas? 🍺

👉 Reserva tu cancha hoy en PadelTown Nomad, disfruta de un gran partido de pádel y, al terminar, quédate con nosotros para ver el partido del Mundial en un ambiente espectacular.

🏆 Pádel
🍻 Cervezas bien frías
⚽ Fútbol del Mundial
🤝 Buena compañía y la mejor energía

No dejes tu reserva para última hora. ¡Arma tu parche, juega, celebra y vive una noche diferente en PadelTown Nomad!

📲 Reserva ahora y asegura tu cancha.

PadelTown Nomad: donde el pádel y la pasión por el deporte se viven al máximo. 🔥🎾⚽🍺

[17:12] **+57 318 5358260:** 🎾🔥 ¡Familia PadelTown! 🔥🎾

Algo grande está por llegar a nuestra sede de *PadelTown Nomad*... 👀

Estamos preparando una sorpresa que hará de este mes uno de los mejores del año. 🚀

⏳ Mantente atento, porque en pocos minutos revelaremos una novedad que no te querrás perder.

💥 Lo mejor está por llegar.
📲 ¡Pendientes de nuestras redes y estados!

#PadelTownNomad #SeVieneAlgoGrande #StayTuned

[18:15] **+57 318 5358260:** [Imagen] 🎾🔥 ¡Llegó la promo que estabas esperando! 🔥🎾

Reserva tu cancha en *PadelTown Nomad* y aprovecha nuestro increíble *2x1 en alquiler de cancha* en horario valle.

⏰ Horarios de la promoción:
📅 Lunes a Viernes: 7:00 a.m. - 5:00 p.m.
📅 Sábados, Domingos y Festivos: 12:00 p.m. - 10:00 p.m.

👥 Reúne a tus amigos, arma el partido y disfruta más pádel por menos.

📲 Reserva ahora y aprovecha esta oportunidad por tiempo limitado.

---

## 17 de junio de 2026

[7:41] **+57 318 5358260:** [Imagen] 🎾🔥 ¡Llegó la promo que estabas esperando! 🔥🎾

Reserva tu cancha en *PadelTown Nomad* y aprovecha nuestro increíble *2x1 en alquiler de cancha* en horario valle.

⏰ Horarios de la promoción:
📅 Lunes a Viernes: 7:00 a.m. - 5:00 p.m.
📅 Sábados, Domingos y Festivos: 12:00 p.m. - 10:00 p.m.

👥 Reúne a tus amigos, arma el partido y disfruta más pádel por menos.

📲 Reserva ahora y aprovecha esta oportunidad por tiempo limitado.

[9:10] **+57 318 5358260:** _Se eliminó este mensaje_

[9:13] **+57 318 5358260:** [Imagen] 🔥🏆 ¡HOY EL MUNDIAL SE VIVE EN PADELTOWN NOMAD! 🏆🔥

La pasión del fútbol, la emoción del pádel y el mejor ambiente se unen esta noche para vivir una jornada inolvidable. ⚽🎾🍻

📺 Partidos de hoy !!!

🇵🇹 Portugal 🆚 RD Congo 🇨🇩 ⏰ 12:00 PM
🏴 Inglaterra 🆚 Croacia 🇭🇷 ⏰ 3:00 PM
🇬🇭 Ghana 🆚 Panamá 🇵🇦 ⏰ 6:00 PM
🇺🇿 Uzbekistán 🆚 Colombia 🇨🇴 ⏰ 9:00 PM

🎾 Ven con tus amigos, juega tu mejor partido y quédate a disfrutar cada gol, cada jugada y cada emoción del Mundial.

🍺 Cervezas bien frías
🎾 El mejor pádel
⚽ Todos los partidos en vivo
🤝 El mejor parche deportivo de la ciudad

Porque hay momentos que no se ven desde casa... se viven entre amigos, celebrando cada punto y cada gol.

💥 Reserva tu cancha, arma tu parche y vive una noche llena de deporte, emoción y pasión mundialista.

🧡 PadelTown Nomad Salitre
⚽ El Mundial se juega en la cancha, pero se vive en el club

[10:10] **+57 318 5358260:** [Imagen] 🍻🔥 ¡ATENCIÓN FAMILIA NOMAD SALITRE! 🔥🍻

Después de un gran partido de pádel, llega el momento perfecto para compartir con amigos y disfrutar del mejor ambiente del club.

🎉 Aprovecha nuestra promoción de cerveza 3x4:
Pide 4 cervezas y paga solo 3. 🍺🍺🍺🍺

🎾 Juega
⚽ Disfruta del Mundial en pantalla
🍻 Comparte unas cervezas bien frías
🤝 Vive el mejor tercer tiempo🫂

[17:43] **+57 312 5549788:** [Imagen]

[17:48] **+57 312 5549788:** _Se eliminó este mensaje_

[18:47] **+57 318 5358260:** [Imagen] 🍻🔥 ¡ATENCIÓN FAMILIA NOMAD SALITRE! 🔥🍻

Después de un gran partido de pádel, llega el momento perfecto para compartir con amigos y disfrutar del mejor ambiente del club.

🎉 Aprovecha nuestra promoción de cerveza 3x4:
Pide 4 cervezas y paga solo 3. 🍺🍺🍺🍺

🎾 Juega
⚽ Disfruta del Mundial en pantalla
🍻 Comparte unas cervezas bien frías
🤝 Vive el mejor tercer tiempo🫂

---

## 18 de junio de 2026

[8:41] **+57 318 5358260:** [Imagen] 🍻🔥 ¡ATENCIÓN FAMILIA NOMAD SALITRE! 🔥🍻

Después de un gran partido de pádel, llega el momento perfecto para compartir con amigos y disfrutar del mejor ambiente del club.

🎉 Aprovecha nuestra promoción de cerveza 3x4:
Pide 4 cervezas y paga solo 3. 🍺🍺🍺🍺

[8:44] **+57 318 5358260:** [Imagen] ⚽🔥 ¡Vive la emoción del Mundial en PadelTown! 🔥⚽

Reúne a tus amigos, disfruta de cada partido, el mejor ambiente deportivo y aprovecha nuestra promoción de cervezas. 🍻

📍 Te esperamos para alentar juntos a tu selección favorita y vivir cada gol como si estuvieras en el estadio.

¡El Mundial se vive mejor en PadelTown! 🌎⚽🙌

[8:47] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 04:00 P.m 6:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[9:48] **+57 318 5358260:** [Imagen] Hola Chicas buenos días !!!
Aún nos quedan cupos para El Torneo del Sábado en Plaza Claro
No olvides que si tienes tu membresía black tienes el 30% de descuento, si cuentas con tu Membresía Orange tienes el 20% en el valor de tu inscripción

[11:59] **@Daniel_preciadov:** Buenas tardes .
Algún partido hoy  de 8pm a 10 pm ?

[12:11] **@cristian_D_nustes:**
> _@Daniel_preciadov: Buenas tardes .
Algún partido hoy  de 8pm a 10 pm ?_
El de México Corea jajajaja😔😔

[12:17] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[12:19] **+57 318 5358260:** [Imagen] 🔥🍻 ¡ATENCIÓN FAMILIA NOMAD SALITRE! 🔥🍻

Después de un gran partido de pádel, llega el momento perfecto para compartir con amigos y disfrutar del mejor ambiente del club.

🎉 Aprovecha nuestra promoción de cerveza 3x4:
Pide 4 cervezas y paga solo 3. 🍺🍺🍺🍺

[12:19] **@Daniel_preciadov:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥_
2 pm ?

[12:25] **@NicolasDuarteB:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥_
60k por persona???

[12:31] **+57 318 5358260:** _Se eliminó este mensaje_

[12:35] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 04:00 P.m 06:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[12:39] **+57 318 5358260:** [Imagen] 🎾🔥 ¡Llegó la promo que estabas esperando! 🔥🎾

Reserva tu cancha en *PadelTown Nomad* y aprovecha nuestro increíble *2x1 en alquiler de cancha* en horario valle.

⏰ Horarios de la promoción:
📅 Lunes a Viernes: 7:00 a.m. - 5:00 p.m.
📅 Sábados, Domingos y Festivos: 12:00 p.m. - 10:00 p.m.

👥 Reúne a tus amigos, arma el partido y disfruta más pádel por menos.

📲 Reserva ahora y aprovecha esta oportunidad por tiempo limitado

[12:44] **+57 305 7120798:**
> _+57 318 5358260: Imagen: 🎾🔥 ¡Llegó la promo que estabas esperando! 🔥🎾

Reserva tu cancha en *PadelTown Nomad* y aprovecha nuestro increíble *2x1 en alquiler de cancha* en horario valle.

⏰ Horarios de la promoción:
📅 Lunes a Viernes: 7:00 a.m. - 5:00 p.m.
📅 Sábados, Domingos y Festivos: 12:00 p.m. - 10:00 p.m.

👥 Reúne a tus amigos, arma el partido y disfruta más pádel por menos.

📲 Reserva ahora y aprovecha esta oportunidad por tiempo limitado_
La promo es que se reserva una hora y dan dos ?

[12:46] **+57 315 7860273:**
> _+57 305 7120798: La promo es que se reserva una hora y dan dos ?_
X2

[12:46] **+57 318 5358260:** Si, exactamente

[12:46] **+57 318 5358260:** Recuerda, únicamente en hora valle

[12:48] **@Daniel_preciadov:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥_
Voy

[12:49] **@cristian_D_nustes:** Tambien voy

[12:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 04:00 P.m 06:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Cris
🎾 
🎾 

Nos faltan dos palas
Quien se Apunta!!! 🔥

[13:22] **@Daniel_preciadov:** Yo puedo de 8 pm a 10 pm

[13:38] **+57 318 5358260:** Hola Daniel, ya te abro partido en ese horario, pero recuerda que a esa hora ya no aplica la promo

[13:40] **@Daniel_preciadov:**
> _+57 318 5358260: Hola Daniel, ya te abro partido en ese horario, pero recuerda que a esa hora ya no aplica la promo_
Dale no hay problema

[13:41] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[13:49] **+57 318 5358260:**
> _@cristian_D_nustes: Tambien voy_
Te apuntas a ese en ese horario?

[13:49] **@cristian_D_nustes:** SI

[13:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Cris
🎾 
🎾 

Quien se Apunta!!! 🔥

[13:52] **+57 318 5358260:** [Imagen] 🔥🍻 ¡ATENCIÓN FAMILIA NOMAD SALITRE! 🔥🍻

Después de un gran partido de pádel, llega el momento perfecto para compartir con amigos y disfrutar del mejor ambiente del club.

🎉 Aprovecha nuestra promoción de cerveza 3x4:
Pide 3 cervezas y lleva 4. 🍺🍺🍺🍺

[15:22] **+57 318 5358260:** Familia nos faltan 2 palas, para que se de este partido. Quien dijo YOO??

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Cris
🎾 
🎾 

Quien se Apunta!!! 🔥

[15:47] **+57 318 5358260:** Familia PadelTown !! 

Que tal un partido de Padel, luego unas cervezas viendo los partidos del Mundial??⚽⚽

Pues es el Plan Perfecto y acá en PadelTown lo hacemos realidad...🔝🔝

Vengan, Jueguen y disfruten de los mejores deportes del Mundo 🌎🌎

[15:48] **+57 318 5358260:** [Imagen]

[17:09] **+57 318 5358260:** Familia nos faltan 2 palas, para que se de este partido. Quien dijo YOO??

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Cris
🎾 
🎾 

Quien se Apunta!!! 🔥

[18:06] **+57 318 5358260:** Familia nos faltan 2 palas, para que se de este partido. Quien dijo YOO??

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Mayo  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA-6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Preciado
🎾 Cris
🎾 
🎾 

Quien se Apunta!!! 🔥

[18:28] **+57 318 5358260:** 🚨🔥 ¡FAMILIA PADELTOWN NOMAD! 🔥🚨

¡No dejen pasar esta oportunidad! 🎾💥

✅ *2x1 en canchas en horario valle*
✅ Más tiempo de juego
✅ Más diversión con tus amigos

📅 *Reserva desde ya para mañana* y asegura tu espacio antes de que se agoten los horarios disponibles.

¡Es el momento perfecto para venir a la cancha, competir y disfrutar al máximo! 💪🎾

📲 Reserva ahora y aprovecha esta promoción exclusiva.

[18:39] **+57 318 5358260:** [Imagen] 🔥🔥🎾🎾

---

## 19 de junio de 2026

[8:13] **+57 318 5358260:** [Imagen] 🏆⚽🎾 Familia PadelTown 🎾⚽🏆

El Mundial se vive mejor cuando se comparte. 🧡

Te invitamos a reservar tu cancha, disfrutar de una buena partida de pádel con amigos y luego quedarte con nosotros para vibrar, celebrar y sufrir cada jugada del Mundial en nuestra sede Nomad.

Ven, juega, comparte una cerveza y vive la pasión del fútbol en el mejor ambiente. ⚽🍻

Reserva tu cancha. ¡Te esperamos! 🔥

[9:29] **+57 318 5358260:** [Imagen]

[13:54] **+57 318 5358260:** [Imagen] 🔥🎾😬

[15:19] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Mayo  
🕘 04:00 P.m 6:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[15:35] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Mayo  
🕘 04:00 P.m 6:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Parra
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[16:01] **+57 318 5358260:** [Imagen] 🏆⚽🎾 Familia PadelTown 🎾⚽🏆

El Mundial se vive mejor cuando se comparte. 🧡

Te invitamos a reservar tu cancha, disfrutar de una buena partida de pádel con amigos y luego quedarte con nosotros para vibrar, celebrar y sufrir cada jugada del Mundial en nuestra sede Nomad.

Ven, juega, comparte una cerveza y vive la pasión del fútbol en el mejor ambiente. ⚽🍻

Reserva tu cancha. ¡Te esperamos! 🔥

[16:53] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Mayo  
🕘 08:00 P.m 9:30 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Quien se Apunta!!! 🔥

[18:10] __@edissriver se unieron mediante el enlace de invitación__

[21:12] **+57 318 5358260:** 🎾🔥 ¡Mañana es día de pádel en PadelTown Nomad! 🔥🎾

No dejes pasar la oportunidad de disfrutar tu deporte favorito y compartir con la mejor comunidad.

📅 Reserva tu cancha para mañana y aprovecha nuestra increíble promoción 2x1 en  alquiler de cancha, horario valle

Invita a tu compañero, juega más y paga menos. ¡Las canchas se están llenando rápido!

📲 Reserva ahora y asegura tu espacio. ¡Te esperamos en PadelTown!

---

## 20 de junio de 2026

[7:52] **+57 318 5358260:** 🏆⚽🎾 Familia PadelTown 🎾⚽🏆

El Mundial se vive mejor cuando se comparte. 🧡

Te invitamos a reservar tu cancha, disfrutar de una buena partida de pádel con amigos y luego quedarte con nosotros para vibrar, celebrar y sufrir cada jugada del Mundial en nuestra sede Nomad.

Ven, juega, comparte una cerveza y vive la pasión del fútbol en el mejor ambiente. ⚽🍻

Reserva tu cancha. ¡Te esperamos! 🔥

[7:56] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 03:00 P.m 5:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[7:58] **+57 318 5358260:** [Imagen] 🚨🔥 ¡FAMILIA PADELTOWN NOMAD! 🔥🚨

¡No dejen pasar esta oportunidad! 🎾💥

✅ *2x1 en canchas en horario valle*
✅ Más tiempo de juego
✅ Más diversión con tus amigos

📅 *Reserva desde ya para mañana* y asegura tu espacio antes de que se agoten los horarios disponibles.

¡Es el momento perfecto para venir a la cancha, competir y disfrutar al máximo! 💪🎾

📲 Reserva ahora y aprovecha esta promoción exclusiva.

[7:59] **+57 318 5358260:** [Imagen]

[11:41] **+57 318 5358260:** [Imagen] 🚨🔥 ¡FAMILIA PADELTOWN NOMAD! 🔥🚨

¡No dejen pasar esta oportunidad! 🎾💥

✅ *2x1 en canchas en horario valle*
✅ Más tiempo de juego
✅ Más diversión con tus amigos

📅 *Reserva desde ya para mañana* y asegura tu espacio antes de que se agoten los horarios disponibles.

[11:41] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 03:00 P.m 5:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[17:03] **+57 318 5358260:** [Imagen] No se pierdan nuestra promoción 🔥😬

[17:53] **+57 315 0618200:** Hola, alguien para armar un partido tipo 7-8?

[17:53] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 07:00 P.m 9:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[17:54] **+57 315 0618200:** Sebastian Figueroa

[17:54] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 07:00 P.m 9:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Figueroa 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[19:29] **@NicolasDuarteB:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 07:00 P.m 9:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Figueroa 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!_
Se puede 8:30-10?

[19:29] **@NicolasDuarteB:** Estaría con un compañero

[19:31] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 08:30 P.m 10:30 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Figueroa 
🎾 Nicolas Duarte
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[19:32] **@NicolasDuarteB:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 08:30 P.m 10:30 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Figueroa 
🎾 Nicolas Duarte
🎾 
🎾 

¡¡¡Quién se Apunta!!!_
Incluye a Benjamin 
Iría Nicolás Duarte - Benjamin

[19:33] **+57 318 5358260:** UNA PALA MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 08:30 P.m 10:30 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Figueroa 
🎾 Nicolas Duarte
🎾 Benjamin
🎾 

¡¡¡Quién se Apunta!!!

[19:35] **+57 315 0618200:** Confírmalo, yo llevo la otra persona

[19:35] **+57 315 0618200:** Andrés Sánchez, Gracias

[19:38] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Junio  
🕘 08:30 P.m 10:30 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Figueroa 
🎾 Nicolas Duarte
🎾 Benjamin
🎾 Andres Sanchez 

PARTIDO CERRADO, NOS VEMOS EN LA CANCHA 🔥🎾

[19:39] **+57 310 6488275:** _Un admin., +57 318 5358260, eliminó este mensaje._

---

## 21 de junio de 2026

[7:21] **+57 318 5358260:** [Imagen] 🇨🇴🎾 ¡En PadelTown premiamos el compromiso con el país! 🎾🇨🇴

Este domingo 21 de junio trae tu certificado de votación y recibe $10.000 de descuento en servicios del club* 🔥

Una excusa más para venir, jugar, compartir y disfrutar un gran día en PadelTown 💙💛❤️
📍 Válido únicamente el domingo 21 de junio

[7:22] **+57 318 5358260:** [Imagen] No se pierdan nuestra promoción 🔥😬

[7:23] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 21 de Junio  
🕘 02:00 P.m 4:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[10:31] **+57 318 5358260:** [Imagen] No se pierdan nuestra promoción 🔥😬

[11:03] **+57 318 5358260:** [Imagen]

[11:42] **+57 300 8142332:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 21 de Junio  
🕘 02:00 P.m 4:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!_
Buenos días , para este partido 
Mauricio
Felipe 
Camilo 
Deicy

[11:55] **+57 318 5358260:** _Se eliminó este mensaje_

[11:58] **+57 318 5358260:** PARTIDO CERRADO
📍 Pádel Town Nomad  
📆 21 de Junio  
🕘 02:00 P.m 04:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio 
🎾 Felipe
🎾Camilo 
🎾Deicy  

🎾🔥NOS VEMOS EN LA CANCHA 🔥🎾

[15:12] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 21 de Junio  
🕘 06:00 P.m 8:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

---

## 22 de junio de 2026

[14:45] **+57 318 5358260:** 🎾🔥 ¡Hola, familia PadelTown! 🔥🎾

Hoy es un gran día para disfrutar del mejor plan: pádel, amigos y fútbol. ⚽🍻

✅ Aprovecha nuestra promoción 2x1 en canchas y juega el doble por el mismo precio.
✅ Quédate después del partido y acompáñanos a ver el encuentro del Mundial de las 7:00 p. m. en pantalla.

Reúne a tu parche, reserva tu cancha y vive una tarde llena de deporte, emoción y buena energía.

📲 ¡Reserva ya y no te quedes por fuera!

¡Nos vemos en PadelTown! 💙🎾⚽

[15:13] **+57 318 5358260:** [Imagen]

[15:15] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 21 de Junio  
🕘 04:00 P.m 6:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[15:20] **+57 318 5358260:** [Imagen] 🔥 ¡Reserva ya y juega el doble! 🎾

[16:42] **+57 318 5358260:** [Imagen] 🔥⚽ ¡Esta noche hay Mundial en PadelTown! ⚽🔥

Disfruta del partidazo 🇳🇴 Noruega vs 🇸🇳 Senegal y aprovecha nuestra promo de cervezas 🍻:

🎉 *Paga 3 y lleva 4* en Corona y Stella Artois.

Ven a vivir la pasión del fútbol, compartir con tus amigos y disfrutar del mejor ambiente. ¡Te esperamos! 🙌🔥

[18:06] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 21 de Junio  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[18:46] **@edissriver:** Hola buenas tardes

[18:46] **@edissriver:** Me confirmas qué precio valdrían dos horas de 4 pm a 6 pm

[18:49] **+57 318 5358260:**
> _@edissriver: Me confirmas qué precio valdrían dos horas de 4 pm a 6 pm_
Hola Eddi, Buenas tardes. 
claro, como tenemos nuestra promocion 2*1 en horario valle, te quedarían las dos horas en 110.000 pesos, aquí ya te incluyen las 4 palas el set de las 3 pelotas y las 2 horas de chancha, Te reservo para el dia de mañana?

[18:50] **@edissriver:** Déjame valido con ellos

[18:51] **+57 318 5358260:**
> _@edissriver: Déjame valido con ellos_
Vale, quedamos atentos para reservarte.

---

## 23 de junio de 2026

[9:00] **+57 318 5358260:** [Imagen] 🔥🧡Buenos dias familia Padeltown nomad🧡🔥

Reserva tu cancha, reúne a tus amigos y disfruta de un gran partido. Después, quédate con nosotros a vivir toda la emoción del Mundial en pantalla gigante mientras compartes una cerveza bien fría. 🍻⚽

[10:43] **+57 318 5358260:** [Imagen] Aprovecha nuestra promoción 🧡🔥

[12:33] __+57 302 4487304 se unieron mediante el enlace de invitación__

[12:33] __Alguien añadió a +57 302 4487304__

[12:39] **+57 318 5358260:** [Imagen] Reserva ya!!!

[16:28] **+57 318 5358260:** [Imagen] 🇨🇴🔥 ¡HOY JUEGA COLOMBIA Y LA PASIÓN SE VIVE EN PADELTOWN! 🔥🇨🇴

⚽ Colombia 🆚 RD Congo
🕘 9:00 p.m.

Reúne a tus amigos, reserva tu cancha y quédate a disfrutar del partido con toda la energía de la Tricolor. 🎾💛💙❤️

🍻 Promoción especial: Lleva 4 cervezas y paga solo 3 (Corona y Stella Artois).

🎾 Juega pádel
⚽ Vive el partido
🍺 Comparte una cerveza
🙌 Celebra cada gol con la familia PadelTown.

[17:17] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 23 de Junio  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[17:58] **+57 318 5358260:** [Imagen]

[18:53] **+57 318 5358260:** [Imagen] “¡Listos para apoyar a la Sele 🇨🇴!
Hoy vivimos el Colombia vs RD Congo a las 9:00 pm en nuestros clubes.
Ven, disfruta el partido y vibra con nosotros ⚽🔥”

[19:32] **+57 318 5358260:** [Imagen]

[20:27] **+57 318 5358260:** [Imagen] ¡En pocos minutos empieza el mejor partido de la Sele 🇨🇴🔥!

Te estamos esperando para apoyarla juntos, vivir la emoción del fútbol y disfrutar el ambiente en PadelTown.

🍻 Aprovecha nuestra promo 3x4 en cerveza y ven a alentar a la Sele como se debe.🍻🍻

---

## 24 de junio de 2026

[8:06] **+57 318 5358260:** [Imagen] 🧡🔥BUENOS DIAS FAMILIA PADELTOWN🔥🧡

Recuerda que nuestra promoción esta por poco tiempo aprovecha ahora y reserva con nosotros🎾🔥😬.

[8:13] __+57 318 5358260 añadió a @ManuelOlivoR__

[9:04] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 24 de Junio  
🕘 08:00 P.m 10:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[9:05] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 24 de Junio  
🕘 04:00 P.m 6:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[9:58] **+57 318 5358260:** _Se eliminó este mensaje_

[9:58] **+57 318 5358260:** _Se eliminó este mensaje_

[10:33] **+57 318 5358260:** 🧡🏆Buenos días familia🧡🏆

🏆!Queremos crear un espacio divertido donde los niños aprendan, hagan deporte y disfruten del pádel!🧡🚀


Queremos hacer una clase para nuestros pequeños deportistas (de 7 años a los 10 años)🚀, quisiéramos saber que dia y en que horario les gustaría

[10:33] **+57 318 5358260:** **Encuesta: 🕒 ¿Cuál de estos horarios les parece más conveniente?**
- Jueves de 10:00 AM a 11:30 AM ☑️
- Jueves de 4:00 PM a 5:30 PM☑️
- Viernes de 4:00 PM a 5:30 PM☑️
- Sabado de 8:30 AM a 10:00 AM ☑️

[10:34] **@gdanderino:**
> _+57 318 5358260: 🧡🏆Buenos días familia🧡🏆

🏆!Queremos crear un espacio divertido donde los niños aprendan, hagan deporte y disfruten del pádel!🧡🚀


Queremos hacer una clase para nuestros pequeños deportistas (de 7 años a los 10 años)🚀, quisiéramos saber que dia y en que horario les gustaría_
mi hijo tiene 13 puede ir ?

[10:55] **+57 318 5358260:** Por el momento el límite de edad es hasta los 10 años pero tendremos una segunda clase para estas edades y lo vamos a comunicar este medio.

[12:52] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 MAÑANA 25 de Junio  
🕘 07:00 P.m 8:00 P.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Jessica
🎾 Fiorella
🎾 
🎾 

¡¡¡Quién se Apunta!!

[12:53] **@DsebasMG:** ✋🏻

[13:29] **+57 318 5358260:** [Imagen] 🔥🔥🔥🔥

[14:04] **+57 318 5358260:** [Imagen] 🔥Aprovecha nuestra promoción🔥

[14:19] **+57 318 5358260:** 🔥PARTIDO FEMENINO ABIERTO

📍 Pádel Town Nomad  
📆 MAÑANA 25 de Junio  
🕘 07:00 P.m 8:00 P.m
Categoría: 5TA,
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Jessica
🎾 Fiorella
🎾 
🎾 

¡¡¡Quién se Apunta!!

[14:25] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 24 de Junio  
🕘 04:00 P.m 6:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[14:32] **+57 318 5358260:** [Imagen] ⚽🔥 ¡HOY VIVIMOS EL MUNDIAL EN PADELTOWN NOMAD! 🔥⚽

Ven a disfrutar de una jornada llena de fútbol, amigos y cerveza fría. 🍻

[15:37] **+57 318 5358260:**
> _+57 318 5358260: [poll_creation]_
👋 ¡Hola!

Te recordamos que tenemos una encuesta activa para conocer qué día y horario te queda mejor para traer a tu hijo(a) a nuestras clases de pádel.

Tu opinión es muy importante para nosotros, ya que nos ayudará a crear grupos en los horarios que más se ajusten a las familias de nuestro club.

🎾 ¡Si aún no has respondido, te invitamos a hacerlo! Gracias por ayudarnos a construir esta experiencia para nuestros pequeños jugadores.

[16:13] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 24 de Junio  
🕘 07:00 P.m 8:00 P.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[17:29] **+57 318 5358260:** [Imagen] ¡¡¡Quién se Apunta!!

[19:00] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 24 de Junio  
🕘 09:00 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

---

## 25 de junio de 2026

[8:23] **+57 318 5358260:** [Imagen] Buenos días familia🧡🏆
Les recordamos que tenemos promociones para ustedes, reserva ahora!🧡🔥🎾

[8:46] **+57 318 5358260:** [Imagen] Recuerda venir a nuestro club a ver el mundial y aprovechar nuestra promoción 4x3 en cerveza corona y stella🍻 😌.

[8:51] **@DsebasMG:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 24 de Junio  
🕘 09:00 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!_
✋🏻

[8:52] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 09:00 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[9:21] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 07:00 P.m 8:00 P.m
Categoría: 5TA,
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Jessica
🎾 Fiorella
🎾 
🎾 

¡¡¡Quién se Apunta!!

[9:39] **+57 318 5358260:** Una pala mas familia 

🔥PARTIDO FEMENINO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 07:00 P.m 8:30 P.m
Categoría: 5TA,
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Jessica
🎾 Fiorella
🎾 Lia
🎾 

¡¡¡Quién se Apunta!!

[10:16] **@Santyamen:** Una pala mas familia 

🔥PARTIDO FEMENINO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 07:00 P.m 8:30 P.m
Categoría: 5TA,
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Jessica
🎾 Fiorella
🎾 Lia
🎾 Lisa B

¡¡¡Quién se Apunta!!

[10:17] **+57 318 5358260:** 🔥PARTIDO FEMENINO CERRADO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 07:00 P.m 8:30 P.m
Categoría: 5TA,
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Jessica
🎾 Fiorella
🎾 Lia
🎾 Lisa B

NOS VEMOS EN LA CANCHA CHICAS🎀🔥🎾

[10:19] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 09:00 P.m 10:00 P.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[10:23] **+57 318 5358260:** 2 palas mas familia!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 
🎾 

¡¡¡Quién se Apunta!!

[11:55] **+57 318 5358260:** 2 palas mas familia!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 
🎾 

¡¡¡Quién se Apunta!!

[13:45] **@Daniel_preciadov:**
> _+57 318 5358260: 2 palas mas familia!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 
🎾 

¡¡¡Quién se Apunta!!_
2 palas mas familia!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 Daniel p 
🎾 

¡¡¡Quién se Apunta!!

[15:14] **+57 318 5358260:** Familia nos falta 1 pala, quien se anima!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 Daniel p 
🎾 

¡¡¡Quién se Apunta!!

[15:47] **@Santyamen:** Familia nos falta 1 pala, quien se anima!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 Daniel p 
🎾 

¡¡¡Quién se Apunta!!

[16:02] **@Daniel_preciadov:** Familia nos falta 1 pala, quien se anima!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:20] **@Santyamen:** Familia nos falta 1 pala, quien se anima!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:26] **+57 318 5358260:** [Imagen] 🔥Aprovecha nuestra promoción🔥

[19:13] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 HOY 25 de Junio  
🕘 08:30 P.m 10:00 P.m
Categoría: 5TA
💰 Precio por jugador: 45.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian M 
🎾 Santiago C
🎾 
🎾 

¡¡¡Quién se Apunta!!

---

## 26 de junio de 2026

[7:46] **+57 318 5358260:** [Imagen] Buenos días familia 🧡🏆
Les recordamos que tenemos promociones para ustedes, reserva ahora! 🧡🔥🎾

[8:32] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 26 de Junio  
🕘 02:00 P.m 4:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[9:45] **+57 318 5358260:** [Imagen]

[12:31] **+57 318 5358260:** [Imagen] 🍻⚡ ¡El plan está en PadelTown Nomad!

Ven a jugar, disfruta el mejor ambiente y aprovecha nuestra promo 3x4 en cervezas. Reúne a tu parche, pide 4 y paga solo 3. 🍺

¡Te esperamos! 🎾

[17:09] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 26 de Junio  
🕘 06:00 P.m 8:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 60.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[22:06] **+57 318 5358260:** [Imagen] 🎾 Dobla la diversión este fin de semana. ¡Paga 1 hora y juega 2!🔥🔥🔥

---

## 27 de junio de 2026

[8:00] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 27 de Junio  
🕘 02:00 P.m 4:00 P.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[8:04] **+57 318 5358260:** 🇨🇴🔥 ¡La Sele nos vuelve a unir y queremos vivir este partidazo contigo! ⚽💛💙❤️

Reúne a tus amigos, ven a PadelTown Nomad y disfruta el encuentro en el mejor ambiente.

No importa si vienes a jugar un partido de pádel o solo a alentar a Colombia, aquí te esperamos para vivir cada gol y cada emoción juntos. ¡No te lo pierdas! 🇨🇴🙌

[9:20] **+57 318 5358260:** [Imagen] 🇨🇴⚽ ¡Hoy juega Colombia y el mejor lugar para vivir el partido es PadelTown Nomad!

Ven con tu parche, disfruta de un gran ambiente, alienta a la Sele como se merece y aprovecha nuestra promo 3x4 en cerveza. 🍻

Haz tu reserva, juega un buen partido de pádel y luego quédate con nosotros para disfrutar cada minuto del encuentro. ¡Te esperamos para celebrar juntos y hacer de este partido una experiencia inolvidable! 💛💙❤️

[10:17] **+57 318 5358260:** [Imagen] Reúne a tus amigos, disfruta del partido en pantalla, aprovecha nuestras promociones y vive una noche llena de fútbol, pádel y buena energía. ¡Te esperamos desde las 6:30 p. m.! 💛💙❤️

[13:48] **+57 318 5358260:** [Imagen] Ya casi se acaba nuestra promoción, aprovecha y reserva ahora 🔥🎾.

[15:40] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 27 de Junio  
🕘 06:00 P.m 8:00 P.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[17:10] **+57 318 5358260:** [Imagen] Aprovecha nuestra promoción de cerveza para poder ver a nuestra selección Colombia 🔥🇨🇴🍻.

[17:19] **+57 318 5358260:** [Imagen] Te estamos esperando para ver a nuestra sele ganar 🔥🇨🇴🍻.

[17:31] **+57 318 5358260:** 🚨 HOY EN PADELTOWN  🇨🇴⚽🇵🇹

📺 Vive con nosotros el partido HOY 6:30PM

🇨🇴Colombia 🆚 Portugal.🇵🇹

🎯 ¡Participa consumiendo cualquier producto en nuestro club!

¿Cómo participar?
consume cualquiera de nuestros productos y das tu pronostico.

Ejemplo:
👤 Juan Pérez
🇨🇴 Colombia 2️⃣ - 1️⃣ Portugal 🇵🇹

🏆 Si aciertas el resultado exacto, ganas 1 hora de cancha GRATIS en hora valle.

📍Único requisito: estar presente en padeltown nomad o consumir cualquier producto.

¡Los esperamos! 🔥⚽

[17:37] **+57 318 5358260:** Glena Amaya 
1🇨🇴 // 1🇵🇹

[17:37] **+57 318 5358260:** Martha Palacios 
0🇨🇴 // 1🇵🇹

[17:38] **+57 318 5358260:** Cristian Cortes 
0🇨🇴 // 0🇵🇹

[17:41] **@PadelTownSantafe:** 1🇨🇴// 0🇵🇹

[18:21] **@sandrita234:** Sandra Vargas 
🇨🇴 1 // 1 🇵🇹

[19:18] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 27 de Junio  
🕘 09:00 P.m 11:00 P.m
*Categoría: 5TA *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[21:11] __[Notificación del sistema]__

---

## 28 de junio de 2026

[8:44] **+57 318 5358260:** 🌧️🎾 ¡Buenos días familia PadelTown! ⚽☕
Que el clima no decida el plan de hoy… el plan lo ponemos nosotros: pádel, parche, partidos y buena energía.
Aprovecha nuestras promociones 
🎾2 x 1 en cancha 
🎾3 x 4 en cerveza 
🔥TE ESPERAMOS🔥

[8:45] **+57 318 5358260:** [Imagen]

[9:26] __+57 318 4990342 se unieron mediante el enlace de invitación__

[9:26] __Alguien añadió a +57 318 4990342__

[11:06] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Junio  
🕘 1:00 P.m 3:00 P.m
*Categoría: 5TA *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[11:22] **+57 310 2578035:** _Esperando el mensaje… Esto puede demorar un poco._

[11:23] **+57 310 2578035:** voy

[11:23] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Junio  
🕘 1:00 P.m 3:00 P.m
*Categoría: 5TA *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[11:56] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Junio  
🕘 1:00 P.m 3:00 P.m
*Categoría: 5TA *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[12:28] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Junio  
🕘 1:00 P.m 3:00 P.m
*Categoría: 5TA *
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[13:36] **+57 318 5358260:** [Imagen]

[16:42] **+57 318 5358260:** [Imagen] 🎾🔥Aprovecha nuestra promo de 2x1 en anquiler de cancha🔥🎾

[21:35] __+57 313 6659489 se unieron mediante el enlace de invitación__

---

## 29 de junio de 2026

[7:46] **+57 318 5358260:** 🔥 BUENOS DÍAS FAMILIA PADELTOWN 🔥

🎾 ¡Hoy es un gran día para jugar! No dejes que la rutina te gane, ven a la cancha, disfruta de un buen partido, mejora tu nivel y comparte con la mejor comunidad de pádel. 💪

📅 Reserva tu cancha hoy, reúne a tus amigos y vive la energía de PadelTown Nomad. ¡Te esperamos para seguir sumando grandes puntos dentro y fuera de la cancha! 🔥

[7:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Junio  
🕘  9:00 AM - 10:00 AM 
*Categoría: 5TA - 6TA *
💰 Precio por jugador: 25.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[9:13] **+57 318 5358260:** [Imagen] Reúne a tus amigos, disfruta de cada partido en un gran ambiente y acompáñalo con nuestras promociones de cerveza. 🍻

[10:17] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  2:00 PM - 4:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[10:28] **+57 300 8142332:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  2:00 PM - 4:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!_
Buenos días , por favor anotar a Mauricio y Felipe para este partido.

[10:29] **+57 318 5358260:** ¡DOS PALAS MAS FAMILIA!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  2:00 PM - 4:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[11:24] **+57 318 5358260:** ¡DOS PALAS MAS FAMILIA!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  2:00 PM - 4:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[11:33] **+57 318 5358260:**
> _+57 318 5358260: ¡DOS PALAS MAS FAMILIA!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  2:00 PM - 4:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 
🎾 

¡¡¡Quién se Apunta!!!_
SE CANCELA PARTIDO POR DISPONIBILIDAD DE CANCHAS

[11:46] **+57 318 5358260:** ¡DOS PALAS MAS FAMILIA!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  4:00 PM - 6:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[12:16] **+57 310 2578035:** Voy

[12:17] **+57 318 5358260:** ¡UNA PALA MAS FAMILIA!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  4:00 PM - 6:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 Enrique 
🎾 

¡¡¡Quién se Apunta!!!

[13:46] **+57 318 5358260:** ¡UNA PALA MAS FAMILIA!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  4:00 PM - 6:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 Enrique 
🎾 

¡¡¡Quién se Apunta!!!

[13:46] **+57 318 5358260:** [Imagen]

[14:13] **@Santyamen:** ¡UNA PALA MAS FAMILIA!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  4:00 PM - 6:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 Enrique 
🎾 Santiago C

¡¡¡Quién se Apunta!!!

[14:13] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  4:00 PM - 6:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Mauricio
🎾 Felipe
🎾 Enrique 
🎾 Santiago C

🔥NOS VEMOS EN LA CANCHA🔥

[14:24] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  6:00 PM - 8:00 PM 
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[15:17] __+1 (954) 673-0996 se unieron mediante el enlace de invitación__

[15:17] __Alguien añadió a +1 (954) 673-0996__

[15:18] __+1 (954) 673-0996 añadió a +1 (954) 290-7291__

[15:19] **+1 (954) 673-0996:** Buenas tardes estamos interesados en clases para joven de 14 años y un niño de 9 en salitre.

[15:20] **+57 318 5358260:**
> _+1 (954) 673-0996: Buenas tardes estamos interesados en clases para joven de 14 años y un niño de 9 en salitre._
Hola Buenas tardes, ya te comparto informacion.

[15:28] **+57 318 5358260:** ⚽🔥 ¡Esta tarde el Mundial se vive en PadelTown Nomad! 🔥⚽

Ven a disfrutar del partidazo *Alemania 🇩🇪 vs Paraguay 🇵🇾* en el mejor ambiente, acompañado de tus amigos y con la mejor energía.

🍻 *Además, aprovecha nuestra promo 3*4 en cerveza:* ¡paga 3 y recibe 4!

Te esperamos para vivir juntos toda la emoción del Mundial. ¡No te lo pierdas! 🙌

[15:31] **+57 310 2192130:** Alguna pareja para jugar hoy  4ta, 5:30 a 7:30 o similar, si quieren apostamos la cancha

[15:33] **+57 310 2192130:** Habrá cancha ?

[15:33] **+57 318 5358260:** Familia nos faltan 3 palas, Quien se anima??
🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  5:30 PM - 7:30 PM 
Categoría: 4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marcel Romero 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[15:33] **+57 318 5358260:**
> _+57 310 2192130: Habrá cancha ?_
Hola buenas tardes Marcel, Si señor

[15:33] **+57 310 2192130:** Voy con Simón

[15:34] **+57 318 5358260:** Familia nos faltan 2 palas, Quien se anima??

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  5:30 PM - 7:30 PM 
Categoría: 4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marcel Romero 
🎾 Simón 
🎾 
🎾 

¡¡¡Quién se Apunta!!!

[16:59] **+57 311 2924242:** Familia nos faltan 2 palas, Quien se anima??

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  5:30 PM - 7:30 PM 
Categoría: 4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marcel Romero 
🎾 Simón 
🎾 Marlon
🎾 Marco

¡¡¡Quién se Apunta!!!

[16:59] **+57 311 2924242:** Partido cerrado.

[17:00] **+57 310 2192130:** Pero de 6 a 8 entonces para llegar, les parece ?

[17:00] **+57 310 2192130:** Nomad se puede ?

[17:00] **+57 311 2924242:** Si si

[17:02] **+57 311 5915669:** 6 a 8

[17:02] **+57 311 5915669:** 20.000

[17:03] **+57 310 2192130:** Nomad se puede ?

[17:04] **+57 310 2192130:** Allá miramos la apuesta, si nomad confirma

[17:05] **+57 318 5358260:**
> _+57 310 2192130: Allá miramos la apuesta, si nomad confirma_
Si señor, aqui los esperamos

[17:05] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 29 de Junio  
🕘  6:00 PM - 8:00 PM 
Categoría: 4TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marcel Romero 
🎾 Simón 
🎾 Marlon
🎾 Marco

Los esperamos en la Cancha

[17:08] **+57 310 2192130:** Listo gracias

---

## 30 de junio de 2026

[8:47] **+57 318 5358260:** [Imagen] 🧡🧡Buen día Familia🧡🧡
🎾🔥Aprovecha nuestra promo de 2x1 en anquiler de cancha🔥🎾

[8:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 30 de Junio  
🕘 02:00 P.m 4:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[11:36] __+34 660 31 30 31 se unieron mediante el enlace de invitación__

[11:36] __Alguien añadió a +34 660 31 30 31__

[11:36] **+34 660 31 30 31:** Gracias!

[14:15] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 30 de Junio  
🕘 04:00 P.m 6:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[14:27] __+57 318 5358260 añadió a +58 412-7646786__

[16:36] **+57 318 5358260:** 🎉 ¡Familia PadelTown, les tenemos una sorpresa! 🎉

Pensando en todos ustedes, lanzamos una promoción para que jueguen más y disfruten al máximo. 🎾💙

🔥 Reserva tu cancha y aprovecha nuestro 2x1. ¡Aplica en todos los horarios!

¡Los esperamos en PadelTown Nomad Salitre! 💥

[16:36] **+57 318 5358260:** [Imagen]

[17:26] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 30 de Junio  
🕘 07:30 P.m 09:30 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 37.500 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:28] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 01 de Julio  
🕘 09:00 A.m 11:00 A.m
Categoría: 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Ivan
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:33] **+57 318 5358260:** TORNEO  AMERICANO INDIVIDUAL

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:

🎾 Ricardo 
🎾 Mauricio
🎾 Gustavo Danderino
🎾
🎾
🎾
🎾
🎾
🎾

[19:07] **@Daniel_preciadov:** TORNEO  AMERICANO INDIVIDUAL

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:

🎾 Ricardo 
🎾 Mauricio
🎾 Gustavo Danderino
🎾Daniel P
🎾
🎾
🎾
🎾
🎾

[19:19] __+57 314 3709115 se unieron mediante el enlace de invitación__

[19:46] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:

🎾 Ricardo 
🎾 Mauricio
🎾 Gustavo Danderino
🎾Daniel P
🎾
🎾
🎾
🎾
🎾

[20:36] __@san.kive se unieron mediante el enlace de invitación__

---

## 1 de julio de 2026

[7:15] __+57 310 7781465 se unieron mediante el enlace de invitación__

[8:04] **+57 318 5358260:** [Imagen] 🎉 ¡Familia PadelTown! 🎉

🔥 Reserva tu cancha y aprovecha nuestro 2x1. ¡Aplica en todos los horarios!

¡Los esperamos en PadelTown Nomad Salitre! 💥

[8:07] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 01 de Julio  
🕘 10:00 P.m 12:00 P.m
Categoría: 5TA/6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Ivan
🎾 
🎾 

¡¡¡Quién se Apunta!!

[8:32] **@edissriver:** _Se eliminó este mensaje_

[8:32] **@edissriver:** _Se eliminó este mensaje_

[8:32] **@edissriver:** _Se eliminó este mensaje_

[8:57] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:

🎾 Ricardo 
🎾 Mauricio
🎾 Gustavo Danderino
🎾Daniel P
🎾
🎾
🎾
🎾
🎾

[10:26] **+57 318 5358260:** [Imagen] ⚽🔥 ¡El Mundial se vive mejor en PadelTown Nomad!

Ven a disfrutar los partidos con nosotros, vive la emoción de cada gol y aprovecha nuestras promociones imperdibles...🍻🎾

[12:29] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL @all 

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:

🎾 Ricardo 
🎾 Mauricio
🎾 Gustavo Danderino
🎾Daniel P
🎾
🎾
🎾
🎾
🎾

[15:01] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 01 de Julio  
🕘 06:00 p.m 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[16:18] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL @all 

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:

🎾 Ricardo 
🎾 Mauricio
🎾 Gustavo Danderino
🎾Daniel P
🎾
🎾
🎾
🎾
🎾

[17:29] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL @all 

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:
 
🎾 Gustavo Danderino
🎾Daniel P
🎾
🎾
🎾
🎾
🎾

[17:36] **+57 318 5358260:** [Imagen]

[17:43] **+57 350 4256023:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 01 de Julio  
🕘 06:00 p.m 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!_
Yo juego ✌️

[17:44] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 01 de Julio  
🕘 06:00 p.m 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan Gomez
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:21] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 01 de Julio  
🕘 08:00 p.m 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:32] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥 *¡Los cupos son limitados!*

🎾 Andrea Ortiz
🎾 Sebastian Figueroa
🎾
🎾
🎾
🎾

📲 *Inscríbete ya y asegura tu lugar.*

[19:01] **@angiefuentes16:**
> _+57 318 5358260: 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥 *¡Los cupos son limitados!*

🎾 Andrea Ortiz
🎾 Sebastian Figueroa
🎾
🎾
🎾
🎾

📲 *Inscríbete ya y asegura tu lugar.*_
Angelica Fuentes

[19:01] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥 *¡Los cupos son limitados!*

🎾 Andrea Ortiz
🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾
🎾
🎾

📲 *Inscríbete ya y asegura tu lugar.*

[19:02] **+57 301 4170998:** _Se eliminó este mensaje_

[19:02] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL @all 

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:
 
🎾 Gustavo Danderino
🎾Daniel P
🎾 Alejandro
🎾
🎾
🎾
🎾

[19:35] **@juanp.b:**
> _+57 318 5358260: 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥 *¡Los cupos son limitados!*

🎾 Andrea Ortiz
🎾 Sebastian Figueroa
🎾
🎾
🎾
🎾

📲 *Inscríbete ya y asegura tu lugar.*_
Juan Blanco

[19:37] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!

🎾 Andrea Ortiz
🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾
🎾

📲 *Inscríbete ya y asegura tu lugar.*

[20:03] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!

🎾 Andrea Ortiz
🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾 Johan Ovalle
🎾

📲 *Inscríbete ya y asegura tu lugar.*

[20:09] **+57 311 4982613:**
> _+57 318 5358260: 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!

🎾 Andrea Ortiz
🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾 Johan Ovalle
🎾

📲 *Inscríbete ya y asegura tu lugar.*_
🙋🏻

[20:22] **+57 318 5358260:** Familia  nos queda 1 cupo para completar la Clase, Quien se apunta.

🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Daniel robles
🎾

📲 *Inscríbete ya y asegura tu lugar.*

[20:24] **@andy.suarez:** 🙋🏻‍♂️

[20:28] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL CERRADA!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Daniel robles
🎾 Andres Sanchez

📲 *Los esperamos en la cancha.*

---

## 2 de julio de 2026

[8:00] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL @all 

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:
 
🎾 Gustavo Danderino
🎾Daniel P
🎾 Alejandro
🎾 
🎾
🎾
🎾

[9:44] **+57 318 5358260:** [Imagen] Buenos días familia PadelTown 🧡.
Recuerda que en nuestro club puedes ver los partidos del mundial y disfrutar de nuestra promoción de cerveza 4x3. 
LOS ESPERAMOS🍻🧡

[10:13] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 02 de Julio  
🕘 06:00 p.m 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[10:51] **+57 318 5358260:** TORNEO AMERICANO INDIVIDUAL @all 

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:
 
🎾 Gustavo Danderino
🎾Daniel P
🎾 Alejandro
🎾 
🎾
🎾
🎾

[12:27] **+57 318 5358260:**
> _+57 318 5358260: TORNEO AMERICANO INDIVIDUAL @all 

📅 Jueves 2 de Julio
⏰ 7:30 PM a 9:30 PM
💸 Inscripción: $45.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO

🏆 Categoría: 5TA


✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización

🏆 PREMIOS

🥇 1er Lugar: 100.000 pesos Consumibles en el club  + 🏓 1 Hora de cancha Gratis 
 

🥈 2do Lugar: 🏓 1 Hora de cancha Gratis 


✍️ INSCRÍBETE AQUÍ:
 
🎾 Gustavo Danderino
🎾Daniel P
🎾 Alejandro
🎾 
🎾
🎾
🎾_
!FAMILIA NOMAD! 
Se cancela torneo del dia de hoy por falta de participantes

[12:51] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 02 de Julio  
🕘 08:00 p.m 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[16:01] **+57 318 5358260:** [Imagen]

[17:34] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 02 de Julio  
🕘 07:00 p.m 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[20:23] **+57 318 5358260:** [Imagen]

---

## 3 de julio de 2026

[7:54] **+57 318 5358260:** ¡🌞🇨🇴 Buenos días, familia PadelTown Nomad! 🇨🇴🌞

Hoy es un gran día para apoyar a nuestra Selección. ⚽💛💙❤️ Los esperamos en el club para vivir juntos toda la emoción del partido, disfrutar del mejor ambiente, compartir con amigos y alentar a Colombia como se merece.

Además, aprovecha nuestra promo 3x4 en cerveza 🍻 y haz que la pasión por el fútbol se viva aún mejor.

¡Ven con tu parche y hagamos sentir el apoyo a la Tricolor! 💪🇨🇴 ¡Nos vemos en PadelTown Nomad!

[8:44] **+57 318 5358260:** [Imagen] 🔥 ¡La pasión se vive en Nomad! Ven y apoya a la Sele con nosotros. 🇨🇴⚽🍻

[9:28] **+57 318 5358260:** [Imagen] 🔥🔥Recuerda y aprovecha nuestra promo🔥🔥

2x1 !ahora en todos los horarios, paga UNA hora y juega DOS!🎾🧡

[9:37] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 03 de Julio  
🕘 02:00 p.m - 04:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[15:07] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 03 de Julio  
🕘 04:00 p.m - 06:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[17:41] **+57 318 5358260:** [Imagen]

[19:49] **+57 318 5358260:** [Imagen] Familia Nomad🧡🔥
Los estamos esperando para ver el partido de nuestra sele, que nos une y nos vuelve familia a todos🇨🇴🧡.
Y aprovecha nuestra promoción de 3 x 4 en cerveza 🍻.

[20:29] **+57 318 5358260:** [Imagen]

---

## 4 de julio de 2026

[8:04] **+57 318 5358260:** 🧡 ¡Buenos días familia Nomad!🧡
 ¿Ya tienes plan para hoy? 🎾
Te esperamos en nuestro club PadelTown Nomad para disfrutar de una gran jornada. Aprovecha para conocer nuestras academias, clases personalizadas, membresías y productos.

¿No tienes con quién jugar? ¡Nosotros te ayudamos a armar un partido en las canchas disponibles para que solo llegues a disfrutar!

Ven, vive la experiencia, mejora tu juego y comparte un gran momento con nuestra comunidad. 🧡🔥

¡Reserva tu cancha y nos vemos en la cancha! 🙌

[9:19] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 04 de Julio  
🕘 02:00 p.m - 04:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[9:41] **+57 318 5358260:** [Imagen]

[10:06] **+57 318 5358260:** Familia  nos queda 1 cupo para completar la Clase, Quien se apunta.

🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Andres Sanchez
🎾

📲 *Inscríbete ya y asegura tu lugar.*

[10:22] **+57 300 8142332:**
> _+57 318 5358260: Familia  nos queda 1 cupo para completar la Clase, Quien se apunta.

🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Andres Sanchez
🎾

📲 *Inscríbete ya y asegura tu lugar.*_
Buenos días , Felipe Gómez por favor

[10:23] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Angelica Fuentes
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Andres Sanchez
🎾 Felipe Gomez

Clase cerrada, nos vemos en la cancha🎾🔥

[11:23] **+57 318 5358260:** [Imagen]

[11:23] **+57 318 5358260:** [Imagen]

[12:34] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 04 de Julio  
🕘 04:00 p.m - 06:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[12:41] **+57 318 5358260:** UNA PALA MAS FAMILIA, QUIEN SE UNE?

🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Andres Sanchez
🎾 Felipe Gomez
🎾

[12:58] **+57 310 2192130:** UNA PALA MAS FAMILIA, QUIEN SE UNE?

🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Andres Sanchez
🎾 Felipe Gomez
🎾Daniela Romero

[12:58] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Juan Blanco
🎾 Johan Ovalle
🎾 Andres Sanchez
🎾 Felipe Gomez
🎾Daniela Romero

Clase cerrada, nos vemos en la cancha🎾🔥

[13:02] **+57 318 5358260:** UNA PALA MAS FAMILIA, QUIEN SE UNE?

🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Juan Blanco
🎾 Andres Sanchez
🎾 Felipe Gomez
🎾Daniela Romero
🎾

[13:04] **+57 350 5786150:**
> _+57 318 5358260: UNA PALA MAS FAMILIA, QUIEN SE UNE?

🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Juan Blanco
🎾 Andres Sanchez
🎾 Felipe Gomez
🎾Daniela Romero
🎾_
Por favor inscribir a Elcy Marín

[13:05] **+57 318 5358260:** 🎾 *¡CLASE GRATIS DE PÁDEL!* 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 4 de julio*
🕘 *4:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastian Figueroa
🎾 Juan Blanco
🎾 Andres Sanchez
🎾 Felipe Gomez
🎾Daniela Romero
🎾 Elcy Marín

Clase cerrada, nos vemos en la cancha🎾🔥

---

## 5 de julio de 2026

[7:31] **+57 318 5358260:** 🎾 ¡Buenos días, familia PadelTown Nomad! ☀️

Esperamos que tengan un excelente día. Los esperamos en el club para disfrutar del mejor pádel y aprovechar nuestra *PROMO 2x1 en canchas*. 🔥

¡Es el momento perfecto para invitar a un amigo, reservar y jugar el doble por el mismo precio! 🎾

¡Los esperamos!

[9:35] **+57 318 5358260:** _Se eliminó este mensaje_

[10:25] **+57 318 5358260:** [Imagen] ⚽🍻 Partidazo entre estas dos selecciones, ven y disfruta el partido aqui, acompañalo con una cerveza, snacks o una pizza ☝🏻🔥🔥

[12:04] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 05de Julio  
🕘 02:00 p.m - 06:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[12:53] **+57 318 5358260:** Familia nos faltan dos palas, Quien dijo Yoo!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 05 de Julio  
🕘 05:00 p.m - 07:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesús
🎾 Arturo
🎾 
🎾 

¡¡¡Quién se Apunta!!

[12:53] **@marlon.iragorri:**
> _+57 318 5358260: Familia nos faltan dos palas, Quien dijo Yoo!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 05 de Julio  
🕘 05:00 p.m - 07:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesús
🎾 Arturo
🎾 
🎾 

¡¡¡Quién se Apunta!!_
Yo

[12:54] **+57 318 5358260:** Familia nos faltan Dos palas, Quien dijo Yoo!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 05 de Julio  
🕘 05:00 p.m - 07:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesús
🎾 Arturo
🎾 
🎾 

¡¡¡Quién se Apunta!!

[13:38] **+57 318 5358260:** Familia nos faltan Dos palas, Quien dijo Yoo!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 05 de Julio  
🕘 05:00 p.m - 07:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesús
🎾 Arturo
🎾 
🎾 

¡¡¡Quién se Apunta!!

[14:37] **+57 318 5358260:** Familia nos faltan Dos palas, Quien dijo Yoo!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 05 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jesús
🎾 Arturo
🎾 
🎾

[14:43] __@arturov.00 se unieron mediante el enlace de invitación__

[17:30] **+57 318 5358260:** [Imagen] Ven a PadelTown, disfruta del mejor ambiente, reúne a tu parche y aprovecha nuestra PROMO 3x4 en cerveza. 🎉🍺

[20:11] __@aleja.jaramillo17 se unieron mediante el enlace de invitación__

---

## 6 de julio de 2026

[14:19] **+57 318 5358260:** [Imagen] 🎾🍻 *¡El mejor plan está en Nomad!* 🔥

Ven a jugar aprovechando nuestra *PROMO 2x1 en canchas, vive toda la emoción del **Mundial* en pantalla gigante y acompaña cada partido con nuestra *PROMO 3x4 en cerveza*. 🍺⚽

¡Pádel, fútbol, amigos y el mejor ambiente te esperan! 💙 ¡Nos vemos en el club!

---

## 7 de julio de 2026

[8:39] **+57 318 5358260:** [Imagen] 💚 ¡Buenos días, familia PadelTown! ⚽🎾

Hoy vivimos una jornada imperdible de Mundial y queremos disfrutarla junto a ustedes. Los esperamos en el club para compartir la pasión por el fútbol, vivir cada jugada en pantalla grande y, por supuesto, aprovechar para entrar a la cancha y jugar un buen partido de pádel. 🔥

⚽ *Partidos de hoy:*
🕚 11:00 a. m. | Argentina 🇦🇷 🆚 Egipto 🇪🇬
🕒 3:00 p. m. | Colombia 🇨🇴 🆚 Suiza 🇨🇭

Nada mejor que combinar el mejor ambiente, buen pádel y toda la emoción del Mundial. ¡Los esperamos para alentar juntos a la Selección Colombia! 💛💙❤️

[9:01] **+57 318 5358260:** [Imagen] 🇨🇴🔥🔥🔥

[10:15] **+57 318 5358260:** [Imagen] 🍻⚽ ¡Hoy el mejor plan está en Nomad! 🎾

Ven a vivir toda la emoción del partido con nosotros y aprovecha nuestras promociones:

🍺 Happy Hour  2x1 en cervezas Stella Artois y Club Colombia.

Te esperamos... 🎾🔥

[14:50] **+57 318 5358260:** _Se eliminó este mensaje_

[14:50] **+57 318 5358260:** [Imagen] Ya casi empieza el partido de nuestra sele, LOS ESTAMOS ESPERANDO PARA VERLO JUNTOS EN FAMILIA🧡🇨🇴 y aprovecha nuestra promoción de 2x1 en cerveza 🍻.

[19:21] __@lauraisaza_ se unieron mediante el enlace de invitación__

---

## 8 de julio de 2026

[12:53] __@santi.suarezmusic99 se unieron mediante el enlace de invitación__

[12:59] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 08 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[13:19] __+57 318 5358260 añadió a +57 321 9363616__

[13:57] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 08 de Julio  
🕘 03:00 p.m - 05:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo
🎾 Jesús 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[13:58] **+57 350 4256023:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 08 de Julio  
🕘 03:00 p.m - 05:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo
🎾 Jesús 
🎾 
🎾 

¡¡¡Quién se Apunta!!_
Yo

[13:59] **+57 318 5358260:** Una pala más familia 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 08 de Julio  
🕘 03:00 p.m - 05:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo
🎾 Jesús 
🎾 Juan Gomez
🎾 

¡¡¡Quién se Apunta!!

[14:04] **@arturov.00:** _Se eliminó este mensaje_

[14:08] **+58 412-7646786:** _Se eliminó este mensaje_

[14:33] **+57 318 5358260:** Una pala más familia 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 08 de Julio  
🕘 03:00 p.m - 05:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo
🎾 Jesús 
🎾 Juan Gomez
🎾 

¡¡¡Quién se Apunta!!

[16:23] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 08 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

---

## 9 de julio de 2026

[9:31] **+57 318 5358260:** [Imagen] !Buenos días Familia PádelTown! 

Hoy hoy vivimos en PádelTown Nomad, un día lleno de momentos maravillosos ver el ⚽MUNDIAL ⚽Y 🎾JUGAR PADEL🎾 ven y disfruta de nuestros alimentos 🍕 y bebidas  🍻 

FRANCIA 🇫🇷 VS MARRUECOS 🇲🇦

Te esperamos no te pierdas de este gran día

[11:52] **+57 318 5358260:** [Imagen] !!LLeva Tu juego al siguiente Nivel !!🔥🥳

[11:53] **+57 318 5358260:** [Imagen] 🎾🔥🎾🔥🎾

[12:20] __+1 (829) 266-8723 se unieron mediante el enlace de invitación__

[13:18] **+57 315 3525636:** _Se eliminó este mensaje_

[16:36] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 09 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[16:39] **+57 350 4256023:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 09 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!_
yo

[16:40] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 09 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juan Gomez
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

---

## 10 de julio de 2026

[9:53] **+57 318 5358260:** [Imagen] ¡Buenos días Familia PádelTown! 

Hoy viviremos un gran plan en PádelTown Nomad, un día lleno de momentos maravillosos primero disfrutaremos de un gran partido del  ⚽MUNDIAL ⚽ Y despues nos veremos en cancha para 🎾JUGAR PADEL🎾 sera una tarde perfecta para compartir en familia y amigos, ven y disfruta de nuestros alimentos 🍕 y bebidas  🍻 

⚽ESPAÑA 🇪🇸 VS BELGICA 🇧🇪 ⚽

Te esperamos NO TE LO PIERDAS

[15:31] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Parra
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[16:39] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 de Julio  
🕘 06:00 p.m - 08:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Parra
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:31] **+57 318 5358260:** UNA PALA MAS FAMILIA!!!🔥

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 de Julio  
🕘 09:00 p.m - 11:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita 
🎾 Juan 
🎾 Sebastian  
🎾 

¡¡¡Quién se Apunta!!

[18:39] __+57 316 4985390 se unieron mediante el enlace de invitación__

[18:39] __Alguien añadió a +57 316 4985390__

[18:40] __@rojasandresfe se unieron mediante el enlace de invitación__

[18:50] **+57 318 5358260:** UNA PALA MAS FAMILIA!!!🔥

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 de Julio  
🕘 09:00 p.m - 11:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita 
🎾 Juan 
🎾 Sebastian  
🎾 

¡¡¡Quién se Apunta!!

[19:07] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 10 de Julio  
🕘 09:00 p.m - 11:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita 
🎾 Juan 
🎾 Sebastian  
🎾 Sebastian Parra

NOS VEMOS EN LA CANCHA🎾🔥

[19:33] **+57 318 5358260:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Camilo Garzon
🎾 Tatiana  
🎾 Sebastian Parra
🎾 
🎾 
🎾 

QUIEN SE APUNTA🎾🔥

[19:43] **+57 318 5358260:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Camilo Garzon
🎾 Tatiana  
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 
🎾 

QUIEN SE APUNTA🎾🔥

[19:46] **+57 318 5358260:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 
🎾 

QUIEN SE APUNTA🎾🔥

[19:47] **+57 316 4600939:**
> _+57 318 5358260: 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 
🎾 

QUIEN SE APUNTA🎾🔥_
Es de alguna categoría en específico?

[19:47] **+57 318 5358260:**
> _+57 316 4600939: Es de alguna categoría en específico?_
No señor, es para todas las categorías

[19:48] **+57 316 4600939:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 Diego m
🎾 

QUIEN SE APUNTA🎾🔥

[20:34] **+57 318 5358260:** DOS PALAS MAS FAMILIA!!!🔥

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 de Julio  
🕘 10:00 p.m - 11:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Anyely
🎾 
🎾 

¡¡¡Quién se Apunta!!

[20:36] __+57 323 2363947 se unieron mediante el enlace de invitación__

[21:05] __@sleimalejandra se unieron mediante el enlace de invitación__

[21:50] **+57 318 5358260:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 Diego m
🎾 

QUIEN SE APUNTA🎾🔥

[22:01] **+57 350 5786150:**
> _+57 318 5358260: 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 Diego m
🎾 

QUIEN SE APUNTA🎾🔥_
Me apunto

[22:17] **+57 318 5358260:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 Diego m
🎾 Omar Rojas

CLASE CERRADA, NOS VEMOS EN LA CANCHA🎾🔥
LISTA DE ESPERA 
🎾
🎾

---

## 11 de julio de 2026

[8:37] **+57 316 4600939:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 
🎾 Omar Rojas

CLASE CERRADA, NOS VEMOS EN LA CANCHA🎾🔥
LISTA DE ESPERA 
🎾
🎾

[8:53] **@DsebasMG:** ✋🏻

[10:14] **+57 318 5358260:** _Se eliminó este mensaje_

[10:15] **+57 318 5358260:** [Imagen] ¡Buenos días Familia PádelTown! 

Hoy viviremos un gran plan en PádelTown Nomad, un día lleno de momentos maravillosos primero disfrutaremos de un gran partido del  ⚽MUNDIAL ⚽ Y despues nos veremos en cancha para 🎾JUGAR PADEL🎾 sera una tarde perfecta para compartir en familia y amigos, ven y disfruta de nuestros alimentos 🍕 y bebidas  🍻 

⚽ARGENTINA🇦🇷 VS SUIZA 🇨🇭 ⚽

Te esperamos NO TE LO PIERDAS

[10:21] **+57 305 7120798:**
> _+57 316 4600939: 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 
🎾 Omar Rojas

CLASE CERRADA, NOS VEMOS EN LA CANCHA🎾🔥
LISTA DE ESPERA 
🎾
🎾_
Yo

[16:27] **+57 318 5358260:** 🎾 ¡CLASE GRATIS DE PÁDEL! 🎾

¿Quieres aprender, mejorar tu juego y pasar un excelente rato? 💥

📅 *Sábado 11 de julio*
🕘 *6:00 P. m.*
👥 *Clase mixta* (hombres y mujeres)

🔥¡Los cupos son limitados!


🎾 Sebastián Alfaro
🎾 Juanita Rojas
🎾 Sebastian Parra
🎾 Lina Candia  
🎾 Sebastian M 
🎾 Omar Rojas

CLASE CERRADA, NOS VEMOS EN LA CANCHA🎾🔥
LISTA DE ESPERA 
🎾 Laura Guanumen 
🎾

[16:29] **+57 318 5358260:** 🎾🔥 Familia PadelTown 🔥🎾

Les recordamos que nuestra clase gratis de hoy inicia a las 6:00 p.m. ⏰

⚠️ A tener en cuenta:
Daremos inicio con los participantes que estén PUNTUALES en la cancha 
Arrancamos puntuales y le sacamos todo el provecho a la jornada 💪😎
¡Nos vemos en cancha! 🎾🔥

[17:11] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 11 de Julio  
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[17:57] **+57 318 5358260:** 🎾🔥 Familia PadelTown 🔥🎾

Les recordamos que nuestra clase gratis de hoy inicia a las 6:00 p.m. ⏰

⚠️ A tener en cuenta:
Daremos inicio con los participantes que estén PUNTUALES en la cancha 
Arrancamos puntuales y le sacamos todo el provecho a la jornada 💪😎
¡Nos vemos en cancha! 🎾🔥

[18:16] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 11 de Julio  
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[18:34] **+57 318 5358260:** [Mensaje de album]

[18:34] **+57 318 5358260:** [Video]

[18:34] **+57 318 5358260:** [Imagen]

[18:34] **+57 318 5358260:** [Imagen]

[18:34] **+57 318 5358260:** [Imagen]

[18:34] **+57 318 5358260:** [Imagen]

[18:34] **+57 318 5358260:** [Imagen]

[18:34] **+57 318 5358260:** [Imagen]

[18:34] **+57 318 5358260:** [Imagen]

[18:34] **+57 318 5358260:** Cada clase es una oportunidad para mejorar tu juego, aprender algo nuevo y disfrutar al máximo en la cancha. 💪🔥
No importa si estás comenzando o si ya tienes experiencia, el mejor momento para seguir creciendo como jugador es hoy. Nuestros entrenadores están listos para ayudarte a perfeccionar tu técnica, mejorar tu estrategia y llevar tu nivel al siguiente escalón.
📅 Reserva tu clase de pádel ahora y asegura tu espacio🎾

[20:04] __+57 305 3234838 se unieron mediante el enlace de invitación__

[20:04] __+57 322 7916539 se unieron mediante el enlace de invitación__

---

## 12 de julio de 2026

[10:24] __¡Bienvenidos al grupo oficial de PadelTown Nomad 🎾👋! Este será nuestro espacio para compartir horarios, organizar partidos, comentar torneos y mantenernos al día con todo lo relacionado al pádel en nuestra cuarta sede Nomad Salitre.

¡Prepárense para mucha diversión y buenos partidos! 💪 Si tienen preguntas, ideas o simplemente quieren organizar un partido, ¡este es el lugar para hacerlo!
¡Nos vemos en las pistas! 

Reservas: https://www.easycancha.com/book/club-info

Formato partido:
*Fecha*
Categoría
⌚Horario
📍PadelTown Nomad Salitre
Pista #
🎾Jugador
🎾Jugador
🎾Jugador
🎾Jugador
**
Reserva a nombre de (Jugador)__

[10:25] __@StivenAJDesign cambió el nombre del grupo a "PadelTown Nomad Salitre 🎾"__

[11:24] __[Notificación del sistema]__

[11:38] __[Notificación del sistema]__

[17:55] **+57 318 5358260:** 🎾🔥Buenas tardes familia PadelTown Nomad🔥🎾

Tuvimos un pequeño inconveniente con nuestro grupo de WhatsApp pero ya estamos de vuelta con la mejor actitud para atenderlos y aun mejor seguimos con nuestra promoción.‼️

2X1 EN CANCHA🧡🔥🎾 
¡RESERVA AHORA!

[17:56] **+57 318 5358260:** [Imagen]

---

## 13 de julio de 2026

[12:24] __+1 (732) 755-8424 se unieron mediante el enlace de invitación__

[15:26] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 de Julio  
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[15:27] **+1 (732) 755-8424:** Yo activo🙌

[15:30] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 de Julio  
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sommy Ogando
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

[15:35] **+57 302 6055008:** _Se eliminó este mensaje_

[17:07] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 de Julio  
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sommy Ogando
🎾 
🎾 
🎾 

¡¡¡Quién se Apunta!!

---

## 14 de julio de 2026

[7:39] **+57 318 5358260:** 🎾🔥 ¡Hoy es un gran día para jugar pádel! 🔥🎾
Cada partido es una oportunidad para mejorar, competir, compartir con amigos y disfrutar de este deporte que tanto nos apasiona.
Te esperamos para seguir construyendo juntos esta gran comunidad de pádel. 🧡

📲 ¡Reserva ahora y nos vemos en la cancha!

[7:40] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 14 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Partidito o miedo?😬🔥
Quien se apunta!

[9:33] **+57 318 5358260:** [Imagen] Hoy hoy vivimos en PádelTown Nomad, un día lleno de momentos maravillosos ver el ⚽MUNDIAL ⚽Y 🎾JUGAR PADEL🎾 ven y disfruta de nuestros alimentos 🍕 y bebidas  🍻 

FRANCIA 🇫🇷 VS ESPAÑA🇪🇸

[10:05] __[Notificación del sistema]__

[12:49] **+57 321 9801846:** buenas tardes ya hay grupo de nuestro bogota ? sale que esta suspendido

[12:50] **+57 310 2578035:** De nuestro Bogotá y plaza claro también

[12:51] **+57 318 5358260:** Buenas tardes, se trata de un inconveniente temporal por favor,  no se salgan de las comunidades. En caso de que ya hayan salido, unirse nuevamente apenas las comunidades sean reactivadas.
Muchas gracias por su compresión

[15:57] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 14 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

Partidito o miedo?😬🔥
Quien se apunta!

[19:07] __+57 320 9066308 se unieron mediante el enlace de invitación__

---

## 15 de julio de 2026

[8:40] **+57 318 5358260:** 🧡🎾 ¡Hola familia PadelTown!🎾🧡

Queremos agradecerles por hacer parte de esta increíble comunidad que sigue creciendo cada día. 🙌🔥
Por eso, queremos recordares que tenemos promoción de 2x1 en cancha, en todos los horarios 

Es el momento perfecto para venir a jugar, compartir con amigos, mejorar su nivel y disfrutar del mejor ambiente dentro y fuera de la cancha 💪🎾
¡No dejen pasar esta oportunidad y hagan su reserva desde ya!🎾🔥

[9:28] **+57 318 5358260:** [Imagen] Y seguimos con nuestras promociones para nuestra familia PadelTown NOMAD 🔥🍻.

[11:29] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 15 de Julio  
🕘 3:00 p.m - 5:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Santiago C
🎾 Lisa B 
🎾 
🎾 

Partidito o miedo?😬🔥
Quien se apunta!

[11:58] **@Santyamen:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 15 de Julio  
🕘 3:00 p.m - 5:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

Partidito o miedo?😬🔥
Quien se apunta!

[13:26] **+57 318 5358260:** [Imagen] Recuerda que te estamos esperando para ver este gran partido del mundial 😬🔥⚽

[15:42] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 15 de Julio  
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian P.
🎾 
🎾 

🔥
Quien se apunta 3 palas mas !

---

## 16 de julio de 2026

[13:44] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 de Julio  
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian G.
🎾 
🎾 
🎾

🔥
Quien se apunta 3 palas mas !

[13:57] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 de Julio  
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian G.
🎾 Sebastian P. 
🎾 
🎾

🔥
Quien se apunta 2 palas mas !

[15:33] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita
🎾 Sebastian 
🎾 Sebastian Parra
🎾

🔥
Quien se apunta 1 palas mas !

[15:43] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 16 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita
🎾 Sebastian 
🎾 Sebastian Parra
🎾 Laura 

NOS VEMOS EN LA CANCHA🔥🎾

[15:47] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾 
🎾

Quien se apunta🔥

[16:05] __+57 310 2071187 se unieron mediante el enlace de invitación__

[16:06] __Alguien añadió a +57 310 2071187__

[16:06] __+57 312 3297466, +57 321 4821647, @linacandia, +57 311 2866676, +57 313 2640889, @diegoahernandezsilva, @arturov.00, +57 312 5528991, +57 312 4173824, +57 318 4990342, @juanvanegas.vel, +57 312 4829489, +58 412-7646786, +57 312 6444545, +57 310 6974733, +57 311 4982613, +57 312 8437733 y Jorge😎 Pádel salieron__

[17:16] **+57 318 5358260:** [Imagen] Y seguimos con nuestras promociones para nuestra familia PadelTown NOMAD 🔥🍻.

[18:57] **+57 318 5358260:** Hola🤗 buenas noches familia Padeltown 🎾

Debido a los inconvenientes con nuestros grupos de WhatsApp, vamos a iniciar de nuevo 

Los invitamos a unirse a nuestro grupo de Nuestro Bogotá

Únete aquí y sigue conectado con todas las novedades de PadelTown.
https://chat.whatsapp.com/BtX1KzU444HKVEJiZ23yLN?s=cl&p=a&ilr=1&amv=1

[19:37] __@hech.un se unieron mediante el enlace de invitación__

[21:30] __@rojasandresfe añadió a @DavidRojas12__

---

## 17 de julio de 2026

[12:08] **+57 350 4256023:** Buenas buenas para mañana hay partidos ? Gracias

[12:10] **+57 310 2192130:** Mañana juega Francia vs Inglaterra

[12:11] **+57 350 4256023:** Jajaja

[12:12] **+57 350 4256023:** Es verdad

[12:13] **+57 310 2192130:** 👍

[12:57] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 17 de Julio  
🕘 6:00 p.m - 7:00 p.m
Categoría: 4TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jorge Ruiz 
🎾 Jaime Orozco 
🎾 
🎾

Quien se apunta🔥

[17:01] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 17 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Juanita
🎾 Isabella
🎾

Quien se apunta🔥

[17:20] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 17 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Juanita
🎾 Isabella
🎾 Laura 

NOS VEMOS EN LA CANCHA 🔥🎾

[17:20] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 17 de Julio  
🕘 6:00 p.m - 7:00 p.m
Categoría: 4TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jorge Ruiz 
🎾 Jaime Orozco 
🎾 
🎾

Quien se apunta🔥

[18:21] __+57 318 5358260 añadió a +57 319 3983703__

---

## 18 de julio de 2026

[8:02] **+57 318 5358260:** 🔥🎾 ¡Sabadito de pádel en Padel Town! 🎾🔥

Hoy es el día perfecto para salir de la rutina, disfrutar con amigos y vivir la pasión por el Pádel. 💪🔥

Te esperamos para que aproveches todos nuestros servicios:

🎾 Clases personalizadas para todos los niveles.
🎾Academia de pádel para mejorar tu juego.
🎾 Reserva de canchas y arma tu partido.
🎾 Membresías con excelentes beneficios y descuentos exclusivos
No importa si eres principiante o avanzado, siempre hay una cancha y una oportunidad para seguir creciendo en este gran deporte. ¡Anímate y vive una mañana llena de energía, deporte y buena compañía! 🎉🏆

📲 Reserva ahora y ven a disfrutar tu sábado en Padel Town. ¡Nos vemos en la cancha! 🎾😎

[12:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 de Julio  
🕘 4:00 p.m - 5:30 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Edgardo 
🎾 
🎾

Quien se apunta🔥

---

## 19 de julio de 2026

[15:05] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾

Quien se apunta🔥

[15:07] **+57 318 5358260:** DOS PALAS MAS FAMILIA!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Andres  
🎾 
🎾

Quien se apunta🔥

[17:05] **+57 318 5358260:** DOS PALAS MAS FAMILIA!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Andres  
🎾 
🎾

Quien se apunta🔥

[18:03] **+57 318 5358260:** DOS PALAS MAS FAMILIA!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Andres  
🎾 
🎾

Quien se apunta🔥 **

[19:38] **+57 318 5358260:** UNA PALA MAS FAMILIA!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Julio  
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Andres  
🎾 Julian 
🎾

Quien se apunta🔥 **

[20:01] **+57 318 5358260:** UNA PALA MAS FAMILIA!!!

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 19 de Julio  
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: GRATIS 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Andres  
🎾 Julian 
🎾

Quien se apunta🔥

---

## 20 de julio de 2026

[8:25] __+57 320 4279193 se unieron mediante el enlace de invitación__

[8:38] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Julio  
🕘 11:00 a.m - 1:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 25.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾

Quien se apunta🔥

[10:52] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Omar Rojas 
🎾 
🎾 
🎾

Quien se apunta🔥

[12:07] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Omar Rojas 
🎾 
🎾 
🎾

Quien se apunta🔥

[13:05] **+57 310 2578035:** Voy

[13:08] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Omar Rojas 
🎾 Enrique 
🎾 
🎾

Quien se apunta🔥

[15:28] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 20 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sofia Cuervo  
🎾 Hector Cuervo  
🎾 
🎾

Quien se apunta🔥

[15:42] **+57 310 2578035:** Voy  al de las 7pm

[15:47] **+57 350 5786150:** Me sumo al de 7 pm

[15:51] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 20 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sofia Cuervo  
🎾 Hector Cuervo  
🎾 Enrique 
🎾 Omar Rojas 

NOS VEMOS EN CANCHA🔥🎾

---

## 21 de julio de 2026

[8:28] **+57 318 5358260:** BUENOS DIAS FAMILIA PADELTOWN🔥.
Hoy es el día perfecto para salir de la rutina, disfrutar con amigos y vivir la pasión por el pádel. 💪🔥
 ¡Anímate y vive una mañana llena de energía, deporte y buena compañía! 🎉🏆

[11:22] **+57 318 5358260:** _Se eliminó este mensaje_

[17:24] **+57 318 5358260:** 🧡 ¡Hola a todos!

Queremos invitarlos a unirse a la Comunidad PadelTown, donde encontrarán todas las novedades, promociones, torneos y eventos de nuestros clubes.

Este grupo seguirá funcionando con normalidad, pero al hacer parte de la comunidad tendrás acceso a toda la información de PadelTown en un solo lugar.

¡Te esperamos! 🎾

👉 Únanse aquí: https://chat.whatsapp.com/Deu956KZTL4FDMqRKhZAAe?s=cl&p=a&ilr=1&amv=0

[17:56] __@kbercast se unieron mediante el enlace de invitación__

[18:41] __+57 300 5526808 se unieron mediante el enlace de invitación__

---

## 22 de julio de 2026

[9:04] **+57 318 5358260:** DOS PALAS MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría: 4TA - 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Edgardo
🎾 
🎾 

QUIEN SE APUNTA 🔥🎾

[9:18] **@marlon.iragorri:**
> _+57 318 5358260: DOS PALAS MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría: 4TA - 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Edgardo
🎾 
🎾 

QUIEN SE APUNTA 🔥🎾_
🙋🏻‍♂️

[9:18] **+57 318 5358260:** UNA PALA MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría: 4TA - 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Edgardo
🎾 Marlon
🎾 

QUIEN SE APUNTA 🔥🎾

[9:48] **@Santyamen:** UNA PALA MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría: 4TA - 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Edgardo
🎾 Marlon
🎾 Santiago

QUIEN SE APUNTA 🔥🎾

[9:49] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría: 4TA - 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾 Edgardo
🎾 Marlon
🎾 Santiago

NOS VEMOS EN LA CANCHA  🔥🎾

[15:46] **+57 318 5358260:** DOS PALAS MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 
🎾 

QUIEN SE APUNTA 🔥🎾

[17:56] **+57 318 5358260:** DOS PALAS MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 
🎾 

QUIEN SE APUNTA 🔥🎾

[18:37] **+57 318 5358260:** DOS PALAS MAS FAMILIA 

🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 22 de Julio  
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Nico Lopez 
🎾 Isa Hernandez 

NOS VEMOS EN LA CANCHA 🔥🎾

[19:41] __+57 310 8524199 se unieron mediante el enlace de invitación__

[19:41] __Alguien añadió a +57 310 8524199__

[21:36] __@danielafeijoo97 se unieron mediante el enlace de invitación__

[21:36] __Alguien añadió a @danielafeijoo97__

---

## 23 de julio de 2026

[10:16] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[11:13] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾
🎾
🎾
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[11:58] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾
🎾
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[12:07] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾 Catalina Urdaneta 
🎾
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[12:14] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[12:15] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[12:17] __+57 312 4284273 se unieron mediante el enlace de invitación__

[12:17] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾
🎾
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[16:23] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 23 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Juan camilo
🎾 

QUIEN SE APUNTA UNA PALA MAS🔥🎾

[16:24] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 23 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Juan camilo
🎾 

QUIEN SE APUNTA UNA PALA MAS🔥🎾_
Yo

[16:43] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 23 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Juan camilo
🎾 Marlon 

NOS VEMOS EN LA CANCHA 🔥🎾

[17:59] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 23 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Juan camilo
🎾 Marlon 

NOS VEMOS EN LA CANCHA 🔥🎾_
Disculpa me debo salir no alcanzo a llegar

[18:23] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 23 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Juan camilo
🎾 

QUIEN SE APUNTA UNA PALA MAS🔥🎾

[18:28] **@cristian_D_nustes:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 23 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Juan camilo
🎾 

QUIEN SE APUNTA UNA PALA MAS🔥🎾_
Voy

[18:34] **@cristian_D_nustes:** Si es fijo?

[18:36] **+57 305 3234838:**
> _@cristian_D_nustes: Si es fijo?_
Sii

[18:39] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 23 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian alfaro 
🎾 Juan camilo
🎾 Cris

NOS VEMOS EN LA CANCHA 🔥🎾

---

## 24 de julio de 2026

[9:48] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾
🎾
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[10:16] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾 Laura Sanchez 
🎾
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[11:25] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 24 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría: 4TA - 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Edgardo  Gomez
🎾 Marlon 
🎾 Santiago 
🎾 

QUIEN SE APUNTA UNA PALA MAS🔥🎾

[11:54] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾 Laura Sanchez 
🎾 Nancy Suspes 
🎾
🎾


¡Nos vemos en la cancha! 🙌🏻🎾

[12:36] **@Santyamen:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 24 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría: 4TA - 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Edgardo  Gomez
🎾 Marlon 
🎾 Santiago 
🎾 

QUIEN SE APUNTA UNA PALA MAS🔥🎾

[16:01] __+57 313 4798891 se unieron mediante el enlace de invitación__

[17:25] __+57 311 2146248 se unieron mediante el enlace de invitación__

[19:52] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾 Laura Sanchez 
🎾 Nancy Suspes 
🎾
🎾

Dos Palas mas quien se anima !!
¡Nos vemos en la cancha! 🙌🏻🎾

[21:12] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾 Laura Sanchez 
🎾 Nancy Suspes 
🎾Paula Riaño 
🎾

Una Pala mas quien se anima !!
¡Nos vemos en la cancha! 🙌🏻🎾

[22:27] __+57 322 9087633 se unieron mediante el enlace de invitación__

[22:27] __Alguien añadió a +57 322 9087633__

[22:28] __@johanbohorque se unieron mediante el enlace de invitación__

---

## 25 de julio de 2026

[7:05] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina 
🎾Catalina urdaneta 
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾 Laura Sanchez 
🎾 Nancy Suspes 
🎾Paula Riaño 
🎾

Una Pala mas quien se anima !!
¡Nos vemos en la cancha! 🙌🏻🎾

[7:13] **+57 318 5358260:** 🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 25 de julio
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $40.000 por jugadora
🟠 Miembros Orange: $32.000
⚫ Miembros Black: $28.00

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, desayuno sorpresa toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada para 2 personas gratis 

🥈 2do lugar: 1 Kit padeltown 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 Valentina 
🎾 Juanita 
🎾 Laura Puerto 
🎾 Daniela Ospina  
🎾Daniela Gil 
🎾 Heidy Martinez
🎾 Nubia Rada
🎾 Laura Sanchez 
🎾 Nancy Suspes 
🎾Paula Riaño 
🎾Stefanie rojas 
🎾 Claudia Loaiza 

TORNEO CERRADO🔥🎾
¡Nos vemos en la cancha! 🙌🏻🎾

[7:17] **+57 318 5358260:** @all Buenos Dias Familia PadelTown🎾🧡

Para nuestras participantes del torneo femenino de hoy de 6ta, les recordamos su puntualidad para dar inicio a las 9:00 am y puedan jugar  todos los partido con normalidad 

Las chicas que deseen llegar a las 8:30 am para reclamar su desayuno y calentar un poco los motores antes de iniciar este gran torneo las esperamos 🌞🎾  

Vamos con toda chicas 🔥🔥

[8:04] **+57 318 5358260:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAQCAwEFBwYI/8QANRAAAgEDAgUBBgQGAwEAAAAAAQIDAAQRBSESMUFRYRMGIjJCcaEHFIGxI3LB0eHwgpGi8f/EABoBAQEBAAMBAAAAAAAAAAAAAAABAgMEBQb/xAApEQACAQMDAgQHAAAAAAAAAAAAAQIDETEEBVEh0RITFEEGIiQyQ4Gx/9oADAMBAAIRAxEAPwD6bpe+kRICHAYtsAaukdY0LscAUnbIbib8xKNh8IqrkPgoSOS2AkkjDIwww7VJlACMGaSzByV6r9fFbIjIwdxSUsD27mS23X5kqp3MtWLlb0lBU8cB5HmV/uKvBBAIOQeta+F+HMlsMpzeHqPIq6ORAyGBgyyHdB08+KNFTG6puZ1gj4jux2VRzJqVxKIYi5BPYDqa85rOtw6TG15dMkzxSxJcLHIC1nFIcCVl3OBkH6b9KiVyt2KfanVLvSVsPT9KG81C4FvHdXSE29t19/BG55KMjJ5mvL2OhXura/dW+q2q27CdZtSt/UkSLjIIjvbOUbq5xgrnfkaR9lvZfU4dZmstW0V5JZAtreTsCbO6gzxSTu/FmSVuSjHuZBxtXW7O0js9Ogso2lkghjESmVy7MAMZYnma23Ywlc1+kW1voduLKNZlhLM/rTSGR5WJyzu53LHua24ORkbilpFwvpS5ZD8DdQeg+vmq7eFOJkmjRZefujAI8YrBtDoIIyDkUUutnEFAPGT/ADsP60VClDE3s/CuRCnM96fAAAAGANgKhDEsUYRenM96sqtkSCiiioUUuLUlvVgPDIN8DrXi9e9vtP8AZ+4nt1ge91Hi/iRxkIkfhm3wfABPevW+0l+dL0DUb1CPVgt5JIwerKpIH2r5fvbh4onmcmSVjksxyWYncmunq9TKklGOWe7sm10tZKVSs/lj7cnQNd/Ei+1QWQg/N6QYboSPJaTLJxR4wQVZBnHPG4OMbbEeh0jT5vbhEf2h0OKa1lWSKHXrRxaztEAVDPHktwtuAMkd1ANcU0+9eeUxyAcsgiu1/gbezyWmq2Lvm3t3jljB6GTiyB4ymfqTXHpNXOU/LmdveNm09Kh6nTdEsrP9OlWFsllYW1pG8siW8SxK8rcTsFGMsep23NX0UV6B8uYZQylWGQeYpMkMChLEKf4cg79v951axM5KocRDZmHzeBVxRTHwcI4cYxVwTIkl+BlZwI5FOCNz/SioPYi5bid2V19xsdSOv/WKKdB1NlRUIZVlTiQ5H7VOoUKrmlSGMu52+58UTSrDGXc4A+9aiaV55ON/0XoK0lczKVinUY11KCeG6GYpo2iZQeSsMEV8/a3pM2l30+nX65ZOTY2kXow+v2OR0r6HijeaTgj59SeSitT+IPspFrXs8/5WPOo2gMsDD4nON0P82P0OO1dXW0PNheOUezsW5ejrOM/slnv3PnyC2ituJkGNtyT0rvX4S6DJo+iTT3iNHfXjLI8bDDRoB7gI77k/8sdK8T+EPs7HrOpvql2nHZ2TL6akbPMRkZ/lGDjuR2rtcsfHhkPDIvI/0PiuroaH5Zfo9T4i3FP6OlhZ7FtLsTOSqHEQ2Zh83gVFWe5HDgog2c55nsPHmmVAUAKMAcgK9PB8nkFAUAKMAcgKzRRUKUK3DLN5YH/yKKnHGFB4veYnJPmiqQVltnhf1bXbulWR3sRiLOeArzXr+ner5pVhjLyHAH3rTSuZZWkKhc8gOn+aqV8mW/DglPK08nG+wHwr2/zWIo3mk4I+fUnkoqKLxyKgZVycZPIVuYIUgjCIPJJ5k9zWm7GUvEEEKQRhEHkk8ye5qyiiuM5RHSNJsdHtnt9Mtkt4XkaVlXO7NzO9MPxSsUGVQfE3fwKuooklgspOTvJ3ZhQFACjAHICs0UUIFFFFAFFFFAaSaV55ON+nwr0FEMTzycCfq3QVmCJp5OBNgPibt/mttDEkMYRBgfvXI3Y40r9WVGziMIjC4x83XPeqUlktGCT5aPkGFP1F1V1KuAVPMVi/Ju3BlWDKGUgg8iKzSDJJZktFl4uqnp/vem4ZVmTiQ7ciO1GgmWUUUVChUZGCIWYgADmaw8iRjLsFHPeqo1MzCSQEKN0Q/ufNAWQSNJGGdCjdjRNIIkyQSTsFHMntRLKsakk5PRRzJ6CoxRtxepLgyHkOijsKAXW2eReKUl2PL3yuB2op6ilxYhDEsMYSMYA+9ToooAoorX3dw0vFFbgsAPeI61UrkbsZuJmnf0LfcfM3+9KtSL8qoZMsvzjv5FY08xejiP4vmzz/APlN0fBEr9TCsGUFSCD1FZqKoqklVAzucDnRISI2IODjY1DQuE/NEtJn01JCAHmR839qvlkWJOJvoB1J7VVZMGtUCqVAHD73cc/vWYY3Ll58FxsuOQHcUBiOEtIJpdpegB2UdqYoqEkixoWc7fvQEiQOZFFKNbNcH1JWKE8lUDYefNFCDlFFFCiOqSsiKinAYHPnFM28SRRgIOe5PU0UVr2MrInfqIZEliyrknOKehYvCjnGWUE4ooo8BZJ1jPvEeBRRWTRTF7t1Mo+EhXx5OQf2FX0UUBGQ8MbMOYBNLWp9eR5JNyhwo6DYb/XeiigG6KKKA//Z: Ubicación: 4.6430056, -74.1115526 — https://maps.google.com/?q=4.6430056,-74.1115526

[8:19] __+57 350 4256023 añadió a +57 312 6444545__

[10:00] __+57 314 3703697 añadió a +57 314 4441297__

[12:31] **@danielafeijoo97:** Holaa dejé una chaqueta azul claro me la pueden guardar por favor

[12:31] **@danielafeijoo97:** Quedo en un espaldar de una silla

[12:44] **+57 318 5358260:** UNA PALA MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 25 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres Rojas
🎾 Hector Romero 
🎾 David Rojas
🎾 

QUIEN SE APUNTA 🔥🎾

[12:45] **+57 300 5526808:** Yo, Hernán

[12:45] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 25 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres Rojas
🎾 Hector Romero 
🎾 David Rojas
🎾 Hernan

NOS VEMOS EN LA CANCHA 🔥🎾

[13:06] **+57 318 5358260:** [Reenviado] [Imagen]

[13:06] **+57 318 5358260:** Buenas tardes Familia PadelTown🌞🎾
Enviamos nuestra tabla de puntuación de nuestro torneo femenino 6TA.
MUCHAS GRACIAS A TODAS POR ASISTIR😉🎾🔥

[14:35] __+57 319 2913176 se unieron mediante el enlace de invitación__

---

## 26 de julio de 2026

[7:44] **+57 318 5358260:** 🏆🧡 ¡Qué gran jornada vivimos ayer en nuestro Torneo Femenino de Pádel!🎀

Gracias a todas las jugadoras por su energía, entrega y excelente actitud dentro y fuera de la cancha. Fue un día lleno de buenos partidos, risas y momentos inolvidables.

📸 Les compartimos las mejores fotos para que revivan cada instante. ¡Etiquétense, compártanlas y nos vemos muy pronto en el próximo torneo! 🎾✨

[7:44] **+57 318 5358260:** [Mensaje de album]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[7:44] **+57 318 5358260:** [Imagen]

[11:18] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 26 de Julio  
🕘 3:00 p.m - 5:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Parra
🎾 
🎾 
🎾 

QUIEN SE APUNTA 🔥🎾

---

## 27 de julio de 2026

[14:59] **+57 318 5358260:** ¿Listo para vivir la mejor experiencia de pádel?
En nuestro club encontrarás todo lo que necesitas:
🎾 Canchas disponibles para reservar.
🔥Clases para principiantes y jugadores avanzados.
🏆 Academias para niños, jóvenes y adultos.
💳 Membresías con beneficios exclusivos.


No importa si vienes a competir, aprender o simplemente disfrutar con amigos, aquí tenemos un espacio para ti.

📲 Escríbenos ahora y conoce nuestras promociones, horarios y disponibilidad.
¡Reserva hoy y sé parte de la comunidad que está haciendo crecer el pádel! 💥

[17:25] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 27 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría:  6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 David
🎾 Andres Rojas 
🎾 
🎾 

DOS PALAS QUIEN SE APUNTA 🔥🎾

---

## 28 de julio de 2026

[11:02] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

DOS PALAS QUIEN SE APUNTA 🔥🎾

[11:04] **@hech.un:** Me apunto, Hector Cuervo

[11:04] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Hector Cuervo 
🎾 
🎾 
🎾 

DOS PALAS QUIEN SE APUNTA 🔥🎾

[11:04] **@DavidRojas12:** Me apunto ☝️

[11:04] **@DavidRojas12:**
> _@DavidRojas12: Me apunto ☝️_
David Rojas

[11:05] **@rojasandresfe:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Hector Cuervo 
🎾 
🎾 
🎾 

DOS PALAS QUIEN SE APUNTA 🔥🎾_
Me apunto también, Andrés Rojas

[11:12] **@cristian_D_nustes:** y yo

[11:17] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 7:30 p.m - 9:30 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Hector Cuervo 
🎾 David Rojas
🎾 Andres Rojas
🎾 Cristian 

NOS VEMOS EN LA CANCHA🔥🎾

[11:24] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 4:30 p.m - 6:30 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Diego
🎾 Jhoan 
🎾 
🎾 

DOS PALAS QUIEN SE APUNTA 🔥🎾

[11:25] __+57 301 4170998 añadió a +57 311 4731467__

[13:40] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Jhoan 
🎾 Edgardo 
🎾 

UNA PALAS QUIEN SE APUNTA 🔥🎾

[13:52] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 4:00 p.m - 6:00 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Jhoan 
🎾 Edgardo 
🎾 

UNA PALAS QUIEN SE APUNTA 🔥🎾_
🙋🏻‍♂️

[14:07] **@pomboemilio:** _Un admin., +57 318 5358260, eliminó este mensaje._

[14:08] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 4:30 p.m - 6:30 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Jhoan 
🎾 Edgardo 
🎾 Marlon 

NOS VEMOS EN LA CANCHA🔥🎾

[15:32] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 4:30 p.m - 6:30 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Jhoan 
🎾 Edgardo 
🎾 

UNA PALA MAS FAMILIA🔥🎾

[16:11] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 4:30 p.m - 6:30 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Jhoan 
🎾 Edgardo 
🎾 

UNA PALA MAS FAMILIA🔥🎾

[16:12] **+57 311 8475699:** Hola buenas tardes, por favor cambiarlo para empezar a las 5 gracias

[16:13] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 5:00 p.m - 7:00 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Jhoan 
🎾 Edgardo 
🎾 

UNA PALA MAS FAMILIA🔥🎾

[16:39] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 5:00 p.m - 7:00 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Jhoan 
🎾 Edgardo 
🎾 Reservado 

NOS VEMOS EN CANCHA 🔥🎾

[16:47] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian Alfaro  
🎾 Sebastian Vargas 
🎾 

UNA PALA MAS FAMILIA🔥🎾

[16:56] __+57 310 6488275 añadió a Andres R__

[17:11] **@cristian_D_nustes:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian Alfaro  
🎾 Sebastian Vargas 
🎾 Andrea Rodriguez

[17:13] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 28 de Julio  
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Sebastian Alfaro  
🎾 Sebastian Vargas 
🎾 Andrea Rodriguez 

NOS VEMOS EN CANCHA 🔥🎾

[18:36] __+57 318 5358260 añadió a +57 312 3711878__

---

## 29 de julio de 2026

[8:36] **+57 312 3711878:** _Un admin., +57 318 5358260, eliminó este mensaje._

[11:28] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[11:34] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[11:42] **@Santyamen:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾Lisa // Santiago 
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[12:03] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[12:32] **+57 322 9087633:** hola

[12:32] **+57 322 9087633:** entramos !

[12:32] **+57 322 9087633:** Paula y Brayan por favor

[12:33] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[12:59] **+57 318 5358260:** [Imagen] SEGUIMOS CON NUESTRA PROMOCION DE 2X1 EN CANCHA🔥🎾

¡Reserva ahora!😬🍻🎾

[13:05] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[17:20] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

---

## 30 de julio de 2026

[7:37] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Laura // Kevin
🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[8:48] __+57 320 9790901 se unieron mediante el enlace de invitación__

[8:54] **+57 312 3711878:** _Un admin., +57 318 5358260, eliminó este mensaje._

[9:08] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[9:54] **+57 320 9790901:** [Imagen] Adidas metalbone PRO EDT ale galan vendo a cambio 🥳

[10:21] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 30 de Julio  
🕘 5:30 p.m - 7:30 p.m
Categoría:  4TA-5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Santiago
🎾 Edgardo 
🎾 Marco

NOS VEMOS EN LA CANCHA🔥🎾

[11:03] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[12:11] **+57 320 9790901:** [Imagen] Ofrezco mi adidas galan reserve escasos  partidos👽

[17:54] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Buscar Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

---

## 31 de julio de 2026

[7:23] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Busca Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[11:15] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Busca Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[11:40] __+57 322 9087633 añadió a +57 316 8070239__

[11:40] **+57 322 9087633:** [Mensaje de message_history_notice]

[11:55] **+57 316 8070239:**
> _+57 318 5358260: 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Busca Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾_
Mayra y Rubén

[12:08] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Busca Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾 Mayra // Ruben 
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[12:51] **+57 320 9790901:** [Imagen] Ofrezco mi adidas galan reserve escasos  partidos👽

[13:08] __+57 315 5772137 se unieron mediante el enlace de invitación__

[13:09] __+57 315 5772137 añadió a @gdag__

[16:37] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Sebastian Parra // Busca Partner 
🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾 Mayra // Ruben 
🎾 William // Busca Partner
🎾 Alberto // Nancy 

¡Nos vemos en la cancha! 🙌🏻🎾

[16:42] **+57 320 9790901:** [Imagen] Recien llegada a gran precio nox 18k del mozart 2026🙂‍↕️

[16:53] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾 Mayra // Ruben 
🎾 William // Busca Partner
🎾 Alberto // Nancy 

¡Nos vemos en la cancha! 🙌🏻🎾

[17:13] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾 Mayra // Ruben 
🎾 William // Busca Partner
🎾 Alberto // Nancy 
🎾 Sebastian Vargas // Lina Candia  

¡Nos vemos en la cancha! 🙌🏻🎾

[17:14] __+57 322 9087633 añadió a +57 321 3782532__

[17:14] **+57 322 9087633:** [Mensaje de message_history_notice]

[17:41] **+57 320 9066308:** Nos falta un partner para William, alguiennnn?

[17:55] **+57 318 5358260:** 🌟 TORNEO PAREJAS FIJAS 5TA - 6TA (mixto) 🌟
 
📅 VIERNES 31 de julio
⏰ 7:00 pm a 10 p.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugador
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: 5ta - 6ta (Mixto)

🎾 Incluye: Pala, pelotas, pizza por pareja, toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: tarjeta 100.000 x persona (consumibles en el club)

🥈 2do lugar: 4 Cervezas para la pareja 

🥉 3er lugar: Premio sorpresa

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 

🎾 Valentina // Manuel
🎾 Lisa // Santiago 
🎾 Juanita // Sebastian 
🎾 Paula // Brayan
🎾 Sebastian // Heirimar
🎾 Mayra // Ruben 
🎾 William // Leo (provisional) 
🎾 Alberto // Nancy 
🎾 Sebastian Vargas // Lina Candia  

¡Nos vemos en la cancha! 🙌🏻🎾

[18:33] **+57 318 5358260:** Buenas tardes Familia PadelTown NOMAD  

🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 1 de Agosto
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugadora
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, tinto, agua o jugo) toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada, Gatorade

🥈 2do lugar: 1 Hora de cancha gratis 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 
🎾 
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[21:08] **+57 318 5358260:** Buenas tardes Familia PadelTown NOMAD  

🌟 TORNEO FEMENINO C (6ta) 🌟
 
📅 Sabado 1 de Agosto
⏰ 9 am a 11 a.m.
🎾 Sede Nomad Salitre

💸 Inscripción: $50.000 por jugadora
🟠 Miembros Orange: $40.000
⚫ Miembros Black: $35.000

🏆 Categoría: Femenino C

🎾 Incluye: Pala, pelotas, tinto, agua o jugo) toda la organización para que solo se enfoquen en jugar y disfrutar! 🙌🏻

🏆 Premios:
🥇 1er lugar: 1 clase personalizada, Gatorade

🥈 2do lugar: 1 Hora de cancha gratis 

🥉 3er lugar: Gatorade

💥Súbanle nivel al juego y vivan una noche llena de competencia, risas y buena energía🔥🎾

Inscríbete aquí: 
🎾 
🎾 
🎾
🎾
🎾

¡Nos vemos en la cancha! 🙌🏻🎾

[22:36] **+57 320 9790901:** [Imagen] Para ellas 👩 Adidas Cross it edicion especial martita ortega .
3 palas disponibles y con garantia🙂‍↕️

[22:49] __@linacandia se unieron mediante el enlace de invitación__

---

## 1 de agosto de 2026

[10:08] **+57 318 5358260:** 🚨 ¡Hoy no te quedes sin jugar! 🎾🔥

¿Sin compañero? ¡No hay problema! Ya tenemos partido armado y solo faltas tú. 💥

Ven a disfrutar de un buen juego, conocer nuevos jugadores y vivir la mejor energía de PadelTown Nomad.

Fecha: Hoy 1 de Agosto
Categoría: 5ta - 6ta
⌚Horario: 3:00 pm - 5:00 pm
📍PadelTown Nomad Salitre
Cancha 2
🎾
🎾
🎾
🎾

[10:35] **@DavidRojas12:** _Un admin., +57 318 5358260, eliminó este mensaje._

[10:40] **+57 315 5772137:** 🚨 ¡Hoy no te quedes sin jugar! 🎾🔥

¿Sin compañero? ¡No hay problema! Ya tenemos partido armado y solo faltas tú. 💥

Ven a disfrutar de un buen juego, conocer nuevos jugadores y vivir la mejor energía de PadelTown Nomad.

Fecha: Hoy 1 de Agosto
Categoría: 5ta - 6ta
⌚Horario: 3:00 pm - 5:00 pm
📍PadelTown Nomad Salitre
Cancha 2
🎾 Laura 
🎾
🎾
🎾

[11:11] **+57 318 5358260:** 🚨 ¡Hoy no te quedes sin jugar! 🎾🔥

¿Sin compañero? ¡No hay problema! Ya tenemos partido armado y solo faltas tú. 💥

Ven a disfrutar de un buen juego, conocer nuevos jugadores y vivir la mejor energía de PadelTown Nomad.

Fecha: Hoy 1 de Agosto
Categoría: 5ta - 6ta
⌚Horario: 3:00 pm - 5:00 pm
📍PadelTown Nomad Salitre
Cancha 2
🎾 Laura 
🎾Sebastian Parra
🎾
🎾

[12:49] **+57 318 5358260:** Familia nos faltan 2 palas 
¿Quien dijo yo?


🚨 ¡Hoy no te quedes sin jugar! 🎾🔥

¿Sin compañero? ¡No hay problema! Ya tenemos partido armado y solo faltas tú. 💥

Ven a disfrutar de un buen juego, conocer nuevos jugadores y vivir la mejor energía de PadelTown Nomad.

Fecha: Hoy 1 de Agosto
Categoría: 5ta - 6ta
⌚Horario: 3:00 pm - 5:00 pm
📍PadelTown Nomad Salitre
Cancha 2
🎾 Laura 
🎾Sebastian Parra
🎾
🎾

[16:19] **+57 320 9790901:** [Imagen] Adidas metalbone PRO EDT ale galan vendo a cambio 🥳

---

## 2 de agosto de 2026

[9:19] **+57 320 4279193:** Buen día, algún partido americano de 6ta el día de hoy? En la mañana o en la tarde.

[9:25] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 1 AGOSTO
🕘 4:00 p.m - 6:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis Esquivel
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[11:32] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 1 AGOSTO
🕘 4:00 p.m - 6:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis Esquivel
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[15:58] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 1 AGOSTO
🕘 6:30 p.m - 8:30 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[16:12] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 1 AGOSTO
🕘 6:30 p.m - 8:30 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis Esquivel
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[17:20] __+57 310 7173212 se unieron mediante el enlace de invitación__

[17:20] __Alguien añadió a +57 310 7173212__

---

## 3 de agosto de 2026

[12:55] **+57 320 9790901:** [Imagen] a gran precio nox 18k del mozart 2026🙂‍↕️

[14:33] **+57 312 4284273:** _Se eliminó este mensaje_

[14:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 3 AGOSTO
🕘 6:30 p.m - 8:30 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[14:50] __+57 318 5358260 añadió a +57 321 3782532__

---

## 4 de agosto de 2026

[7:20] __@NazSanchez se unieron mediante el enlace de invitación__

[9:19] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

[9:19] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

[9:27] **+57 318 5358260:** [Imagen] 🎾🔥 ¡Hoy no hay excusas para quedarse en casa! Es el día perfecto para sacar la pala, reunir a tus amigos y disfrutar de un gran partido. 💪😎

🚨 ¡Aprovecha nuestra PROMO 2x1 en cancha! Paga 1 hora y juega 2. 🤩

¡Reserva ahora, arma tu parche y vive la mejor experiencia de pádel en Padel Town! 🎾💙

📲 ¡Te esperamos!

[14:49] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

---

## 5 de agosto de 2026

[8:08] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

[10:54] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian c
🎾 Oscar 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[11:03] __+57 312 4284273 añadió a +57 313 3675848__

[11:03] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 05 de Agoasto
🕘 5:30 p.m - 7:30 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon 
🎾 Marcos
🎾 Juan Carlos
🎾 Edgardo

NOS VEMOS EN LA CANCHA🔥🎾

[12:57] **+57 350 5786150:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian c
🎾 Oscar 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾_
Me apunto

[12:58] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian c
🎾 Oscar 
🎾 Omar R
🎾 

QUIEN SE ANIMA 🔥🎾

[13:19] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian c
🎾 Oscar 
🎾 Omar R
🎾 Nazlhy

NOS VEMOS EN LA CANCHA 🔥🎾

[18:30] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 7:30 p.m - 9:30 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian alfaro
🎾 Sebastian Vargas 
🎾 
🎾 

DOS PALAS MAS QUIEN SE ANIMA 🔥🎾

[18:33] **+57 350 4289994:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 7:30 p.m - 9:30 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian alfaro
🎾 Sebastian Vargas 
🎾 
🎾 

DOS PALAS MAS QUIEN SE ANIMA 🔥🎾_
Yo

[18:33] **+57 350 4289994:** Y Julián Henao

[18:36] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 7:30 p.m - 9:30 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian alfaro
🎾 Sebastian Vargas 
🎾 Juan G
🎾 Julian Henao  

NOS VEMOS EN CANCHA 🔥🎾

[18:48] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 7:30 p.m - 9:30 p.m
Categoría:  6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian alfaro
🎾 
🎾 Juan G
🎾 Julian Henao  

UNA PALA MAS QUIEN SE ANIMA🔥🎾

[19:44] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 5 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian alfaro
🎾 Reservado 
🎾 Juan G
🎾 Julian Henao  

NOS VEMOS EN CANCHA🔥🎾

---

## 6 de agosto de 2026

[9:18] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 6 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[9:42] **+57 322 9087633:** Hola buenos días

[15:53] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 6 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

---

## 7 de agosto de 2026

[9:19] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 7 AGOSTO
🕘 4:00 p.m - 6:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[12:24] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 7 AGOSTO
🕘 4:00 p.m - 6:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[12:24] **+57 316 8070239:** _Se eliminó este mensaje_

[14:12] **+57 318 5358260:** [Imagen] Buenas tardes familia PadelTown🎾🧡.

🔥🎾 ¡CLASE ESPECIAL DE PÁDEL – CATEGORÍA 6TA! 🎾🔥
¿Quieres mejorar tu técnica, competir y disfrutar aún más la cancha? 💪😎
¡Esta clase es para ti! 🚀
🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Camila
🎾 Juan
🎾
🎾
🎾
🎾

[15:45] **+57 318 5358260:** [Imagen] 🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Camila
🎾 Juan
🎾 Gustavo
🎾 Angelica
🎾
🎾

[15:46] **+57 318 5358260:** [Imagen] 🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾
🎾

[15:47] **+57 318 5358260:** [Imagen] 🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian A
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾 Sebastian P
🎾

[16:09] **+57 310 2192130:** Alguna pareja para partido quinta - cuarta? apostemos la cancha

[16:51] **+57 316 4600939:** Algun partido de 5ta a las 7?

[16:52] **+57 314 2854357:**
> _+57 310 2192130: Alguna pareja para partido quinta - cuarta? apostemos la cancha_
Para cuando

[16:52] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 7 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Diego
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[16:52] **+57 316 4600939:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 7 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Diego
🎾 Fredy 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[17:19] **+57 310 2578035:** Voy

[17:19] **+57 318 5358260:** UNA PALA MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 7 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Diego
🎾 Fredy 
🎾 Enrique
🎾 

QUIEN SE ANIMA 🔥🎾

[17:28] **+57 316 4600939:** UNA PALA MAS FAMILIA 

🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 7 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 Enrique
🎾 

QUIEN SE ANIMA 🔥🎾

[17:31] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 7 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[19:44] **@DavidRojas12:** _Se eliminó este mensaje_

[19:44] **@DavidRojas12:** _Se eliminó este mensaje_

[20:04] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

[21:13] **Jaime X Comentarios Ignorar Lozano:** _Se eliminó este mensaje_

---

## 8 de agosto de 2026

[8:51] **+57 318 5358260:** 🎾 ¡Buenos días, Familia PadelTown🎾

Hoy es un buen día para salir de la rutina, coger la pala y disfrutar un buen partido. 🔥💪

Tenemos

🎾 Partidos abiertos
🏆 Clases y academia
🍿 Snacks para acompañar
💪 ¡Diversión asegurada!

¡Arma tu partido y nos vemos en cancha! 🎾💙

[8:52] **+57 318 5358260:** [Imagen] 🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
¿uno más quien se anima?😄
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian A
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾 Sebastian P
🎾

[12:24] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 8 AGOSTO
🕘 3:00 p.m - 5:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo Villamizar
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[14:41] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

[16:02] **+57 318 5358260:** [Imagen] ULTIMO CUPO PARA NUESTRA CLASE 🎾.

🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
¿uno más quien se anima?😄
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian A
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾 Sebastian P
🎾

[16:11] **@arturov.00:**
> _+57 318 5358260: Imagen: ULTIMO CUPO PARA NUESTRA CLASE 🎾.

🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
¿uno más quien se anima?😄
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian A
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾 Sebastian P
🎾_
Yo

[16:11] **+57 318 5358260:** [Imagen] 🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
¿uno más quien se anima?😄
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian A
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾 Sebastian P
🎾 Arturo

[18:15] **+57 318 5358260:** [Imagen] Un cupo mas familia 

🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
¿uno más quien se anima?😄
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian A
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾 Arturo
🎾

[21:48] **+57 318 5358260:** [Imagen] 🔥 CUPOS LIMITADOS 🔥
No te quedes por fuera, reserva tu cupo y ven a jugar, aprender y superarte con PadelTown Nomad Salitre.
¿uno más quien se anima?😄
📲 Inscripciones: 318 535 8260
¡Nos vemos en la cancha! 🧡🎾

🎾 Sebastian A
🎾 Juanita
🎾 Gustavo
🎾 Angelica
🎾 Arturo
🎾 Jesus

---

## 9 de agosto de 2026

[7:50] **+57 318 5358260:** @all Buenos Dias Familia PadelTown🎾🧡

Para nuestros participantes de la clase de hoy de 6ta, les recordamos su puntualidad para dar inicio a las 9:00 am y sacarle el mayor provecho a la clase.

Vamos con toda🔥🔥

[9:35] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

[11:48] **+57 320 9790901:** _Un admin., +57 318 5358260, eliminó este mensaje._

[16:30] __+57 311 6758920 se unieron mediante el enlace de invitación__

---

## 10 de agosto de 2026

[14:11] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[14:16] **@Santyamen:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Lisa 
🎾 Santiago 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[14:17] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Lisa 
🎾 Santiago 
🎾 
🎾 

DOS PALAS MAS, QUIEN SE ANIMA 🔥🎾

[16:45] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Lisa 
🎾 Santiago 
🎾 Jhoan Robles 
🎾 

UNA PALAS MAS, QUIEN SE ANIMA 🔥🎾

[17:06] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Lisa 
🎾 Santiago 
🎾 Jhoan Robles 
🎾 

UNA PALAS MAS, QUIEN SE ANIMA 🔥🎾

[17:16] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 10 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 Jhoan Robles 
🎾 

UNA PALAS MAS, QUIEN SE ANIMA 🔥🎾

---

## 11 de agosto de 2026

[10:38] **+57 312 4284273:** _Se eliminó este mensaje_

[10:38] **+57 312 4284273:** _Se eliminó este mensaje_

[10:38] **+57 312 4284273:** _Se eliminó este mensaje_

[10:38] **+57 312 4284273:** _Se eliminó este mensaje_

[10:38] **+57 312 4284273:** _Se eliminó este mensaje_

[11:31] **+57 318 5358260:** Buen dia Sebastian, ya te ayudamos por interno

---

## 12 de agosto de 2026

[10:07] **+57 318 5358260:** [Imagen] 🎾🔥 ¡HOY ES DÍA DE JUGAR!

No dejes pasar nuestra promo 2x1 en cancha 😎🙌
👉 Paga 1 hora y juega 2.

Reúne a tus amigos, arma el partido y disfruta el pádel al máximo. 💥🎾

📲 ¡Reserva tu cancha y aprovecha la promo! 🔥

---

## 13 de agosto de 2026

[10:58] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[11:32] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Oscar 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[11:34] **@Santyamen:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Oscar 
🎾 Santiago
🎾 

QUIEN SE ANIMA 🔥🎾

[13:06] **@Santyamen:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Oscar 
🎾 Santiago
🎾 

QUIEN SE ANIMA 🔥🎾

[13:07] **@marlon.iragorri:**
> _@Santyamen: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Oscar 
🎾 Santiago
🎾 

QUIEN SE ANIMA 🔥🎾_
Yo 👏🏼

[13:08] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 13 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Oscar 
🎾 Santiago
🎾 Marlon

NOS VEMOS EN LA CANCHA  🔥🎾

[17:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 13 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian A 
🎾  
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

---

## 14 de agosto de 2026

[7:57] **+57 318 5358260:** [Imagen] 🔥🎾 ¡HOY SE JUEGA PÁDEL! 🎾🔥

No lo pienses tanto… reúne a tus amigos, toma tu pala y ven a disfrutar un partidazo en PadelTown 😎💪

🏆 Partidos abiertos
🎾 Clases 
🔥 Canchas disponibles
🍻 Snacks y buena energía

¡La cancha te está esperando! 😏🎾 ¿Quién se apunta?

[12:08] **+57 318 5358260:** _Se eliminó este mensaje_

[12:46] **+57 318 5358260:** _Se eliminó este mensaje_

[12:47] **+57 318 5358260:** [Imagen] ¿Quieres mejorar tu nivel y disfrutar de un buen partido? 💪😎 Únete a nuestra clase de categoría 5ta – 6ta y lleva tu juego al siguiente nivel.

🎾
🎾
🎾
🎾

🔥 ¡Cupos limitados! Reserva el tuyo y ven a disfrutar, entrenar y competir con nosotros. 🧡🖤

¡Nos vemos en la cancha! 🎾🔥

[15:14] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 14 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo
🎾  
🎾 
🎾 

3 PALAS MAS 🔥🎾

---

## 15 de agosto de 2026

[7:12] **+57 318 5358260:** [Imagen] ¿Quieres mejorar tu nivel y disfrutar de un buen partido? 💪😎 Únete a nuestra clase de categoría 5ta – 6ta y lleva tu juego al siguiente nivel.

🎾 Sebastian A
🎾
🎾
🎾

🔥 ¡Cupos limitados! Reserva el tuyo y ven a disfrutar, entrenar y competir con nosotros. 🧡🖤

¡Nos vemos en la cancha! 🎾🔥

[12:01] **+57 318 5358260:** [Imagen]

---

## 16 de agosto de 2026

[10:20] **+57 310 5691636:** me regalan la direccion exacta de nomad

[10:20] **+57 310 5691636:** porfa

[10:25] **+57 318 5358260:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMCBAEFBwYI/8QANxAAAgEDAQYEAwcCBwAAAAAAAQIDAAQRBRIhMUFRYQYTInEyQlIHFIGhscHRM+EjJENicpHw/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwUEBv/EACsRAAIBAwIDBgcAAAAAAAAAAAABEQIDMQQFEiFBBhQiUWHREyQyQkOBsf/aAAwDAQACEQMRAD8A+m6VcSJHCxkAI4Y69qYxCgknAG8mqCA3s+2w/wAFOAPOmgbExxSxKtwEBX6e1SZdqMtbljATmSIcR7VtKpT2zI/m23pYcV605knhgZGQqB4PXCeKjl7fxT0ZXUMpBB51r4nLOZLcBZfniPBvbvThMmPNhOGJw0Z4k/zQ0NMuUuaVYYy7ncPz7VKRxGhds4AzuGa89rWqiytLm8eNbm4t4Dcx2CSgSvGD6mA4nAzy34xSSkbcCvFmqz6PosuqPCGfbWKIyKTFAWOBJKRvCDiTXkbzStV1TxDNb6lb2sl1PEjXBG2thqlopGHBGTDNHkEEHpjINUYdJ1V/Fk1/Bpr37XTSXFjfxqWt7qKY+n7y+0CI0QgeUB6sV1jSNMtdG05NP08SLaRsxRHcvsgknZGflGcAchVtwQlJr9J0218O+bHb/epI53Be5uJmnkc4AALMSdkAYArdqwdQykFTwIqu6iJSjjat23b/AJf7fpSYYUWXZnRct8DYG/3I51BaLwIOcHhuNFIW0jGd8m853SMP3opDEXDtczeREfQPiarsaLGgVRgCl2sAgjxuLHiadTbEl1CiiikMrXNqJTtp6ZRwPWvEeIfHtjoF9NAYHvdRUBWjjIVY+zNv3+wP4V6/xHetpvh/Ur6PZ8y3tpJU2uBZVJH5ivl69uHiieZyZJWOSzHJZid5NePV6mq0lTTlnd2Ta7etqquXn4aenmdE8Rfabd6no91Bb291plxlHhltLgM3pYEqSVGAwyMjPLcRnO50V73xe0B1LRk1zSUlVLfWcCxu4ubMADkhTuJUrkjcDiuMafevPKY5AOGQRXa/sOvZ5bTU7Bnzb2zpKgO8gybQIHQZTPuT1rPSauuqv4dw9e8bNp7VjvOmlJZWf6dA8P6Rb6BotrpdnLPLb2wKo87hnILE4JAG4ZwO2K2NFFdA+XMceNU22AWiOTCPmH+mff8A9inSO0jmOI4x8T9Ow70xEVE2FA2elMWTXvqLW7eXNGdoc+o60UyQ28blLlQSPhJ+nlRTgUl+ilW86TplTv5g8RTakoKjI6xoWcgKOJod1jQs5AUDJJrUXM7XD5OQg+Ff3PemlIm4E6oq6nbzwXAP3eVGjKf7SMH8cGvnzW9Jm0u+n06/XLJwbG6ReTj3/I5HKvoVFaRwkYy55fua1Pj7wlHrPh6RrdNrVLZTLC4G9zjfH7HGB0OD1z5tbp1dolZR2Ni3Lud501/RVn09fc+foLaK22mQY3byTyrvP2TaFJoujSy3sbRX16VlaNhgrGB6Ae+8k9M45V4r7IfDses6m+qXabdnZMvlqRueYjIz/wARg46kdK7ZLGJAN+GG9WHEGvLobH5av0dTtFuKfydrCz7DKRI7SOY4jjHxP07DvUBJLJmIDZZTh3HD8O/6VYjRY0CqMAV08HyeQjRY0CqMAVKiikM1OqptXCnPyD9TRV97ZJGLSjaY8OWB0orRVwjN0NsVcWp2vNtzsyDfgc6zDeIQwmxG68c7hVl2VELOQFG8k1p7mX7xNt7OyoGAMbz3NSuZT8JK6uGuH5iMfCvXuaUitI4SMZc8v3NY4kAEAnrwHetva26wJ6TtMd7N1/tVNwQlxMLW3W3TA3ufibrT6KKzNSjpGk2Oj2z2+mWyW8LyNKyrnezcTvqzIWZvLjyOrdB2702ihJLA6qnU5qcsiiKihVGAKlRRQIKKKKACiiigDTXM7XD5ORGPhX9zUI0aRwkYyx/LuaI0aWQJGMsefIDqa21tAkCYXeTxY8TWjcGaXFzZCOziWEoRtE7y3PNIzLZHDZeDkelbCsEAggjIPI1ElwRjdZEDIcg1OqMkEluxktsleacasW1wk65XcRxHShoE/MdRRRSGFYJABJOAKwzKoyxAHDfSB/mTk/0Adw+vv7UATt5TKpJUgZ9J+odanI6xoWc4AokkSMEuwGBmlxo0jCWUYx8CfT3PegCv5VzKS6zNGCfg6flRV+igIFW8CQR7Kbyd5J4k02iigAooqld3DFvJt8s54kcqaUg3Bm6uGLeTBvkO4kcqzFbG3QMh2pPmHJh0qGmmMAjhNzz+1Xqb5ciVz5kY3WRQynINSqIRQxYKAx4nHGs1JRXdfvMjo39FDgj6j/FOJWKPLHCqOJpFi+1GwwchjtE8yTn+KksbvLmcgqpygHD3PegDAiM7LLKCuDlF5jue9WaKi7BFLMQFG8k0AZJA4kUVWInm9aFY1PAMmTjr2ooFJaooooGVdQkaOEbBwWOM1mwiVIEcD1MASaKKroT9wrUY1VRMuVkBAyKsWcjS26O+No54e9FFLoCyOrGfUB2NFFIoSfTerj50JP4EY/Wn0UUAFUoXNzPiTGygDADhnJ3n/qiigTLtFFFAz//Z: Ubicación: 4.6430046, -74.1116001 — https://maps.google.com/?q=4.6430046,-74.1116001

[11:54] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 5:00 p.m - 7:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sergio
🎾 Sebastian   
🎾 
🎾 

2 PALAS MAS FAMILIA  🔥🎾

[11:55] **@arturov.00:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 5:00 p.m - 7:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sergio
🎾 Sebastian   
🎾 
🎾 

2 PALAS MAS FAMILIA  🔥🎾_
Voy

[11:55] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 5:00 p.m - 7:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sergio
🎾 Sebastian   
🎾 Arturo
🎾 

1 PALAS MAS FAMILIA  🔥🎾

[12:02] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 5:00 p.m - 7:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sergio
🎾 Sebastian   
🎾 Arturo
🎾 

1 PALAS MAS FAMILIA  🔥🎾_
🙋🏻‍♂️

[12:02] **+57 318 5358260:** 🔥PARTIDO CERRADO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 5:00 p.m - 7:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sergio
🎾 Sebastian   
🎾 Arturo
🎾 Marlon

NOS VEMOS EN LA CANCHA  🔥🎾

[12:03] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Camilo
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[12:26] **+57 310 2578035:** Voy

[12:29] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Camilo
🎾 Enrique
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[12:45] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 16 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Camilo
🎾 Enrique
🎾 Felipe
🎾 

QUIEN SE ANIMA 🔥🎾

---

## 18 de agosto de 2026

[8:21] **+57 318 5358260:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 AGOSTO
🕘 5:00 p.m - 7:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[11:01] **+57 311 5915669:** 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 AGOSTO
🕘 5:00 p.m - 7:00 p.m
*Categoría:  4 o 5 alta
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO


🎾 
🎾 

QUIEN SE ANIMA 🔥🎾

[11:14] **+57 314 2854357:**
> _+57 311 5915669: 🔥PARTIDO ABIERTO

📍 Pádel Town Nomad  
📆 18 AGOSTO
🕘 5:00 p.m - 7:00 p.m
*Categoría:  4 o 5 alta
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO


🎾 
🎾 

QUIEN SE ANIMA 🔥🎾_
8 pm

[11:15] **+57 314 2854357:** Puedo

[16:03] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 18 AGOSTO
🕘 8:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel Aljure 
🎾 
🎾 
🎾 

Partido abierto. tres pala mas¡¡🔥🏓

[17:18] **+57 318 5358260:** _Se eliminó este mensaje_

[17:18] __+57 318 5358260 añadió a +57 300 6258821__

[19:12] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 18 AGOSTO
🕘 9:00 p.m - 10:00 p.m
Categoría:  5TA - 6TA
Cancha: 2 
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Daniel 
🎾 
🎾 
🎾 

Partido abierto¡¡🔥🏓

---

## 19 de agosto de 2026

[9:15] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 19 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis Esquivel
🎾 
🎾 
🎾 

QUIEN SE ANIMA🎾🔥

[11:44] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 19 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis Esquivel
🎾 
🎾 
🎾 

QUIEN SE ANIMA🎾🔥

[15:23] **+57 318 5358260:** [Video] 🔥TORNEO  – Mac Center Padel Cup🔥

Parejas fijas- Round Robin

📅 Jueves 20 de agosto
⏰ 5:30 PM a 09:30 PM
💸 Inscripción: $110.000 por persona (SIN MEMBRESÍA)

🟠 Miembros Orange: 20% DCTO
⚫ Miembros Black: 30% DCTO
🟣 Por compras entre el 10 y el 20 de agosto en Mac Center: 20% DCTO

🏆 Categoría: 5TA y 6TA

✅ INCLUYE:

🎾 Pala
🎾 Pelotas
🎾 Organización
📺 Transmisión en vivo 

🏆 PREMIOS
🥇 2 Parlantes JBL CLIP 5
🥈 1 hora de cancha gratis (hora valle)

✍️ INSCRÍBETE AQUÍ

🎾 Esteban-Carlos
🎾 Paola - Andrés 
🎾 Juan David- Vanessa
🎾 
🎾 
🎾 
🎾 
🎾  
🎾 
🎾 
🎾 
🎾

 🔥 Torneo o miedo🎾

[15:25] **+57 318 5358260:** Se viene un super torneo en Padeltown Plaza Claro se trata del Mac Center Padel Cup, que esperas para jugar y competir con los mejores, inscribete aqui ☝🏻🔥🏆

[18:19] **+57 318 5358260:** [Imagen] No te quedes sin tu cupo,para mas informacion: 3105691636 📍☝🏻

[18:35] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 19 AGOSTO
🕘 8:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian A 
🎾  Sebas B
🎾  Juanita  
🎾 

Partido abierto, 1 pala mas¡¡🏓🔥

[18:36] **Jaime X Comentarios Ignorar Lozano:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 19 AGOSTO
🕘 8:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian A 
🎾  Sebas B
🎾  Juanita  
🎾 

Partido abierto, 1 pala mas¡¡🏓🔥_
Voy

[18:39] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 19 AGOSTO
Cancha: 3 
🕘 8:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian A 
🎾  Sebas B
🎾  Juanita  
🎾  Jaime 

Partido cerrado🏓🔥

---

## 20 de agosto de 2026

[10:25] **+57 318 5358260:** 🔥PARTIDO CERADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 20 AGOSTO
🕘 5:00 p.m - 7:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Edgardo 
🎾 Marlon   
🎾 Santiago    
🎾 Marco 

NOS VEMOS EN CANCHA¡🏓🔥

[10:43] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 20 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾  
🎾 

PARTIDO QUIEN SE ANIMA¡¡🏓🔥

[12:34] **@gdanderino:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 20 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾  
🎾 

PARTIDO QUIEN SE ANIMA¡¡🏓🔥_
Yo

[12:36] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 20 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Gustavo 
🎾 
🎾  
🎾 

QUIEN SE ANIMA¡¡🏓🔥

[16:52] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 20 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Gustavo 
🎾 Julian R
🎾  
🎾 

QUIEN SE ANIMA¡¡🏓🔥

[17:34] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 20 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Gustavo 
🎾 Julian R
🎾  
🎾 

QUIEN SE ANIMA DOS PALAS MAS¡¡🏓🔥

---

## 21 de agosto de 2026

[10:23] **+57 318 5358260:** _Se eliminó este mensaje_

[11:27] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 21 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Rios 
🎾 
🎾  
🎾 

QUIEN SE ANIMA ¡¡🏓🔥

[13:03] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 21 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Rios 
🎾 
🎾  
🎾 

QUIEN SE ANIMA ¡¡🏓🔥

[14:39] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 21 AGOSTO
🕘 4:30 p.m - 6:30 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo 
🎾 
🎾  
🎾 

QUIEN SE ANIMA ¡¡🏓🔥

[15:53] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 21 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Rios 
🎾 Arturo 
🎾  
🎾 

QUIEN SE ANIMA ¡¡🏓🔥

---

## 22 de agosto de 2026

[8:47] **+57 318 5358260:** [Imagen]

[10:31] **+57 318 5358260:** 🔥PARTIDO CERADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 4:00 p.m - 6:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Edgardo 
🎾 Marlon   
🎾 Juan Carlos    
🎾 Marco 

NOS VEMOS EN CANCHA¡🏓🔥

[15:26] **+57 310 2578035:** _Se eliminó este mensaje_

[16:04] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 21 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Rios 
🎾 Arturo 
🎾  
🎾 

QUIEN SE ANIMA ¡¡🏓🔥_
yo

[16:26] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Rios 
🎾 Arturo 
🎾  Marlon 
🎾 

QUIEN SE ANIMA ¡¡ 1 pala mas 🏓🔥

[16:27] **+57 310 2578035:** Esta mal la fecha 
Será para hoy 22 ?

[16:28] **+57 318 5358260:**
> _+57 310 2578035: Esta mal la fecha 
Será para hoy 22 ?_
Si señor para hoy 22 de Agosto

[16:28] **+57 310 2578035:** Voy

[16:29] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique A 
🎾 Marlon 
🎾
🎾 

QUIEN SE ANIMA ¡¡ 2 palas mas 🏓🔥

[16:30] **@arturov.00:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique A 
🎾 Marlon 
🎾
🎾 

QUIEN SE ANIMA ¡¡ 2 palas mas 🏓🔥_
Yo

[16:31] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique A 
🎾 Marlon 
🎾 Arturo Villamizar 
🎾 

QUIEN SE ANIMA ¡¡ 1 palas mas 🏓🔥

[17:15] **+57 312 4284273:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique A 
🎾 Marlon 
🎾 Arturo Villamizar 
🎾 

QUIEN SE ANIMA ¡¡ 1 palas mas 🏓🔥_
Yo 👆🏼

[17:16] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique A 
🎾 Marlon 
🎾 Arturo Villamizar 
🎾 Sebastian R

Nos vemos en la cancha 🏓🔥

[18:00] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 21 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Rios 
🎾 Arturo 
🎾  
🎾 

QUIEN SE ANIMA ¡¡🏓🔥_
Este sigue.?

[18:00] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian Rios 
🎾 Arturo 
🎾  Marlon 
🎾 

QUIEN SE ANIMA ¡¡ 1 pala mas 🏓🔥_
Sigue.?

[18:02] **+57 318 5358260:** Si señor ya se cerro el partido para las 7

[18:02] **@marlon.iragorri:** Aa bueno gracias

[18:03] **+57 318 5358260:** Nos vemos a las 7 🏓

[18:57] **@arturov.00:**
> _+57 318 5358260: 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 22 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Enrique A 
🎾 Marlon 
🎾 Arturo Villamizar 
🎾 Sebastian R

Nos vemos en la cancha 🏓🔥_
Llego 5 tarde

---

## 23 de agosto de 2026

[10:54] **+57 310 5691636:** _Un admin., +57 318 5358260, eliminó este mensaje._

[10:55] **+57 310 5691636:** _Un admin., +57 318 5358260, eliminó este mensaje._

[13:29] **+57 318 5358260:** [Imagen]

[15:55] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo Villamizar 
🎾 Sebastian 
🎾 
🎾  

DOS PALAS MAS, QUIEN SE ANIMA 🏓🔥

[15:56] **@jesus_danielg:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo Villamizar 
🎾 Sebastian 
🎾 
🎾  

DOS PALAS MAS, QUIEN SE ANIMA 🏓🔥_
Voy!

[15:57] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo Villamizar 
🎾 Sebastian 
🎾 Jesus D. 
🎾  

UNA PALAS MAS, QUIEN SE ANIMA 🏓🔥

[15:57] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo Villamizar 
🎾 Sebastian 
🎾 Jesus D. 
🎾  

UNA PALAS MAS, QUIEN SE ANIMA 🏓🔥_
Se puede de 8:30 a 10:30.?

[17:37] **+57 313 6659489:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo Villamizar 
🎾 Sebastian 
🎾 Jesus D. 
🎾  

UNA PALAS MAS, QUIEN SE ANIMA 🏓🔥_
Jesús Villamizar

[17:43] **+57 318 5358260:** 🔥PARTIDO CARRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Arturo Villamizar 
🎾 Sebastian 
🎾 Jesus D. 
🎾  Jesus Villamizar

NOS VEMOS EN CANCHA  🏓🔥

[18:05] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:30 p.m - 9:30 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Julian  
🎾 
🎾  
🎾  

PARTIDO ABIERTO, tres palas mas 🔥 🏓

[19:12] **@marlon.iragorri:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 7:30 p.m - 9:30 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Julian  
🎾 
🎾  
🎾  

PARTIDO ABIERTO, tres palas mas 🔥 🏓_
De 8:30 a 10:30

[19:12] **@marlon.iragorri:** O de 8 a 10

[19:12] **@marlon.iragorri:**
> _@marlon.iragorri: De 8:30 a 10:30_
Nos inscribiríamos 2

[19:23] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 23 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon  
🎾 Partner  
🎾  
🎾  

PARTIDO ABIERTO, dos  palas mas 🔥 🏓

---

## 25 de agosto de 2026

[7:53] **+57 318 5358260:** 🎾🔥 ¡Buenos días, familia PadelTown! 🔥🎾

¡Hoy es un excelente día para sacar la pala y darle con toda! 💪😎

Tenemos *canchas, clases y partidos abiertos* para que armes tu plan y disfrutes del mejor pádel. 🏆🎾

👉 ¿Quién se apunta a jugar hoy? ¡Los esperamos! 🔥

[9:19] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 25 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon  (MAIQ)
🎾 Felipe  
🎾  
🎾  

Dos palas mas... Vamos Vamos🔥 🏓

[9:57] **@Santyamen:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 25 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon  (MAIQ)
🎾 Felipe  
🎾  Santiago C
🎾  

Dos palas mas... Vamos Vamos🔥 🏓

[9:58] **@cristian_D_nustes:** Voy

[10:05] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 25 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon  (MAIQ)
🎾 Felipe  
🎾  Santiago C
🎾  Cristian Ñ

Los esperamos🔥 🏓

---

## 26 de agosto de 2026

[7:27] **+57 318 5358260:** 🎾🔥 ¡Buenos días, familia PadelTown! 🔥🎾

¡Hoy es un excelente día para sacar la pala y darle con toda! 💪😎

Tenemos *canchas, clases y partidos abiertos* para que armes tu plan y disfrutes del mejor pádel. 🏆🎾

👉 ¿Quién se apunta a jugar hoy? ¡Los esperamos! 🔥

[8:18] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 26 AGOSTO
🕘 1:00 p.m - 3:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾   
🎾  
🎾 

Vamos Vamos ...🔥 🏓

---

## 27 de agosto de 2026

[8:31] **+57 318 5358260:** SOLO QUEDA UNA PALA FAMILIA 
🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 27 AGOSTO
🕘 4:30 p.m - 6:30 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 JOHAN 
🎾 DANIEL   
🎾 JULIAN
🎾 

QUIEN SE ANIMA??🔥

[9:27] **+57 350 4289994:** Yo 🙋🏻‍♂️

[9:34] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 27 AGOSTO
🕘 4:30 p.m - 6:30 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 JOHAN 
🎾 DANIEL   
🎾 JULIAN
🎾 JUAN

NOS VEMOS EN LA CANCHA🎾🔥

---

## 28 de agosto de 2026

[9:34] **+57 318 5358260:** SOLO QUEDAN DOS PALAS FAMILIA 
🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 28 AGOSTO
🕘 3:00 p.m - 5:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jorge
🎾 Mateo 
🎾
🎾 

QUIEN SE ANIMA??🔥

[13:07] **+57 318 5358260:** SOLO QUEDAN DOS PALAS FAMILIA 
🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 28 AGOSTO
🕘 3:00 p.m - 5:00 p.m
Categoría:  5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jorge
🎾 Mateo 
🎾
🎾 

QUIEN SE ANIMA??🔥

[14:53] **+57 318 5358260:** 🎾🔥 TORNEO AMERICANO – PADELTOWN CAT. 6ta🔥🎾 PLAZA CLARO

¡Este sábado se juega! 🧡

📅 Sábado 29 de agosto
⏰ 9:00 AM a 12:00 PM
🎾 Modalidad: Americano Individual
💰 Inscripción: $65.000 por persona

🎾 JUGADORES:
🎾 Fiorella
🎾Juan E de la Calle
🎾Gustavo D.
🎾
🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾

🏆 PREMIOS

🥇 1er puesto: Clase personalizada para 2 personas o 50% para ingreso en academia + 2 Gatorlit
🥈 2do puesto: 2 over grip + 2 Gatorlit
🥉 3er puesto: 2 Gatorlit 

¡Nos vemos en la cancha! ⚡️🎾🔥

[15:13] **+57 318 5358260:** 🎾🔥 TORNEO AMERICANO – PADELTOWN CAT. 6ta🔥🎾 PLAZA CLARO

¡Este sábado se juega! 🧡

📅 Sábado 29 de agosto
⏰ 9:00 AM a 12:00 PM
🎾 Modalidad: Americano Individual
💰 Inscripción: $65.000 por persona

🎾 JUGADORES:
🎾 Fiorella
🎾Juan E de la Calle
🎾Gustavo D.
🎾 Luis Esquivel 
🎾 
🎾 
🎾 
🎾 
🎾
🎾
🎾
🎾

🏆 PREMIOS

🥇 1er puesto: Clase personalizada para 2 personas o 50% para ingreso en academia + 2 Gatorlit
🥈 2do puesto: 2 over grip + 2 Gatorlit
🥉 3er puesto: 2 Gatorlit 

¡Nos vemos en la cancha! ⚡️🎾🔥

---

## 29 de agosto de 2026

[10:52] **+57 318 5358260:** _Se eliminó este mensaje_

[10:53] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 29 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis
🎾 
🎾
🎾 

QUIEN SE ANIMA??🔥

[15:01] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 29 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis
🎾 
🎾
🎾 

QUIEN SE ANIMA??🔥

[17:13] **+57 310 5536018:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 29 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis
🎾 
🎾
🎾 

QUIEN SE ANIMA??🔥_
Aun ESTA disponible Este partido

[17:54] **+57 350 4289994:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 29 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis
🎾 
🎾
🎾 

QUIEN SE ANIMA??🔥_
Juan y Julián

[18:03] **+57 318 5358260:** claro que si

[18:07] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 29 AGOSTO
🕘 7:00 p.m - 9:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis
🎾 Juan
🎾 Julian
🎾 

UNA PALA MAS ... VAMOS VAMOS 🔥

[18:35] **+57 318 5358260:** quien dijo yo chicos.. vamos

[18:46] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 29 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾
🎾 
🎾 

... VAMOS VAMOS ...

---

## 30 de agosto de 2026

[13:14] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 30 AGOSTO
🕘 6:00 p.m - 8:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Luis 
🎾
🎾 
🎾 

... VAMOS VAMOS ...

[16:54] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 30 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Nelson Vargas
🎾 Sebastian Vargas  
🎾 

... VAMOS VAMOS ...

[17:11] **@jesus_danielg:** _Se eliminó este mensaje_

[18:54] **+57 310 2578035:** Voy

[18:56] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 30 AGOSTO
🕘 8:00 p.m - 10:00 p.m
Categoría:  5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Juanita Rojas 
🎾 Nelson Vargas
🎾 Sebastian Vargas  
🎾 Enrique 

NOS VEMOS EN CANCHA 🎾🔥🔥

[19:42] __+57 320 4279193 añadió a +57 316 3747432__

[22:35] **+57 310 2578035:** Buenas noches

[22:40] __+57 305 3234838 añadió a +57 310 2329994__

[22:40] __+57 305 3234838 añadió a +57 311 2682229__

---

## 31 de agosto de 2026

[14:29] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 31 AGOSTO
🕘 6:30 p.m - 8:30 p.m
Categoría: 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾Oscar 
🎾 
🎾 

Vamos Vamos ...

[14:44] **+57 350 4289994:** 🙋🏻‍♂️

[14:49] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 31 AGOSTO
🕘 6:30 p.m - 8:30 p.m
Categoría: 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾Oscar 
🎾 Juan
🎾 

Una pala mas ...Vamos Vamos ...

[14:57] **+57 318 5358260:** **Encuesta: hacemos torneo americano ?**
- Si me gusta🔥
- No 😢

[15:08] **@arturov.00:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 31 AGOSTO
🕘 6:30 p.m - 8:30 p.m
Categoría: 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾Oscar 
🎾 Juan
🎾 

Una pala mas ...Vamos Vamos ..._
Voy

[15:10] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 31 AGOSTO
🕘 6:30 p.m - 8:30 p.m
Categoría: 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾Oscar 
🎾 Juan
🎾 Arturo

Los esperamos ...🔥🔥🔥

[18:24] **+57 318 5358260:** ya van llegando nuestros jugadores de este gran partido 🔥🎾🔥🎾

[20:15] **+57 318 5358260:** 🚨 ATENCIÓN 🚨
A petición de ustedes...
En los próximos dias lanzaremos nuestro torneo americano.
🔥🔥🔥Todos atentos 🔥🔥🔥

---

## 1 de septiembre de 2026

[14:20] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

VAMOS VAMOS ...🔥🔥🔥

[14:31] **@rojasandresfe:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

VAMOS VAMOS ...🔥🔥🔥_
Me apunto 🙋🏻‍♂️

[14:32] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Andres
🎾 
🎾 
🎾 

VAMOS VAMOS ...🔥🔥🔥

[14:41] **@DavidRojas12:** Me apunto ☝️

[14:42] **@DavidRojas12:**
> _@DavidRojas12: Me apunto ☝️_
David Rojas

[14:46] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Andres
🎾 David
🎾 
🎾 

Dos palas mas ...VAMOS VAMOS ...🔥🔥🔥

[14:57] __+57 318 5358260 añadió a @_camilocasanova__

[16:07] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Andres
🎾 David
🎾 
🎾 

Dos palas mas ...VAMOS VAMOS ...🔥🔥🔥

[16:07] **+57 318 5358260:** vamos vamos chicos aun tenemos tiempo

[17:04] **@rojasandresfe:**
> _+57 318 5358260: vamos vamos chicos aun tenemos tiempo_
🫠

[17:06] **+57 312 4284273:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Andres
🎾 David
🎾 
🎾 

Dos palas mas ...VAMOS VAMOS ...🔥🔥🔥_
yo

[17:07] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Andres
🎾 David
🎾 Sebastian
🎾 

Una pala mas ...VAMOS VAMOS ...🔥🔥🔥

[17:51] **+57 318 5358260:** Quien dijo yo ??? ultimo cupo

[17:56] **@rojasandresfe:** [Sticker]

[18:10] **@arturov.00:**
> _+57 318 5358260: Quien dijo yo ??? ultimo cupo_
Yo

[18:11] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 1 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾Andres
🎾 David
🎾 Sebastian
🎾 Arturo

LOS ESPERAMOS🔥🔥🔥

[18:53] **+57 318 5358260:** ya van llegando nuestros jugadores de nuestro gran partido abierto del dia de hoy

[19:10] **+57 318 5358260:** Alguna pala para jugar hoy a las 8:00 pm ??

[19:10] **+57 318 5358260:** Quien dijo yo???

[19:14] **+57 318 5358260:** ya conseguimos ... a Jugar 🔥🔥🔥

---

## 2 de septiembre de 2026

[10:28] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 2 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

...VAMOS VAMOS ...🔥🔥🔥

---

## 3 de septiembre de 2026

[6:51] __+57 318 5358260 añadió a +507 6402-8892__

[12:28] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 3 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾
🎾 
🎾 
🎾 

...VAMOS VAMOS ...🔥🔥🔥

[19:35] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 3 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian
🎾 Juanita 
🎾 Juan Camilo
🎾 

...VAMOS VAMOS ...🔥🔥🔥

---

## 4 de septiembre de 2026

[7:44] **+57 318 5358260:** 🎾🔥 ¡Buenos días, familia PadelTown! 🔥🎾

¡Hoy es un excelente día para sacar la pala y darle con toda! 💪😎

Tenemos *canchas, clases y partidos abiertos* para que armes tu plan y disfrutes del mejor pádel. 🏆🎾

👉 ¿Quién se apunta a jugar hoy? ¡Los esperamos! 🔥

[7:45] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 4 SEPTIEMBRE 
🕘 1:00 p.m - 3:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾 
🎾 

...VAMOS VAMOS ...🔥🔥🔥

[17:12] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 4 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾  
🎾 
🎾 

...VAMOS VAMOS ...🔥🔥🔥

[17:15] **+57 318 5358260:** [Imagen]

[19:10] **+57 319 5820607:** Buenas una pregunta hay posibilidad para sacar un partido de 8 a 10 pm? Ya somos 3 Sebastian, Carlos y Sergio y nos faltaria 1 persona.

[19:12] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 4 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾  Carlos 
🎾 Sergio  
🎾 

...VAMOS VAMOS ...🔥🔥🔥

[19:38] **@Josebrm:**
> _+57 318 5358260: 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 4 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾  Carlos 
🎾 Sergio  
🎾 

...VAMOS VAMOS ...🔥🔥🔥_
Me animo!

[19:40] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 4 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾  Carlos 
🎾 Sergio  
🎾  Jose

...VAMOS VAMOS ...🔥🔥🔥

[20:08] **+57 318 5358260:** UNA PALA MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 4 SEPTIEMBRE 
🕘 8:30 p.m - 10:30 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Sergio  
🎾  Jose
🎾
...VAMOS VAMOS ...🔥🔥🔥

---

## 5 de septiembre de 2026

[11:44] **+57 318 5358260:** DOS PALAS MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 5 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Arturo 
🎾  
🎾

...VAMOS VAMOS ...🔥🔥🔥

[14:19] __+57 310 8826053 se unieron mediante el enlace de invitación__

[14:26] **+57 318 5358260:** DOS PALAS MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 5 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Arturo 
🎾  
🎾

...VAMOS VAMOS ...🔥🔥🔥

[16:18] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 5 SEPTIEMBRE 
🕘 5:00 p.m - 7:00 p.m
Categoría: femenino /mixto - categoría D\C
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Jessica 
🎾 
🎾  
🎾

...VAMOS VAMOS ...🔥🔥🔥

[16:32] **@arturov.00:**
> _+57 318 5358260: DOS PALAS MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 5 SEPTIEMBRE 
🕘 7:00 p.m - 9:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Arturo 
🎾  
🎾

...VAMOS VAMOS ...🔥🔥🔥_
Dos más!!!

[17:49] **+57 318 5358260:** Vamos Vamos Dos palas mas... Quien dijo yo ??

[17:59] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 5 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾 
🎾  
🎾

...VAMOS VAMOS ...🔥🔥🔥

[20:27] __+57 318 5358260 añadió a +57 314 4800124__

[20:31] __@daniel_amaya610 añadió a +57 318 4938265 y +57 310 4207290__

---

## 6 de septiembre de 2026

[9:27] **+57 318 5358260:** [Imagen] 🎾🔥 ¡LA CANCHA TE ESTÁ ESPERANDO! 🔥🎾

¿Plan para jugar pádel? 😎 Es el momento perfecto para reunir a tus amigos, armar el partido y disfrutar al máximo.

🚨 PROMO 2x1 EN CANCHA 🚨
🔥 ¡Paga 1 hora y juega 2!

📅 Promoción válida hasta el 15 de septiembre

[11:59] **+57 318 5358260:** DOS PALAS MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 6 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Arturo 
🎾  
🎾

...VAMOS VAMOS ...🔥🔥🔥

[12:56] **+57 318 5358260:** _Se eliminó este mensaje_

[12:57] **+57 311 2682229:** _Un admin., +57 318 5358260, eliminó este mensaje._

[13:13] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 6 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Andres 
🎾 Jaime  
🎾  
🎾

...VAMOS VAMOS ...🔥🔥🔥

[13:44] **Jaime X Comentarios Ignorar Lozano:** Esperemos a ver q

[15:07] **+57 310 2578035:** Voy

[15:13] **+57 310 2578035:** El de 6

[15:14] **+57 318 5358260:** UNA PALAS MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 6 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Arturo 
🎾  Enrique 
🎾

...VAMOS VAMOS ...🔥🔥🔥

[15:25] **+57 313 6659489:**
> _+57 318 5358260: UNA PALAS MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 6 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Arturo 
🎾  Enrique 
🎾

...VAMOS VAMOS ...🔥🔥🔥_
Voy

[15:26] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 6 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Sebastian 
🎾 Arturo 
🎾  Enrique 
🎾 Jesus 

NOS VEMOS EN CANCHA🔥🔥🔥

---

## 7 de septiembre de 2026

[13:28] **+57 318 5358260:** 🎾🔥 *¡PADELTOWN YA ESTÁ ABIERTO!* 🔥🎾

¡Buenos días, familia! 🧡 Ya abrimos nuestras puertas y nuestras canchas están listas para ustedes. 🙌

¿Ya tienes tu partido? 😎🎾
📲 *Reserva tu cancha y ven a jugar con nosotros.*

¡Los esperamos en *PadelTown*! 🧡🔥

[13:29] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 7 SEPTIEMBRE 
🕘 4:00 p.m - 6:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾  
🎾  
🎾   
🎾  

NOS VEMOS EN CANCHA🔥🔥🔥

[13:34] **+57 318 5358260:** **Encuesta: Torneo americano este viernes 11 de septiembre?**
- SI, estoy que me juego 🎾🔥
- NO, mejor otro dia 😢😢

[13:34] **+57 318 5358260:** Con 8 confirmados lo lanzamos 💪🏻💪🏻

[13:52] **@edissriver:**
> _+57 318 5358260: [poll_creation]_
Qué categoría sería ?

[14:03] **+57 318 5358260:** Hola Eddison, seria categoria 5ta - 6ta

[14:07] **@johanbohorque:** Mixto

[14:08] **+57 322 9087633:** Mixto

[14:16] **+57 318 5358260:** Si señor

[14:45] **+57 350 5786150:** Cual seria el horario?

[14:48] **+57 318 5358260:** Hola Omar, seria en la noche ya lo vamos a lanzar todos atentos por favor

[14:59] **@edissriver:** _Se eliminó este mensaje_

[15:00] **+57 320 4279193:**
> _+57 318 5358260: Hola Omar, seria en la noche ya lo vamos a lanzar todos atentos por favor_
Si, en la noche sería mucho mejor 🙌🏼

[15:49] __+57 318 5358260 añadió a +57 314 3706094__

[16:40] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 7 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA-6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾  
🎾  
🎾   
🎾  

VAMOS.. VAMOS..🔥🔥🔥

[16:54] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 7 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾  Sebastian Alfaro 
🎾  Juanita 
🎾   
🎾  

DOS PALAS MAS..🔥🔥🔥

[17:55] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾

[17:56] **+57 322 9087633:**
> _+57 318 5358260: 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾_
no quedo mixto?

[17:57] **@johanbohorque:** Mixto parejas fijas 🙏🏻

[18:03] **@alejaortiz05:**
> _+57 318 5358260: 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾_
Masculino o femenino?

[18:10] **+57 350 5786150:** Me apunto

[18:13] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾

[18:20] **+57 318 5358260:** 🎾 ¡Hola, Familia PadelTown Nomad! 🧡

Pensando en nuestros jugadores que actualmente no cuentan con una pareja fija, hemos lanzado este torneo individual, para que todos puedan participar y disfrutar de la experiencia PadelTown Nomad. 🙌🔥

Además, estamos evaluando para la próxima semana un torneo de parejas mixtas fijas. 👩‍🦰👨‍🦱

🎾🔥!LOS ESPERAMOS¡🔥🎾

[19:18] **@Josebrm:**
> _+57 318 5358260: 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾_
Dos por aquí!

[19:24] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾

---

## 8 de septiembre de 2026

[9:19] **+57 318 5358260:** Buenos dias, ya iniciamos nuestra jornada... los esperamos

[10:17] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 8 SEPTIEMBRE 
🕘 4:00 p.m - 6:00 p.m
Categoría: 5TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾   
🎾   
🎾   
🎾  

VAMOS VAMOS..🔥🔥🔥

[12:55] **+57 318 5358260:** UNA PALA MAS FAMILIA

🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 8 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Oscar 
🎾 Sebastian 
🎾 Jorge
🎾  

VAMOS VAMOS..🔥🔥🔥

[13:54] **+57 318 5358260:** una pala mas... vamos vamos

[14:14] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 8 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Oscar 
🎾 Sebastian 
🎾 Jorge
🎾 Sebastian Parra 

Los esperamos..🔥🔥🔥

[14:19] **+57 318 5358260:** 🚨ALERTA🚨
Recuerden que tenemos torneo de 5ta y 6ta el viernes...
aun tenemos cupos..
...Inscribete ya...

[15:53] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 8 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Oscar 
🎾 Sebastian 
🎾 Jorge
🎾 

UNA PALA MÁS🔥🔥🔥

[16:15] __+57 311 2769632 se unieron mediante el enlace de invitación__

[17:10] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾

[17:16] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 8 SEPTIEMBRE 
🕘 6:00 p.m - 8:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Oscar 
🎾 Sebastian 
🎾 Jorge
🎾 Roberto 

NOS VEMOS EN CANCHA🔥🔥🔥

[17:24] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 8 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Yury
🎾 Andres
🎾 
🎾 

DOS PALAS MAS🔥🔥🔥

[18:32] **+57 318 5358260:** 🔥PARTIDO CERRADO🔥

📍 Pádel Town Nomad  
📆 Hoy: 8 SEPTIEMBRE 
🕘 8:00 p.m - 10:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Yury
🎾 Andres
🎾 Sebastian Alfaro
🎾Juanita  

NOS VEMOS EN CANCHA🔥🔥🔥

[18:32] **+57 322 9087633:**
> _+57 318 5358260: 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾_
Buena noche 
Paula, heiri, brayan, Sebastián por favor

[18:37] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾

[19:37] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾 Luis Esquivel 
🎾
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾

---

## 9 de septiembre de 2026

[8:25] **+57 318 5358260:** 🎾🧡 ¡Bienvenidos a PadelTown Nomad! 🧡

¡Ya abrimos! 🙌🔥
Ven a disfrutar, jugar y compartir con nosotros. 🎾

¡Te esperamos! 🧡

[9:02] **+57 310 8524199:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾 Luis Esquivel 
🎾Andres Chaves
🎾
🎾

Nos vemos en cancha 🔥🔥🎾🎾

[9:28] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾 Luis Esquivel 
🎾Andres Chaves
🎾
🎾
🎾
Ultimos tres cupos
Nos vemos en cancha 🔥🔥🎾🎾

[10:02] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 9 SEPTIEMBRE 
🕘 4:00 p.m - 6:00 p.m
Categoría: 5TA - 6TA
💰 Precio por jugador: 20.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 
🎾
🎾 
🎾  

...VAMOS VAMOS...🔥🔥🔥

[10:28] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾 Luis Esquivel 
🎾Andres Chaves
🎾Sebastian rios
🎾
🎾
Ultimos dos cupos
Nos vemos en cancha 🔥🔥🎾🎾

[10:32] **@cristian_D_nustes:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾 Luis Esquivel 
🎾Andres Chaves
🎾Sebastian rios
🎾Cristian Ñustes
🎾
Ultimos dos cupos
Nos vemos en cancha 🔥🔥🎾🎾

[10:33] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾 Luis Esquivel 
🎾Andres Chaves
🎾Sebastian rios
🎾Cristian Ñustes
🎾
Ultimo cupo familiaaa
Nos vemos en cancha 🔥🔥🎾🎾

[10:46] __+57 301 6966197 se unieron mediante el enlace de invitación__

[11:09] **+57 318 5358260:** 🏆 TORNEO AMERICANO individual MIXTO, 5ta - 6ta CATEGORÍA🏆🔥

🗓️  Viernes 11 de Sept de 7:00 pm - 10pm
📍 Padeltown Nomad Salitre

💰 Inscripción: $60.000 x  jugador
🟠 _MIEMBROS ORANGE: 20% OFF  
⚫ _MIEMBROS BLACK: 30% OFF
Incluye
Prestamo de palas y pelotas
🏆💸 PREMIOS💸🏆  
🥇 CAMPEÓN Gif card de $200.000
🥈 SUBCAMPEON Reserva gratis en hora valle (solo cancha)
🥉 Tercer Lugar Bebida

🎾 Omar Rojas
🎾 Ivan Aparicio 
🎾 Jose Bermudez 
🎾 Paula 
🎾 Heiri
🎾 Brayan 
🎾 Sebastian 
🎾 Luis Esquivel 
🎾Andres Chaves
🎾Sebastian rios
🎾Cristian Ñustes
🎾Marlon Iragorri
TORNEO COMPLETO
Nos vemos en cancha 🔥🔥🎾🎾

[11:09] __[Notificación del sistema]__

[11:14] **+57 318 5358260:** 🔥PARTIDO ABIERTO🔥

📍 Pádel Town Nomad  
📆 Hoy: 9 SEPTIEMBRE 
🕘 6:30 p.m - 8:30 p.m
Categoría: 5TA
💰 Precio por jugador: 30.000 
🟠 Miembros Orange ➝ 20% DCTO
⚫ Miembros Black ➝ 30% DCTO

🎾 Marlon
🎾
🎾 
🎾  

...VAMOS VAMOS...🔥🔥🔥
