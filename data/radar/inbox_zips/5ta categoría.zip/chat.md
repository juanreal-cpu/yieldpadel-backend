# Exportación de chat de WhatsApp: 5ta categoría
Fecha de exportación: 9 de septiembre de 2026 a las 16:17

---

## 25 de abril de 2025

[13:13] __+57 302 3414909 creó el grupo__

---

## 7 de septiembre de 2026

[13:01] __[Notificación del sistema]__

[13:36] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[15:29] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel G
🎾 sergio o
🎾 gerardo
🎾 santiago

Partido CERRADO 🔓

[16:48] **+57 301 7614700:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Juan Falla
🎾 Javier Barreto
🎾 
🎾 

Partido CERRADO 🔓

[16:48] **+57 315 5681335:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Juan Falla
🎾 Javier Barreto
🎾 Brandon
🎾 Alejandro

Partido CERRADO 🔓

[16:50] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Juan Falla
🎾 Javier Barreto
🎾 Brandon
🎾 Alejandro

Partido CERRADO 🔒

[21:03] __[Notificación del sistema]__

[21:12] __[Notificación del sistema]__

[21:15] __[Notificación del sistema]__

---

## 9 de septiembre de 2026

[7:19] **+57 301 1388105:** Miercoles 9 de septiembre 
 Categoría: 5ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Daniel G
🎾 
🎾 
🎾 

Partido Abierto 🔓

[8:17] **+57 301 1388105:** _Se eliminó este mensaje_

[12:14] **+57 318 2920893:** _Se eliminó este mensaje_

[13:03] **@cporrasy:**
> _+57 301 1388105: Miercoles 9 de septiembre 
 Categoría: 5ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Daniel G
🎾 
🎾 
🎾 

Partido Abierto 🔓_
Más tarde? Tipo 830pm?

[15:25] **+57 300 2883023:** Miercoles 9 de septiembre 
 Categoría: 5ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Daniel G
🎾 Daniel
🎾 Holman
🎾 

Partido Abierto 🔓

[15:36] **@nicolas.210:** Miercoles 9 de septiembre 
 Categoría: 5ta
🕣 5:30pm - 7:00pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Daniel G
🎾 Daniel
🎾 Holman
🎾 Nicolas E 

Partido Abierto 🔓
