# Exportación de chat de WhatsApp: SpinPadel Community
Fecha de exportación: 9 de septiembre de 2026 a las 16:18

---

## 11 de octubre de 2025

[6:41] __+57 301 1388105 creó el grupo__

---

## 7 de septiembre de 2026

[13:01] __[Notificación del sistema]__

[13:36] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[13:38] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 4ta
🕣 3:00pm - 4:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel
🎾 Diego
🎾 Camilo 
🎾 

Partido ABIERTO 🔓

[14:12] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel G
🎾 
🎾 
🎾 

Partido ABIERTO 🔓

[15:09] **+57 301 1388105:**
> _+57 301 1388105: Lunes 7 de septiembre 
 Categoría: 4ta
🕣 3:00pm - 4:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel
🎾 Diego
🎾 Camilo 
🎾 

Partido ABIERTO 🔓_
CHICOS ESTE JUEGO SI SE JUEGA

[15:14] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel G
🎾 sergio o
🎾 gerardo
🎾 

Partido ABIERTO 🔓

[15:23] **@santi.catam:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel G
🎾 sergio o
🎾 gerardo
🎾 santiago

Partido ABIERTO 🔓

[15:28] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Daniel G
🎾 sergio o
🎾 gerardo
🎾 santiago

Partido CERRADO 🔓

[16:07] **+57 301 1388105:** Lunes 7 de septiembre 
 Categoría: 5ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Juan Falla
🎾 Javier Barreto
🎾 
🎾 

Partido CERRADO 🔓

[16:43] __[Notificación del sistema]__

[21:03] __[Notificación del sistema]__

[21:12] __[Notificación del sistema]__

[21:15] __[Notificación del sistema]__

---

## 8 de septiembre de 2026

[9:10] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Samuel V
🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 

🎾 
🎾
🎾
🎾

TORNEO ABIERTO 🔓

[9:14] **+57 311 5388729:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Samuel V
🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 

🎾 Felipe R
🎾
🎾
🎾

TORNEO ABIERTO 🔓

[9:29] **+57 301 7614700:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Samuel V
🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 

🎾 Felipe R
🎾Juan falla 
🎾Javier Barreto
🎾

TORNEO ABIERTO 🔓

[9:31] **+57 301 1388105:** _Se eliminó este mensaje_

[9:31] **+57 311 6736961:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

TORNEO ABIERTO 🔓

[9:32] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 
🎾 
🎾 
🎾 

TORNEO ABIERTO 🔓

[9:37] **@esantiagomc:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 
🎾 
🎾 

TORNEO ABIERTO 🔓

[10:38] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Santiago
🎾 
🎾 
🎾 

Partido ABIERTO 🔓

[11:07] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Santiago
🎾 Cliff
🎾 
🎾 

Partido ABIERTO 🔓

[11:52] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 
🎾 

TORNEO ABIERTO 🔓

[13:21] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 3ra alta
🕣 4:30pm - 6:00pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Hermes
🎾 Víctor 
🎾 
🎾 

Partido ABIERTO 🔓

[13:28] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 3ra alta
🕣 4:30pm - 6:00pm
📍 Spin Pádel 
💸 30.000 c/u

🎾 Hermes
🎾 Víctor 
🎾 Monsalve
🎾 Santiago J

Partido CERRADO 🔒

[14:24] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 

TORNEO ABIERTO 🔓

[15:00] __[Notificación del sistema]__

[15:14] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 6:00pm - 8:30pm
📍 Spin Pádel 
💸 55.000 c/u
🏟️ Cancha estadio

🎾 Nicolás G
🎾 Pablo C
🎾 
🎾 

Partido ABIERTO 🔓

[15:16] **+57 301 1388105:** Martes 8 de septiembre 
 Categoría: 4ta
🕣 6:00pm - 8:30pm
📍 Spin Pádel 
💸 55.000 c/u
🏟️ Cancha estadio

🎾 Nicolás G
🎾 Pablo C
🎾 Camilo G
🎾 Cliff

Partido CERRADO 🔒

[16:18] **+57 301 1388105:** 🚨ULTIMO CUPO
🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 

TORNEO ABIERTO 🔓

[16:21] **@camilo.cruzh:** 🚨ULTIMO CUPO
🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 Sebastian R

TORNEO ABIERTO 🔓

[16:24] **+57 301 1388105:** 🏆 Americano Nocturno 6TA🏆
🗓️ MARTES 8 DE SEPTIEMBRE
🕘 9:00 pm a 11:00 pm
💰 $45.000
🥇 Próximo Americano Gratis

🎾 Camilo Cruz
🎾 Pablo V
🎾 Giussepe Gentile 
🎾 Felipe R

🎾Juan falla 
🎾Javier Barreto
🎾 carlos M 
🎾 Juan Lozano 

🎾 Santiago M
🎾 Víctor M 
🎾 Guiova 
🎾 Sebastian R

TORNEO CERRADO 🔒

---

## 9 de septiembre de 2026

[13:43] **+57 301 1388105:** Miercoles 9 de septiembre   
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro S
🎾 Nicolas M 
🎾 
🎾  

Partido Abierto 🔓

[14:15] **Alan Padel Shot Cuarta Torres:** Miercoles 9 de septiembre   
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro S
🎾 Nicolas M 
🎾 Alan
🎾  

Partido Abierto 🔓

[14:15] **@camilo.gm5:** Miercoles 9 de septiembre   
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro S
🎾 Nicolas M 
🎾 Alan
🎾  Camilo G

Partido Abierto 🔓

[14:16] **+57 301 1388105:** Miercoles 9 de septiembre   
 Categoría: 4ta
🕣 9:00pm - 10:30pm
📍 Spin Pádel 
💸 42.500 c/u

🎾 Alejandro S
🎾 Nicolas M 
🎾 Alan
🎾 Camilo G

Partido Cerrado 🔐
